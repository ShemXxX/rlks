<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 17.09.2018
 * Time: 18:58
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/header.php");

if (!defined('DBOARD')) {
    define('DBOARD', 'democontent2.board');
}

use Bitrix\Main\Loader;
use Bitrix\Main\IO\Path;
use Bitrix\Main\IO\Directory;
use Bitrix\Main\IO\InvalidPathException;
use Bitrix\Main\LoaderException;
use Bitrix\Main\Application;
use Bitrix\Main\ModuleManager;

try {
    if (Loader::includeModule(DBOARD)) {
        $router = new \Democontent2\Board\Router($_GET);
        $includeComponent = $router->getMap();

        if (!empty($includeComponent) && count($includeComponent) > 0) {
            try {
                if (Directory::isDirectoryExists(
                        Path::normalize(
                            Application::getDocumentRoot() . '/local/components/'
                            . ((isset($includeComponent['namespace'])) ? $includeComponent['namespace'] : DBOARD) . '/' . $includeComponent['component'])
                    )
                    || Directory::isDirectoryExists(
                        Path::normalize(
                            Application::getDocumentRoot() . '/bitrix/components/'
                            . ((isset($includeComponent['namespace'])) ? $includeComponent['namespace'] : DBOARD) . '/' . $includeComponent['component'])
                    )
                ) {
                    $APPLICATION->IncludeComponent(
                        ((isset($includeComponent['namespace'])) ? $includeComponent['namespace'] : DBOARD) . ":" . $includeComponent['component'],
                        ((isset($includeComponent['template'])) ? $includeComponent['template'] : '.default'),
                        ((isset($includeComponent['params']) && !empty($includeComponent['params'])) ? $includeComponent['params'] : [])
                    );
                } else {
                    $APPLICATION->IncludeComponent(DBOARD . ':404', '', []);
                }
            } catch (InvalidPathException $e) {
                \Democontent2\Board\ErrorLog::add(0, 'router', [__FILE__, __LINE__]);
                $APPLICATION->IncludeComponent(DBOARD . ':404', '', []);
            }
        } else {
            $APPLICATION->IncludeComponent(DBOARD . ':404', '', []);
        }
    } else {
        if (!ModuleManager::isModuleInstalled(DBOARD)) {
            if (function_exists('AddMessage2Log')) {
                AddMessage2Log(DBOARD . ' not loaded', DBOARD);
            }
        } else {
            if (function_exists('AddMessage2Log')) {
                AddMessage2Log(DBOARD . ' is not installed', DBOARD);
            }
        }
    }
} catch (LoaderException $e) {
    if (function_exists('AddMessage2Log')) {
        AddMessage2Log(DBOARD . ' not loaded. Exception: ' . strip_tags($e->getMessage()), DBOARD);
    }
}

require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/footer.php");