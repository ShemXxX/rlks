#!/bin/bash
JPEGOPTIM=`which jpegoptim`
FOLDER="/home/bitrix/www/upload/resize_cache"

if [ -z "JPEGOPTIM" ]; then
	yum install -y jpegoptim >/dev/null 2>&1
fi

jpegoptimize() {
cd "$FOLDER"
    find . -type f \( -name "*.jpeg" -or -name "*.jpg" \) -exec jpegoptim --strip-all --all-progressive --max=90 {} \;
}

jpegoptimize
