<?php
require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_before.php';
$rluksLoadedFromInit=class_exists('Rluks\\SellerLocation\\Location',false);
require_once $_SERVER['DOCUMENT_ROOT'].'/local/php_interface/rluks_seller_location/bootstrap.php';
use Rluks\SellerLocation\Location;
use Bitrix\Main\Config\Option;
global $USER;
header('Cache-Control: no-store, private');header('X-Robots-Tag: noindex, nofollow');
if(!$USER || !$USER->IsAuthorized()){http_response_code(403);die('Войдите в аккаунт.');}
function rlLocationJson(array $data,$status=200){http_response_code($status);header('Content-Type: application/json; charset=UTF-8');echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
function rlLocationFieldsReady(){
    $existing=[];$r=CUserTypeEntity::GetList([],['ENTITY_ID'=>'USER']);while($f=$r->Fetch())$existing[$f['FIELD_NAME']]=$f['USER_TYPE_ID'];
    foreach(Location::FIELDS as $key=>$type)if(($existing[$key]??'')!==$type)return false;return true;
}
$mode=isset($_GET['mode'])&&is_string($_GET['mode'])?$_GET['mode']:'';
$isPost=($_SERVER['REQUEST_METHOD']??'')==='POST';
$target=(int)$USER->GetID();
if(Location::admin())$target=(int)($_POST['user_id']??$_GET['user_id']??$target);
if($mode==='profile'){
    try{
        if(!rlLocationFieldsReady())throw new RuntimeException('Сначала установите поля местоположения.');
        Location::modules();$districts=Location::districts();$profile=Location::profile($target);
        rlLocationJson(['ok'=>true,'profile'=>$profile,'districts'=>array_values($districts),'token'=>Location::token(),
            'admin'=>Location::admin(),'editable'=>Location::admin()||!$profile['set'],
            'active'=>Location::enabled(),
            'mapKey'=>Option::get('democontent2.board','yandex_maps_api_key','')]);
    }catch(Throwable $e){rlLocationJson(['ok'=>false,'error'=>$e->getMessage()],400);}
}
if(!Location::admin()){http_response_code(403);die('Доступ только администратору.');}
$message='';
if($isPost){
    try{
        if(!Location::validToken($_POST))throw new RuntimeException('Форма устарела. Откройте страницу заново.');
        $action=$_POST['action']??'';
        if($action==='install'){
            $labels=['UF_RL_DISTRICT'=>'Район магазина (РЛАКС)','UF_RL_LAT'=>'Широта магазина (РЛАКС)',
                'UF_RL_LON'=>'Долгота магазина (РЛАКС)','UF_RL_ADDRESS'=>'Адрес магазина (РЛАКС)','UF_RL_LOC_SET'=>'Местоположение задано (РЛАКС)'];
            foreach(Location::FIELDS as $key=>$type){
                $existing=CUserTypeEntity::GetList([],['ENTITY_ID'=>'USER','FIELD_NAME'=>$key])->Fetch();
                if($existing){if($existing['USER_TYPE_ID']!==$type)throw new RuntimeException('Поле '.$key.' существует с другим типом.');continue;}
                $entity=new CUserTypeEntity();
                $settings=$type==='double'?['PRECISION'=>7,'DEFAULT_VALUE'=>0]:($type==='string'?['ROWS'=>2,'SIZE'=>50]:['DEFAULT_VALUE'=>0]);
                $added=$entity->Add(['ENTITY_ID'=>'USER','FIELD_NAME'=>$key,'USER_TYPE_ID'=>$type,'SORT'=>1000,'MULTIPLE'=>'N',
                    'MANDATORY'=>'N','SHOW_FILTER'=>'N','SHOW_IN_LIST'=>'Y','EDIT_IN_LIST'=>'N','IS_SEARCHABLE'=>'N',
                    'EDIT_FORM_LABEL'=>['ru'=>$labels[$key]],'LIST_COLUMN_LABEL'=>['ru'=>$labels[$key]],'SETTINGS'=>$settings]);
                if(!$added){global $APPLICATION;$error=$APPLICATION->GetException();throw new RuntimeException('Не создано поле '.$key.($error?': '.$error->GetString():''));}
            }
            $message='Поля установлены. Заполните местоположение существующих продавцов и затем включите доработку.';
        }elseif($action==='enable'){
            if(!rlLocationFieldsReady())throw new RuntimeException('Сначала установите поля.');
            if(!$rluksLoadedFromInit)throw new RuntimeException('Сначала подключите bootstrap.php в /local/php_interface/init.php и откройте страницу заново.');
            if(!CAgent::GetList([],['NAME'=>Location::AGENT])->Fetch()){
                if(!CAgent::AddAgent(Location::AGENT,'','N',60,'','Y'))throw new RuntimeException('Не удалось зарегистрировать агент.');
            }
            Option::set('main','rluks_location_enabled','Y');
            $message='Доработка включена. Новые запросы используют местоположение профиля.';
        }elseif($action==='disable'){
            Option::set('main','rluks_location_enabled','N');CAgent::RemoveAgent(Location::AGENT,'');
            $message='Доработка отключена для новых запросов; агент удалён. Сохранённые данные остаются в базе.';
        }elseif(in_array($action,['save','run','resync'],true)){
            if(!rlLocationFieldsReady())throw new RuntimeException('Сначала установите поля.');
            if(!Location::user($target))throw new RuntimeException('Пользователь не найден.');
            if($action==='save'){
                $data=Location::formData($_POST);$u=new CUser();
                if(!$u->Update($target,Location::fields($data)))throw new RuntimeException($u->LAST_ERROR);
                Location::queue($target);
            }elseif($action==='resync')Location::queue($target,true);
            $job=Location::runBatch($target,25);
            if(isset($_POST['ajax']))rlLocationJson(['ok'=>true,'job'=>$job]);
            $message=$job['status']==='done'?'Все товары продавца обновлены.':'Местоположение сохранено. Синхронизация продолжается ниже.';
        }else throw new RuntimeException('Неизвестное действие.');
    }catch(Throwable $e){if(isset($_POST['ajax']))rlLocationJson(['ok'=>false,'error'=>$e->getMessage()],400);$message='Ошибка: '.$e->getMessage();}
}
$ready=rlLocationFieldsReady();$job=$ready?Location::job($target):[];$user=Location::user($target);
?>
<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Местоположение продавца — РЛАКС</title>
<style>body{font:16px/1.5 system-ui,sans-serif;background:#f5f7fa;color:#243144;margin:24px}main{max-width:1000px;margin:auto}section,.notice{background:white;padding:20px;margin:18px 0;border:1px solid #dce2e9;border-radius:8px}button{font:inherit;padding:10px 18px;background:#075cbb;color:white;border:0;border-radius:5px;cursor:pointer}input,select{font:inherit;padding:8px;max-width:100%;box-sizing:border-box}a{color:#075cbb}.rluks-location-widget label{display:block;margin:12px 0 4px}.rluks-location-map{height:340px;width:100%;margin:16px 0}.rluks-coordinates{display:flex;gap:12px;flex-wrap:wrap}</style></head><body><main>
<h1>Местоположение продавца</h1>
<p>Состояние: <strong><?=Location::enabled()?'включена':'отключена (подготовка)'?></strong>. Подключение в init.php: <strong><?=$rluksLoadedFromInit?'обнаружено':'не обнаружено'?></strong>.</p>
<?php if($ready):?><form method="post"><input type="hidden" name="RL_TOKEN" value="<?=Location::escape(Location::token())?>"><button name="action" value="<?=Location::enabled()?'disable':'enable'?>"><?=Location::enabled()?'Отключить доработку':'Включить доработку'?></button></form><?php endif;?>
<?php if($message):?><p class="notice"><?=Location::escape($message)?></p><?php endif;?>
<?php if(!$ready || $mode==='install'):?>
<section><h2>Установка</h2><p>Будут добавлены пять полей пользователя. Агент синхронизации регистрируется отдельно при включении доработки.</p>
<form method="post"><input type="hidden" name="RL_TOKEN" value="<?=Location::escape(Location::token())?>"><input type="hidden" name="action" value="install"><button type="submit">Установить поля</button></form></section>
<?php endif;?>
<?php if($ready):?>
<form method="get"><label>ID продавца: <input type="number" min="1" name="user_id" value="<?=$target?>" required></label> <button type="submit">Открыть</button></form>
<?php if($user):?>
<section><h2><?=Location::escape(trim(($user['NAME']??'').' '.($user['LAST_NAME']??''))?:$user['LOGIN'])?> · ID <?=$target?></h2>
<p><a href="/bitrix/admin/user_edit.php?ID=<?=$target?>&amp;lang=ru" target="_blank" rel="noopener">Профиль пользователя в Битриксе</a></p>
<form method="post"><input type="hidden" name="action" value="save"><input type="hidden" name="user_id" value="<?=$target?>">
<div class="rluks-location-widget" data-mode="admin" data-user="<?=$target?>">Загрузка местоположения…</div>
<button type="submit">Сохранить и обновить все товары</button></form></section>
<section><h2>Обновление товаров</h2><p id="rluks-sync-status"><?php if($job):?>Обработано: <?=(int)$job['processed']?>. <?=Location::escape($job['status'])?> <?=Location::escape($job['error']??'')?><?php else:?>Задача пока не создана.<?php endif;?></p>
<form method="post"><input type="hidden" name="RL_TOKEN" value="<?=Location::escape(Location::token())?>"><input type="hidden" name="user_id" value="<?=$target?>"><button name="action" value="run">Продолжить</button> <button name="action" value="resync">Проверить все товары заново</button></form>
</section>
<?php endif;endif;?>
<p>Изменять местоположение после первой подачи может только администратор. При большом числе товаров обновление выполняется порциями; агент продолжит его при закрытии страницы.</p>
</main><script src="/local/assets/rluks_seller_location/location.js"></script>
<?php if($job && $job['status']==='pending'):?>
<script>
(function(){var status=document.getElementById('rluks-sync-status');function next(){var p=new URLSearchParams();p.set('action','run');p.set('ajax','1');p.set('user_id',<?=json_encode((string)$target)?>);p.set('RL_TOKEN',<?=json_encode(Location::token())?>);fetch(location.pathname,{method:'POST',credentials:'same-origin',body:p}).then(function(r){return r.json();}).then(function(r){if(!r.ok)throw new Error(r.error);status.textContent='Обработано: '+r.job.processed+'. '+(r.job.status==='done'?'Готово.':r.job.error||'Выполняется…');if(r.job.status==='pending')setTimeout(next,200);}).catch(function(e){status.textContent=e.message;});}next();})();
</script><?php endif;?></body></html>
