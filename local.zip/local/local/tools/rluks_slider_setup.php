<?php
require($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_before.php');
global $USER;
if (!is_object($USER) || !$USER->IsAdmin()) {
    http_response_code(403);
    exit('Доступ только для администратора.');
}
if (!\Bitrix\Main\Loader::includeModule('iblock')) { exit('Не установлен модуль iblock.'); }
$request = \Bitrix\Main\Context::getCurrent()->getRequest();
$rawId = $request->isPost() ? $request->getPost('IBLOCK_ID') : $request->getQuery('IBLOCK_ID');
$blockId = is_scalar($rawId) ? max(1, (int)$rawId) : 150;
$block = CIBlock::GetByID($blockId)->Fetch();
$messages = [];
$specs = [
    'MOBILE_PICTURE' => ['NAME' => 'Изображение для телефона', 'PROPERTY_TYPE' => 'F', 'FILE_TYPE' => 'jpg,jpeg,png,webp,gif,avif'],
    'LINK' => ['NAME' => 'Ссылка при нажатии на баннер', 'PROPERTY_TYPE' => 'S'],
];
$status = [];
foreach ($specs as $code => $spec) {
    $row = CIBlockProperty::GetList([], ['IBLOCK_ID' => $blockId, 'CODE' => $code])->Fetch();
    $status[$code] = $row ?: null;
}
if ($request->isPost()) {
    if (!check_bitrix_sessid()) {
        $messages[] = 'Сессия истекла. Обновите страницу и повторите.';
    } elseif (!$block) {
        $messages[] = 'Инфоблок не найден. Ничего не изменено.';
    } else {
        foreach ($specs as $code => $spec) {
            if ($status[$code]) {
                $row = $status[$code];
                $compatible = $row['PROPERTY_TYPE'] === $spec['PROPERTY_TYPE'] && $row['MULTIPLE'] === 'N' && empty($row['USER_TYPE']) && $row['ACTIVE'] === 'Y';
                $messages[] = $compatible ? $code . ': уже существует, изменений нет.' : $code . ': существует с другими настройками или выключено. Проверьте вручную; свойство не изменено.';
                continue;
            }
            $property = new CIBlockProperty();
            $id = $property->Add(array_merge($spec, [
                'IBLOCK_ID' => $blockId, 'CODE' => $code, 'ACTIVE' => 'Y', 'MULTIPLE' => 'N',
                'IS_REQUIRED' => 'N', 'SORT' => $code === 'MOBILE_PICTURE' ? 510 : 500,
            ]));
            $messages[] = $id ? $code . ': создано, ID ' . (int)$id . '.' : $code . ': ошибка — ' . $property->LAST_ERROR;
            if ($id) { $status[$code] = CIBlockProperty::GetByID($id)->Fetch(); }
        }
    }
}
$escape = static function ($text) { return htmlspecialcharsbx((string)$text); };
?>
<!doctype html><html lang="ru"><head><meta charset="<?= $escape(defined('SITE_CHARSET') ? SITE_CHARSET : 'UTF-8') ?>"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Настройка слайдера Рлакс</title>
<style>body{max-width:850px;margin:40px auto;padding:0 20px;font:16px/1.6 system-ui;color:#263142}label{display:block;margin:12px 0}input,button{font:inherit;padding:8px}button{cursor:pointer}table{border-collapse:collapse;width:100%}td,th{padding:10px;border:1px solid #ddd;text-align:left}.notice{padding:12px;background:#eef3f8;margin:12px 0}</style></head><body>
<h1>Свойства баннеров</h1>
<p>Открытие страницы ничего не меняет. Кнопка создаёт только отсутствующие свойства <code>MOBILE_PICTURE</code> и <code>LINK</code>. Существующие свойства и элементы не перезаписываются.</p>
<?php foreach ($messages as $message): ?><p class="notice"><?= $escape($message) ?></p><?php endforeach; ?>
<p>Инфоблок: <?= (int)$blockId ?> — <?= $escape($block['NAME'] ?? 'не найден') ?></p>
<table><thead><tr><th>Код</th><th>Назначение</th><th>Состояние</th></tr></thead><tbody>
<?php foreach ($specs as $code => $spec): ?><tr><td><?= $escape($code) ?></td><td><?= $escape($spec['NAME']) ?></td><td><?= $status[$code] ? 'Есть, ID ' . (int)$status[$code]['ID'] . ', тип ' . $escape($status[$code]['PROPERTY_TYPE']) . ', множественное: ' . $escape($status[$code]['MULTIPLE']) : 'Не создано' ?></td></tr><?php endforeach; ?>
</tbody></table>
<form method="post">
<?= bitrix_sessid_post() ?>
<label>ID инфоблока: <input type="number" name="IBLOCK_ID" min="1" value="<?= (int)$blockId ?>" required></label>
<button type="submit">Создать отсутствующие свойства в указанном инфоблоке</button>
</form>
<p>После настройки загрузите мобильные изображения в элементах инфоблока и заполните ссылки. Для просмотра состояния другого инфоблока откройте эту страницу с <code>?IBLOCK_ID=число</code>. После завершения настройки страницу можно удалить.</p>
</body></html>
