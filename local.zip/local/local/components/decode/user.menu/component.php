<? if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

use Bitrix\Main\Loader,
  Bitrix\Main,
  Bitrix\Iblock;

/** check if admin submit creation seller */
global $USER;
global $APPLICATION;
use Bitrix\Main\Application;
use Democontent2\Board\User;

$menus = decode::getUserMenus();

debug::console($menus, "User Groups in menu!!!!");


//if ($seller == "1") {
//  /** buyer can be the seller */
//  $template = "form";
//
//  $request = Application::getInstance()->getContext()->getRequest();
//
//  $userId = $USER->GetID();
//  $rsUser = CUser::GetByID($userId);
//  $userData = $rsUser->Fetch();
//
//  $us = new User(intval($USER->GetID()), 0);
//
//  if ($request->isPost()) {
//
//    $fields = array(
//      "UF_INN" => $_POST['UF_INN'],
//      "UF_OGRN" => $_POST['UF_OGRN'],
//      "UF_MARKET_PLACE" => $_POST['UF_MARKET_PLACE'],
//      "UF_COMPANY_PERSON" => $_POST['UF_COMPANY_PERSON'],
//      "UF_MARKET" => array($_POST['UF_MARKETS']),
//    );
//
//    $USER = new CUser;
//    $makUserGroups = $USER->GetUserGroup($userId);
//    foreach($makUserGroups as $key=>$gid) {
//      if($gid == "5")
//      {
//        unset($makUserGroups[$key]);
//      }
//    }
//
//    $gid = array_merge($makUserGroups, array(6));
//
//    $USER->SetUserGroup($userId, $gid);
//    if ($USER->Update($userId, $fields)) {
////      LocalRedirect("/user/seller-data/");
//    } else
//      echo $USER->LAST_ERROR;
//
////            $us->update($_POST, $_FILES);
////            LocalRedirect($APPLICATION->GetCurPage(false), true);
//  }
//
//  $this->arResult['USER'] = $userData;
//
//  // get list from markets
//
//  $arSelect = Array("ID", "NAME");
//  $arFilter = Array("IBLOCK_ID"=>IntVal(1), "ACTIVE"=>"Y");
//  $res = CIBlockElement::GetList(Array(), $arFilter, false, Array(), $arSelect);
//  while($ob = $res->GetNextElement())
//  {
//    $arFields = $ob->GetFields();
//    $this->arResult['MARKETS'][] = array(
//      "ID" => $arFields['ID'],
//      "NAME" => $arFields['NAME']
//    );
//  }
//
//} else {
//  /** buyer can`t be the seller -> show information page */
//  $template = "info";
//}

$this->IncludeComponentTemplate();
