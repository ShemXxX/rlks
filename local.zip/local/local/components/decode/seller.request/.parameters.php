<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
$arComponentParameters = array(
  "GROUPS" => array(),
  "PARAMETERS" => array(
    "IBLOCK_BASE" => array(
      "PARENT" => "BASE",
      "NAME" => "Товары на главной - Инфоблок",
      "TYPE" => "STRING",
      "MULTIPLE" => "N",
      "DEFAULT" => "Y-m-d",
    ),
  ),
);
?>