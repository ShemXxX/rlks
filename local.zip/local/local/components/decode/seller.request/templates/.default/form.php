<? if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Democontent2\Board\Utils as UtilsAlias;

global $APPLICATION;
?>

Чтобы стать продавцом - необходимо заполнить данные!

<form
	action="<?= $APPLICATION->GetCurPage(false) ?>"
	method="post"
	enctype="multipart/form-data"
	class="edit-form">

	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<label><?= Loc::getMessage('USER_SETTINGS_COMPONENT_INN') ?></label>
		<input
			class="required"
			type="text"
			name="UF_INN"
			value="<?= $arResult['USER']['UF_INN'] ?>"
			placeholder="<?= Loc::getMessage('USER_SETTINGS_COMPONENT_INN') ?>">
	</div>

	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<label><?= Loc::getMessage('USER_SETTINGS_COMPONENT_OGRN') ?></label>
		<input
			class="required"
			type="text"
			name="UF_OGRN"
			value="<?= $arResult['USER']['UF_OGRN'] ?>"
			placeholder="<?= Loc::getMessage('USER_SETTINGS_COMPONENT_OGRN') ?>">
	</div>

	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<label><?= Loc::getMessage('USER_SETTINGS_COMPONENT_PLACE_MARKET') ?></label>
		<input
			class="required" type="text"
			name="UF_MARKET_PLACE"
			value="<?= $arResult['USER']['UF_MARKET_PLACE'] ?>"
			placeholder="<?= Loc::getMessage('USER_SETTINGS_COMPONENT_PLACE_MARKET') ?>">
	</div>

	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<label><?= Loc::getMessage('USER_SETTINGS_COMPONENT_COMPANY_PERSON') ?></label>
		<input
			class="required"
			type="text"
			name="UF_COMPANY_PERSON"
			value="<?= $arResult['USER']['UF_COMPANY_PERSON'] ?>"
			placeholder="<?= Loc::getMessage('USER_SETTINGS_COMPONENT_COMPANY_PERSON') ?>">
	</div>

	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<label><?= Loc::getMessage('USER_SETTINGS_COMPONENT_MARKETS') ?></label>

    <? foreach ($arResult['MARKETS'] as $marketId => $marketItem) { ?>
			<div class="checkBoxBlock">
				<input
					type="radio"
					name="UF_MARKETS"
					value="<?=$marketItem['ID']?>"
          <?=$marketItem['ID'] == $arResult['USER']['UF_MARKET'] ? "checked='checked'" : ""?>
				>
				<span><?=$marketItem['NAME']?></span>
			</div>
    <? } ?>
	</div>

	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<button class="apply _mt" type="submit">
      <?= Loc::getMessage('USER_SETTINGS_COMPONENT_BTN_SUBMIT') ?>
		</button>
	</div>
</form>
