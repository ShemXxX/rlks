<? if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();


?>




<!--<div id="employesList">-->
<!--  <div class="employersDesc">-->
<!--    <p>Согласно заказанной Вами площади, вы можете получить <span class='red'>--><?//=$arResult['ALL_BADGES']?><!--</span>-->
<!--      бейджей. <br>Если Вам потребуется большее количество бейджей, их можно приобрести связавшись с менеджером.</p>-->
<!--  </div>-->
<!--  -->
<!--  -->
<!--  --><?// if (!empty($arResult['EMPLOYERS'])) { ?>
<!--  <div class="employesList">-->
<!--    <strong>Уже зарегистрированные сотрудники: </strong>-->
<!--    <ol class="empList">-->
<!--    --><?// foreach ($arResult['EMPLOYERS'] as $employee) { ?>
<!--      <li>--><?//=$employee['LAST_NAME']?><!-- --><?//=$employee['FIRST_NAME']?><!--</li>-->
<!--    --><?// }?>
<!--    </ol>-->
<!--  </div>-->
<!--  --><?// } ?>
<!--  -->
<!--  --><?// if ($arResult['EMPTY_BADGES']> 0) { ?>
<!--    <strong>Вы можете зарегестрировать еще сотрудников: <span class="red">--><?//=$arResult['EMPTY_BADGES']?><!--</span></strong>-->
<!--  --><?// } ?>
<!--  <form name="add-staffs" id="add-staffs" action="/profile-ex/employee-registration/action.php" method="post">-->
<!--    --><?// for ($i= 1; $i<=$arResult['EMPTY_BADGES']; $i++) { ?>
<!--    <div class="row">-->
<!--      <div class="col-md-2 col-sm-none">-->
<!--        <div class="form-group">-->
<!--          <label for="inputID---><?//=$i?><!--">№</label>-->
<!--          <input type="text" readonly class="form-control-plaintext" id="inputID---><?//=$i?><!--" value="--><?//=$i?><!--">-->
<!--        </div>-->
<!--      </div>-->
<!--      <div class="col-md-5 col-sm-12">-->
<!--        <div class="form-group">-->
<!--          <label for="inputLastName---><?//=$i?><!--">Фамилия</label>-->
<!--          <input type="text" name="emp[--><?//=$i?><!--][LAST_NANE]" class="form-control" id="inputLastName---><?//=$i?><!--">-->
<!--        </div>-->
<!--      </div>-->
<!--      <div class="col-md-5 col-sm-12">-->
<!--        <div class="form-group">-->
<!--          <label for="inputFirstName---><?//=$i?><!--">Имя</label>-->
<!--          <input type="text" name="emp[--><?//=$i?><!--][FIRST_NANE]" class="form-control" id="inputFirstName---><?//=$i?><!--">-->
<!--        </div>-->
<!--      </div>-->
<!--    </div>-->
<!--    --><?// } ?>
<!--    <div class="row">-->
<!--      <div class="col-12">-->
<!--        <div class="itm-inp">-->
<!--          <input type="hidden" name="EMP_QTY" value="--><?//=$arResult['EMPTY_BADGES']?><!--">-->
<!--          <input type="hidden" name="COMPANY" value="--><?//=$arResult['COMPANY']?><!--">-->
<!--          <input type="hidden" name="COMPANY_EN" value="--><?//=$arResult['COMPANY_EN']?><!--">-->
<!--          <input type="hidden" name="EMAIL" value="--><?//=$arResult['EMAIL']?><!--">-->
<!--          <input type="hidden" name="EXHIBITOR" value="--><?//=$arResult['EXHIBITOR']?><!--">-->
<!--          <input class="btn-blue" type="submit" value="Отправить данные">-->
<!--        </div>-->
<!---->
<!--      </div>-->
<!--  </form>-->
<!--</div>-->
<!--</div>-->
<!---->
