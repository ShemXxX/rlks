<?
$MESS["SLIDER_PREV"] = "Предыдущий";
$MESS["SLIDER_NEXT"] = "Следующий";
