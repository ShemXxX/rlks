<? if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
?>

Чтобы стать продавцом - необходимо подать заявку администратору!

