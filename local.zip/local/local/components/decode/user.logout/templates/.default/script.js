$(document).ready(function() {
	$('a[href="/user/exit/"]').on('click', function(event) {
		event.preventDefault();
		$('#userLogoutModal').show();
	});
	$('#userLogoutModal').on('click', '#btnSubmit', function() {
		$('#userLogoutModal').hide();
		window.location.href = "/user/exit/";

	});
	$('#userLogoutModal').on('click', '#btnCancel', function() {
		$('#userLogoutModal').hide();
	});

});