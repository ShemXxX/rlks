<? if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<div id="userLogoutModal" style="display:none;">
	<div class="modalWrapper">
		<div class="modalWindow">
			<div class="modalTitle"></div>
			<div class="modalBody">
				Действительно хотите покинуть сайт?
			</div>
			<div class="modalFooter">
				<button id="btnCancel">Остаться</button>
				<button id="btnSubmit">Выйти</button>
			</div>
		</div>
	</div>
</div>