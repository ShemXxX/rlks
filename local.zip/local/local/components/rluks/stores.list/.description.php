<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) { die(); }
$arComponentDescription = [
    'NAME' => 'Каталог магазинов Рлакс',
    'DESCRIPTION' => 'Список магазинов Democontent2 Board со ссылками на их страницы и товары.',
    'PATH' => ['ID' => 'rluks', 'NAME' => 'Рлакс'],
    'CACHE_PATH' => 'Y',
];
