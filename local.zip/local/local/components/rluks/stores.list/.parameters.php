<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) { die(); }

$blocks = [0 => 'Автоматически: democontentboardcompanies'];
if (\Bitrix\Main\Loader::includeModule('highloadblock')) {
    $rows = \Bitrix\Highloadblock\HighloadBlockTable::getList(['order' => ['NAME' => 'ASC']]);
    while ($row = $rows->fetch()) {
        $blocks[$row['ID']] = '[' . $row['ID'] . '] ' . $row['NAME'];
    }
}
$groups = [0 => 'Без фильтра по группе (только записи компаний)'];
$by = 'c_sort'; $order = 'asc';
$rows = CGroup::GetList($by, $order, ['ACTIVE' => 'Y']);
while ($row = $rows->Fetch()) {
    $groups[$row['ID']] = '[' . $row['ID'] . '] ' . $row['NAME'];
}

$arComponentParameters = [
    'GROUPS' => [
        'SOURCE' => ['NAME' => 'Источник данных и отбор'],
        'VIEW' => ['NAME' => 'Оформление карточек'],
        'LINKS' => ['NAME' => 'Ссылки'],
    ],
    'PARAMETERS' => [
        'HL_BLOCK_ID' => ['PARENT' => 'SOURCE', 'NAME' => 'HL-блок компаний', 'TYPE' => 'LIST', 'VALUES' => $blocks, 'DEFAULT' => '0'],
        'SELLER_GROUP_ID' => ['PARENT' => 'SOURCE', 'NAME' => 'Группа продавцов (проверьте ID на сайте)', 'TYPE' => 'LIST', 'VALUES' => $groups, 'ADDITIONAL_VALUES' => 'Y', 'DEFAULT' => '6'],
        'EXCLUDE_ADMINS' => ['PARENT' => 'SOURCE', 'NAME' => 'Исключать администраторов (системная группа 1)', 'TYPE' => 'CHECKBOX', 'DEFAULT' => 'Y'],
        'INCLUDE_WITHOUT_COMPANY' => ['PARENT' => 'SOURCE', 'NAME' => 'Включать продавцов без компании (нужна группа продавцов)', 'TYPE' => 'CHECKBOX', 'DEFAULT' => 'Y'],
        'ONLY_VALID_ACCOUNT' => ['PARENT' => 'SOURCE', 'NAME' => 'Только с действующим UF_COMPANY_ACCOUNT (отсекает обычные профили)', 'TYPE' => 'CHECKBOX', 'DEFAULT' => 'N'],
        'PAGE_SIZE' => ['PARENT' => 'BASE', 'NAME' => 'Магазинов на странице (1–100)', 'TYPE' => 'STRING', 'DEFAULT' => '12'],
        'SORT_FIELD' => ['PARENT' => 'BASE', 'NAME' => 'Сортировка', 'TYPE' => 'LIST', 'VALUES' => ['UF_COMPANY_NAME' => 'Название компании / публичное имя', 'UF_CREATED_AT' => 'Дата компании / регистрации', 'ID' => 'ID пользователя'], 'DEFAULT' => 'UF_COMPANY_NAME'],
        'SORT_ORDER' => ['PARENT' => 'BASE', 'NAME' => 'Направление сортировки', 'TYPE' => 'LIST', 'VALUES' => ['ASC' => 'По возрастанию', 'DESC' => 'По убыванию'], 'DEFAULT' => 'ASC'],
        'TITLE' => ['PARENT' => 'VIEW', 'NAME' => 'Заголовок блока (можно оставить пустым)', 'TYPE' => 'STRING', 'DEFAULT' => 'Магазины'],
        'SHOW_LOGO' => ['PARENT' => 'VIEW', 'NAME' => 'Показывать логотип', 'TYPE' => 'CHECKBOX', 'DEFAULT' => 'Y'],
        'SHOW_ADDRESS' => ['PARENT' => 'VIEW', 'NAME' => 'Показывать адрес', 'TYPE' => 'CHECKBOX', 'DEFAULT' => 'Y'],
        'SHOW_PHONE' => ['PARENT' => 'VIEW', 'NAME' => 'Показывать телефон', 'TYPE' => 'CHECKBOX', 'DEFAULT' => 'Y'],
        'SHOW_WORKTIME' => ['PARENT' => 'VIEW', 'NAME' => 'Показывать режим работы', 'TYPE' => 'CHECKBOX', 'DEFAULT' => 'N'],
        'SHOW_DESCRIPTION' => ['PARENT' => 'VIEW', 'NAME' => 'Показывать краткое описание', 'TYPE' => 'CHECKBOX', 'DEFAULT' => 'Y'],
        'DESCRIPTION_LENGTH' => ['PARENT' => 'VIEW', 'NAME' => 'Длина описания (50–1000 символов)', 'TYPE' => 'STRING', 'DEFAULT' => '160'],
        'COLUMNS' => ['PARENT' => 'VIEW', 'NAME' => 'Колонок на компьютере', 'TYPE' => 'LIST', 'VALUES' => [2 => '2', 3 => '3', 4 => '4', 5 => '5'], 'DEFAULT' => '3'],
        'MOBILE_COLUMNS' => ['PARENT' => 'VIEW', 'NAME' => 'Колонок на телефоне', 'TYPE' => 'LIST', 'VALUES' => [1 => '1', 2 => '2'], 'DEFAULT' => '1'],
        'BUTTON_TEXT' => ['PARENT' => 'VIEW', 'NAME' => 'Текст ссылки на магазин', 'TYPE' => 'STRING', 'DEFAULT' => 'Посмотреть товары'],
        'STORE_URL_TEMPLATE' => ['PARENT' => 'LINKS', 'NAME' => 'URL магазина: #CODE#, #USER_ID#, #ID#', 'TYPE' => 'STRING', 'DEFAULT' => SITE_DIR . 'store-#CODE#/'],
        'PROFILE_URL_TEMPLATE' => ['PARENT' => 'LINKS', 'NAME' => 'URL профиля при истёкшем аккаунте: #USER_ID#', 'TYPE' => 'STRING', 'DEFAULT' => SITE_DIR . 'user/#USER_ID#/'],
        'PAGER_ID' => ['PARENT' => 'BASE', 'NAME' => 'ID пагинации (разный для нескольких списков)', 'TYPE' => 'STRING', 'DEFAULT' => 'rluks_stores'],
        'CACHE_TIME' => ['DEFAULT' => 300],
    ],
];
