<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) { die(); }
$this->setFrameMode(true);
$escape = static function ($value) { return htmlspecialcharsbx((string)$value); };
?>
<section class="rluks-stores rluks-stores--cols-<?= (int)$arParams['COLUMNS'] ?> rluks-stores--mobile-<?= (int)$arParams['MOBILE_COLUMNS'] ?>">
    <?php if ($arResult['TITLE'] !== ''): ?>
        <h2 class="rluks-stores__title"><?= $escape($arResult['TITLE']) ?></h2>
    <?php endif; ?>
    <?php if (!$arResult['ITEMS']): ?>
        <p class="rluks-stores__empty">На этой странице пока нет магазинов.</p>
    <?php else: ?>
        <div class="rluks-stores__grid">
            <?php foreach ($arResult['ITEMS'] as $store): ?>
                <article class="rluks-stores__card">
                    <?php if ($arParams['SHOW_LOGO'] === 'Y'): ?>
                        <a class="rluks-stores__logo" href="<?= $escape($store['URL']) ?>" aria-label="<?= $escape($store['UF_COMPANY_NAME']) ?>">
                            <?php if ($store['LOGO']): ?>
                                <img src="<?= $escape($store['LOGO']) ?>" alt="<?= $escape($store['UF_COMPANY_NAME']) ?>" loading="lazy" width="360" height="180">
                            <?php else: ?>
                                <span class="rluks-stores__placeholder" aria-hidden="true">Магазин</span>
                            <?php endif; ?>
                        </a>
                    <?php endif; ?>
                    <div class="rluks-stores__body">
                        <h3 class="rluks-stores__name"><a href="<?= $escape($store['URL']) ?>"><?= $escape($store['UF_COMPANY_NAME']) ?></a></h3>
                        <?php if ($arParams['SHOW_DESCRIPTION'] === 'Y' && $store['DESCRIPTION'] !== ''): ?>
                            <p class="rluks-stores__description"><?= $escape($store['DESCRIPTION']) ?></p>
                        <?php endif; ?>
                        <?php foreach (['ADDRESS' => ['UF_COMPANY_ADDRESS', 'Адрес'], 'WORKTIME' => ['UF_COMPANY_WORKTIME', 'Режим работы']] as $flag => $field): ?>
                            <?php if ($arParams['SHOW_' . $flag] === 'Y' && !empty($store[$field[0]])): ?>
                                <p class="rluks-stores__detail"><strong><?= $field[1] ?>:</strong> <?= $escape($store[$field[0]]) ?></p>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        <?php if ($arParams['SHOW_PHONE'] === 'Y' && $store['PHONE_LINK'] !== ''): ?>
                            <p class="rluks-stores__detail"><a href="tel:<?= $escape($store['PHONE_LINK']) ?>"><?= $escape($store['UF_COMPANY_PHONE']) ?></a></p>
                        <?php endif; ?>
                        <a class="rluks-stores__button" href="<?= $escape($store['URL']) ?>"><?= $escape($arParams['BUTTON_TEXT']) ?></a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <?php if ($arResult['PAGE_COUNT'] > 1): ?>
        <nav class="rluks-stores__pagination" aria-label="Страницы каталога магазинов">
            <?php $previous = 0; foreach ($arResult['PAGES'] as $page): ?>
                <?php if ($previous && $page['NUMBER'] > $previous + 1): ?><span>…</span><?php endif; ?>
                <?php if ($page['CURRENT']): ?>
                    <span class="rluks-stores__current" aria-current="page"><?= (int)$page['NUMBER'] ?></span>
                <?php else: ?>
                    <a href="<?= $escape($page['URL']) ?>"><?= (int)$page['NUMBER'] ?></a>
                <?php endif; ?>
            <?php $previous = $page['NUMBER']; endforeach; ?>
        </nav>
    <?php endif; ?>
</section>
