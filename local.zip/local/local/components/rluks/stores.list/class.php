<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) { die(); }

use Bitrix\Main\Loader;
use Bitrix\Main\Type\DateTime;
use Bitrix\Main\UserTable;
use Bitrix\Main\UserGroupTable;
use Bitrix\Main\Entity\ReferenceField;
use Bitrix\Main\Entity\ExpressionField;
use Bitrix\Highloadblock\HighloadBlockTable;

class RluksStoresListComponent extends CBitrixComponent
{
    public function onPrepareComponentParams($params)
    {
        $defaults = [
            'HL_BLOCK_ID' => 0, 'SELLER_GROUP_ID' => 6, 'ONLY_VALID_ACCOUNT' => 'N', 'INCLUDE_WITHOUT_COMPANY' => 'Y', 'EXCLUDE_ADMINS' => 'Y',
            'PAGE_SIZE' => 12, 'SORT_FIELD' => 'UF_COMPANY_NAME', 'SORT_ORDER' => 'ASC',
            'TITLE' => 'Магазины', 'SHOW_LOGO' => 'Y', 'SHOW_ADDRESS' => 'Y',
            'SHOW_PHONE' => 'Y', 'SHOW_WORKTIME' => 'N', 'SHOW_DESCRIPTION' => 'Y',
            'DESCRIPTION_LENGTH' => 160, 'COLUMNS' => 3, 'MOBILE_COLUMNS' => 1,
            'BUTTON_TEXT' => 'Посмотреть товары', 'STORE_URL_TEMPLATE' => SITE_DIR . 'store-#CODE#/',
            'PROFILE_URL_TEMPLATE' => SITE_DIR . 'user/#USER_ID#/',
            'PAGER_ID' => 'rluks_stores', 'CACHE_TYPE' => 'A', 'CACHE_TIME' => 300,
        ];
        $params = array_replace($defaults, $params);
        foreach (['HL_BLOCK_ID', 'SELLER_GROUP_ID', 'CACHE_TIME'] as $key) {
            $params[$key] = max(0, (int)$params[$key]);
        }
        $params['PAGE_SIZE'] = max(1, min(100, (int)$params['PAGE_SIZE']));
        $params['DESCRIPTION_LENGTH'] = max(50, min(1000, (int)$params['DESCRIPTION_LENGTH']));
        $params['COLUMNS'] = in_array((int)$params['COLUMNS'], [2, 3, 4, 5], true) ? (int)$params['COLUMNS'] : 3;
        $params['MOBILE_COLUMNS'] = (int)$params['MOBILE_COLUMNS'] === 2 ? 2 : 1;
        $params['SORT_FIELD'] = in_array($params['SORT_FIELD'], ['UF_COMPANY_NAME', 'UF_CREATED_AT', 'ID'], true) ? $params['SORT_FIELD'] : 'UF_COMPANY_NAME';
        $params['SORT_ORDER'] = $params['SORT_ORDER'] === 'DESC' ? 'DESC' : 'ASC';
        foreach (['EXCLUDE_ADMINS', 'INCLUDE_WITHOUT_COMPANY', 'ONLY_VALID_ACCOUNT', 'SHOW_LOGO', 'SHOW_ADDRESS', 'SHOW_PHONE', 'SHOW_WORKTIME', 'SHOW_DESCRIPTION'] as $key) {
            $params[$key] = $params[$key] === 'Y' ? 'Y' : 'N';
        }
        $params['PAGER_ID'] = preg_replace('/[^a-zA-Z0-9_]/', '', (string)$params['PAGER_ID']) ?: 'rluks_stores';
        foreach (['STORE_URL_TEMPLATE', 'PROFILE_URL_TEMPLATE'] as $key) {
            // Only same-site paths, never javascript:, external or protocol-relative links.
            $url = (string)$params[$key];
            if (!preg_match('~^/(?!/)~', $url) || preg_match('/[\x00-\x20\x7f\\\\]/', $url)) {
                $params[$key] = $defaults[$key];
            }
        }
        return $params;
    }

    protected function plainText($value)
    {
        $charset = defined('SITE_CHARSET') ? SITE_CHARSET : 'UTF-8';
        $value = (string)$value;
        // Democontent2 may already store escaped text (e.g. &quot;).
        for ($i = 0; $i < 2; $i++) {
            $decoded = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, $charset);
            if ($decoded === $value) { break; }
            $value = $decoded;
        }
        return trim(strip_tags($value));
    }

    protected function prepareStore(array $source)
    {
        $userId = (int)$source['ID'];
        $companyName = $this->plainText($source['UF_COMPANY_NAME'] ?? '');
        $publicName = trim($this->plainText($source['NAME'] ?? '') . ' ' . $this->plainText($source['LAST_NAME'] ?? ''));
        $row = $source;
        $row['UF_USER_ID'] = $userId;
        $row['UF_COMPANY_NAME'] = $companyName !== '' ? $companyName : ($publicName !== '' ? $publicName : 'Продавец №' . $userId);
        $code = trim((string)($source['UF_COMPANY_CODE'] ?? ''));
        $until = $source['ACCOUNT_UNTIL'] ?? null;
        $timestamp = $until instanceof \Bitrix\Main\Type\Date ? $until->getTimestamp() : ($until ? MakeTimeStamp((string)$until) : 0);
        $hasCompany = (int)($source['COMPANY_ID'] ?? 0) > 0;
        $template = $hasCompany && $code !== '' && $timestamp > time()
            ? $this->arParams['STORE_URL_TEMPLATE'] : $this->arParams['PROFILE_URL_TEMPLATE'];
        $row['URL'] = strtr($template, [
            '#CODE#' => rawurlencode($code), '#USER_ID#' => (string)$userId,
            '#ID#' => (string)(int)($source['COMPANY_ID'] ?? 0),
        ]);
        $row['LOGO'] = '';
        $photoId = !empty($source['UF_LOGO_ID']) ? (int)$source['UF_LOGO_ID'] : (int)($source['PERSONAL_PHOTO'] ?? 0);
        if ($this->arParams['SHOW_LOGO'] === 'Y' && $photoId > 0) {
            $logo = CFile::ResizeImageGet($photoId, ['width' => 360, 'height' => 180], BX_RESIZE_IMAGE_PROPORTIONAL, true);
            $row['LOGO'] = is_array($logo) ? $logo['src'] : '';
        }
        foreach (['UF_COMPANY_ADDRESS', 'UF_COMPANY_PHONE', 'UF_COMPANY_WORKTIME'] as $field) {
            $row[$field] = $this->plainText($source[$field] ?? '');
        }
        // No fallback to login, email, personal address or personal phone.
        $text = $this->plainText($source['UF_COMPANY_DESCR'] ?? '');
        $text = trim(preg_replace('/\s+/u', ' ', $text) ?? $text);
        $length = $this->arParams['DESCRIPTION_LENGTH'];
        $row['DESCRIPTION'] = mb_strlen($text) > $length ? mb_substr($text, 0, $length) . '…' : $text;
        $row['PHONE_LINK'] = preg_replace('/[^0-9+]/', '', $row['UF_COMPANY_PHONE']);
        return $row;
    }

    public function executeComponent()
    {
        global $APPLICATION, $USER;
        $pageKey = $this->arParams['PAGER_ID'] . '_page';
        $rawPage = \Bitrix\Main\Context::getCurrent()->getRequest()->getQuery($pageKey);
        $page = max(1, min(1000000, is_scalar($rawPage) ? (int)$rawPage : 1));
        if (!$this->startResultCache(false, ['v1.2.2-admin-exclusion', SITE_ID, LANGUAGE_ID, $page, $APPLICATION->GetCurPageParam('', [$pageKey])])) {
            return;
        }
        try {
            if (!Loader::includeModule('highloadblock')) {
                throw new \RuntimeException('Модуль highloadblock не установлен.');
            }
            $hl = $this->arParams['HL_BLOCK_ID'] > 0
                ? HighloadBlockTable::getById($this->arParams['HL_BLOCK_ID'])->fetch()
                : HighloadBlockTable::getList(['filter' => ['=TABLE_NAME' => 'democontentboardcompanies'], 'limit' => 1])->fetch();
            if (!$hl) {
                throw new \RuntimeException('HL-блок компаний не найден. Выберите его в параметрах компонента.');
            }
            $entity = HighloadBlockTable::compileEntity($hl);
            foreach (['UF_USER_ID', 'UF_COMPANY_NAME', 'UF_COMPANY_CODE'] as $required) {
                if (!$entity->hasField($required)) {
                    throw new \RuntimeException('В выбранном HL-блоке отсутствует поле ' . $required . '.');
                }
            }
            $userEntity = UserTable::getEntity();
            $hasAccountField = $userEntity->hasField('UF_COMPANY_ACCOUNT');
            if ($this->arParams['ONLY_VALID_ACCOUNT'] === 'Y' && !$hasAccountField) {
                throw new \RuntimeException('У пользователей нет поля UF_COMPANY_ACCOUNT. Проверьте установку или отключите фильтр действующего аккаунта.');
            }
            // Select users first: a company record is optional for approved sellers.
            // Use one deterministic company per user, even if legacy data has duplicates.
            $table = \Bitrix\Main\Application::getConnection()->getSqlHelper()->quote($hl['TABLE_NAME']);
            $runtime = [
                new ExpressionField('RLUKS_COMPANY_ID', '(SELECT MAX(RC.ID) FROM ' . $table . ' RC WHERE RC.UF_USER_ID = %s)', ['ID']),
                new ReferenceField('COMPANY', $entity, ['=this.RLUKS_COMPANY_ID' => 'ref.ID'], ['join_type' => 'LEFT']),
            ];
            $filter = ['=ACTIVE' => 'Y'];
            $now = new DateTime();
            if ($this->arParams['ONLY_VALID_ACCOUNT'] === 'Y') {
                $filter['>UF_COMPANY_ACCOUNT'] = $now;
            }
            if ($this->arParams['SELLER_GROUP_ID'] > 0) {
                $runtime[] = new ReferenceField('SELLER_MEMBERSHIP', UserGroupTable::class, ['=this.ID' => 'ref.USER_ID'], ['join_type' => 'INNER']);
                $filter['=SELLER_MEMBERSHIP.GROUP_ID'] = $this->arParams['SELLER_GROUP_ID'];
                $filter[] = ['LOGIC' => 'OR', ['=SELLER_MEMBERSHIP.DATE_ACTIVE_FROM' => false], ['<=SELLER_MEMBERSHIP.DATE_ACTIVE_FROM' => $now]];
                $filter[] = ['LOGIC' => 'OR', ['=SELLER_MEMBERSHIP.DATE_ACTIVE_TO' => false], ['>SELLER_MEMBERSHIP.DATE_ACTIVE_TO' => $now]];
            }
            if ($this->arParams['EXCLUDE_ADMINS'] === 'Y') {
                // Exclude all explicit members of the built-in Administrators group,
                // regardless of membership dates. User 1 is the built-in superuser.
                $adminRows = UserGroupTable::getList([
                    'select' => ['USER_ID'],
                    'filter' => ['=GROUP_ID' => 1],
                ]);
                $adminIds = [1 => 1];
                while ($adminRow = $adminRows->fetch()) {
                    $adminId = (int)$adminRow['USER_ID'];
                    if ($adminId > 0) { $adminIds[$adminId] = $adminId; }
                }
                $filter['!ID'] = array_values($adminIds);
            }
            // Without an explicit seller group, never expand this public directory to all users.
            if ($this->arParams['INCLUDE_WITHOUT_COMPANY'] !== 'Y' || $this->arParams['SELLER_GROUP_ID'] === 0) {
                $filter['>COMPANY.ID'] = 0;
                $filter['!COMPANY.UF_COMPANY_NAME'] = false;
            }
            $select = ['ID', 'NAME', 'LAST_NAME', 'PERSONAL_PHOTO', 'DATE_REGISTER', 'COMPANY_ID' => 'COMPANY.ID'];
            foreach (['UF_COMPANY_NAME', 'UF_COMPANY_CODE', 'UF_LOGO_ID', 'UF_COMPANY_ADDRESS', 'UF_COMPANY_PHONE', 'UF_COMPANY_WORKTIME', 'UF_COMPANY_DESCR'] as $field) {
                if ($entity->hasField($field)) { $select[$field] = 'COMPANY.' . $field; }
            }
            if ($hasAccountField) { $select['ACCOUNT_UNTIL'] = 'UF_COMPANY_ACCOUNT'; }
            $runtime[] = new ExpressionField('RLUKS_SORT_NAME',
                "COALESCE(NULLIF(TRIM(%s), ''), NULLIF(TRIM(CONCAT(COALESCE(%s, ''), ' ', COALESCE(%s, ''))), ''), CONCAT('Продавец №', %s))",
                ['COMPANY.UF_COMPANY_NAME', 'NAME', 'LAST_NAME', 'ID']);
            $sort = $this->arParams['SORT_FIELD'];
            if ($sort === 'UF_COMPANY_NAME') {
                $sort = 'RLUKS_SORT_NAME';
            } elseif ($sort === 'UF_CREATED_AT') {
                if ($entity->hasField('UF_CREATED_AT')) {
                    $runtime[] = new ExpressionField('RLUKS_SORT_DATE', 'COALESCE(%s, %s)', ['COMPANY.UF_CREATED_AT', 'DATE_REGISTER']);
                    $sort = 'RLUKS_SORT_DATE';
                } else { $sort = 'DATE_REGISTER'; }
            }
            $order = [$sort => $this->arParams['SORT_ORDER']];
            if ($sort !== 'ID') { $order['ID'] = 'ASC'; }
            $queryResult = UserTable::getList([
                'select' => $select, 'filter' => $filter, 'runtime' => $runtime,
                'order' => $order, 'limit' => $this->arParams['PAGE_SIZE'],
                'offset' => ($page - 1) * $this->arParams['PAGE_SIZE'], 'count_total' => true,
            ]);
            $this->arResult = ['ITEMS' => [], 'TOTAL' => (int)$queryResult->getCount(), 'PAGE' => $page, 'PAGES' => [], 'TITLE' => $this->arParams['TITLE']];
            while ($source = $queryResult->fetch()) {
                $row = $this->prepareStore($source);
                $this->arResult['ITEMS'][] = $row;
            }
            $pageCount = (int)ceil($this->arResult['TOTAL'] / $this->arParams['PAGE_SIZE']);
            $this->arResult['PAGE_COUNT'] = $pageCount;
            $windowPage = min($page, max(1, $pageCount));
            $pageNumbers = $pageCount > 0 ? array_unique(array_merge([1, $pageCount], range(max(1, $windowPage - 2), min($pageCount, $windowPage + 2)))) : [];
            sort($pageNumbers);
            foreach ($pageNumbers as $number) {
                if ($number < 1 || $number > $pageCount) { continue; }
                $this->arResult['PAGES'][] = ['NUMBER' => $number, 'URL' => $APPLICATION->GetCurPageParam($pageKey . '=' . $number, [$pageKey]), 'CURRENT' => $number === $page];
            }
            $this->includeComponentTemplate();
        } catch (\Throwable $error) {
            $this->abortResultCache();
            AddMessage2Log($error->getMessage(), 'rluks:stores.list');
            // Never cache detailed administrator-only diagnostics in the public template.
            if (is_object($USER) && $USER->IsAdmin()) {
                ShowError(htmlspecialcharsbx($error->getMessage()));
            } else {
                ShowError('Каталог магазинов временно недоступен.');
            }
        }
    }
}
