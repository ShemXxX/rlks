(function () {
    'use strict';
    var selector = '[data-rluks-slider]';
    var serial = 0;

    function initialize(root) {
        if (root.dataset.rluksReady) { return; }
        var config;
        try { config = JSON.parse(root.getAttribute('data-rluks-slider')); }
        catch (error) { return; }
        var track = root.querySelector('.rluks-banner-slider__track');
        if (!track || !track.children.length) { return; }
        if (track.children.length > 1 && typeof window.tns !== 'function') { return; }
        root.dataset.rluksReady = '1';
        if (root.id && document.getElementById(root.id) !== root) { root.id += '-' + (++serial); }
        var count = track.children.length;
        if (count === 1) { root.classList.add('is-single'); return; }
        var controls = root.querySelector('.rluks-banner-slider__controls');
        var dots = root.querySelector('.rluks-banner-slider__dots');
        var bottom = root.querySelector('.rluks-banner-slider__bottom');
        var pause = root.querySelector('.rluks-banner-slider__pause');
        var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        var manualPause = !!reduced;
        var hovered = false;
        var focused = false;
        var pointer = null;
        var suppressUntil = 0;
        var api;

        controls.hidden = !config.arrows;
        dots.hidden = !config.dots;
        pause.hidden = !config.autoplay;
        bottom.hidden = !config.dots && !config.autoplay;
        root.classList.add('is-initialized');
        try {
            api = window.tns({
                container: track,
                items: 1,
                slideBy: 1,
                loop: true,
                rewind: false,
                gutter: 0,
                controls: !!config.arrows,
                controlsContainer: controls,
                nav: !!config.dots,
                navContainer: dots,
                navAsThumbnails: true,
                autoplay: !!config.autoplay,
                autoplayTimeout: config.interval || 3000,
                autoplayButtonOutput: false,
                autoplayHoverPause: false,
                autoplayResetOnVisibility: false,
                speed: reduced ? 0 : (config.speed || 0),
                touch: !!config.touch,
                mouseDrag: !!config.touch,
                arrowKeys: false,
            });
        } catch (error) {
            root.classList.remove('is-initialized');
            controls.hidden = true; bottom.hidden = true;
            delete root.dataset.rluksReady;
            if (window.console) { console.error('Innova slider initialization failed', error); }
            return;
        }
        // Expose this instance on its own root for diagnostics, not as a global variable.
        root.rluksSlider = api;

        function synchronizePlayback() {
            if (!config.autoplay) { return; }
            if (manualPause || hovered || focused || document.hidden || pointer) { api.pause(); }
            else { api.play(); }
            pause.textContent = manualPause ? 'Запустить' : 'Пауза';
            pause.setAttribute('aria-label', manualPause ? 'Запустить автопрокрутку' : 'Остановить автопрокрутку');
        }
        function labelNavigation() {
            Array.prototype.forEach.call(dots.children, function (button, index) {
                button.setAttribute('aria-label', 'Слайд ' + (index + 1) + ' из ' + count);
                button.setAttribute('title', 'Слайд ' + (index + 1) + ' из ' + count);
            });
            var buttons = controls.querySelectorAll('button');
            if (buttons[0]) { buttons[0].setAttribute('aria-label', 'Предыдущий слайд'); }
            if (buttons[1]) { buttons[1].setAttribute('aria-label', 'Следующий слайд'); }
            // Cloned slides and hidden slides must not introduce extra tab stops.
            Array.prototype.forEach.call(track.children, function (slide) {
                var link = slide.querySelector('a.rluks-banner-slider__link');
                if (link) { link.tabIndex = slide.getAttribute('aria-hidden') === 'true' ? -1 : 0; }
            });
        }
        api.events.on('indexChanged', function () { window.setTimeout(labelNavigation, 0); });
        api.events.on('transitionEnd', labelNavigation);
        labelNavigation();

        if (config.pauseHover) {
            root.addEventListener('mouseenter', function () { hovered = true; synchronizePlayback(); });
            root.addEventListener('mouseleave', function () { hovered = false; synchronizePlayback(); });
        }
        function keyboardFocusInside() {
            var active = document.activeElement;
            if (!active || active === pause || !root.contains(active)) { return false; }
            try { return active.matches(':focus-visible'); }
            catch (error) { return true; }
        }
        root.addEventListener('focusin', function () { focused = keyboardFocusInside(); synchronizePlayback(); });
        root.addEventListener('focusout', function () {
            window.setTimeout(function () { focused = keyboardFocusInside(); synchronizePlayback(); }, 0);
        });
        document.addEventListener('visibilitychange', synchronizePlayback);
        pause.addEventListener('click', function () { manualPause = !manualPause; synchronizePlayback(); });

        // Keep clicks on banners, but suppress navigation after a drag/swipe.
        track.addEventListener('pointerdown', function (event) {
            if (event.isPrimary === false || (event.pointerType === 'mouse' && event.button !== 0)) { return; }
            pointer = { id: event.pointerId, x: event.clientX, y: event.clientY, moved: false };
            synchronizePlayback();
        }, true);
        document.addEventListener('pointermove', function (event) {
            if (!pointer || pointer.id !== event.pointerId) { return; }
            if (Math.abs(event.clientX - pointer.x) > 10 || Math.abs(event.clientY - pointer.y) > 10) {
                pointer.moved = true;
                suppressUntil = Date.now() + 600;
            }
        }, true);
        function endPointer(event) {
            if (!pointer || pointer.id !== event.pointerId) { return; }
            if (pointer.moved) { suppressUntil = Date.now() + 600; }
            pointer = null;
            synchronizePlayback();
        }
        document.addEventListener('pointerup', endPointer, true);
        document.addEventListener('pointercancel', endPointer, true);
        track.addEventListener('click', function (event) {
            if (Date.now() < suppressUntil && event.target.closest('a.rluks-banner-slider__link')) {
                event.preventDefault();
                event.stopPropagation();
            }
        }, true);
        synchronizePlayback();
    }

    function scan(scope) {
        if (scope.nodeType !== 1 && scope.nodeType !== 9) { return; }
        if (scope.matches && scope.matches(selector)) { initialize(scope); }
        Array.prototype.forEach.call(scope.querySelectorAll(selector), initialize);
    }
    function boot() {
        scan(document);
        window.addEventListener('load', function () { scan(document); });
        // Also handle fragments inserted by the Bitrix composite mode / AJAX.
        if (window.MutationObserver && document.body) {
            new MutationObserver(function (changes) {
                changes.forEach(function (change) {
                    Array.prototype.forEach.call(change.addedNodes, function (node) { scan(node); });
                });
            }).observe(document.body, { childList: true, subtree: true });
        }
        var retries = 0;
        var timer = window.setInterval(function () {
            scan(document);
            if (++retries >= 20) { window.clearInterval(timer); }
        }, 100);
        if (window.BX && typeof window.BX.addCustomEvent === 'function') {
            window.BX.addCustomEvent('onFrameDataReceived', function () { scan(document); });
        }
    }
    if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', boot); }
    else { boot(); }
})();
