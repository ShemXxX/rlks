<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) { die(); }
$blocks = []; $files = ['MOBILE_PICTURE' => 'MOBILE_PICTURE — изображение для телефона'];
$links = ['LINK' => 'LINK — ссылка'];
if (\Bitrix\Main\Loader::includeModule('iblock')) {
    $rows = CIBlock::GetList(['SORT' => 'ASC'], ['ACTIVE' => 'Y']);
    while ($row = $rows->Fetch()) { $blocks[$row['ID']] = '[' . $row['ID'] . '] ' . $row['NAME']; }
    $blockId = (int)($arCurrentValues['IBLOCK_ID'] ?? 150);
    if ($blockId > 0) {
        $rows = CIBlockProperty::GetList(['SORT' => 'ASC'], ['IBLOCK_ID' => $blockId, 'ACTIVE' => 'Y', 'MULTIPLE' => 'N']);
        while ($row = $rows->Fetch()) {
            if (!$row['CODE']) { continue; }
            if ($row['PROPERTY_TYPE'] === 'F') { $files[$row['CODE']] = $row['NAME'] . ' [' . $row['CODE'] . ']'; }
            if ($row['PROPERTY_TYPE'] === 'S' && empty($row['USER_TYPE'])) { $links[$row['CODE']] = $row['NAME'] . ' [' . $row['CODE'] . ']'; }
        }
    }
}
$fit = ['2' => 'Заполнить область, обрезать края (cover)', '1' => 'Показать целиком, возможны поля (contain)'];
$arComponentParameters = [
    'GROUPS' => ['IMAGES' => ['NAME' => 'Изображения и размеры'], 'PLAYBACK' => ['NAME' => 'Управление и автопрокрутка']],
    'PARAMETERS' => [
        'IBLOCK_ID' => ['PARENT' => 'BASE', 'NAME' => 'Инфоблок баннеров', 'TYPE' => 'LIST', 'VALUES' => $blocks, 'ADDITIONAL_VALUES' => 'Y', 'REFRESH' => 'Y', 'DEFAULT' => '150'],
        'LINK_PROPERTY' => ['PARENT' => 'BASE', 'NAME' => 'Свойство ссылки (строка, одиночное)', 'TYPE' => 'LIST', 'VALUES' => $links, 'ADDITIONAL_VALUES' => 'Y', 'DEFAULT' => 'LINK'],
        'MOBILE_IMAGE_PROPERTY' => ['PARENT' => 'IMAGES', 'NAME' => 'Свойство изображения для телефона (файл, одиночное)', 'TYPE' => 'LIST', 'VALUES' => $files, 'ADDITIONAL_VALUES' => 'Y', 'DEFAULT' => 'MOBILE_PICTURE'],
        'HEIGHT' => ['PARENT' => 'IMAGES', 'NAME' => 'Высота на компьютере, px', 'TYPE' => 'STRING', 'DEFAULT' => '460'],
        'HEIGHT_MOBILE' => ['PARENT' => 'IMAGES', 'NAME' => 'Высота на телефоне (ширина менее 768 px), px', 'TYPE' => 'STRING', 'DEFAULT' => '150'],
        'STRETCH_TYPE' => ['PARENT' => 'IMAGES', 'NAME' => 'Режим изображения на компьютере', 'TYPE' => 'LIST', 'VALUES' => $fit, 'DEFAULT' => '2'],
        'STRETCH_TYPE_MOBILE' => ['PARENT' => 'IMAGES', 'NAME' => 'Режим изображения на телефоне', 'TYPE' => 'LIST', 'VALUES' => $fit, 'DEFAULT' => '2'],
        'BTN_COLOR' => ['PARENT' => 'IMAGES', 'NAME' => 'Цвет стрелок и точек (#RRGGBB)', 'TYPE' => 'COLORPICKER', 'DEFAULT' => '#FFFFFF'],
        'SLIDER_COLOR' => ['PARENT' => 'IMAGES', 'NAME' => 'Цвет фона (#RRGGBB или rgba)', 'TYPE' => 'STRING', 'DEFAULT' => '#F4F5F7'],
        'SHOW_ARROWS' => ['PARENT' => 'PLAYBACK', 'NAME' => 'Показывать стрелки', 'TYPE' => 'CHECKBOX', 'DEFAULT' => 'Y'],
        'SHOW_DOTS' => ['PARENT' => 'PLAYBACK', 'NAME' => 'Показывать точки внизу изображения', 'TYPE' => 'CHECKBOX', 'DEFAULT' => 'Y'],
        'TOUCH' => ['PARENT' => 'PLAYBACK', 'NAME' => 'Переключение свайпом и перетаскиванием', 'TYPE' => 'CHECKBOX', 'DEFAULT' => 'Y'],
        'PAUSE_HOVER' => ['PARENT' => 'PLAYBACK', 'NAME' => 'Пауза при наведении', 'TYPE' => 'CHECKBOX', 'DEFAULT' => 'Y'],
        'AUTOPLAY' => ['PARENT' => 'PLAYBACK', 'NAME' => 'Автоматическое переключение', 'TYPE' => 'LIST', 'VALUES' => ['true' => 'Включено', 'false' => 'Выключено'], 'DEFAULT' => 'true'],
        'AUTOPLAY_SPEED' => ['PARENT' => 'PLAYBACK', 'NAME' => 'Интервал переключения, мс', 'TYPE' => 'STRING', 'DEFAULT' => '3000'],
        'SPEED' => ['PARENT' => 'PLAYBACK', 'NAME' => 'Длительность перехода, мс', 'TYPE' => 'STRING', 'DEFAULT' => '600'],
        'CACHE_TIME' => ['DEFAULT' => 300],
    ],
];
