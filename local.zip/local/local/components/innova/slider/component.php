<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) { die(); }
global $USER;

$defaults = [
    'IBLOCK_ID' => 150, 'LINK_PROPERTY' => 'LINK', 'MOBILE_IMAGE_PROPERTY' => 'MOBILE_PICTURE',
    'HEIGHT' => 460, 'HEIGHT_MOBILE' => 150, 'STRETCH_TYPE' => '2', 'STRETCH_TYPE_MOBILE' => '2',
    'SHOW_ARROWS' => 'Y', 'SHOW_DOTS' => 'Y', 'TOUCH' => 'Y', 'PAUSE_HOVER' => 'Y',
    'AUTOPLAY' => 'true', 'AUTOPLAY_SPEED' => 3000, 'SPEED' => 600,
    'BTN_COLOR' => '#FFFFFF', 'SLIDER_COLOR' => '#F4F5F7', 'CACHE_TYPE' => 'N', 'CACHE_TIME' => 300,
];
$arParams = array_replace($defaults, $arParams);
$arParams['IBLOCK_ID'] = max(0, (int)$arParams['IBLOCK_ID']);
foreach (['HEIGHT', 'HEIGHT_MOBILE'] as $key) { $arParams[$key] = max(80, min(1600, (int)$arParams[$key])); }
$arParams['AUTOPLAY_SPEED'] = max(1000, min(60000, (int)$arParams['AUTOPLAY_SPEED']));
$arParams['SPEED'] = max(0, min(3000, (int)$arParams['SPEED']));
$arParams['CACHE_TIME'] = max(0, (int)$arParams['CACHE_TIME']);
$arParams['AUTOPLAY'] = in_array($arParams['AUTOPLAY'], ['true', 'Y', true, 1, '1'], true) ? 'true' : 'false';
foreach (['SHOW_ARROWS', 'SHOW_DOTS', 'TOUCH', 'PAUSE_HOVER'] as $key) { $arParams[$key] = $arParams[$key] === 'N' ? 'N' : 'Y'; }
foreach (['STRETCH_TYPE', 'STRETCH_TYPE_MOBILE'] as $key) { $arParams[$key] = (string)$arParams[$key] === '1' ? '1' : '2'; }
foreach (['LINK_PROPERTY', 'MOBILE_IMAGE_PROPERTY'] as $key) {
    if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/D', (string)$arParams[$key])) { $arParams[$key] = $defaults[$key]; }
}
if (!preg_match('/^#[a-fA-F0-9]{3}(?:[a-fA-F0-9]{3})?$/D', (string)$arParams['BTN_COLOR'])) { $arParams['BTN_COLOR'] = '#FFFFFF'; }
if (!preg_match('/^(?:#[a-fA-F0-9]{3}(?:[a-fA-F0-9]{3})?|rgba?\(\s*[0-9.]+\s*,\s*[0-9.]+\s*,\s*[0-9.]+(?:\s*,\s*[0-9.]+)?\s*\))$/D', (string)$arParams['SLIDER_COLOR'])) {
    $arParams['SLIDER_COLOR'] = '#F4F5F7';
}
if (!\Bitrix\Main\Loader::includeModule('iblock') || $arParams['IBLOCK_ID'] < 1) {
    if (is_object($USER) && $USER->IsAdmin()) { ShowError('Слайдер: выберите существующий инфоблок.'); }
    return;
}
$base = $this->GetPath();
CJSCore::RegisterExt('RLUKS_INNOVA_SLIDER_V2', [
    'js' => [$base . '/lib/min/tiny-slider.js', $base . '/assets/slider.js'],
    'css' => [$base . '/lib/tiny-slider.css', $base . '/assets/slider.css'],
    'rel' => [],
]);
CJSCore::Init(['RLUKS_INNOVA_SLIDER_V2']);

$groups = is_object($USER) ? $USER->GetGroups() : '';
if ($this->StartResultCache(false, ['rluks-slider-v2', SITE_ID, $groups])) {
    try {
        $arResult = ['ITEMS' => []];
        $safeLink = static function ($raw) {
            if (!is_scalar($raw)) { return ''; }
            $url = trim(html_entity_decode((string)$raw, ENT_QUOTES, defined('SITE_CHARSET') ? SITE_CHARSET : 'UTF-8'));
            if ($url === '' || preg_match('/[\x00-\x20\x7f\\\\]/', $url)) { return ''; }
            if (preg_match('~^(?:/(?!/)|\?|#)~', $url)) { return $url; }
            $parts = parse_url($url);
            return is_array($parts) && in_array(strtolower($parts['scheme'] ?? ''), ['https', 'http'], true) && !empty($parts['host']) ? $url : '';
        };
        $rows = CIBlockElement::GetList(['SORT' => 'ASC', 'ID' => 'ASC'], [
            'IBLOCK_ID' => $arParams['IBLOCK_ID'], 'ACTIVE' => 'Y', 'ACTIVE_DATE' => 'Y',
            'CHECK_PERMISSIONS' => 'Y', 'MIN_PERMISSION' => 'R',
        ], false, false, ['ID', 'IBLOCK_ID', 'NAME', 'PREVIEW_PICTURE', 'SORT']);
        while ($element = $rows->GetNextElement()) {
            $fields = $element->GetFields();
            $props = $element->GetProperties();
            $desktop = CFile::GetFileArray((int)$fields['PREVIEW_PICTURE']);
            if (!$desktop || empty($desktop['SRC'])) { continue; }
            $mobileValue = $props[$arParams['MOBILE_IMAGE_PROPERTY']]['VALUE'] ?? null;
            $mobile = is_scalar($mobileValue) ? CFile::GetFileArray((int)$mobileValue) : false;
            if (!$mobile || empty($mobile['SRC'])) { $mobile = $desktop; }
            $linkProp = $props[$arParams['LINK_PROPERTY']] ?? [];
            $link = $safeLink($linkProp['~VALUE'] ?? $linkProp['VALUE'] ?? '');
            $name = trim(strip_tags(html_entity_decode((string)($fields['~NAME'] ?? $fields['NAME']), ENT_QUOTES, defined('SITE_CHARSET') ? SITE_CHARSET : 'UTF-8')));
            $arResult['ITEMS'][] = [
                'ID' => (int)$fields['ID'], 'NAME' => $name ?: 'Баннер', 'URL' => $link,
                'DESKTOP' => $desktop['SRC'], 'MOBILE' => $mobile['SRC'],
                'WIDTH' => max(1, (int)$desktop['WIDTH']), 'HEIGHT' => max(1, (int)$desktop['HEIGHT']),
            ];
        }
        $this->IncludeComponentTemplate();
    } catch (\Throwable $error) {
        $this->AbortResultCache();
        AddMessage2Log($error->getMessage(), 'innova:slider');
        if (is_object($USER) && $USER->IsAdmin()) { ShowError(htmlspecialcharsbx('Слайдер: ' . $error->getMessage())); }
    }
}
