<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) { die(); }
if (empty($arResult['ITEMS'])) { return; }
$this->setFrameMode(true);
$id = 'rluks-slider-' . $this->randString(10);
$escape = static function ($value) { return htmlspecialcharsbx((string)$value); };
$config = [
    'autoplay' => $arParams['AUTOPLAY'] === 'true', 'interval' => (int)$arParams['AUTOPLAY_SPEED'],
    'speed' => (int)$arParams['SPEED'], 'arrows' => $arParams['SHOW_ARROWS'] === 'Y',
    'dots' => $arParams['SHOW_DOTS'] === 'Y', 'touch' => $arParams['TOUCH'] === 'Y',
    'pauseHover' => $arParams['PAUSE_HOVER'] === 'Y',
];
?>
<section id="<?= $escape($id) ?>" class="rluks-banner-slider" aria-label="Предложения магазинов" aria-roledescription="карусель"
    data-rluks-slider="<?= $escape(json_encode($config, JSON_UNESCAPED_UNICODE)) ?>"
    style="--banner-height-desktop:<?= (int)$arParams['HEIGHT'] ?>px;--banner-height-mobile:<?= (int)$arParams['HEIGHT_MOBILE'] ?>px;--banner-fit-desktop:<?= $arParams['STRETCH_TYPE'] === '1' ? 'contain' : 'cover' ?>;--banner-fit-mobile:<?= $arParams['STRETCH_TYPE_MOBILE'] === '1' ? 'contain' : 'cover' ?>;--banner-controls-color:<?= $escape($arParams['BTN_COLOR']) ?>;--banner-background:<?= $escape($arParams['SLIDER_COLOR']) ?>;">
    <div class="rluks-banner-slider__viewport">
        <div class="rluks-banner-slider__track">
            <?php foreach ($arResult['ITEMS'] as $index => $slide): ?>
                <div class="rluks-banner-slider__slide" role="group" aria-roledescription="слайд" aria-label="<?= (int)$index + 1 ?> из <?= count($arResult['ITEMS']) ?>">
                    <?php if ($slide['URL'] !== ''): ?>
                        <a class="rluks-banner-slider__link" href="<?= $escape($slide['URL']) ?>" aria-label="<?= $escape($slide['NAME']) ?>" draggable="false">
                    <?php else: ?>
                        <div class="rluks-banner-slider__link">
                    <?php endif; ?>
                        <picture>
                            <?php if ($slide['MOBILE'] !== $slide['DESKTOP']): ?>
                                <source media="(max-width: 767px)" srcset="<?= $escape($slide['MOBILE']) ?>">
                            <?php endif; ?>
                            <img src="<?= $escape($slide['DESKTOP']) ?>" alt="<?= $escape($slide['NAME']) ?>"
                                width="<?= (int)$slide['WIDTH'] ?>" height="<?= (int)$slide['HEIGHT'] ?>" decoding="async" loading="<?= $index === 0 ? 'eager' : 'lazy' ?>" draggable="false">
                        </picture>
                    <?php if ($slide['URL'] !== ''): ?></a><?php else: ?></div><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="rluks-banner-slider__controls" hidden>
        <button class="rluks-banner-slider__arrow rluks-banner-slider__arrow--prev" type="button" aria-label="Предыдущий слайд"><span aria-hidden="true">‹</span></button>
        <button class="rluks-banner-slider__arrow rluks-banner-slider__arrow--next" type="button" aria-label="Следующий слайд"><span aria-hidden="true">›</span></button>
    </div>
    <div class="rluks-banner-slider__bottom" hidden>
        <div class="rluks-banner-slider__dots" aria-label="Выбор слайда" hidden>
            <?php foreach ($arResult['ITEMS'] as $index => $slide): ?>
                <button type="button" aria-label="Слайд <?= (int)$index + 1 ?> из <?= count($arResult['ITEMS']) ?>"></button>
            <?php endforeach; ?>
        </div>
        <button class="rluks-banner-slider__pause" type="button" hidden>Пауза</button>
    </div>
</section>
