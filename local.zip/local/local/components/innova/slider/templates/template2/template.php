<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) { die(); }
// Preserve calls using the original template2 name; both use the banner-only view.
include dirname(__DIR__) . '/.default/template.php';
