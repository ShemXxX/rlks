<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) { die(); }
$arComponentDescription = [
    'NAME' => 'Слайдер баннеров Innova — версия Рлакс',
    'DESCRIPTION' => 'Кликабельные баннеры с отдельным изображением для телефона, стрелками и точками.',
    'PATH' => ['ID' => 'innova', 'NAME' => 'Innova'],
];
