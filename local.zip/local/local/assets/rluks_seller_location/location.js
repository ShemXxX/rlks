(function () {
    'use strict';
    if (window.RluksSellerLocationUI) { window.RluksSellerLocationUI.scan(); return; }
    var api = '/local/tools/rluks_seller_location.php';
    var mapPromise;
    function el(tag, text, attrs) {
        var node = document.createElement(tag);
        if (text !== null && text !== undefined) node.textContent = text;
        Object.keys(attrs || {}).forEach(function (k) { node.setAttribute(k, attrs[k]); });
        return node;
    }
    function input(root, name, value, type) {
        var node = el('input', null, { name: name, type: type || 'hidden' });
        node.value = value === null || value === undefined ? '' : value;
        root.appendChild(node); return node;
    }
    function label(root, text, node) { var l = el('label', text); l.appendChild(document.createElement('br')); l.appendChild(node); root.appendChild(l); }
    function maps(key) {
        if (window.ymaps) return new Promise(function (resolve) { window.ymaps.ready(function () { resolve(window.ymaps); }); });
        if (!mapPromise) mapPromise = new Promise(function (resolve, reject) {
            var pending = Array.prototype.find.call(document.scripts, function (node) { return node.src.indexOf('api-maps.yandex.ru/2.1') >= 0; });
            if (pending) {
                var timeout = setTimeout(function () { reject(new Error('Карта не загрузилась. Можно указать координаты вручную.')); }, 15000);
                pending.addEventListener('load', function () { clearTimeout(timeout); if (!window.ymaps) return reject(new Error('Карта недоступна.')); window.ymaps.ready(function () { resolve(window.ymaps); }); }, { once: true });
                pending.addEventListener('error', function () { clearTimeout(timeout); reject(new Error('Карта недоступна.')); }, { once: true });
                return;
            }
            var script = document.createElement('script');
            script.src = 'https://api-maps.yandex.ru/2.1/?lang=ru_RU&apikey=' + encodeURIComponent(key || '');
            script.onload = function () { if (!window.ymaps) return reject(new Error('Карта недоступна.')); window.ymaps.ready(function () { resolve(window.ymaps); }); };
            script.onerror = function () { reject(new Error('Карта недоступна. Можно указать координаты вручную.')); };
            document.head.appendChild(script);
        });
        return mapPromise;
    }
    function config(user) {
        return fetch(api + '?mode=profile' + (user ? '&user_id=' + encodeURIComponent(user) : ''), { credentials: 'same-origin', cache: 'no-store' })
            .then(function (r) { return r.json(); }).then(function (r) { if (!r.ok) throw new Error(r.error); return r; });
    }
    function widget(root, data, forceReadonly) {
        root.textContent = '';
        var profile = data.profile;
        var readonly = !!forceReadonly || (root.dataset.mode === 'application' && profile.set);
        var district = data.districts.find(function (d) { return d.id === profile.district; });
        var form = root.closest('form');
        input(root, 'RL_TOKEN', data.token);
        root.appendChild(el('h4', 'Местоположение магазина'));
        var select, lat, lon, address;
        if (readonly) {
            root.appendChild(el('p', 'Район: ' + (district ? district.name : 'не указан')));
            root.appendChild(el('p', profile.address || ('Координаты: ' + profile.lat + ', ' + profile.lon)));
            root.appendChild(el('small', 'Для изменения района или точки магазина обратитесь к администратору.'));
        } else {
            select = el('select', null, { name: 'RL_DISTRICT', required: 'required', style: 'width:100%' });
            select.appendChild(el('option', 'Выберите район', { value: '' }));
            data.districts.forEach(function (d) { select.appendChild(el('option', d.name, { value: d.id })); });
            select.value = profile.district || '';
            label(root, 'Район *', select);
            address = el('input', null, { name: 'RL_ADDRESS', type: 'text', maxlength: '500', style: 'width:100%', placeholder: 'Улица, дом, магазин' });
            address.value = profile.address || ''; label(root, 'Адрес магазина', address);
            var coords = el('div', null, { 'class': 'rluks-coordinates' }); root.appendChild(coords);
            lat = el('input', null, { name: 'RL_LAT', type: 'number', step: 'any', min: '-90', max: '90', required: 'required' });
            lon = el('input', null, { name: 'RL_LON', type: 'number', step: 'any', min: '-180', max: '180', required: 'required' });
            lat.value = profile.set ? profile.lat : ''; lon.value = profile.set ? profile.lon : '';
            label(coords, 'Широта *', lat); label(coords, 'Долгота *', lon);
            root.appendChild(el('small', 'Найдите магазин на карте и выберите точную точку. После подачи заявки изменить её сможет только администратор.'));
        }
        var mapRoot = el('div', null, { 'class': 'rluks-location-map', style: 'height:320px;width:100%;margin:16px 0' });
        root.appendChild(mapRoot);
        maps(data.mapKey).then(function (ymaps) {
            var center = profile.set ? [profile.lat, profile.lon] : (district && district.coordinates.length ? district.coordinates : [47.2357, 39.7015]);
            var map = new ymaps.Map(mapRoot, { center: center, zoom: profile.set ? 16 : 11, controls: ['zoomControl', 'fullscreenControl'] });
            var marker = null;
            function mark(point, write, resolvedAddress) {
                if (marker) marker.geometry.setCoordinates(point);
                else { marker = new ymaps.Placemark(point, {}, { draggable: !readonly, preset: 'islands#violetDotIcon' }); map.geoObjects.add(marker); marker.events.add('dragend', function () { mark(marker.geometry.getCoordinates(), true); }); }
                if (write && lat && lon) { lat.value = Number(point[0]).toFixed(7); lon.value = Number(point[1]).toFixed(7); if (resolvedAddress && address) address.value = resolvedAddress; }
            }
            if (profile.set) mark(center, false);
            if (!readonly) {
                map.events.add('click', function (e) { mark(e.get('coords'), true); });
                var search = new ymaps.control.SearchControl({ options: { noPlacemark: true } }); map.controls.add(search);
                search.events.add('resultselect', function (e) { search.getResult(e.get('index')).then(function (result) { var point = result.geometry.getCoordinates(); mark(point, true, result.properties.get('text') || ''); map.setCenter(point, 16); }); });
                select.addEventListener('change', function () { var d = data.districts.find(function (x) { return String(x.id) === select.value; }); if (d && d.coordinates && d.coordinates.length) map.setCenter(d.coordinates, 12); });
                [lat, lon].forEach(function (node) { node.addEventListener('change', function () { if (lat.value && lon.value) { var point = [Number(lat.value), Number(lon.value)]; if (isFinite(point[0]) && isFinite(point[1])) { mark(point, false); map.setCenter(point); } } }); });
            } else map.behaviors.disable('scrollZoom');
        }).catch(function (e) { mapRoot.textContent = e.message; });
        if (form) form.dataset.rluksLocationReady = '1';
    }
    function applicationWidgets() {
        document.querySelectorAll('.rluks-location-widget:not([data-ready])').forEach(function (root) {
            root.dataset.ready = 'loading'; var form = root.closest('form');
            var submitGuard = function (e) { if (form.dataset.rluksLocationReady !== '1') { e.preventDefault(); alert('Дождитесь загрузки местоположения магазина.'); } };
            if (form) form.addEventListener('submit', submitGuard);
            config(root.dataset.user).then(function (data) { widget(root, data, false); root.dataset.ready = '1'; })
                .catch(function (e) { root.textContent = e.message; root.dataset.ready = 'error'; });
        });
    }
    function productForms() {
        if (!/\/user\/(?:create\/?|items\/\d+-\d+\/?)$/.test(location.pathname)) return;
        var fields = document.querySelectorAll('form.edit-form input[name="location"], form.edit-form select[name="city"]');
        if (!fields.length) return;
        config().then(function (data) {
            if (!data.active) return;
            if (data.admin) return;
            var forms = [];
            fields.forEach(function (field) { var form = field.closest('form'); if (forms.indexOf(form) < 0) forms.push(form); });
            forms.forEach(function (form) {
                if (form.dataset.rluksLocationLocked) return;
                form.dataset.rluksLocationLocked = '1';
                var root = el('div', null, { 'class': 'rluks-location-widget', 'data-mode': 'readonly' });
                if (!data.profile.set) { root.textContent = 'Администратор должен указать район и точку магазина в вашем профиле.'; form.insertBefore(root, form.firstChild); return; }
                form.querySelectorAll('.map-container').forEach(function (container) { container.hidden = true; container.style.setProperty('display', 'none', 'important'); });
                form.querySelectorAll('select[name="city"],select[name="region"]').forEach(function (field) {
                    if (field.name === 'city') field.value = String(data.profile.district);
                    field.disabled = true;
                    field.required = false; field.classList.remove('required');
                    var group = field.closest('.group'); if (group) { group.hidden = true; group.style.setProperty('display', 'none', 'important'); }
                });
                var locationField = form.querySelector('input[name="location"]');
                if (locationField) locationField.value = data.profile.lat + ',' + data.profile.lon;
                else input(form, 'location', data.profile.lat + ',' + data.profile.lon);
                input(form, 'city', data.profile.district);
                var oldMap = form.querySelector('.map-container');
                if (oldMap) oldMap.parentNode.insertBefore(root, oldMap); else form.insertBefore(root, form.firstChild);
                widget(root, data, true);
            });
        }).catch(function (e) { console.error('РЛАКС: ' + e.message); });
    }
    function scan() { applicationWidgets(); productForms(); }
    window.RluksSellerLocationUI = { scan: scan };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', scan); else scan();
})();
