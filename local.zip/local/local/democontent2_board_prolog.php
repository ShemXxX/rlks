<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 17.09.2018
 * Time: 18:58
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */

require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

use Bitrix\Main\Application;
use Bitrix\Main\IO\Directory;
use Bitrix\Main\IO\Path;
use Bitrix\Main\Loader;
use Bitrix\Main\Web\Json;

if (!defined('DBOARD')) {
    define('DBOARD', 'democontent2.board');
}

Loader::includeModule(DBOARD);

$router = new \Democontent2\Board\Router($_GET);
$includeComponent = $router->getMap();

header('Content-Type: application/json');

if (!empty($includeComponent) && count($includeComponent) > 0) {
    if (Directory::isDirectoryExists(
            Path::normalize(
                Application::getDocumentRoot() . '/local/components/'
                . ((isset($includeComponent['namespace'])) ? $includeComponent['namespace'] : DBOARD) . '/' . $includeComponent['component'])
        )
        || Directory::isDirectoryExists(
            Path::normalize(
                Application::getDocumentRoot() . '/bitrix/components/'
                . ((isset($includeComponent['namespace'])) ? $includeComponent['namespace'] : DBOARD) . '/' . $includeComponent['component'])
        )
    ) {
        $APPLICATION->IncludeComponent(
            ((isset($includeComponent['namespace'])) ? $includeComponent['namespace'] : DBOARD) . ":" . $includeComponent['component'],
            ((isset($includeComponent['template'])) ? $includeComponent['template'] : '.default'),
            ((isset($includeComponent['params']) && !empty($includeComponent['params'])) ? $includeComponent['params'] : [])
        );
    } else {
        echo Json::encode(['error' => 1]);
    }
} else {
    echo Json::encode(['error' => 1]);
}
