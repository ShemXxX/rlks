<?php
/**
 * Created by PhpStorm.
 * User: Deleka
 * Date: 16.02.2019
 * Time: 4:12
 */

class decode
{

  static function getUserMenus() {
    /** check user authorization */
    global $USER;
    $arMenus = array();
    if ($USER->IsAuthorized()) {

      /** get user groups array */
      $arUserGroups = $USER->GetUserGroupArray();

      /** get menus by group */
      debug::console($arUserGroups, "группы пользователя");

      /** get menus */
      $arSelect = Array("*");
      $arFilter = Array("IBLOCK_ID"=>IntVal(94), "ACTIVE"=>"Y");
      $res = CIBlockElement::GetList(Array(), $arFilter, false, false, $arSelect);
      while($ob = $res->GetNextElement())
      {
        $arFields = $ob->GetFields();
        $arProps = $ob->GetProperties();

        $arGroups = $arProps['SHOW_IN_GROUPS']['VALUE_XML_ID'];

        foreach ($arUserGroups as $groupId) {
          if (in_array("G_".$groupId, $arProps['SHOW_IN_GROUPS']['VALUE_XML_ID'])) {
            debug::console($arProps['SHOW_IN_GROUPS']['VALUE_XML_ID'], $arFields['NAME']." в группе");

          }

        }
        debug::console($arFields['NAME']);
      }

    } else {
      $arMenus = array();
    }
    return $arMenus;
  }


  static function IsSeller () {
    global $USER;
    $userId = $USER->GetID();
    $rsUser = CUser::GetByID($userId);
    $arUser = $rsUser->Fetch();
    $seller = true;
    if (in_array(5, $USER->GetUserGroupArray())) {
      $seller = false;
    } else if (in_array(6, $USER->GetUserGroupArray())) {
      $seller = true;

    }
    return $seller;
  }
}