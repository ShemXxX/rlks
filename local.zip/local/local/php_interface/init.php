<?
require_once $_SERVER['DOCUMENT_ROOT'] . '/local/php_interface/rluks_seller_location/bootstrap.php';
use Bitrix\Main\EventManager;
CModule::AddAutoloadClasses(
  '', // не указываем имя модуля
  array(
    // ключ - имя класса, значение - путь относительно корня сайта к файлу с классом
    'debug' => '/local/classes/debug.php', // функции дебаггера
    'decode' => '/local/classes/decode.php', // функции Дениса
  )
);

/*
EventManager::getInstance()->addEventHandler(
    "iblock",
    "OnAfterIBlockElementAdd",
    "callDemocontentBoardAddHandler"
);
function callDemocontentBoardAddHandler(&$arFields) 
{
	$eventHandler = new \Democontent2\Board\Events\Elements\Add();
	$eventHandler->handler($arFields);
}
*/