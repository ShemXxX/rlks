<?php
namespace Rluks\SellerLocation;

use Bitrix\Main\Application;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Loader;
use Bitrix\Highloadblock\HighloadBlockTable;

final class Location
{
    const FIELDS = ['UF_RL_DISTRICT'=>'integer','UF_RL_LAT'=>'double','UF_RL_LON'=>'double','UF_RL_ADDRESS'=>'string','UF_RL_LOC_SET'=>'boolean'];
    const AGENT = '\\Rluks\\SellerLocation\\Location::agent();';
    private static $prepared = [];
    private static $before = [];
    private static $syncing = false;
    private static $propertyIds = [];
    public static function enabled() { return Option::get('main','rluks_location_enabled','N')==='Y'; }

    public static function modules() {
        foreach (['iblock','highloadblock','democontent2.board'] as $m) {
            if (!Loader::includeModule($m)) throw new \RuntimeException('Не подключён модуль '.$m);
        }
    }
    public static function escape($v) { return htmlspecialchars((string)$v, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
    public static function admin() { global $USER; return $USER && $USER->IsAdmin(); }
    public static function user($id) { return \CUser::GetByID((int)$id)->Fetch() ?: []; }
    public static function profile($id) {
        $u=self::user($id);
        return ['district'=>(int)($u['UF_RL_DISTRICT']??0),'lat'=>(float)($u['UF_RL_LAT']??0),
            'lon'=>(float)($u['UF_RL_LON']??0),'address'=>(string)($u['UF_RL_ADDRESS']??''),
            'set'=>!empty($u['UF_RL_LOC_SET'])];
    }
    public static function districts() {
        self::modules(); $city=new \Democontent2\Board\Iblock\City(); $city->setTtl(0);
        $out=[];
        foreach ($city->getList(0,0,false,false) as $row) {
            $out[(int)$row['id']]=['id'=>(int)$row['id'],'name'=>$row['name'],'coordinates'=>$row['coordinates']??[]];
        }
        return $out;
    }
    public static function numeric($v) {
        if (!is_scalar($v) || !preg_match('/^-?\d+(?:[.,]\d+)?$/D',trim((string)$v))) throw new \InvalidArgumentException('Укажите корректные координаты.');
        $n=(float)str_replace(',','.',trim((string)$v));
        if (!is_finite($n)) throw new \InvalidArgumentException('Некорректные координаты.');
        return $n;
    }
    public static function normalize(array $data, array $districts) {
        $raw=$data['district']??'';
        if (!is_scalar($raw) || !preg_match('/^[1-9]\d*$/D',(string)$raw) || !isset($districts[(int)$raw])) throw new \InvalidArgumentException('Выберите район из списка.');
        $lat=self::numeric($data['lat']??''); $lon=self::numeric($data['lon']??'');
        if ($lat < -90 || $lat > 90 || $lon < -180 || $lon > 180 || ($lat==0 && $lon==0)) throw new \InvalidArgumentException('Выберите точку магазина на карте.');
        if (!is_scalar($data['address']??'')) throw new \InvalidArgumentException('Некорректный адрес.');
        $address=trim(strip_tags((string)($data['address']??'')));
        if (mb_strlen($address)>500) throw new \InvalidArgumentException('Адрес не должен превышать 500 символов.');
        return ['district'=>(int)$raw,'lat'=>$lat,'lon'=>$lon,'address'=>$address,'set'=>true];
    }
    public static function formData(array $post) {
        return self::normalize(['district'=>$post['RL_DISTRICT']??'', 'lat'=>$post['RL_LAT']??'',
            'lon'=>$post['RL_LON']??'', 'address'=>$post['RL_ADDRESS']??''],self::districts());
    }
    public static function fields(array $p) {
        return ['UF_RL_DISTRICT'=>$p['district'],'UF_RL_LAT'=>$p['lat'],'UF_RL_LON'=>$p['lon'],
            'UF_RL_ADDRESS'=>$p['address'],'UF_RL_LOC_SET'=>1];
    }
    public static function token() {
        global $USER;
        $id=(int)$USER->GetID();
        if (!isset($_SESSION['RLUKS_LOCATION_TOKEN'],$_SESSION['RLUKS_LOCATION_TOKEN_USER']) || $_SESSION['RLUKS_LOCATION_TOKEN_USER']!==$id) {
            $_SESSION['RLUKS_LOCATION_TOKEN']=bin2hex(random_bytes(32)); $_SESSION['RLUKS_LOCATION_TOKEN_USER']=$id;
        }
        return $_SESSION['RLUKS_LOCATION_TOKEN'];
    }
    public static function validToken(array $post) {
        return isset($post['RL_TOKEN']) && is_string($post['RL_TOKEN']) && hash_equals(self::token(),$post['RL_TOKEN']);
    }
    public static function prepareApplication(array $post) {
        global $USER;
        if (!$USER || !$USER->IsAuthorized()) throw new \RuntimeException('Войдите в аккаунт.');
        if (!self::validToken($post)) throw new \RuntimeException('Форма устарела. Откройте страницу заново.');
        $id=(int)$USER->GetID(); $old=self::profile($id);
        if ($old['set']) { self::$prepared[$id]=$old; return; }
        $user=self::user($id);
        if (!self::admin() && (int)($user['UF_IS_SELLER']??0)!==1) throw new \RuntimeException('Заполнение заявки пока недоступно.');
        self::$prepared[$id]=self::formData($post);
    }
    public static function prepareApplicationOrStop(array $post) {
        if(!self::enabled())return;
        try { self::prepareApplication($post); }
        catch (\Throwable $e) {
            http_response_code(400);
            echo '<meta charset="utf-8"><p>'.self::escape($e->getMessage()).'</p><p><a href="'.self::escape(parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH)).'">Вернуться к заявке</a></p>';
            exit;
        }
    }
    public static function beforeUserUpdate(&$fields) {
        global $USER,$APPLICATION;
        $id=(int)($fields['ID']??0); if (!$id) return true;
        $touch=false; foreach(self::FIELDS as $key=>$type) if(array_key_exists($key,$fields)) $touch=true;
        if (!$touch && !isset(self::$prepared[$id])) return true;
        try {
            $old=self::profile($id); self::$before[$id]=$old;
            if (isset(self::$prepared[$id]) && (int)$USER->GetID()===$id && !$old['set']) {
                foreach(self::FIELDS as $key=>$type) unset($fields[$key]);
                $fields=array_merge($fields,self::fields(self::$prepared[$id])); return true;
            }
            if (!self::admin()) {
                foreach(self::FIELDS as $key=>$type) unset($fields[$key]);
                if ($touch) throw new \RuntimeException('Район и местоположение магазина меняет только администратор.');
                return true;
            }
            $p=['district'=>$fields['UF_RL_DISTRICT']??$old['district'],'lat'=>$fields['UF_RL_LAT']??$old['lat'],
                'lon'=>$fields['UF_RL_LON']??$old['lon'],'address'=>$fields['UF_RL_ADDRESS']??$old['address']];
            if (!$old['set'] && empty($p['district']) && empty($p['lat']) && empty($p['lon']) && empty($p['address'])) {
                foreach(self::FIELDS as $key=>$type) unset($fields[$key]); return true;
            }
            $fields=array_merge($fields,self::fields(self::normalize($p,self::districts()))); return true;
        } catch(\Throwable $e) { $APPLICATION->ThrowException($e->getMessage()); return false; }
    }
    public static function beforeUserAdd(&$fields) {
        if (!self::admin()) foreach(self::FIELDS as $key=>$type) unset($fields[$key]);
        return true;
    }
    public static function afterUserUpdate(&$fields) {
        $id=(int)($fields['ID']??0);
        if (!$id || empty($fields['RESULT']) || !isset(self::$before[$id])) return;
        $old=self::$before[$id]; unset(self::$before[$id],self::$prepared[$id]); $new=self::profile($id);
        if ($new['set'] && $old!==$new) {
            try { self::queue($id,true); self::runBatch($id,20); }
            catch (\Throwable $e) { self::log($e); }
        }
    }
    public static function productBlock($id) {
        if (!Loader::includeModule('iblock')) return false;
        $b=\CIBlock::GetByID((int)$id)->Fetch();
        return $b && preg_match('/^democontent2_board_[a-z_]+$/D',$b['IBLOCK_TYPE_ID']);
    }
    public static function propertyIds($block) {
        if (!isset(self::$propertyIds[$block])) {
            self::$propertyIds[$block]=[]; $r=\CIBlockProperty::GetList([],['IBLOCK_ID'=>$block]);
            while($p=$r->Fetch()) self::$propertyIds[$block][$p['CODE']]=(int)$p['ID'];
        }
        return self::$propertyIds[$block];
    }
    private static function propInput(array $props,$code,array $ids) {
        $v=$props[$code]??($props[$ids[$code]??0]??null);
        if (is_array($v)) { if(array_key_exists('VALUE',$v)) $v=$v['VALUE']; else { $v=reset($v); if(is_array($v)) $v=$v['VALUE']??null; } }
        return $v;
    }
    private static function injectProperty(&$fields,$code,$value,array $ids) {
        if(!isset($ids[$code])) throw new \RuntimeException('Нет свойства '.$code.' в инфоблоке.');
        unset($fields['PROPERTY_VALUES'][$code],$fields['PROPERTY_VALUES'][$ids[$code]]);
        $fields['PROPERTY_VALUES'][$ids[$code]]=$value;
    }
    public static function beforeElementAdd(&$fields) {
        global $USER,$APPLICATION;
        $block=(int)($fields['IBLOCK_ID']??0); if(!self::productBlock($block)) return true;
        try {
            $ids=self::propertyIds($block); $owner=(int)self::propInput($fields['PROPERTY_VALUES']??[],'__hidden_user',$ids);
            if (!self::admin()) { $owner=(int)$USER->GetID(); if(!$owner) throw new \RuntimeException('Для размещения товара войдите в аккаунт.'); }
            $p=self::profile($owner);
            if (!$p['set']) { if(self::admin()) return true; throw new \RuntimeException('Администратор должен заполнить местоположение магазина в вашем профиле.'); }
            self::normalize($p,self::districts());
            self::injectProperty($fields,'__hidden_user',$owner,$ids);
            self::injectProperty($fields,'__hidden_city',$p['district'],$ids);
            self::injectProperty($fields,'__hidden_location',self::coordinateString($p),$ids);
            return true;
        } catch(\Throwable $e) { $APPLICATION->ThrowException($e->getMessage());return false; }
    }
    public static function coordinateString(array $p) {
        return sprintf('%.7F,%.7F',$p['lat'],$p['lon']);
    }
    private static function props($element,$block) {
        $values=[]; $r=\CIBlockElement::GetProperty($block,$element,[],[]);
        while($p=$r->Fetch()) if(in_array($p['CODE'],['__hidden_user','__hidden_city','__hidden_location'],true)) $values[$p['CODE']]=$p['VALUE'];
        return $values;
    }
    public static function beforeElementUpdate(&$fields) {
        global $APPLICATION;
        $id=(int)($fields['ID']??0);if(!$id)return true;
        $element=\CIBlockElement::GetByID($id)->Fetch();
        if(!$element || !self::productBlock($element['IBLOCK_ID']))return true;
        $props=self::props($id,(int)$element['IBLOCK_ID']);$p=self::profile((int)($props['__hidden_user']??0));
        if(!$p['set'])return true;
        try {
            if(isset($fields['PROPERTY_VALUES'])) {
                $ids=self::propertyIds((int)$element['IBLOCK_ID']);
                self::injectProperty($fields,'__hidden_city',$p['district'],$ids);
                self::injectProperty($fields,'__hidden_location',self::coordinateString($p),$ids);
            }
            return true;
        }catch(\Throwable $e){$APPLICATION->ThrowException($e->getMessage());return false;}
    }
    public static function afterElement(&$fields) {
        if(self::$syncing || empty($fields['ID']) || (isset($fields['RESULT']) && !$fields['RESULT']))return;
        try { self::syncElement((int)$fields['ID'],(int)$fields['IBLOCK_ID']); } catch(\Throwable $e){self::log($e);}
    }
    public static function afterProperties($element,$block) {
        if(self::$syncing)return;
        try { self::syncElement((int)$element,(int)$block); }catch(\Throwable $e){self::log($e);}
    }
    private static function dataClass($name) {
        $hl=HighloadBlockTable::getList(['filter'=>['=NAME'=>$name]])->fetch();
        if(!$hl)return null;
        return HighloadBlockTable::compileEntity($hl)->getDataClass();
    }
    public static function syncElement($id,$block,$expectedOwner=0) {
        self::modules(); if(!self::productBlock($block))return false;
        $props=self::props($id,$block);$owner=(int)($props['__hidden_user']??0);
        if(!$owner || ($expectedOwner && $expectedOwner!==$owner))return false;
        $p=self::profile($owner);if(!$p['set'])return false;
        self::normalize($p,self::districts());
        $name=ucfirst(strtolower(preg_replace('/[^a-zA-Z]/','',md5((string)$block))));
        $class=self::dataClass($name);
        if(!$class)throw new \RuntimeException('У инфоблока #'.$block.' отсутствует HL-блок. Сначала восстановите его.');
        $rows=$class::getList(['select'=>['ID','UF_CITY'],'filter'=>['=UF_IBLOCK_ID'=>$block,'=UF_ID'=>$id]]);
        $hlRows=[];while($row=$rows->fetch())$hlRows[]=$row;
        if(!$hlRows){
            // During Add(), properties may be written before the module creates its HL row.
            // The later OnAfterIBlockElementAdd handler will synchronize it.
            if(!$expectedOwner)return false;
            throw new \RuntimeException('Нет записи товара #'.$id.' в HL-блоке инфоблока #'.$block.'.');
        }
        $previous=self::$syncing;self::$syncing=true;
        try {
            $ids=self::propertyIds($block);
            foreach(['__hidden_city','__hidden_location'] as $code)if(!isset($ids[$code]))throw new \RuntimeException('Нет свойства '.$code.'.');
            \CIBlockElement::SetPropertyValuesEx($id,$block,['__hidden_city'=>$p['district'],'__hidden_location'=>self::coordinateString($p)]);
            $verify=self::props($id,$block);
            if((int)($verify['__hidden_city']??0)!==$p['district'] || (string)($verify['__hidden_location']??'')!==self::coordinateString($p))throw new \RuntimeException('Не удалось записать местоположение товара #'.$id.'.');
            foreach($hlRows as $row) {
                $r=$class::update($row['ID'],['UF_CITY'=>$p['district'],'UF_LAT'=>$p['lat'],'UF_LONG'=>$p['lon']]);
                if(!$r->isSuccess())throw new \RuntimeException(implode('; ',$r->getErrorMessages()));
                self::clearLocationCache($id,$block,(int)$row['UF_CITY'],$p['district']);
            }
            foreach(['Democontentboardtemppremium','Democontentboardtempvip'] as $service) {
                $serviceClass=self::dataClass($service);if(!$serviceClass)continue;
                $serviceRows=$serviceClass::getList(['select'=>['ID','UF_CITY_ID'],'filter'=>['=UF_IBLOCK_ID'=>$block,'=UF_ITEM_ID'=>$id]]);
                while($row=$serviceRows->fetch()) {
                    $r=$serviceClass::update($row['ID'],['UF_CITY_ID'=>$p['district']]);
                    if(!$r->isSuccess())throw new \RuntimeException(implode('; ',$r->getErrorMessages()));
                    self::clearLocationCache($id,$block,(int)$row['UF_CITY_ID'],$p['district']);
                }
            }
            if(Loader::includeModule('search'))\CSearch::ChangeIndex('iblock',['PARAM1'=>$p['district']],(string)$id,false,(string)$block);
            if(class_exists('Bitrix\\Iblock\\PropertyIndex\\Manager'))\Bitrix\Iblock\PropertyIndex\Manager::updateElementIndex($block,$id);
        }finally{self::$syncing=$previous;}
        return true;
    }
    private static function clearLocationCache($id,$block,$old,$new) {
        $cache=Application::getInstance()->getTaggedCache();
        foreach(['element_id_'.$id,'iblock_id_'.$block,'iblock_id_'.$block.'_city_id_'.$old,'iblock_id_'.$block.'_city_id_'.$new,
            md5('premium'.$old),md5('premium'.$new),md5('vip'.$old),md5('vip'.$new),'premium'] as $tag)$cache->clearByTag($tag);
    }
    private static function jobKey($id){return 'rluks_location_sync_'.(int)$id;}
    public static function job($id){$j=json_decode(Option::get('main',self::jobKey($id),''),true);return is_array($j)?$j:[];}
    private static function lock($id) {
        $fp=fopen(sys_get_temp_dir().'/rluks_location_'.sha1($_SERVER['DOCUMENT_ROOT']).'_'.$id.'.lock','c');
        if(!$fp || !flock($fp,LOCK_EX|LOCK_NB)){if(is_resource($fp))fclose($fp);throw new \RuntimeException('Синхронизация уже выполняется. Повторите через несколько секунд.');}
        return $fp;
    }
    public static function queue($id,$force=false) {
        self::modules();$p=self::profile($id);if(!$p['set'])throw new \RuntimeException('Нет местоположения продавца.');
        $fp=self::lock($id);
        try {
            $hash=hash('sha256',json_encode($p));$job=self::job($id);
            if(!$force && ($job['hash']??'')===$hash)return;
            $blocks=[];$r=\CIBlock::GetList([],[],false);
            while($b=$r->Fetch())if(preg_match('/^democontent2_board_[a-z_]+$/D',$b['IBLOCK_TYPE_ID']))$blocks[]=(int)$b['ID'];
            sort($blocks);
            $last=\CIBlockElement::GetList(['ID'=>'DESC'],[],false,['nTopCount'=>1],['ID'])->Fetch();
            $job=['user'=>(int)$id,'hash'=>$hash,'blocks'=>$blocks,'block'=>0,'after'=>0,'max'=>(int)($last['ID']??0),
                'status'=>'pending','processed'=>0,'error'=>'','updated'=>date('c')];
            Option::set('main',self::jobKey($id),json_encode($job));
        }finally{flock($fp,LOCK_UN);fclose($fp);}
    }
    public static function runBatch($id,$limit=25) {
        self::modules();$fp=self::lock($id);$job=self::job($id);
        try {
            if(!$job || $job['status']==='done')return $job;
            $p=self::profile($id);
            if(!$p['set'] || ($job['hash']??'')!==hash('sha256',json_encode($p)))throw new \RuntimeException('Местоположение изменилось. Запустите синхронизацию заново.');
            $used=0;$job['error']='';
            while($job['block']<count($job['blocks']) && $used<$limit) {
                $block=$job['blocks'][$job['block']];
                if(!self::productBlock($block)){$job['block']++;$job['after']=0;continue;}
                $elements=\CIBlockElement::GetList(['ID'=>'ASC'],['IBLOCK_ID'=>$block,'PROPERTY___hidden_user'=>$id,
                    '>ID'=>$job['after'],'<=ID'=>$job['max'],'CHECK_PERMISSIONS'=>'N'],false,['nTopCount'=>$limit-$used],['ID']);
                $found=0;
                while($e=$elements->Fetch()) {
                    self::syncElement((int)$e['ID'],$block,(int)$id);
                    $job['after']=(int)$e['ID'];$job['processed']++;$found++;$used++;
                    Option::set('main',self::jobKey($id),json_encode($job));
                }
                if(!$found){$job['block']++;$job['after']=0;}
            }
            $job['status']=$job['block']>=count($job['blocks'])?'done':'pending';
        }catch(\Throwable $e){$job['status']='error';$job['error']=$e->getMessage();}
        finally {
            if($job){$job['updated']=date('c');Option::set('main',self::jobKey($id),json_encode($job));}
            flock($fp,LOCK_UN);fclose($fp);
        }
        return $job;
    }
    public static function agent() {
        if(!self::enabled())return self::AGENT;
        foreach(Option::getForModule('main') as $key=>$value) {
            if(strpos($key,'rluks_location_sync_')!==0)continue;
            $job=json_decode($value,true);
            if(!is_array($job) || empty($job['user']))continue;
            try{
                $id=(int)$job['user'];$current=self::profile($id);
                if($current['set'] && ($job['hash']??'')!==hash('sha256',json_encode($current))){
                    self::queue($id,true);$job=self::job($id);
                }
                if(($job['status']??'')!=='pending')continue;
                self::runBatch($id,25);
            }catch(\Throwable $e){self::log($e);}
            break;
        }
        return self::AGENT;
    }
    public static function onBeforeProlog() {
        global $USER;
        if(defined('ADMIN_SECTION') && ADMIN_SECTION===true)return;
        if(!$USER || !$USER->IsAuthorized())return;
        $path=parse_url($_SERVER['REQUEST_URI']??'',PHP_URL_PATH);
        if(!preg_match('~/user/(?:create/?|items/\d+-\d+/?)$~',$path))return;
        \Bitrix\Main\Page\Asset::getInstance()->addJs('/local/assets/rluks_seller_location/location.js');
        if(($_SERVER['REQUEST_METHOD']??'')==='POST' && (isset($_POST['name']) || isset($_POST['location']))) {
            if(self::admin())return;
            $p=self::profile((int)$USER->GetID());
            if(!$p['set']){http_response_code(400);echo '<meta charset="utf-8"><p>Администратор должен заполнить район и точку магазина в вашем профиле.</p>';exit;}
            $_POST['city']=$p['district'];$_POST['location']=self::coordinateString($p);
        }
    }
    public static function renderApplicationFields() {
        if(!self::enabled())return;
        global $USER;
        echo '<div class="rluks-location-widget" data-mode="application"><p>Местоположение магазина загружается…</p></div>';
        echo '<script src="/local/assets/rluks_seller_location/location.js"></script>';
    }
    public static function log(\Throwable $e){if(function_exists('AddMessage2Log'))AddMessage2Log($e->getMessage(),'rluks.sellerlocation');}
}
