<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true) return;
if (defined('RLUKS_LOCATION_BOOTSTRAPPED')) return;
define('RLUKS_LOCATION_BOOTSTRAPPED',true);
require_once __DIR__.'/Location.php';
if (!\Rluks\SellerLocation\Location::enabled()) return;
$rluksLocationClass='\\Rluks\\SellerLocation\\Location';
AddEventHandler('main','OnBeforeUserAdd',[$rluksLocationClass,'beforeUserAdd'],10000);
AddEventHandler('main','OnBeforeUserUpdate',[$rluksLocationClass,'beforeUserUpdate'],10000);
AddEventHandler('main','OnAfterUserUpdate',[$rluksLocationClass,'afterUserUpdate'],10000);
AddEventHandler('main','OnBeforeProlog',[$rluksLocationClass,'onBeforeProlog'],10000);
AddEventHandler('iblock','OnBeforeIBlockElementAdd',[$rluksLocationClass,'beforeElementAdd'],10000);
AddEventHandler('iblock','OnBeforeIBlockElementUpdate',[$rluksLocationClass,'beforeElementUpdate'],10000);
AddEventHandler('iblock','OnAfterIBlockElementAdd',[$rluksLocationClass,'afterElement'],10000);
AddEventHandler('iblock','OnAfterIBlockElementUpdate',[$rluksLocationClass,'afterElement'],10000);
AddEventHandler('iblock','OnAfterIBlockElementSetPropertyValuesEx',[$rluksLocationClass,'afterProperties'],10000);
AddEventHandler('iblock','OnAfterIBlockElementSetPropertyValues',[$rluksLocationClass,'afterProperties'],10000);
unset($rluksLocationClass);
