<?
$MESS["PROFI_PLANOGRAF_PLANOGRAF"] = "Планограф список элементов";
?>