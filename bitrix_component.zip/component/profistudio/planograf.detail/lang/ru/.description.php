<?
$MESS["PROFI_PLANOGRAF_PLANOGRAF"] = "Планограф детальный просмотр";
?>