<?
$MESS["PROFI_PLANOGRAF_COORDS"] = "Координаты центра и зум";
?>