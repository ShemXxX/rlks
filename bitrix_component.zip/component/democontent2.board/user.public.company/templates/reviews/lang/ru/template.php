<?php
/**
 * Date: 17.04.2020
 * Time: 09:23
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
$MESS['USER_PUBLIC_PROFILE_DATE'] = 'Дата регистрации';
$MESS['USER_PUBLIC_PROFILE_REVIEWS'] = 'Отзывы о компании';
$MESS['USER_PUBLIC_PROFILE_ADD_FEEDBACK'] = 'Оставить отзыв';
$MESS['USER_PUBLIC_PROFILE_ADD_FEEDBACK_PLACEHOLDER'] = 'Текст отзыва';
$MESS['USER_PUBLIC_PROFILE_ADD_FEEDBACK_SEND'] = 'Отправить';
$MESS['USER_PUBLIC_PROFILE_ADD_FEEDBACK_ABANDONED'] = 'Вы уже оставили отзыв для этой компании.';
$MESS['USER_PUBLIC_PROFILE_ADD_FEEDBACK_EMPTY'] = 'У данной компании еще нет отзывов';
$MESS['USER_PUBLIC_PROFILE_REV_1'] = 'отзыв';
$MESS['USER_PUBLIC_PROFILE_REV_2'] = 'отзыва';
$MESS['USER_PUBLIC_PROFILE_REV_3'] = 'отзывов';
$MESS['USER_PUBLIC_PROFILE_SHOW_ALL'] = 'Посмотреть все';
$MESS['USER_PUBLIC_PROFILE_WEB_SITE'] = 'Перейти на сайт компании';
$MESS['USER_PUBLIC_PROFILE_ONLINE'] = 'онлайн';
$MESS['USER_PUBLIC_PROFILE_OFFLINE'] = 'не в сети';
$MESS['USER_PUBLIC_PROFILE_DATE_REGISTER'] = 'На сайте с';
$MESS['USER_PUBLIC_PROFILE_RATING'] = 'Оценка';
$MESS['DETAIL_COMPONENT_REV_1'] = 'отзыв';
$MESS['DETAIL_COMPONENT_REV_2'] = 'отзыва';
$MESS['DETAIL_COMPONENT_REV_3'] = 'отзывов';

$MESS['TIME_ACROSS'] = 'через';
$MESS['TIME_BACK'] = 'назад';
$MESS['TIME_LESS_MINUTE'] = 'меньше минуты';
$MESS['TIME_MINUTE_1'] = 'минута';
$MESS['TIME_MINUTE_2'] = 'минуты';
$MESS['TIME_MINUTE_3'] = 'минут';
$MESS['TIME_MINUTE_4'] = 'минуту';
$MESS['TIME_HOUR_1'] = 'час';
$MESS['TIME_HOUR_2'] = 'часа';
$MESS['TIME_HOUR_3'] = 'часов';
$MESS['TIME_DAY_1'] = 'день';
$MESS['TIME_DAY_2'] = 'дня';
$MESS['TIME_DAY_3'] = 'дней';
$MESS['TIME_MONTH_1'] = 'месяц';
$MESS['TIME_MONTH_2'] = 'месяца';
$MESS['TIME_MONTH_3'] = 'месяцев';
$MESS['TIME_YEAR_1'] = 'год';
$MESS['TIME_YEAR_2'] = 'года';
$MESS['TIME_YEAR_3'] = 'лет';
