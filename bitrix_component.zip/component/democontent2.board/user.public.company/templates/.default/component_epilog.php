<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 09.10.2018
 * Time: 11:23
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;

$APPLICATION->AddChainItem($arResult['COMPANY']['UF_COMPANY_NAME']);
$APPLICATION->SetTitle(
    Loc::getMessage('USER_PUBLIC_PROFILE_COMPONENT_USER') . ' ' . $arResult['COMPANY']['UF_COMPANY_NAME']
);
$APPLICATION->SetPageProperty(
    'title',
    Loc::getMessage('USER_PUBLIC_PROFILE_COMPONENT_USER') . ' ' . $arResult['COMPANY']['UF_COMPANY_NAME']
);