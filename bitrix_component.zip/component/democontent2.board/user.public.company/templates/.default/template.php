<?php
/**
 * Date and Time: 30.07.2020, 9:14
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Democontent2\Board\Utils;

if (method_exists($this, 'setFrameMode')) {
    $this->setFrameMode(true);
}

$pict = null;
$companyLogo = null;

if (isset($arResult['USER']['PERSONAL_PHOTO'])) {
    $pict = CFile::ResizeImageGet(
        $arResult['USER']['PERSONAL_PHOTO'],
        [
            'width' => 100,
            'height' => 100
        ],
        BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
        true
    );
}

if (isset($arResult['COMPANY']['UF_LOGO_ID'])) {
    $companyLogo = CFile::ResizeImageGet(
        $arResult['COMPANY']['UF_LOGO_ID'],
        [
            'width' => 360,
            'height' => 150
        ],
        BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
        true
    );
}
$companyBanner = null;
if (isset($arResult['COMPANY']['UF_BANNER_ID'])) {
    $companyBanner = CFile::ResizeImageGet(
        $arResult['COMPANY']['UF_BANNER_ID'],
        [
            'width' => 1130,
            'height' => 350
        ],
        BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
        true
    );
}

$reviewsCount = count($arResult['REVIEWS']);

?>
<div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
    <h1><?= $arResult['COMPANY']['UF_COMPANY_NAME'] ?></h1>
    <? if (!is_null($companyBanner)): ?>
        <div class="_box">
            <?php
            if (strlen($arResult['COMPANY']['UF_COMPANY_SITE'])) {
                ?>
                <noindex>
                    <a href="<?= $arResult['COMPANY']['UF_COMPANY_SITE'] ?>" rel="nofollow" target="_blank">
                        <img width="100%" src="<?= $companyBanner['src'] ?>"
                             alt="<?= $arResult['COMPANY']['UF_COMPANY_NAME'] ?>">
                    </a>
                </noindex>
                <?php
            } else {
                ?>
                <img width="100%" src="<?= $companyBanner['src'] ?>"
                     alt="<?= $arResult['COMPANY']['UF_COMPANY_NAME'] ?>">
                <?php
            }
            ?>
        </div>
    <? endif ?>
    <?php
    foreach ($arResult['ITEMS'] as $type => $typeValue) {
        foreach ($typeValue as $iblockId => $iblock) {
            $names = [];
            $url = [];
            foreach ($iblock['names'] as $name) {
                $url[] = $name['code'];
                $names[] = '<a href="' . SITE_DIR . implode('/', $url) . '/">' . $name['name'] . '</a>';
            }
            ?>
            <div class="section-links">
                <?php
                foreach ($names as $name) {
                    ?>
                    <div class="item">
                        <?= $name ?>
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g>
                                <path d="M16.125 9L13.125 6V8.25H1.875V9.75H13.125V12L16.125 9Z" fill="#4F4F4F"/>
                            </g>
                        </svg>
                    </div>
                    <?php
                }

                if (count($iblock['items']) >= 4) {
                    ?>
                    <div class="item">
                        <a href="<?= $APPLICATION->GetCurPage(false) ?>?id=<?= $iblockId ?>">
                            <?= Loc::getMessage('USER_PUBLIC_PROFILE_SHOW_ALL') ?>
                        </a>
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g>
                                <path d="M16.125 9L13.125 6V8.25H1.875V9.75H13.125V12L16.125 9Z" fill="#4F4F4F"/>
                            </g>
                        </svg>
                    </div>
                    <?php
                }
                ?>
            </div>
            <div class="items-list">
                <?php
                foreach ($iblock['items'] as $product) {
                    $isFavourite = in_array($product['UF_ID'], $arResult['FAVOURITES']);
                    $pict = null;
                    $imageCounter = 1;
                    if (intval($product['UF_IMAGE_ID'])) {
                        $pict = intval($product['UF_IMAGE_ID']);
                        $pict = CFile::ResizeImageGet(
                            $pict,
                            [
                                'width' => 199,
                                'height' => 151
                            ],
                            BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
                            true
                        );
                    }

                    $imagesCounter = 0;
                    $unserializedImages = [];
                    if (strlen($product['UF_IMAGES'])) {
                        $unserializedImages = unserialize($product['UF_IMAGES']);
                        $imagesCounter = count($unserializedImages);
                    }
                    ?>
                    <div class="item">
                        <div class="image">
                            <?php
                            if ($imagesCounter) {
                                ?>
                                <div class="counter">
                                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <g>
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                  d="M12.25 0.583328H4.08334C3.44168 0.583328 2.91668 1.10833 2.91668 1.74999V9.91666C2.91668 10.5583 3.44168 11.0833 4.08334 11.0833H12.25C12.8917 11.0833 13.4167 10.5583 13.4167 9.91666V1.74999C13.4167 1.10833 12.8917 0.583328 12.25 0.583328ZM0.583344 2.91666H1.75001V12.25H11.0833V13.4167H1.75001C1.10834 13.4167 0.583344 12.8917 0.583344 12.25V2.91666ZM7.70584 8.0675L9.31001 6.0025L11.375 8.75H4.95834L6.56251 6.69083L7.70584 8.0675ZM4.08334 9.91666H12.25V1.74999H4.08334V9.91666Z"
                                                  fill="#4F4F4F"/>
                                        </g>
                                    </svg>
                                    <span><?= $imagesCounter + 1 ?></span>
                                </div>
                                <?php
                            }
                            ?>
                            <div class="favourite<?= ($isFavourite ? ' active' : '') ?>"
                                 data-id="<?= $product['UF_ID'] ?>" data-i="<?= $product['UF_IBLOCK_ID'] ?>">
                        <span class="wenk--right" data-wenk-pos="right"
                              data-wenk="<?= ($isFavourite ? Loc::getMessage('LIST_COMPONENT_REMOVE_FAV') : Loc::getMessage('LIST_COMPONENT_ADD_FAV')) ?>">
                            <?php
                            if ($isFavourite) {
                                ?>
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <g>
                                        <path d="M9 15.8812L7.9125 14.8912C4.05 11.3887 1.5 9.07874 1.5 6.24374C1.5 3.93374 3.315 2.11874 5.625 2.11874C6.93 2.11874 8.1825 2.72624 9 3.68624C9.8175 2.72624 11.07 2.11874 12.375 2.11874C14.685 2.11874 16.5 3.93374 16.5 6.24374C16.5 9.07874 13.95 11.3887 10.0875 14.8987L9 15.8812Z"
                                              fill="#EB5757"/>
                                    </g>
                                </svg>
                                <?php
                            } else {
                                ?>
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <g>
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                              d="M9 3.68624C9.8175 2.72624 11.07 2.11874 12.375 2.11874C14.685 2.11874 16.5 3.93374 16.5 6.24374C16.5 9.07642 13.9542 11.385 10.097 14.8826L10.0875 14.8912L9 15.8812L7.9125 14.8987L7.88289 14.8718C4.03697 11.3769 1.5 9.07149 1.5 6.24374C1.5 3.93374 3.315 2.11874 5.625 2.11874C6.93 2.11874 8.1825 2.72624 9 3.68624ZM9 13.8562L9.075 13.7812C12.645 10.5487 15 8.41124 15 6.24374C15 4.74374 13.875 3.61874 12.375 3.61874C11.22 3.61874 10.095 4.36124 9.705 5.38874H8.3025C7.905 4.36124 6.78 3.61874 5.625 3.61874C4.125 3.61874 3 4.74374 3 6.24374C3 8.41124 5.355 10.5487 8.925 13.7812L9 13.8562Z"
                                              fill="#4F4F4F"/>
                                    </g>
                                </svg>
                                <?php
                            }
                            ?>
                        </span>
                            </div>
                            <?php
                            if ($imagesCounter) {
                                ?>
                                <div class="images">
                                    <div class="nav">
                                        <?php
                                        if (!is_null($pict)) {
                                            ?>
                                            <a class="item" href="<?= $product['URL'] ?>"
                                               data-img="<?= $pict['src'] ?>">
                                                <div class="line"></div>
                                            </a>
                                            <?php
                                        }
                                        $imgI = 0;
                                        foreach ($unserializedImages as $img) {
                                            if ($imgI++ == 3) {
                                                break;
                                            }
                                            $pict = CFile::ResizeImageGet(
                                                $img,
                                                [
                                                    'width' => 199,
                                                    'height' => 151
                                                ],
                                                BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
                                                true
                                            );
                                            if (!is_null($pict)) {
                                                ?>
                                                <a class="item" href="<?= $product['URL'] ?>"
                                                   data-img="<?= $pict['src'] ?>">
                                                    <div class="line"></div>
                                                </a>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                            <a href="<?= $product['URL'] ?>" title="<?= $product['UF_NAME'] ?>">
                                <div class="fotorama _mb" data-width="100%" data-height="151px" data-maxheight="151px"
                                     data-allowfullscreen="false" data-loop="false">
                                    <?php
                                    if (!is_null($pict)) {
                                        ?>
                                        <div data-img="<?= $pict['src'] ?>">
                                            <div class="fotorama__blur"
                                                 style="background:url(<?= $pict['src'] ?>)"></div>
                                        </div>
                                        <?php
                                    } else {
                                        ?>
                                        <svg class="stub" width="40" height="40" viewBox="0 0 40 40" fill="none"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <g>
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                      d="M35 1.66666H11.6667C9.83335 1.66666 8.33335 3.16666 8.33335 4.99999V28.3333C8.33335 30.1667 9.83335 31.6667 11.6667 31.6667H35C36.8334 31.6667 38.3334 30.1667 38.3334 28.3333V4.99999C38.3334 3.16666 36.8334 1.66666 35 1.66666ZM1.66669 8.33332H5.00002V35H31.6667V38.3333H5.00002C3.16669 38.3333 1.66669 36.8333 1.66669 35V8.33332ZM22.0167 23.05L26.6 17.15L32.5 25H14.1667L18.75 19.1167L22.0167 23.05ZM11.6667 28.3333H35V4.99999H11.6667V28.3333Z"
                                                      fill="#BDBDBD"
                                                / >
                                            </g>
                                        </svg>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </a>
                        </div>
                        <div class="content">
                            <div class="link">
                                <a href="<?= $product['URL'] ?>"><?= $product['UF_NAME'] ?></a>
                            </div>
                            <div class="location">
                                <div class="icon">
                                    <svg width="17" height="17" viewBox="0 0 17 17" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                              d="M2.125 7.45875L14.875 2.125L9.53417 14.875H8.84L6.97 10.03L2.125 8.15292V7.45875ZM9.22958 11.9425L12.2329 4.76708L5.0575 7.76333L7.48708 8.70541L8.06791 8.93208L8.29458 9.52L9.22958 11.9425Z"
                                              fill="#999999"/>
                                    </svg>
                                </div>
                                <?php
                                if (intval($product['UF_CITY'])) {
                                    ?>
                                    <div class="text">
                                        <?= $arResult['CITIES'][$product['UF_CITY']]['name'] ?>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
            <?php
        }
    }
    ?>
</div>
<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
    <div class="_box _mb">
        <div class="owner<?= (!is_null($companyLogo) ? ' company' : '') ?>">
            <?php
            if (!is_null($companyLogo)) {
                ?>
                <div class="image">
                    <img src="<?= $companyLogo['src'] ?>" alt="<?= $arResult['COMPANY']['UF_COMPANY_NAME'] ?>">
                </div>
                <?php
            } else {
                if (!is_null($pict)) {
                    ?>
                    <div class="image">
                        <img src="<?= $pict['src'] ?>" alt="<?= $arResult['COMPANY']['UF_COMPANY_NAME'] ?>">
                    </div>
                    <?php
                } else {
                    ?>
                    <div class="colored-name"
                         style="background: <?= strlen($arResult['USER']['NAME']) ? Utils::userBgColor($arResult['USER']['NAME']) : '#ffffff' ?>">
                        <?= strlen($arResult['USER']['NAME']) ? Utils::userNamePrefix($arResult['USER']['NAME'], $arResult['USER']['LAST_NAME']) : '' ?>
                    </div>
                    <?php
                }
            }
            ?>
            <div class="data">
                <div class="name">
                    <?= $arResult['COMPANY']['UF_COMPANY_NAME'] ?>
                    <?php
                    if ($USER->IsAuthorized() && intval(Option::get(DBOARD, 'chatEnabled')) > 0) {
                        ?>
                        <span class="status indicator"></span>
                        <?php
                    }
                    ?>
                </div>
                <div class="register">
                    <?= Loc::getMessage('USER_PUBLIC_PROFILE_DATE_REGISTER') ?>
                    : <?= date('d.m.Y', strtotime($arResult['USER']['DATE_REGISTER'])) ?>
                </div>
                <div class="rating">
                    <?php
                    foreach ([20, 40, 60, 80, 100] as $chunk) {
                        if ($arResult['CURRENT_RATING'] >= $chunk) {
                            ?>
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g>
                                    <path d="M7 10.713L11.3283 14L9.67167 8.69217L14 5.47826H8.69167L7 0L5.30833 5.47826H0L4.32833 8.69217L2.67167 14L7 10.713Z"
                                          fill="#F2994A"/>
                                </g>
                            </svg>
                            <?php
                        } else {
                            ?>
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g>
                                    <path d="M7 10.713L11.3283 14L9.67167 8.69217L14 5.47826H8.69167L7 0L5.30833 5.47826H0L4.32833 8.69217L2.67167 14L7 10.713Z"
                                          fill="#BDBDBD"/>
                                </g>
                            </svg>
                            <?php
                        }
                    }
                    ?>
                </div>
                <div class="reviews">
                    <a href="<?= SITE_DIR ?>user/<?= $arResult['USER']['ID'] ?>/?reviews=1">
                        <?php
                        if ($reviewsCount > 0) {
                            echo Utils::declension(
                                $reviewsCount,
                                [
                                    Loc::getMessage('DETAIL_COMPONENT_REV_1'),
                                    Loc::getMessage('DETAIL_COMPONENT_REV_2'),
                                    Loc::getMessage('DETAIL_COMPONENT_REV_3')
                                ]
                            );
                        } else {
                            echo Loc::getMessage('DETAIL_COMPONENT_NO_REVIEWS');
                        }
                        ?>
                    </a>
                </div>
                <div class="info">
                    <div class="item">
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g>
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                      d="M15 11.625C14.0625 11.625 13.1625 11.475 12.3225 11.1975C12.2475 11.175 12.165 11.16 12.09 11.16C11.895 11.16 11.7075 11.235 11.5575 11.3775L9.9075 13.0275C7.785 11.9475 6.045 10.215 4.965 8.0925L6.615 6.435C6.825 6.2325 6.885 5.94 6.8025 5.6775C6.525 4.8375 6.375 3.9375 6.375 3C6.375 2.5875 6.0375 2.25 5.625 2.25H3C2.5875 2.25 2.25 2.5875 2.25 3C2.25 10.0425 7.9575 15.75 15 15.75C15.4125 15.75 15.75 15.4125 15.75 15V12.375C15.75 11.9625 15.4125 11.625 15 11.625ZM9.75 6.75H8.25V8.25H9.75V6.75ZM12.75 6.75H11.25V8.25H12.75V6.75ZM4.89749 3.75H3.77249C3.83999 4.74 4.03499 5.6925 4.34249 6.6L5.24249 5.6925C5.06249 5.0625 4.94999 4.41 4.89749 3.75ZM14.25 14.2275C13.26 14.16 12.3 13.965 11.4 13.6575L12.3 12.7575C12.9375 12.9375 13.59 13.05 14.25 13.095V14.2275ZM15.75 8.25V6.75H14.25V8.25H15.75Z"
                                      fill="#4F4F4F"/>
                            </g>
                        </svg>
                        <a href="tel:<?= $arResult['COMPANY']['UF_COMPANY_PHONE'] ?>" target="_blank">
                            <?= Utils::formatPhone($arResult['COMPANY']['UF_COMPANY_PHONE']) ?>
                        </a>
                    </div>
                    <? if (strlen($arResult['COMPANY']['UF_COMPANY_EMAIL']) > 0): ?>
                        <div class="item">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g>
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                          d="M15 3H3C2.175 3 1.5075 3.675 1.5075 4.5L1.5 13.5C1.5 14.325 2.175 15 3 15H15C15.825 15 16.5 14.325 16.5 13.5V4.5C16.5 3.675 15.825 3 15 3ZM3 6L9 9.75L15 6V13.5H3V6ZM3 4.5L9 8.25L15 4.5H3Z"
                                          fill="#333333"/>
                                </g>
                            </svg>
                            <?= $arResult['COMPANY']['UF_COMPANY_EMAIL'] ?>
                        </div>
                    <? endif ?>
                    <? if (strlen($arResult['COMPANY']['UF_COMPANY_ADDRESS']) > 0): ?>
                        <div class="item">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g>
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                          d="M9 1.5C11.4825 1.5 13.5 3.5175 13.5 6C13.5 9.375 9 14.25 9 14.25C9 14.25 4.5 9.375 4.5 6C4.5 3.5175 6.5175 1.5 9 1.5ZM14.25 16.5V15H3.75V16.5H14.25ZM6 6C6 4.3425 7.3425 3 9 3C10.6575 3 12 4.3425 12 6C12 7.5975 10.44 10.095 9 11.9325C7.56 10.1025 6 7.5975 6 6ZM7.5 6C7.5 5.175 8.175 4.5 9 4.5C9.825 4.5 10.5 5.175 10.5 6C10.5 6.825 9.8325 7.5 9 7.5C8.175 7.5 7.5 6.825 7.5 6Z"
                                          fill="#4F4F4F"/>
                                </g>
                            </svg>
                            <?= $arResult['COMPANY']['UF_COMPANY_ADDRESS'] ?>
                        </div>
                    <? endif ?>
                    <? if (strlen($arResult['COMPANY']['UF_COMPANY_WORKTIME']) > 0): ?>
                        <div class="item">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g>
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                          d="M8.9925 1.5C4.8525 1.5 1.5 4.86 1.5 9C1.5 13.14 4.8525 16.5 8.9925 16.5C13.14 16.5 16.5 13.14 16.5 9C16.5 4.86 13.14 1.5 8.9925 1.5ZM9 15C5.685 15 3 12.315 3 9C3 5.685 5.685 3 9 3C12.315 3 15 5.685 15 9C15 12.315 12.315 15 9 15ZM8.25 5.25H9.375V9.1875L12.75 11.19L12.1875 12.1125L8.25 9.75V5.25Z"
                                          fill="#4F4F4F"/>
                                </g>
                            </svg>
                            <?= $arResult['COMPANY']['UF_COMPANY_WORKTIME'] ?>
                        </div>
                    <? endif ?>
                    <?php
                    if (strlen($arResult['COMPANY']['UF_COMPANY_SITE'])) {
                        ?>
                        <div class="item">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g>
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                          d="M1.5 9C1.5 4.86 4.8525 1.5 8.9925 1.5C13.14 1.5 16.5 4.86 16.5 9C16.5 13.14 13.14 16.5 8.9925 16.5C4.8525 16.5 1.5 13.14 1.5 9ZM11.9775 6H14.19C13.47 4.7625 12.3225 3.8025 10.9425 3.33C11.3925 4.1625 11.7375 5.0625 11.9775 6ZM8.99999 3.03C9.62249 3.93 10.11 4.9275 10.4325 6H7.56749C7.88999 4.9275 8.37749 3.93 8.99999 3.03ZM3 9C3 9.5175 3.075 10.02 3.195 10.5H5.73C5.67 10.005 5.625 9.51 5.625 9C5.625 8.49 5.67 7.995 5.73 7.5H3.195C3.075 7.98 3 8.4825 3 9ZM3.81 12H6.0225C6.2625 12.9375 6.6075 13.8375 7.0575 14.67C5.6775 14.1975 4.53 13.245 3.81 12ZM3.81 6H6.0225C6.2625 5.0625 6.6075 4.1625 7.0575 3.33C5.6775 3.8025 4.53 4.755 3.81 6ZM8.99999 14.97C8.37749 14.07 7.88999 13.0725 7.56749 12H10.4325C10.11 13.0725 9.62249 14.07 8.99999 14.97ZM7.245 10.5H10.755C10.8225 10.005 10.875 9.51 10.875 9C10.875 8.49 10.8225 7.9875 10.755 7.5H7.245C7.1775 7.9875 7.125 8.49 7.125 9C7.125 9.51 7.1775 10.005 7.245 10.5ZM10.9425 14.67C11.3925 13.8375 11.7375 12.9375 11.9775 12H14.19C13.47 13.2375 12.3225 14.1975 10.9425 14.67ZM12.375 9C12.375 9.51 12.33 10.005 12.27 10.5H14.805C14.925 10.02 15 9.5175 15 9C15 8.4825 14.925 7.98 14.805 7.5H12.27C12.33 7.995 12.375 8.49 12.375 9Z"
                                          fill="#4F4F4F"/>
                                </g>
                            </svg>
                            <a href="<?= $arResult['COMPANY']['UF_COMPANY_SITE'] ?>" target="_blank" rel="nofollow">
                                <?= Loc::getMessage('USER_PUBLIC_PROFILE_WEB_SITE') ?>
                            </a>
                        </div>
                        <?php
                    }
                    ?>
                </div>
            </div>
        </div>
        <? if ($arResult['ALLOW_REVIEW']): ?>
            <? if ($USER->GetID() != $arResult['USER']['ID']): ?>
                <button class="write review _mt" data-auth="<?= ($USER->IsAuthorized() ? 1 : 0) ?>">
                    <?= Loc::getMessage('USER_PUBLIC_PROFILE_ADD_FEEDBACK') ?>
                </button>
                <div class="owner-add-review _mt">
                    <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post">
                        <textarea rows="6" name="review"
                                  placeholder="<?= Loc::getMessage('USER_PUBLIC_PROFILE_ADD_FEEDBACK_PLACEHOLDER') ?>"></textarea>
                        <button type="submit" class="write review _mt">
                            <?= Loc::getMessage('USER_PUBLIC_PROFILE_ADD_FEEDBACK_SEND') ?>
                        </button>
                    </form>
                </div>
            <? endif ?>
        <? else: ?>
            <div class="owner-review-exists">
                <?= Loc::getMessage('USER_PUBLIC_PROFILE_ADD_FEEDBACK_ABANDONED') ?>
            </div>
        <? endif ?>
    </div>
</div>

<? if (strlen($arResult['COMPANY']['UF_COMPANY_DESCR']) > 0): ?>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="_box _mt">
            <?= $arResult['COMPANY']['UF_COMPANY_DESCR'] ?>
        </div>
    </div>
<? endif ?>

<script>
    var __ajaxPath = '<?=$this->GetFolder()?>/ajax.php',
        __ownerId = '<?=md5($arResult['USER']['ID'])?>';
    BX.message({
        'owner_id': '<?=md5($arResult['USER']['ID'])?>',
        'status_online': '<?=Loc::getMessage('USER_PUBLIC_PROFILE_ONLINE')?>',
        'status_offline': '<?=Loc::getMessage('USER_PUBLIC_PROFILE_OFFLINE')?>',
    });
</script>