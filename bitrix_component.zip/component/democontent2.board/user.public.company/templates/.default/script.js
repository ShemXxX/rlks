$(document).ready(function () {
    if (typeof __ownerId !== 'undefined') {
        $(function () {
            socket.emit('status', __ownerId);
            socket.on(__ownerId + ' user status', (data) => {
                switch (data.status) {
                    case 'online':
                        $('.status.indicator').removeClass('offline').addClass('online').html(BX.message('status_online'));
                        break;
                    case 'offline':
                        $('.status.indicator').removeClass('online').addClass('offline').html(BX.message('status_offline'));
                        break;
                }
            });
        });
    }

    $('.favourite').click(function () {
        let $this = $(this);
        let id = $this.attr('data-id');
        let i = $this.attr('data-i');
        $.ajax({
            type: 'POST',
            url: __ajaxPath + '/ajax.php',
            dataType: "json",
            data: 'id=' + id + '&i=' + i + '&type=like',
        });
    });
});