<?php
/**
 * Date and Time: 30.07.2020, 9:14
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

$MESS['USER_PUBLIC_PROFILE_DATE'] = 'Дата регистрации';
$MESS['USER_PUBLIC_PROFILE_BTN_MORE'] = 'Подробнее';
$MESS['USER_PUBLIC_PROFILE_TAB_HEAD1'] = 'Объявления';
$MESS['USER_PUBLIC_PROFILE_TAB_HEAD2'] = 'Отзывы';
$MESS['USER_PUBLIC_PROFILE_ADD_FEEDBACK'] = 'Оставить отзыв';
$MESS['USER_PUBLIC_PROFILE_ADD_FEEDBACK_PLACEHOLDER'] = 'Текст отзыва';
$MESS['USER_PUBLIC_PROFILE_ADD_FEEDBACK_SEND'] = 'Отправить';
$MESS['USER_PUBLIC_PROFILE_ADD_FEEDBACK_ABANDONED'] = 'Вы уже оставили отзыв, вы можете его изменить в личном кабинете.';
$MESS['USER_PUBLIC_PROFILE_ADD_FEEDBACK_EMPTY'] = 'У данного пользователя еще нет отзывов';
$MESS['USER_PUBLIC_PROFILE_REV_1'] = 'отзыв';
$MESS['USER_PUBLIC_PROFILE_REV_2'] = 'отзыва';
$MESS['USER_PUBLIC_PROFILE_REV_3'] = 'отзывов';
$MESS['USER_PUBLIC_PROFILE_SHOW_ALL'] = 'Посмотреть все';
$MESS['USER_PUBLIC_PROFILE_WEB_SITE'] = 'Перейти на сайт компании';