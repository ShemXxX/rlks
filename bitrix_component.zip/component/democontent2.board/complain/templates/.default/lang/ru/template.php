<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 07.10.2018
 * Time: 12:14
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['COMPLAIN_COMPONENT_BUTTON'] = 'Пожаловаться на объявление';
$MESS['COMPLAIN_COMPONENT_TITLE'] = 'Пожаловаться на объявление';
$MESS['COMPLAIN_COMPONENT_SELECT'] = 'Выберите причину жалобы';
$MESS['COMPLAIN_COMPONENT_SUBMIT'] = 'Отправить';
$MESS['COMPLAIN_COMPONENT_TEXTAREA'] = 'Опишите суть жалобы на объявление';
$MESS['COMPLAIN_COMPONENT_SEND_SUCCESS'] = 'Жалоба успешно отправлена и будет рассмотрена модератором';