<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 07.10.2018
 * Time: 12:14
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if ($arParams['isOwner']) {
    return;
}
if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

use Bitrix\Main\Localization\Loc;

?>
    <div class="detail-abuse">
        <span class="wenk--left" data-wenk="<?= Loc::getMessage('COMPLAIN_COMPONENT_TITLE') ?>" data-wenk-pos="left">
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g><path fill-rule="evenodd" clip-rule="evenodd"
                         d="M8.9925 1.5C4.8525 1.5 1.5 4.86 1.5 9C1.5 13.14 4.8525 16.5 8.9925 16.5C13.14 16.5 16.5 13.14 16.5 9C16.5 4.86 13.14 1.5 8.9925 1.5ZM9.75 9.75V5.25H8.25V9.75H9.75ZM9.75 12.75V11.25H8.25V12.75H9.75ZM3 9C3 12.315 5.685 15 9 15C12.315 15 15 12.315 15 9C15 5.685 12.315 3 9 3C5.685 3 3 5.685 3 9Z"
                         fill="#EB5757"/></g>
            </svg>
        </span>
    </div>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}