$(document).ready(function () {
    $('.detail-abuse').click(function () {
        $('#complain').removeClass('--dn');
    });

    $('button#complainButton').click(function () {
        let complainText = $('#complainText');
        complainText.removeClass('error');
        if (!$(this).hasClass('active')) {
            $(this).addClass('active');
        }
        $(this).removeClass('active');

        if (!complainText.val().trim().length) {
            complainText.addClass('error');
            return false;
        }
    });
});