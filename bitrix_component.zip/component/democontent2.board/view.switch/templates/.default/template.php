<?php
/**
 * Date: 15.05.2020
 * Time: 11:16
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}
?>
    <div class="view">
        <?php
        if ($arResult['VIEW'] == 'table') {
            ?>
            <div class="item">
                <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect width="6" height="6" fill="#4F4F4F"/>
                    <rect x="9" width="6" height="6" fill="#4F4F4F"/>
                    <rect x="9" y="9" width="6" height="6" fill="#4F4F4F"/>
                    <rect y="9" width="6" height="6" fill="#4F4F4F"/>
                </svg>
            </div>
            <a class="item" href="<?= $APPLICATION->GetCurPage(false) ?>?view=list">
                <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="5" width="10" height="3" fill="#828282"/>
                    <rect x="5" y="6" width="10" height="3" fill="#828282"/>
                    <rect x="5" y="12" width="10" height="3" fill="#828282"/>
                    <rect width="3" height="3" fill="#828282"/>
                    <rect y="6" width="3" height="3" fill="#828282"/>
                    <rect y="12" width="3" height="3" fill="#828282"/>
                </svg>
            </a>
            <?php
        } else {
            ?>
            <a class="item" href="<?= $APPLICATION->GetCurPage(false) ?>?view=table">
                <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect width="6" height="6" fill="#828282"/>
                    <rect x="9" width="6" height="6" fill="#828282"/>
                    <rect x="9" y="9" width="6" height="6" fill="#828282"/>
                    <rect y="9" width="6" height="6" fill="#828282"/>
                </svg>
            </a>
            <div class="item">
                <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="5" width="10" height="3" fill="#4F4F4F"/>
                    <rect x="5" y="6" width="10" height="3" fill="#4F4F4F"/>
                    <rect x="5" y="12" width="10" height="3" fill="#4F4F4F"/>
                    <rect width="3" height="3" fill="#4F4F4F"/>
                    <rect y="6" width="3" height="3" fill="#4F4F4F"/>
                    <rect y="12" width="3" height="3" fill="#4F4F4F"/>
                </svg>
            </div>
            <?php
        }
        ?>
    </div>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}

