<?php
/**
 * Date and Time: 22.07.2020, 9:31
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Application;
use Bitrix\Main\Web\Cookie;
use Democontent2\Board\Utils;

class ViewSwitchComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        global $APPLICATION;

        $context = Application::getInstance()->getContext();
        $request = $context->getRequest();
        $utils = new Utils();
        if ($request->get('view')) {
            switch ($request->get('view')) {
                case 'list':
                case 'table':
                    $host = explode(':', $context->getServer()->getHttpHost());
                    $cookie = new Cookie('catalog_view', $request->get('view'));
                    $cookie->setDomain($host[0]);
                    $context->getResponse()->addCookie($cookie);
                    LocalRedirect($APPLICATION->GetCurPage(false));
                    break;
            }
        }
        $this->arResult['VIEW'] = $utils->getView($request);
        $this->includeComponentTemplate();
    }
}
