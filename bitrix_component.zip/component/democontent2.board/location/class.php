<?php
/*
 * Date and Time: 21.10.2020, 8:59
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

use Bitrix\Main\Application;
use Bitrix\Main\Web\Cookie;
use Democontent2\Board\Iblock\City;

class LocationComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        $context = Application::getInstance()->getContext();
        $request = $context->getRequest();
        $city = new City();
        $this->arResult['ITEMS'] = $city->getList(1);
        $this->arResult['REGIONS'] = $city->getRegions();
        $this->arResult['CURRENT_CITY_ID'] = 0;
        $this->arResult['CURRENT_CITY_NAME'] = '';
        $this->arResult['CURRENT_CITY_CODE'] = '';
        $this->arResult['ANY_CITY'] = false;
        $this->arResult['ALL_ITEMS'] = $city->getList();

        if ($request->get('skipCity')) {
            $host = explode(':', $context->getServer()->getHttpHost());

            $cookie = new Cookie('current_city', 0);
            $cookie->setDomain($host[0]);
            $context->getResponse()->addCookie($cookie);

            $cookie = new Cookie('skipCity', 1);
            $cookie->setDomain($host[0]);
            $context->getResponse()->addCookie($cookie);

            LocalRedirect(SITE_DIR, true);
        } else {
            if (count($this->arResult['ALL_ITEMS']) > 1) {
                if (intval($request->getCookie('current_city'))) {
                    if (isset($this->arResult['ALL_ITEMS'][intval($request->getCookie('current_city'))])) {
                        $this->arResult['CURRENT_CITY_ID'] = intval($request->getCookie('current_city'));
                        $this->arResult['CURRENT_CITY_NAME'] = $this->arResult['ALL_ITEMS'][intval($request->getCookie('current_city'))]['name'];

                        if (!$this->arResult['ALL_ITEMS'][intval($request->getCookie('current_city'))]['default']) {
                            $this->arResult['CURRENT_CITY_CODE'] = $this->arResult['ALL_ITEMS'][intval($request->getCookie('current_city'))]['code'];
                        }
                    }
                }

                if ($request->get('changeCity')) {
                    if (intval($request->get('changeCity')) > 0) {
                        if (isset($this->arResult['ALL_ITEMS'][intval($request->get('changeCity'))])) {
                            $host = explode(':', $context->getServer()->getHttpHost());

                            $cookie = new Cookie('current_city', intval($request->get('changeCity')));
                            $cookie->setDomain($host[0]);
                            $context->getResponse()->addCookie($cookie);

                            $cookie = new Cookie('skipCity', 0);
                            $cookie->setDomain($host[0]);
                            $context->getResponse()->addCookie($cookie);
                        }
                    }

                    LocalRedirect(SITE_DIR, true);
                }

                if (!intval($request->getCookie('skipCity'))) {
                    if (!strlen($this->arResult['CURRENT_CITY_NAME'])) {
                        foreach ($this->arResult['ALL_ITEMS'] as $item) {
                            if ($item['default']) {
                                $this->arResult['CURRENT_CITY_ID'] = $item['id'];
                                $this->arResult['CURRENT_CITY_NAME'] = $item['name'];
                                $this->arResult['CURRENT_CITY_CODE'] = $item['code'];
                                break;
                            }
                        }
                    }
                } else {
                    $this->arResult['ANY_CITY'] = true;
                }
            } else {
                $this->arResult['ANY_CITY'] = true;
            }

            if (strlen($this->arResult['CURRENT_CITY_CODE']) > 0) {
                if (!defined('DBOARD_CITY')) {
                    define('DBOARD_CITY', $this->arResult['CURRENT_CITY_CODE']);
                }
            }
        }

        $this->IncludeComponentTemplate();
    }
}
