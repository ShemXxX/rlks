<?php
/*
 * Date and Time: 17.11.2020, 13:11
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (count($arResult['ALL_ITEMS']) < 2) {
    return;
}

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

use Bitrix\Main\Localization\Loc;

?>
    <div class="header-top__link">
        <a href="<?= SITE_DIR ?>" id="change-city">
            <div class="icon">
                <svg width="17" height="17" viewBox="0 0 17 17" fill="none"
                     xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd"
                          d="M2.125 7.45875L14.875 2.125L9.53417 14.875H8.84L6.97 10.03L2.125 8.15292V7.45875ZM9.22958 11.9425L12.2329 4.76708L5.0575 7.76333L7.48708 8.70541L8.06791 8.93208L8.29458 9.52L9.22958 11.9425Z"
                          fill="#4F4F4F"/>
                </svg>
            </div>
            <span>
                <?php
                if ($arResult['ANY_CITY']) {
                    echo Loc::getMessage('LOCATION_POPUP_CITY_SELECTION');
                } else {
                    echo $arResult['CURRENT_CITY_NAME'];
                }
                ?>
            </span>
        </a>
        <?php
        if (!$arResult['ANY_CITY']) {
            ?>
            <svg id="reset-city" width="12" height="12" viewBox="0 0 12 12" fill="none"
                 xmlns="http://www.w3.org/2000/svg">
                <path d="M1.40789 11.2929C1.79842 11.6834 2.43158 11.6834 2.82211 11.2929L5.29289 8.82211C5.68342 8.43158 6.31658 8.43158 6.70711 8.82211L9.17789 11.2929C9.56842 11.6834 10.2016 11.6834 10.5921 11.2929L11.2929 10.5921C11.6834 10.2016 11.6834 9.56842 11.2929 9.17789L8.82211 6.70711C8.43158 6.31658 8.43158 5.68342 8.82211 5.29289L11.2929 2.82211C11.6834 2.43158 11.6834 1.79842 11.2929 1.40789L10.5921 0.707108C10.2016 0.316583 9.56842 0.316583 9.17789 0.707107L6.70711 3.17789C6.31658 3.56842 5.68342 3.56842 5.29289 3.17789L2.82211 0.707107C2.43158 0.316583 1.79842 0.316582 1.40789 0.707107L0.707108 1.40789C0.316583 1.79842 0.316583 2.43158 0.707107 2.82211L3.17789 5.29289C3.56842 5.68342 3.56842 6.31658 3.17789 6.70711L0.707107 9.17789C0.316583 9.56842 0.316582 10.2016 0.707107 10.5921L1.40789 11.2929Z"
                      fill="#4F4F4F"/>
            </svg>
            <?php
        }
        ?>
    </div>
    <script>
        BX.message({
            'locationAjaxPath': '<?=$this->GetFolder()?>/ajax.php',
            'select_city': '<?=Loc::getMessage('LOCATION_POPUP_CITY_SELECTION')?>',
            'select_city_placeholder': '<?=Loc::getMessage('LOCATION_POPUP_CITY_SELECTION_PLACEHOLDER')?>',
            'cities_not_found': '<?=Loc::getMessage('LOCATION_POPUP_CITY_NOT_FOUND')?>',
            'any_city': '<?=Loc::getMessage('ANY_CITY')?>',
        });
    </script>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}