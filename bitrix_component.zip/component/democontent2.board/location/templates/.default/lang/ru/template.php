<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 24.09.2018
 * Time: 14:17
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['ANY_CITY'] = 'Не учитывать район';
$MESS['LOCATION_POPUP_POPULAR_CITIES'] = 'Популярные районы';
$MESS['LOCATION_POPUP_REGION_SELECTION'] = 'Выбарть регион';
$MESS['LOCATION_POPUP_CITY_SELECTION_BACK'] = 'Назад';
$MESS['LOCATION_POPUP_CITY_SELECTION'] = 'Выбрать район города';
$MESS['LOCATION_POPUP_CITY_SELECTION_PLACEHOLDER'] = 'Введите название района...';
$MESS['LOCATION_POPUP_CITY_NOT_FOUND'] = 'Ничего не найдено';