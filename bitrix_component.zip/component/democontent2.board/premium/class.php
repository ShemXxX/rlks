<?php
/**
 * Date and Time: 22.07.2020, 9:20
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

use Bitrix\Main\Application;
use Democontent2\Board\Iblock\City;
use Democontent2\Board\Iblock\Premium;

class PremiumComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        $request = Application::getInstance()->getContext()->getRequest();
        $city = new City();
        $this->arResult['CITIES'] = $city->getList();

        if (!intval($request->getCookie('skipCity'))) {
            $cityId = 0;
            $cityParams = [];

            if (isset($this->arParams['CITY_ID']) && intval($this->arParams['CITY_ID']) > 0) {
                $cityParams = $city->getById(intval($this->arParams['CITY_ID']));
            } else {
                if (intval($request->getCookie('current_city')) > 0) {
                    $cityParams = $city->getById(intval($request->getCookie('current_city')));
                }
            }

            if (!count($cityParams)) {
                $cityParams = $city->getDefault();
            }

            if (count($cityParams)) {
                $cityId = intval($cityParams['id']);
            }

            $premium = new Premium($cityId);
            if (isset($this->arParams['IBLOCK_ID'])) {
                $premium->setIBlockId($this->arParams['IBLOCK_ID']);
            }
            if (!$cityId) {
                $premium->setSkipCity(true);
            }
            $this->arResult['ITEMS'] = $premium->get();
        } else {
            $premium = new Premium(0);
            if (isset($this->arParams['IBLOCK_ID'])) {
                $premium->setIBlockId($this->arParams['IBLOCK_ID']);
            }
            $premium->setSkipCity(true);
            $this->arResult['ITEMS'] = $premium->get();
        }

        $this->includeComponentTemplate();
    }
}
