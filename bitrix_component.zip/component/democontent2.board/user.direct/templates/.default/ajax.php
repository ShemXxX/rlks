<?php
/*
 * Date and Time: 17.11.2020, 9:30
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

use Bitrix\Main\Application;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Context;
use Bitrix\Main\Engine\Response\Json;
use Bitrix\Main\IO\File;
use Bitrix\Main\IO\Path;
use Bitrix\Main\Loader;
use Democontent2\Board\User;
use MongoDB\BSON\ObjectId;
use MongoDB\Client;

$request = Context::getCurrent()->getRequest();
$error = 1;
$result = [];

global $USER;

if ($request->isAjaxRequest() && $request->isPost() && $USER->IsAuthorized()) {
    if (Loader::includeModule('democontent2.board')) {
        if (!class_exists('ComposerAutoloaderInitb3b8815b1cff1dcd9b07af68330d7c45')) {
            if (File::isFileExists(Path::normalize(Application::getDocumentRoot() . '/local/lib/MongoDB/vendor/autoload.php'))) {
                include_once Path::normalize(Application::getDocumentRoot() . '/local/lib/MongoDB/vendor/autoload.php');
            }
        }

        if ($request->getPost('type')) {
            $uidHash = md5($USER->GetID());
            switch ($request->getPost('type')) {
                case 'list':
                    $login = Option::get(DBOARD, 'mongoAdminLogin');
                    $password = Option::get(DBOARD, 'mongoAdminPassword');

                    if ($login && $password) {
                        $_u = new User(0);
                        $client = new Client(\Democontent2\Board\Utils::__mongoDbConnectString());
                        $db = $client->selectDatabase(\Democontent2\Board\Utils::__mongoDbName())->selectCollection('rooms');
                        $rooms = $db->find(
                            [
                                '$or' => [
                                    [
                                        'user1' => $uidHash
                                    ],
                                    [
                                        'user2' => $uidHash
                                    ]
                                ]
                            ],
                            [
                                'sort' => [
                                    'time' => -1
                                ]
                            ]
                        );
                        foreach ($rooms as $room) {
                            $room['unread'] = 0;
                            $db = $client->selectDatabase(\Democontent2\Board\Utils::__mongoDbName())->selectCollection('messages');
                            $unreadCounter = $db->aggregate(
                                [
                                    [
                                        '$match' => [
                                            'roomId' => (string)$room->_id,
                                            'userId' => (($room->user1 == $uidHash) ? $room->user2 : $room->user1),
                                            'status' => 0
                                        ],
                                    ],
                                    [
                                        '$group' => [
                                            '_id' => 1,
                                            'count' => [
                                                '$sum' => 1
                                            ]
                                        ]
                                    ]
                                ]
                            );
                            foreach ($unreadCounter as $unread) {
                                $room['unread'] = intval($unread->count);
                            }

                            $lastMessage = $db->find(
                                [
                                    'roomId' => (string)$room->_id
                                ],
                                [
                                    'sort' => [
                                        'time' => -1
                                    ],
                                    'limit' => 1
                                ]
                            );
                            foreach ($lastMessage as $last) {
                                $room['lastMessage'] = $last;
                            }

                            $_params = [
                                'image' => null,
                                'bgColor' => '#fff',
                                'shortName' => '',
                            ];

                            if ($uidHash == $room['user1']) {
                                $_params['bgColor'] = \Democontent2\Board\Utils::userBgColor($room['user2Name']);
                                $_params['shortName'] = \Democontent2\Board\Utils::userNamePrefix($room['user2Name']);

                                $_u->setId($room['user2RealId']);
                                $userParams = $_u->get();
                                if (isset($userParams['USER']['AVATAR'])) {
                                    $_params['image'] = $userParams['USER']['AVATAR']['src'];
                                }
                            } else {
                                $_params['bgColor'] = \Democontent2\Board\Utils::userBgColor($room['user1Name']);
                                $_params['shortName'] = \Democontent2\Board\Utils::userNamePrefix($room['user1Name']);

                                $_u->setId($room['user1RealId']);
                                $userParams = $_u->get();
                                if (isset($userParams['USER']['AVATAR'])) {
                                    $_params['image'] = $userParams['USER']['AVATAR']['src'];
                                }
                            }

                            $room['id'] = (string)$room->_id;
                            $room['userParams'] = $_params;
                            $result[] = $room;
                        }

                        if (count($result) > 0) {
                            $error = 0;
                        }
                    }
                    break;
                case 'messages':
                    if ($request->getPost('id') && strlen($request->getPost('id')) == 24) {
                        $login = Option::get(DBOARD, 'mongoAdminLogin');
                        $password = Option::get(DBOARD, 'mongoAdminPassword');

                        if ($login && $password) {
                            $roomParams = [];
                            $client = new Client(\Democontent2\Board\Utils::__mongoDbConnectString());
                            $db = $client->selectDatabase(\Democontent2\Board\Utils::__mongoDbName())->selectCollection('rooms');
                            $rooms = $db->find(
                                [
                                    '_id' => new ObjectId($request->getPost('id')),
                                    '$or' => [
                                        [
                                            'user1' => $uidHash
                                        ],
                                        [
                                            'user2' => $uidHash
                                        ]
                                    ]
                                ],
                                [
                                    'limit' => 1
                                ]
                            );
                            foreach ($rooms as $room) {
                                if ($room->user1 == $uidHash || $room->user2 == $uidHash) {
                                    $roomParams = [
                                        'user1' => $room->user1,
                                        'user2' => $room->user2
                                    ];
                                    $db = $client->selectDatabase(\Democontent2\Board\Utils::__mongoDbName())->selectCollection('messages');
                                    $messages = $db->find(
                                        [
                                            'roomId' => $request->getPost('id')
                                        ],
                                        [
                                            'sort' => [
                                                'time' => 1
                                            ]
                                        ]
                                    );
                                    foreach ($messages as $message) {
                                        $result[] = $message;
                                    }
                                }
                            }
                            if (count($result) > 0) {
                                $error = 0;

                                if (count($roomParams) > 0) {
                                    $db->updateMany(
                                        [
                                            'roomId' => $request->getPost('id'),
                                            'userId' => (($roomParams['user1'] == $uidHash) ? $roomParams['user2'] : $roomParams['user1']),
                                            'status' => 0
                                        ],
                                        [
                                            '$set' => [
                                                'status' => 1
                                            ]
                                        ]
                                    );
                                }
                            }
                        }
                    }
                    break;
            }
        }
    }
}

$r = new Json([
    'error' => $error,
    'result' => $result
]);
$r->send();
