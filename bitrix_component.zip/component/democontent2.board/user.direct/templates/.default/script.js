var URL = {
    get: function () {
        return document.location.href;
    },
    parse: function () {
        var url = this.get();

        return url.split("#!");
    }
};

!function (e) {
    e.parseQuery = function (r) {
        var a = {query: window.location.search || ""}, n = {};
        return "string" == typeof r && (r = {query: r}), e.extend(a, e.parseQuery, r), a.query = a.query.replace(/^\?/, ""), a.query.length > 0 && e.each(a.query.split(a.separator), function (e, r) {
            var t = r.split("="), u = "" + a.decode(t.shift(), null), o = a.decode(t.length ? t.join("=") : null, u);
            (a.array_keys.test ? a.array_keys.test(u) : a.array_keys(u)) ? (n[u] = n[u] || [], n[u].push(o)) : n[u] = o
        }), n
    }, e.parseQuery.decode = e.parseQuery.default_decode = function (e) {
        return decodeURIComponent((e || "").replace(/\+/g, " "))
    }, e.parseQuery.array_keys = function () {
        return !1
    }, e.parseQuery.separator = "&"
}(window.jQuery || window.Zepto);

function showChatContent() {
    const regex = /#!([\da-z]{24})/gm;
    const str = URL.get();
    let m;
    var i = 0,
        id_ = '';

    while ((m = regex.exec(str)) !== null) {
        if (m.index === regex.lastIndex) {
            regex.lastIndex++;
        }

        m.forEach((match, groupIndex) => {
            i++;
            if (groupIndex === 1) {
                id_ = match;
            }
        });
    }

    return id_;
}

$(document).ready(function () {
    var contacts = [];

    $(function () {
        var TYPING_TIMER_LENGTH = 400;
        var $window = $(window);
        var $inputMessage = $('.inputMessage');
        var connected = false;
        var typing = false;
        var lastTypingTime;
        var chatId = '';
        var messageItems = $('#messages-items');
        var listMessageUsers = $('#list-message');

        function chatList() {
            $.ajax({
                type: 'POST',
                url: __ajaxPath,
                dataType: "json",
                data: 'type=list',
                success: function (data) {
                    if (!data.error) {
                        var c = 0;
                        listMessageUsers.find('.preloader').fadeOut();
                        $.each(data.result, function (i, itm) {
                            var name = (itm.user1 === username) ? itm.user2Name : itm.user1Name,
                                id = itm.id,
                                to = (itm.user1 === username) ? itm.user2 : itm.user1,
                                date = new Date(itm.lastMessage.time),
                                message = (itm.lastMessage.userId === username) ? '<span class="bold">' + __you + ': </span>' : '';
                            message += itm.lastMessage.message.substring(0, 50);
                            var unread = '<span id="' + id + 'chatCounterArea" class="unread">' + ((itm.unread > 0) ? '<span id="' + id + 'chatCounter">' + ((itm.unread > 99) ? '99+' : itm.unread) + '</span>' : '') + '</span>';

                            listMessageUsers.prepend(messageHeadItm(name, date, message, id, to, unread, itm.userParams));

                            var cont = {};
                            cont.roomId = id;
                            cont.userId = to;

                            contacts.push(cont);

                            if (i + 1 === data.result.length) {
                                listMessageUsers.find('.date').timeago();
                            }

                            c++;
                        });

                        for (let contact in contacts) {
                            socket.on(contacts[contact]['roomId'] + ' ' + contacts[contact]['userId'] + ' stop typing', (data) => {
                                $('#' + contacts[contact]['roomId'] + contacts[contact]['userId'] + '_typing').removeClass('active');
                                $('.loader-write').removeClass('active');
                            });

                            socket.on(contacts[contact]['roomId'] + ' ' + contacts[contact]['userId'] + ' typing', (data) => {
                                $('#' + contacts[contact]['roomId'] + contacts[contact]['userId'] + '_typing').addClass('active');
                                $('.loader-write').addClass('active');
                            });

                            socket.on(contacts[contact]['userId'] + ' connected', (data) => {
                                $('#' + contacts[contact]['userId'] + '_status').addClass('online');
                            });

                            socket.on(contacts[contact]['userId'] + ' disconnected', (data) => {
                                $('#' + contacts[contact]['userId'] + '_status').removeClass('online');
                            });

                            socket.on(contacts[contact]['userId'] + ' user status', (data) => {
                                switch (data.status) {
                                    case 'online':
                                        $('#' + contacts[contact]['userId'] + '_status').addClass('online');
                                        break;
                                    default:
                                        $('#' + contacts[contact]['userId'] + '_status').removeClass('online');
                                }
                            });
                            socket.on(contacts[contact]['roomId'] + ' new message', (data) => {
                                if (chatId === contacts[contact]['roomId']) {
                                    chatNotification = false;
                                    if (data.from !== username) {
                                        socket.emit('read', contacts[contact]['roomId']);
                                        messageItems.append(
                                            '<div class="item clearfix you" id="' + data['_id'] + '">' +
                                            '<div class="info"><span class="bold">' + decodeURIComponent(data.userName) + ': </span><span class="datetime" title="' + formatDate(new Date()) + '"></span></div>' +
                                            '<div class="message">' + decodeURIComponent(data.message) + '</div>' +
                                            '</div>'
                                        );
                                    }
                                    mediaMessage();
                                    $('.dialogs-window scroll-block').mCustomScrollbar("scrollTo", "last");
                                    messageItems.find('.datetime').timeago();
                                    jQuery(".datetime").timeago();
                                } else {
                                    $('#' + chatId + '_lastMessageTime').timeago("update", new Date());
                                    $('.lastMessageText' + chatId).html(decodeURIComponent(data.message));

                                    if ($('#' + contacts[contact]['roomId'] + 'chatCounter').length > 0) {
                                        $('#' + contacts[contact]['roomId'] + 'chatCounterArea').html('<span id="' + contacts[contact]['roomId'] + 'chatCounter">' + (parseInt($('#' + contacts[contact]['roomId'] + 'chatCounter').text()) + 1) + '</span>');
                                    } else {
                                        $('#' + contacts[contact]['roomId'] + 'chatCounterArea').html('<span id="' + contacts[contact]['roomId'] + 'chatCounter">1</span>');
                                    }

                                    try {
                                        getUnreadedMessages();
                                    } catch (e) {

                                    }
                                }
                            });

                            socket.on(contacts[contact]['roomId'] + ' read', () => {
                                if (chatId === contacts[contact]['roomId']) {
                                    $('.readStatus' + chatId).addClass('read');
                                }
                            });

                            checkStatus(contacts[contact]['userId']);
                        }

                        if (showChatContent()) {
                            chatId = showChatContent();
                            if ($('#' + chatId).data('to') !== 'undefined') {
                                $('.chat-container .messages-window').addClass('open').find('.head-top .username').html($('#' + chatId).data('username'));
                                $('.chat-container .messages-window').find('.head-top .indicator').addClass($('#' + chatId).data('to') + '_status');
                                $('.chat-container .messages-window').find('.loader-write >span').html($('#' + chatId).data('username'));
                                $('.chat-container .messages-window').find('.loader-write').addClass($('#' + chatId).data('to') + '_typing');
                                $('.loader-write').addClass('loader-write' + $('#' + chatId).data('to'));
                                messagesList(chatId, $('#' + chatId).data('to'), socket);
                            }
                        }
                    } else {
                        listMessageUsers.find('.preloader').hide();
                        listMessageUsers.prepend('<div class="info-message">' + __messageEmpty + '</div>');
                    }
                },
                error: function (data) {
                }
            });
        }

        function formatDate(date) {
            var date = new Date(date),
                month = (date.getMonth() + 1 < 10) ? '0' + (date.getMonth() + 1) : date.getMonth() + 1,
                days = (date.getDate() < 10) ? '0' + date.getDate() : date.getDate(),
                h = (date.getHours() < 10) ? '0' + date.getHours() : date.getHours(),
                m = (date.getMinutes() < 10) ? '0' + date.getMinutes() : date.getMinutes();
            return date.getFullYear() + '-' + month + '-' + days + ' ' + h + ':' + m;
        }

        function messageHeadItm(name, date, message, id, to, unread, userParams) {
            var itm = '<div data-username="' + name + '" class="item" id="' + id + '" data-to="' + to + '">';

            if (userParams.image !== null) {
                itm += '<div class="image"><div id="' + to + '_status" class="indicator"></div>' + unread + '<div class="img"><img src="' + userParams.image + '" alt=""></div></div>';
            } else {
                itm += '<div class="image"><div id="' + to + '_status" class="indicator"></div>' + unread + '<div class="colored-name" style="background-color: ' + userParams.bgColor + ';">' + userParams.shortName + '</div></div>';
            }

            itm += '<div class="content">';
            itm += '<div class="name">' + name + ' <span id="' + id + to + '_typing">' + __write + '</span></div>';
            itm += '<div id="' + id + '_lastMessageTime" title="' + formatDate(date) + '" class="date">' + formatDate(date) + '</div>';
            itm += '<div class="message last-message lastMessageText' + id + '">' + message + '</div>';
            itm += '</div>';
            itm += '</div>';
            return itm;
        }

        function messageItem(data, id) {
            var items = '';
            $.each(data, function (i, itm) {
                var date = new Date(itm.time);
                if (username === itm.userId) {
                    items += '<div class="item right readStatus' + id + ((itm.status > 0) ? ' read' : '') + '">';
                    items += '<div class="name">' + __you + ' <span class="date datetime" title="' + formatDate(date) + '">' + formatDate(date) + '</span></div>';
                    items += '<div class="message">' + itm.message + '</div>';
                    items += '</div>';
                } else {
                    items += '<div class="item">';
                    items += '<div class="name">' + itm.userName + ' <span class="date datetime" title="' + formatDate(date) + '">' + formatDate(date) + '</span></div>';
                    items += '<div class="message">' + itm.message + '</div>';
                    items += '</div>';
                }

            });
            return items;
        }

        function messagesList(id, userId, socket) {
            messageItems.html('');
            $.ajax({
                type: 'POST',
                url: __ajaxPath,
                dataType: "json",
                data: 'type=messages&id=' + id,
                success: function (data) {
                    if (!data.error) {
                        messageItems.html(messageItem(data.result, id))
                        $('.messages-window .scroll-block').mCustomScrollbar("scrollTo", "last", {
                            scrollInertia: 0
                        });
                        messageItems.find('.datetime').timeago();
                    }
                    checkStatus(userId);
                    socket.on(userId + ' user status', (data) => {
                        switch (data.status) {
                            case 'online':
                                $('.' + userId + '_status').addClass('online');

                                break;
                            default:
                                $('.' + userId + '_status').removeClass('online');
                        }
                    });
                    socket.emit('read', id);
                    $('#' + chatId + 'chatCounterArea').html('');
                },
                error: function (data) {
                }
            });
        }

        $('.chat-container .messages-window .head .menu .toggle').click(function (e) {
            e.preventDefault();
            $(this).closest('.menu').find('.dropdown').stop().slideToggle();
        });
        $(document).click(function (event) {
            if ($(event.target).closest('.chat-container .messages-window .head .menu').length)
                return;
            $('.chat-container .messages-window .head .menu .dropdown').stop().slideUp();
            event.stopPropagation();
        });
        $(document).on('click', '#list-message .item', function (e) {
            var urlParts = URL.parse();
            var userN = $(this).data('username'),
                userId = $(this).data('to');
            chatId = this.id;
            var $this = $(this);

            window.history.pushState(null, null, urlParts[0] + '#!' + chatId);

            $('.loader-write').addClass('loader-write' + $('#' + chatId).data('to'));
            $('.chat-container .messages-window').addClass('open').find('.head-top .username').html(userN);
            $('.chat-container .messages-window').find('.head-top .indicator').addClass(userId + '_status');
            $('.chat-container .messages-window').find('.loader-write >span').html(userN);
            $('.chat-container .messages-window').find('.loader-write').addClass(userId + '_typing');
            messagesList(chatId, userId, socket);

            if ($(window).width() > 992) {
                $('html, body').stop().animate({scrollTop: $this.closest('.chat-container').offset().top - 60}, 200);
            } else {
                $('html, body').stop().animate({scrollTop: $this.closest('.chat-container').offset().top - 50}, 200);
            }
        });
        $(document).on('click', '.chat-container .messages-window .head .back', function (e) {
            e.preventDefault();
            $(this).closest('.messages-window').removeClass('open');
            $('.loader-write').removeClass('loader-write' + $('#' + chatId).data('to'));
            $('.loader-write').removeClass($('#' + chatId).data('to') + '_typing');
            var urlParts = URL.parse();
            chatId = '';
            $inputMessage.val('');
            chatNotification = true;
            window.history.pushState(null, null, urlParts[0]);
        });

        $('button.sendMessage').click(function () {
            if ($(this).siblings('textarea').val() === '') {
                $(this).siblings('textarea').addClass('error')
            } else {
                if (!$(this).hasClass('active')) {
                    $(this).addClass('active');
                    sendMessage();
                    $(this).removeClass('active');
                }
            }
        });

        const checkStatus = (id) => {
            socket.emit('status', id);
        }

        // Sends a chat message
        const sendMessage = () => {
            var message = $inputMessage.val();
            message = cleanInput(message);
            if (message && connected && chatId.length === 24) {
                $inputMessage.val('');

                messageItems.append(
                    '<div class="item right readStatus' + chatId + '">' +
                    '<div class="name">' + __you + ': <span class="date datetime" title="' + formatDate(new Date()) + '"></span></div>' +
                    '<div class="message">' + message + '<span class="message-status"></span></div>' +
                    '</div>'
                );
                $('.datetime').timeago();
                $('.dialogs-window .scroll-block').mCustomScrollbar("scrollTo", "last");
                mediaMessageShipped();
                socket.emit(
                    'new message',
                    {
                        roomId: chatId,
                        from: username,
                        to: $('#' + chatId).attr('data-to'),
                        message: message,
                        userName: userName,
                        skipAdd: false
                    }
                );

                $('#' + chatId + '_lastMessageTime').timeago("update", new Date());
                $('.lastMessageText' + chatId).html('<span class="bold">' + __you + ': </span>' + message);

                updateTyping();
                socket.emit('stop typing', chatId);
                typing = false;
            }
        }

        const log = (message, options) => {
            //TODO реализовать добавление системных сообщений в чат
        }

        const cleanInput = (input) => {
            return $('<div/>').text(input).html();
        }

        // Updates the typing event
        const updateTyping = () => {
            if (connected) {
                if (!typing) {
                    typing = true;
                    socket.emit('typing', chatId);
                }
                lastTypingTime = (new Date()).getTime();

                setTimeout(() => {
                    var typingTimer = (new Date()).getTime();
                    var timeDiff = typingTimer - lastTypingTime;
                    if (timeDiff >= TYPING_TIMER_LENGTH && typing) {
                        socket.emit('stop typing', chatId);
                        typing = false;
                    }
                }, TYPING_TIMER_LENGTH);
            }
        }

        // Gets the 'X is typing' messages of a user
        const getTypingMessages = (data) => {
            return $('.typing.message').filter(function (i) {
                return $(this).data('username') === data.username;
            });
        }

        // Keyboard events

        $window.keydown(event => {
            if (event.which === 13 && $inputMessage.val() != '') {
                if (username) {
                    sendMessage();
                    socket.emit(chatId + ' ' + username + ' stop typing');
                    typing = false;
                }
                return false;
            } else if (event.which === 13) {
                return false;
            }
        });

        $inputMessage.on('input', () => {
            updateTyping();
        });

        $inputMessage.click(() => {
            $inputMessage.focus();
        });

        // Socket events
        socket.on(username + ' login', (data) => {
            connected = true;
        });

        socket.on('disconnect', () => {
            log('you have been disconnected');
        });

        socket.on('reconnect', () => {
            log('you have been reconnected');
            if (username) {
                socket.emit('add user', username);
            }
        });

        socket.on('reconnect_error', () => {
            log('attempt to reconnect has failed');
        });

        chatList();
    });
});