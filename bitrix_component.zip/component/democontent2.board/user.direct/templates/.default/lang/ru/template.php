<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 19.10.2018
 * Time: 11:10
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['USER_DIRECT_COMPONENT_H1'] = 'Мои сообщения';
$MESS['USER_DIRECT_COMPONENT_WRITE'] = 'печатает';
$MESS['USER_DIRECT_COMPONENT_MESSAGE_EMPTY'] = 'У вас еще нету переписки с другими пользователями';
$MESS['USER_DIRECT_COMPONENT_MESSAGES_LIST_EMPTY'] = 'У вас еще нету переписки с данным пользователем';
$MESS['USER_DIRECT_COMPONENT_MESSAGE_YOU'] = 'Вы';
$MESS['USER_DIRECT_COMPONENT_ONLINE'] = 'В сети';
$MESS['USER_DIRECT_COMPONENT_OFLINE'] = 'Не в сети';
$MESS['USER_DIRECT_COMPONENT_TEXTAREA_PLACEHOLDER'] = 'Введите текст сообщения...';