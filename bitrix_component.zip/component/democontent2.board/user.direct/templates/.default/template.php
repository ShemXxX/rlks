<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 19.10.2018
 * Time: 11:10
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Page\Asset;

$uid = intval($USER->GetID());
$userHash = md5(intval($USER->GetID()));

Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . '/app/css/mCustomScrollbar.css');
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/mCustomScrollbar.js');

?>
<div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
    <h1><?= Loc::getMessage('USER_DIRECT_COMPONENT_H1') ?></h1>
    <div class="chat-container">
        <div class="dialogs-window scroll-block" id="list-message">
            <div class="preloader">
                <div class="load">Loading...</div>
            </div>
        </div>
        <div class="messages-window">
            <div class="head">
                <div class="head-top">
                    <a class="back" href="#">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g>
                                <path d="M2.5 12L6.5 16L6.5 13L21.5 13L21.5 11L6.5 11L6.5 8L2.5 12Z" fill="#4F4F4F"/>
                            </g>
                        </svg>
                    </a>
                    <div class="user">
                        <div class="name username"></div>
                    </div>
                </div>
                <div class="delimiter"></div>
            </div>
            <div class="messages-list scroll-block" id="messages-items"></div>
            <div class="bottom">
                <div class="write loader-write light"><span></span></div>
                <textarea class="inputMessage"
                          placeholder="<?= Loc::getMessage('USER_DIRECT_COMPONENT_TEXTAREA_PLACEHOLDER') ?>"></textarea>
                <button class="sendMessage">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g>
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                  d="M1.5 10L1.51 3L22.5 12L1.51 21L1.5 14L16.5 12L1.5 10ZM3.51 6.03L11.02 9.25L3.5 8.25L3.51 6.03ZM11.01 14.75L3.5 17.97V15.75L11.01 14.75Z"
                                  fill="#F2F2F2"/>
                        </g>
                    </svg>
                </button>
            </div>
        </div>
    </div>
</div>
<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
    <?php
    $APPLICATION->IncludeComponent(
        'democontent2.board:user.menu',
        ''
    );
    ?>
</div>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}
?>
<script>
    var uid = '<?=$userHash?>',
        userName = '<?=$arResult['USER']['NAME']?>',
        __messageEmpty = '<?=Loc::getMessage('USER_DIRECT_COMPONENT_MESSAGE_EMPTY')?>',
        __write = '<?=Loc::getMessage('USER_DIRECT_COMPONENT_WRITE')?>',
        __messageItemsEmpty = '<?=Loc::getMessage('USER_DIRECT_COMPONENT_MESSAGES_LIST_EMPTY')?>',
        __ajaxPath = '<?=$this->GetFolder()?>/ajax.php',
        __siteTemplatePach = '<?=SITE_TEMPLATE_PATH?>',
        __you = '<?=Loc::getMessage('USER_DIRECT_COMPONENT_MESSAGE_YOU')?>';

    (function () {
        function numpf(n, f, s, t) {
            var n10 = n % 10;
            if ((n10 == 1) && ((n == 1) || (n > 20))) {
                return f;
            } else if ((n10 > 1) && (n10 < 5) && ((n > 20) || (n < 10))) {
                return s;
            } else {
                return t;
            }
        }

        jQuery.timeago.settings.strings = {
            prefixAgo: null,
            prefixFromNow: "<?=Loc::getMessage('TIME_ACROSS')?>",
            suffixAgo: "<?=Loc::getMessage('TIME_BACK')?>",
            suffixFromNow: null,
            seconds: "<?=Loc::getMessage('TIME_LESS_MINUTE')?>",
            minute: "<?=Loc::getMessage('TIME_MINUTE_4')?>",
            minutes: function (value) {
                return numpf(value, "%d <?=Loc::getMessage('TIME_MINUTE_1')?>", "%d <?=Loc::getMessage('TIME_MINUTE_2')?>", "%d <?=Loc::getMessage('TIME_MINUTE_3')?>");
            },
            hour: "<?=Loc::getMessage('TIME_HOUR_1')?>",
            hours: function (value) {
                return numpf(value, "%d <?=Loc::getMessage('TIME_HOUR_1')?>", "%d <?=Loc::getMessage('TIME_HOUR_2')?>", "%d <?=Loc::getMessage('TIME_HOUR_3')?>");
            },
            day: "<?=Loc::getMessage('TIME_DAY_1')?>",
            days: function (value) {
                return numpf(value, "%d <?=Loc::getMessage('TIME_DAY_1')?>", "%d <?=Loc::getMessage('TIME_DAY_2')?>", "%d <?=Loc::getMessage('TIME_DAY_3')?>");
            },
            month: "<?=Loc::getMessage('TIME_MONTH_1')?>",
            months: function (value) {
                return numpf(value, "%d <?=Loc::getMessage('TIME_MONTH_1')?>", "%d <?=Loc::getMessage('TIME_MONTH_2')?>", "%d <?=Loc::getMessage('TIME_MONTH_3')?>");
            },
            year: "<?=Loc::getMessage('TIME_YEAR_1')?>",
            years: function (value) {
                return numpf(value, "%d <?=Loc::getMessage('TIME_YEAR_1')?>", "%d <?=Loc::getMessage('TIME_YEAR_2')?>", "%d <?=Loc::getMessage('TIME_YEAR_3')?>");
            }
        };
    })();

    jQuery(".datetime").timeago();
</script>
