<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 24.09.2018
 * Time: 14:17
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (!count($arResult['LANGUAGES'])) {
    return;
}

use Bitrix\Main\Page\Asset;

Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . '/app/css/flags.css');

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}
?>
    <div class="flags _mt">
        <a class="flag-icon flag-icon-ru<?= (USER_LANG == 'ru') ? ' active' : '' ?>"
           href="<?= $APPLICATION->GetCurPage(false) ?>?changeLang=ru"></a>
        <?php
        foreach ($arResult['LANGUAGES'] as $language) {
            $active = '';
            if (USER_LANG == $language['UF_CODE']) {
                $active = ' active';
            }
            ?>
            <a class="flag-icon flag-icon-<?= ($language['UF_CODE'] == 'en') ? 'gb' : $language['UF_CODE'] ?><?= $active ?>"
               href="<?= $APPLICATION->GetCurPage(false) ?>?changeLang=<?= $language['UF_CODE'] ?>"></a>
            <?php
        }
        ?>
    </div>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}