<?php
/*
 * Date and Time: 09.12.2020, 10:31
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Democontent2\Board\Utils as UtilsAlias;

debug::console(decode::getUserMenus());

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}
?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('USER_SETTINGS_COMPONENT_H1') ?></h1>
        <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post"
              enctype="multipart/form-data" class="edit-form">
            <?php
            if (intval($arResult['USER']['PERSONAL_PHOTO'])) {
                ?>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="row">
                        <div class="col-lg-1 col-md-1 col-sm-2 col-xs-2">
                            <div class="image">
                                <img src="<?= CFile::GetPath($arResult['USER']['PERSONAL_PHOTO']) ?>" width="auto"
                                     height="45"/>
                            </div>
                        </div>
                        <div class="col-lg-11 col-md-11 col-sm-10 col-xs-10">
                            <input type="file" accept="image/x-png,image/jpeg,image/png,image/gif" name="photo">
                        </div>
                    </div>
                </div>
                <?php
            } else {
                ?>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <input type="file" accept="image/x-png,image/jpeg,image/png,image/gif" name="photo">
                </div>
                <?php
            }
            ?>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <label><?= Loc::getMessage('USER_SETTINGS_COMPONENT_PERSONAL_NAME') ?></label>
                <input class="required" type="text" name="name"
                       value="<?= $arResult['USER']['NAME'] ?>"
                       placeholder="<?= Loc::getMessage('USER_SETTINGS_COMPONENT_PERSONAL_NAME') ?>">
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <label><?= Loc::getMessage('USER_SETTINGS_COMPONENT_PERSONAL_LASTNAME') ?></label>
                <input type="text" name="lastName"
                       value="<?= $arResult['USER']['LAST_NAME'] ?>"
                       placeholder="<?= Loc::getMessage('USER_SETTINGS_COMPONENT_PERSONAL_LASTNAME') ?>">
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <label><?= Loc::getMessage('USER_SETTINGS_COMPONENT_CONTACTS_PHONE') ?></label>
                <input class="required" type="phone" name="phone"
                       value="<?= UtilsAlias::formatPhone($arResult['USER']['PERSONAL_PHONE']) ?>"
                       placeholder="<?= Loc::getMessage('USER_SETTINGS_COMPONENT_CONTACTS_PHONE') ?>" disabled>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <label><?= Loc::getMessage('USER_SETTINGS_COMPONENT_CONTACTS_EMAIL') ?></label>
                <input class="form-control" type="email"
                       value="<?= $arResult['USER']['EMAIL'] ?>"
                       placeholder="<?= Loc::getMessage('USER_SETTINGS_COMPONENT_CONTACTS_EMAIL') ?>"
                       disabled>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <button class="apply _mt" type="submit">
                    <?= Loc::getMessage('USER_SETTINGS_COMPONENT_BTN_SUBMIT') ?>
                </button>
            </div>
        </form>

        <h3 class="_mt"><?= Loc::getMessage('USER_SETTINGS_COMPONENT_BTN_TRANSFORM_PAS') ?></h3>
        <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post"
              class="edit-form">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <label><?= Loc::getMessage('USER_SETTINGS_COMPONENT_PASSWORD_NEW') ?></label>
                <input type="password" name="password" required class="required">
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <label><?= Loc::getMessage('USER_SETTINGS_COMPONENT_PASSWORD_REPIT') ?></label>
                <input type="password" name="confirmPassword" required class="required">
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <button class="apply _mt" type="submit">
                    <?= Loc::getMessage('USER_SETTINGS_COMPONENT_PASSWORD_SAVE') ?>
                </button>
            </div>
        </form>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        $APPLICATION->IncludeComponent("democontent2.board:user.menu", "template2", Array(
	
	),
	false
);
        ?>
    </div>
    <script>
        var __phoneFormat = parseInt('<?=intval(Option::get(DBOARD, 'phone_code_mask'))?>'),
            __phoneMask = '<?=Option::get(DBOARD, 'phone_mask')?>';
    </script>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}
