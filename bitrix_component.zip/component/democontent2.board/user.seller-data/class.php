<?php
/**
 * Date and Time: 22.07.2020, 9:30
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

use Bitrix\Main\Application;
use Democontent2\Board\User;

class UserSettingsComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        global $USER;
        global $APPLICATION;
        if ($USER->IsAuthorized()) {
          $request = Application::getInstance()->getContext()->getRequest();
          
          $userId = $USER->GetID();
          $rsUser = CUser::GetByID($userId);
          $userData = $rsUser->Fetch();
          
          $us = new User(intval($USER->GetID()), 0);

          if ($request->isPost()) {
            
  
            $fields = array(
              "UF_INN" => $_POST['UF_INN'],
              "UF_OGRN" => $_POST['UF_OGRN'],
              "UF_MARKET_PLACE" => $_POST['UF_MARKET_PLACE'],
              "UF_COMPANY_PERSON" => $_POST['UF_COMPANY_PERSON'],
              "UF_MARKET" => $_POST['UF_MARKET'],
            );
  
            $USER = new CUser;
            $makUserGroups = $USER->GetUserGroup($userId);
            foreach($makUserGroups as $key=>$gid) {
              if($gid == "5")
              {
                unset($makUserGroups[$key]);
              }
  
            }
            $gid = array_merge($makUserGroups, array(6));
  
            $USER->SetUserGroup($userId, $gid);
            if ($USER->Update($userId, $fields)) {
              LocalRedirect($APPLICATION->GetCurPage(false), true);
            } else
              echo $USER->LAST_ERROR;
            
//            $us->update($_POST, $_FILES);
//            LocalRedirect($APPLICATION->GetCurPage(false), true);
          }

          $this->arResult['USER'] = $userData;
          
          // get list from markets
          
          $arSelect = Array("ID", "NAME");
          $arFilter = Array("IBLOCK_ID"=>IntVal(1), "ACTIVE"=>"Y");
          $res = CIBlockElement::GetList(Array(), $arFilter, false, Array(), $arSelect);
          while($ob = $res->GetNextElement())
          {
            $arFields = $ob->GetFields();
            $this->arResult['MARKETS'][] = array(
              "ID" => $arFields['ID'],
              "NAME" => $arFields['NAME']
            );
          }
          
          $this->includeComponentTemplate();
        } else {
            LocalRedirect(SITE_DIR, true);
        }
    }
}
