<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 25.09.2018
 * Time: 10:25
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['USER_SETTINGS_COMPONENT_H1'] = 'Данные продавца';

$MESS['USER_SETTINGS_COMPONENT_INN'] = 'ИНН';
$MESS['USER_SETTINGS_COMPONENT_OGRN'] = 'ОГРН (-ИП)';
$MESS['USER_SETTINGS_COMPONENT_PLACE_MARKET'] = 'Место на рынке';
$MESS['USER_SETTINGS_COMPONENT_MARKETS'] = 'Рынки';
$MESS['USER_SETTINGS_COMPONENT_COMPANY_PERSON'] = 'Ответственное лицо';


$MESS['USER_SETTINGS_COMPONENT_AVA_TITLE'] = 'Загрузить аватарку';
$MESS['USER_SETTINGS_COMPONENT_AVA_TITLE_TOOLTIP'] = 'Изображение в формате #FORMATPICT#. Размером не более #SIZE# Мб.';
$MESS['USER_SETTINGS_COMPONENT_AVA_ERROR'] = 'Превышает допустимый размер #SIZE# Мб.';
$MESS['USER_SETTINGS_COMPONENT_PERSONAL_DATA'] = 'Персональные данные';
$MESS['USER_SETTINGS_COMPONENT_PERSONAL_NAME'] = 'Имя *';
$MESS['USER_SETTINGS_COMPONENT_PERSONAL_LASTNAME'] = 'Фамилия';
$MESS['USER_SETTINGS_COMPONENT_CONTACTS_PHONE'] = 'Телефон';
$MESS['USER_SETTINGS_COMPONENT_CONTACTS_EMAIL'] = 'Email';
$MESS['USER_SETTINGS_COMPONENT_CONTACTS_PASSWORD'] = 'Пароль';
$MESS['USER_SETTINGS_COMPONENT_BTN_TRANSFORM_PAS'] = 'Изменение пароля';
$MESS['USER_SETTINGS_COMPONENT_BTN_SUBMIT'] = 'Сохранить профиль';
$MESS['USER_SETTINGS_COMPONENT_PASSWORD_NEW'] = 'Введите новый пароль';
$MESS['USER_SETTINGS_COMPONENT_PASSWORD_REPIT'] = 'Повторите пароль';
$MESS['USER_SETTINGS_COMPONENT_PASSWORD_HIDE'] = 'Скрыть';
$MESS['USER_SETTINGS_COMPONENT_PASSWORD_HIDE'] = 'Скрыть';
$MESS['USER_SETTINGS_COMPONENT_PASSWORD_SAVE'] = 'Сохранить пароль';
$MESS['USER_SETTINGS_COMPONENT_CONTACTS'] = 'Контактные данные';
