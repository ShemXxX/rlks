<?php
/*
 * Date and Time: 09.12.2020, 10:31
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Democontent2\Board\Utils as UtilsAlias;

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
      <h1><?= Loc::getMessage('USER_SETTINGS_COMPONENT_H1') ?></h1>
    
      <form
        action="<?= $APPLICATION->GetCurPage(false) ?>"
        method="post"
        enctype="multipart/form-data"
        class="edit-form">
        
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <label><?= Loc::getMessage('USER_SETTINGS_COMPONENT_INN') ?></label>
          <input
            class="required"
            type="text"
            name="UF_INN"
            value="<?= $arResult['USER']['UF_INN'] ?>"
            placeholder="<?= Loc::getMessage('USER_SETTINGS_COMPONENT_INN') ?>">
        </div>
        
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <label><?= Loc::getMessage('USER_SETTINGS_COMPONENT_OGRN') ?></label>
          <input
            class="required"
            type="text"
            name="UF_OGRN"
            value="<?= $arResult['USER']['UF_OGRN'] ?>"
            placeholder="<?= Loc::getMessage('USER_SETTINGS_COMPONENT_OGRN') ?>">
        </div>
        
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <label><?= Loc::getMessage('USER_SETTINGS_COMPONENT_PLACE_MARKET') ?></label>
          <input
            class="required" type="text"
            name="UF_MARKET_PLACE"
            value="<?= $arResult['USER']['UF_MARKET_PLACE'] ?>"
            placeholder="<?= Loc::getMessage('USER_SETTINGS_COMPONENT_PLACE_MARKET') ?>">
        </div>
        
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <label><?= Loc::getMessage('USER_SETTINGS_COMPONENT_COMPANY_PERSON') ?></label>
          <input
            class="required"
            type="text"
            name="UF_COMPANY_PERSON"
            value="<?= $arResult['USER']['UF_COMPANY_PERSON'] ?>"
            placeholder="<?= Loc::getMessage('USER_SETTINGS_COMPONENT_COMPANY_PERSON') ?>">
        </div>
        
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <label><?= Loc::getMessage('USER_SETTINGS_COMPONENT_MARKETS') ?></label>
  
          <? foreach ($arResult['MARKETS'] as $marketId => $marketItem) { ?>
            <div class="checkBoxBlock">
              <input
                type="radio"
                name="UF_MARKET"
                value="<?=$marketItem['ID']?>"
                <?=$marketItem['ID'] == $arResult['USER']['UF_MARKET'] ? "checked='checked'" : ""?>
              >
              <span><?=$marketItem['NAME']?></span>
            </div>
          <? } ?>
        </div>
        
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <button class="apply _mt" type="submit">
            <?= Loc::getMessage('USER_SETTINGS_COMPONENT_BTN_SUBMIT') ?>
          </button>
        </div>
      </form>

    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        $APPLICATION->IncludeComponent("democontent2.board:user.menu", "template2", Array(
	
	),
	false
);
        ?>
    </div>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}
