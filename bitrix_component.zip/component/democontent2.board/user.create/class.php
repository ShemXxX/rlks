<?php
/*
 * Date and Time: 02.02.2021, 10:38
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

use Bitrix\Main\Application;
use Democontent2\Board\Iblock\City;
use Democontent2\Board\Iblock\Iblock as IblockAlias;
use Democontent2\Board\Iblock\Item;
use Democontent2\Board\User;

class UserCreateComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        global $USER;
        global $APPLICATION;
        if ($USER->IsAuthorized()) {
            $request = Application::getInstance()->getContext()->getRequest();

            $us = new User(intval($USER->GetID()));
            $item = new Item(0);
            $item->setUserId($us->getId());

            if ($request->isPost()) {
                $item->create($_POST);

                if (strlen($item->getPaymentRedirect()) > 0) {
                    LocalRedirect($item->getPaymentRedirect(), true);
                } else {
                    if ($item->getItemId() > 0 && $item->getIBlockId() > 0) {
                        LocalRedirect(SITE_DIR . 'user/items/' . $item->getIBlockId() . '-' . $item->getItemId() . '/', true);
                    }
                }
                LocalRedirect($APPLICATION->GetCurPage(false), true);
            }

            $iBlock = new IblockAlias();
            $city = new City();

            $this->arResult['REGION_ID'] = 0;
            $this->arResult['CITY_ID'] = 0;
            $this->arResult['IBLOCK_TYPES'] = $iBlock->getTypes();
            $this->arResult['CITIES'] = $city->getList(0, 0, false, false);
            $this->arResult['REGIONS'] = $city->getRegions();
            $this->arResult['USER'] = $us->get();
            $this->arResult['USER_ITEMS_COUNT'] = $us->getItemsCount();

            if (intval($request->getCookie('current_city')) > 0) {
                if (isset($this->arResult['CITIES'][intval($request->getCookie('current_city'))])) {
                    $this->arResult['CITY_ID'] = intval($request->getCookie('current_city'));
                }
            }

            if ($this->arResult['CITY_ID'] > 0 && count($this->arResult['REGIONS']) > 1) {
                foreach ($this->arResult['CITIES'] as $item) {
                    if ($item['id'] == $this->arResult['CITY_ID']) {
                        $this->arResult['REGION_ID'] = $item['regionId'];
                        break;
                    }
                }
            }

            $this->includeComponentTemplate();
        } else {
            LocalRedirect(SITE_DIR . 'user/login/', true);
        }
    }
}
