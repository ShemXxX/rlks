<?php
/*
 * Date and Time: 02.02.2021, 10:38
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

$MESS['USER_CREATE_COMPONENT_TITLE'] = 'Разместить объявление';
$MESS['USER_CREATE_COMPONENT_DROPZONE_PLACEHOLDER1'] = 'Выберите фотографии';
$MESS['USER_CREATE_COMPONENT_DROPZONE_PLACEHOLDER2'] = 'Вы можете добавить до #QTY# фото. Допустимые форматы: .jpg, .png';
$MESS['USER_CREATE_COMPONENT_DROPZONE_PLACEHOLDER3'] = 'Вы можете добавить максимум #QTY# фото.';
$MESS['USER_CREATE_COMPONENT_TITLE_IMAGES'] = 'Изображения (макс. #MAX_QTY# шт.)';
$MESS['USER_CREATE_COMPONENT_TITLE_CATEGORY'] = 'Категория';
$MESS['USER_CREATE_COMPONENT_CATEGORY_NOTSELECTED'] = 'Не выбрана';
$MESS['USER_CREATE_COMPONENT_MAIN_IMAGE'] = 'Главное фото';
$MESS['USER_CREATE_COMPONENT_TITLE_DESC'] = 'Описание';
$MESS['USER_CREATE_COMPONENT_BTN_SUBMIT'] = 'Сохранить и опубликовать';
$MESS['USER_CREATE_COMPONENT_BTN_SUBMIT_WITH_PAYMENT'] = 'Разместить за #SUM# #CURRENCY#';
$MESS['USER_CREATE_COMPONENT_TITLE_PRODUCT'] = 'Название';
$MESS['USER_CREATE_COMPONENT_TITLE_PRICE'] = 'Цена';
$MESS['USER_CREATE_COMPONENT_TITLE_CITY'] = 'Рынок';
$MESS['USER_CREATE_COMPONENT_TITLE_REGION'] = 'Регион';
$MESS['USER_CREATE_COMPONENT_SELECT_VARIANT'] = '--Выберите вариант--';
$MESS['USER_CREATE_COMPONENT_TITLE_MAP'] = 'Указать местоположение';
$MESS['USER_CREATE_COMPONENT_HIDE'] = 'Скрыть';
$MESS['USER_CREATE_COMPONENT_SEARCH_IN_MAP'] = 'Искать на карте';
$MESS['USER_CREATE_COMPONENT_FIND'] = 'Найти';
$MESS['USER_CREATE_COMPONENT_ERROR'] = 'Заполните обязательные поля';
$MESS['USER_CREATE_COMPONENT_YOUTUBE'] = 'Видео из YouTube';
$MESS['USER_CREATE_COMPONENT_YOUTUBE_PLACEHOLDER'] = 'Вставьте ссылку на видео в это поле';
