var dropZone;
$(document).ready(function () {
    Dropzone.autoDiscover = false;
    $('#files-previews').sortable({
        stop: function (event, ui) {
            setCounter();
        }
    });
    $('#files-previews').disableSelection();
    $(".dropzone-files__files").each(function () {
        var i = 0;
        dropZone = new Dropzone(
            this,
            {
                url: __path,
                paramName: '__files',
                maxFilesize: __maxImageSize,
                acceptedFiles: "image/*",
                addRemoveLinks: true,
                maxFiles: __allowImageQuantity,
                accept: function (file, done) {
                    var fileLenght = dropZone.files.length + $('.preview-pict').length;
                    if (fileLenght > __allowImageQuantity) {
                        done('maxFiles');
                    } else {
                        done();
                    }
                },
                init: function () {

                },
                success: function (file, response) {
                    $('#dropzone-files-hidden__files').append('<textarea class="__files" name="__files[]" id="' + file.upload.uuid + '">' + file.dataURL + '</textarea>');
                    $('.dropzone-files__files .error').remove();
                    $(document).find(file.previewElement).remove();

                    $('<div class="item preview-pict" data-id="' + file.upload.uuid + '"><div class="remove"><svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.115 12L6 8.115L9.885 12L12 9.885L8.115 6L12 2.115L9.885 0L6 3.885L2.115 0L0 2.115L3.885 6L0 9.885L2.115 12Z" fill="#EB5757"/></svg></div><div class="fotorama _mb" data-width="100%" data-height="80px" data-maxheight="80px" data-allowfullscreen="false" data-loop="false"><div data-img="' + file.dataURL + '"><div class="fotorama__blur" style="background:url(' + file.dataURL + ')"></div></div></div></div>').appendTo('#files-previews');
                    $('.fotorama').fotorama();

                    setCounter();
                    $('#files-previews').sortable({
                        stop: function (event, ui) {
                            setCounter();
                        }
                    });
                    $('#files-previews').disableSelection();
                },
                error: function (file, response) {
                    $('.dropzone-files__files .error').remove();
                    $(document).find(file.previewElement).remove();
                    $(".dropzone-files__files").addClass('dz-limit');
                },
                removedfile: function (file) {
                    $("#" + file.upload.uuid).remove();
                    $(document).find(file.previewElement).remove();
                },
                uploadprogress: function (file, progress) {
                    progress = parseInt(progress);
                    if (progress >= 10) {
                        $(file.previewElement).find('.dz-progress').css('width', '7px').html(progress + '%');
                    }
                    if (progress >= 20) {
                        $(file.previewElement).find('.dz-progress').css('width', '14px').html(progress + '%');
                    }
                    if (progress >= 30) {
                        $(file.previewElement).find('.dz-progress').css('width', '21px').html(progress + '%');
                    }
                    if (progress >= 40) {
                        $(file.previewElement).find('.dz-progress').css('width', '28px').html(progress + '%');
                    }
                    if (progress >= 50) {
                        $(file.previewElement).find('.dz-progress').css('width', '35px').html(progress + '%');
                    }
                    if (progress >= 60) {
                        $(file.previewElement).find('.dz-progress').css('width', '42px').html(progress + '%');
                    }
                    if (progress >= 70) {
                        $(file.previewElement).find('.dz-progress').css('width', '49px').html(progress + '%');
                    }
                    if (progress >= 80) {
                        $(file.previewElement).find('.dz-progress').css('width', '56px').html(progress + '%');
                    }
                    if (progress >= 90) {
                        $(file.previewElement).find('.dz-progress').css('width', '63px').html(progress + '%');
                    }
                    if (progress === 100) {
                        $(file.previewElement).find('.dz-progress').css('width', '78px').html(progress + '%');
                    }
                },
                queuecomplete: function () {
                    $(".dropzone-files__files").removeClass('dz-started');
                },
            }
        );
    });

    $(document).on('change', '.category-select', function (e) {
        var val = $(this).val();
        if (val === 0) {
            $(this).closest('.col').siblings('.col').find('.group').html('');
            $('#properties').html('');
        } else {
            if (typeof __types[val] !== 'undefined') {
                $(this).closest('.col').siblings('.col').find('.group').html('');
                $('#properties').html('');
                $(this).closest('.col').next('.col').find('.group').html(selectCreate(__types[val]['iblocks']));
                $(this).closest('.col').next('.col').find('select').select2({
                    language: 'ru',
                    minimumResultsForSearch: Infinity
                });
            } else {
                $(this).closest('.col').siblings('.col').find('.group').html('');
                $('#properties').html('');
            }
        }
    });
    $(document).on('change', '.category-str .col:nth-child(2) select', function (e) {
        var val = $(this).val();
        if (val === 0) {
            $(this).closest('.col').nextAll('.col').find('.group').html('');
            $('#properties').html('');
        } else {
            var $this = $(this),
                id = $(this).val(),
                depthLevel = 1;
            $.ajax({
                type: 'POST',
                url: __ajaxPath,
                dataType: "json",
                data: 'iblock=' + id + '&depthLevel=' + depthLevel + '&type=section',
                success: function (data) {
                    if (!data.error) {
                        var select = '<select class="required"  name="section[]" required style="width: 100%">';
                        select += '<option value="0">' + __selectVariant + '</option>';
                        $.each(data.result, function (index, value) {
                            select += '<option value="' + value['ID'] + '">' + value['NAME'] + '</option>';
                        });
                        select += '</select>';
                        $this.closest('.col').next('.col').find('.group').html(select);
                        $this.closest('.col').next('.col').find('select').select2({
                            language: 'ru',
                            minimumResultsForSearch: Infinity
                        });
                    }
                },
                error: function (data) {
                }
            });
            $.ajax({
                type: 'POST',
                url: __ajaxPath,
                dataType: "json",
                data: 'iblock=' + id + '&type=properties',
                success: function (data) {
                    if (!data.error) {
                        properties(data['result'])
                    }
                },
                error: function (data) {
                }
            });
        }
    });
    $(document).on('change', '.category-str .col:nth-child(3) select', function (e) {
        var val = $(this).val();
        if (val === 0) {
            $(this).closest('.col').nextAll('.col').find('.group').html('');
        } else {
            var
                $this = $(this),
                id = $('.category-str .col:nth-child(2)').find('select').val(),
                parentId = $this.val(),
                depthLevel = 2;
            $.ajax({
                type: 'POST',
                url: __ajaxPath,
                dataType: "json",
                data: 'iblock=' + id + '&parentId=' + parentId + '&depthLevel=' + depthLevel + '&type=section',
                success: function (data) {
                    if (!data.error) {
                        var select = '<select class="required"  name="section[]" required style="width: 100%">';
                        select += '<option value="0">' + __selectVariant + '</option>';
                        $.each(data.result, function (index, value) {
                            select += '<option value="' + value['ID'] + '">' + value['NAME'] + '</option>';
                        });
                        select += '</select>';
                        $this.closest('.col').next('.col').find('.group').html(select);
                        $this.closest('.col').next('.col').find('select').select2({
                            language: 'ru',
                            minimumResultsForSearch: Infinity
                        });
                    }
                },
                error: function (data) {
                }
            });
        }
    });
    $(document).on('click', '.preview-pict .remove', function (e) {
        e.preventDefault();
        removePict($(this).closest('.preview-pict').data('id'));
    });
    $(document).on('focus', 'input.required', function () {
        var errors = $(this).closest('form').find('.group.error').length;
        if (errors === 0 && !$(this).closest('form').hasClass('disable')) {
            $('#check-required').addClass('--dn');
        }
    });
    $(document).on('change', 'select.required', function () {
        var errors = $(this).closest('form').find('.group.error').length;
        if (errors === 0 && !$(this).closest('form').hasClass('disable')) {
            $('#check-required').addClass('--dn');
        }
    });
    $('.buttons button[type="submit"]').click(function (e) {
        e.preventDefault();
        checkInput($(this).closest('form'));
        var errors = $(this).closest('form').find('.group.error').length;
        if (errors === 0 && !$(this).closest('form').hasClass('disable')) {
            $(this).closest('form').addClass('disable').submit();
            $('#check-required').addClass('--dn');
        } else {
            $('#check-required').removeClass('--dn');
        }
    });
});

function selectCreate(data) {
    var select = '<select class="required" name="iblock" style="width: 100%" required>';
    select += '<option value="0">' + __selectVariant + '</option>';
    $.each(data, function (index, value) {
        select += '<option value="' + value['id'] + '">' + value['name'] + '</option>';
    });
    select += '</select>';
    return select;
}

function propSelectCreate(data) {
    var prop = $('#properties');
    var select = '';
    if (!data.isRequired) {
        select += '<select style="width: 100%" name="prop[' + data.id + ']' + ((data.isMultiple) ? '[]' : '') + '"' + ((data.isMultiple) ? ' multiple' : '') + '>';
        select += '<option value="0">' + __selectVariant + '</option>';
    } else {
        select += '<select class="required" style="width: 100%"  required  name="prop[' + data.id + ']' + ((data.isMultiple) ? '[]' : '') + '"' + ((data.isMultiple) ? ' multiple' : '') + '>';
    }
    $.each(data.values, function (index, item) {
        var selected = (item.isDefault) ? 'selected' : '';
        select += '<option value="' + item['id'] + '" ' + selected + '>' + item['name'] + '</option>';
    });
    select += '</select>';
    prop.append('<div class="col-md-4 col-sm-6 col-xs-12"><div class="group"><label>' + data.name + '</label> ' + select + '</div></div>');
    if (data.isRequired) {
        prop.find('>div:last-child').find('label').append('<span class="required-field">*</span>');
        prop.find('>div:last-child').find('select').attr('required', 'required').addClass('required');
        if (!prop.find('>div:last-child').find('option[selected]').length > 0) {
            prop.find('>div:last-child').find('select option:first-child').attr('selected', 'selected')
        }
    }
    prop.find('select:not(.select2-hidden-accessible)').select2({
        language: 'ru',
        minimumResultsForSearch: Infinity
    });
}

function properties(data) {
    var prop = $('#properties');
    prop.html('');
    $.each(data, function (index, value) {
        switch (value['type']) {
            case 'integer':
                prop.append('<div class="col-md-4 col-sm-6 col-xs-12"><div class="group"><label>' + value.name + '</label><input class="number-float" type="text" name="prop[' + value.id + ']" data-type="integer"></div></div>');
                if (value.isRequired) {
                    prop.find('>div:last-child').find('label').append('<span class="required-field">*</span>');
                    prop.find('>div:last-child').find('input').attr('required', 'required').addClass('required');
                }
                break;
            case 'string':
                prop.append('<div class="col-md-4 col-sm-6 col-xs-12"><div class="group"><label>' + value.name + '</label><input type="text" name="prop[' + value.id + ']" ></div></div>');
                if (value.isRequired) {
                    prop.find('>div:last-child').find('label').append('<span class="required-field">*</span>');
                    prop.find('>div:last-child').find('input').attr('required', 'required').addClass('required');
                }
                break;
            case 'list':
                propSelectCreate(value)
                break;
        }
    });
    $('input[data-type="integer"]').on('keyup', function () {
        let $this = $(this);
        let $val = _App.str_to_float($this.val());
        $this.val($val);

        if (parseFloat($val)) {
            $($this.siblings()[0]).addClass('active');
        } else {
            $($this.siblings()[0]).removeClass('active');
        }
    });
}

function __getRegionCities(regionId) {
    let changeCity = $('#changeCity');
    $(changeCity).html('');
    $.ajax({
        type: 'POST',
        url: __ajaxPath,
        dataType: "json",
        data: 'type=cities&regionId=' + regionId,
        success: function (data) {
            let put = '';
            if (!data.error) {
                for (let k in data.result) {
                    put += '<option value="' + data.result[k]['id'] + '">' + data.result[k]['name'] + '</option>';
                }
            }

            if (put.length) {
                $(changeCity).html(put);
            }
        },
        error: function (data) {
        }
    });

    return false;
}


function checkInput(form) {
    var $form = $(form);
    $form.find('select.required').each(function () {
        if ($(this).val() === '0') {
            $(this).parents('.group').addClass('error');
        } else {
            $(this).parents('.group').removeClass('error');
        }
    });
    $form.find('input[type=text].required').each(function () {
        if ($(this).val() !== '') {
            $(this).parents('.group').removeClass('error');
        } else {
            $(this).parents('.group').addClass('error');
        }
    });
}

function removePict(id) {
    $('#' + id + ', [data-id="' + id + '"]').remove();
    $('.dropzone-files__files').removeClass('dz-limit');
    if (dropZone.files.length > 10) {
        dropZone.files.length = 9;
    } else {
        if (dropZone.files.length) {
            dropZone.files.length--;
        }
    }
    setCounter();
}

function setCounter() {
    let counter = 0;
    $('.preview-pict').removeClass('main');
    $('.preview-pict').each(function () {
        counter++;
        $(this).attr('data-counter', counter);
        $('#' + $(this).data('id')).attr('name', '__files[' + counter + ']');
        if (counter === 1) {
            $(this).addClass('main');
        }
    });
}