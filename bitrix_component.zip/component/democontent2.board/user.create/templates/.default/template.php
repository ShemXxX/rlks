<?php
/*
 * Date and Time: 02.02.2021, 10:34
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Page\Asset;
use Bitrix\Main\Web\Json;

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

$allowImageQuantity = intval(Option::get(DBOARD, 'max_images'));
$upperLimitCost = intval(Option::get(DBOARD, 'upper_limit_cost'));
$freeLimit = intval(Option::get(DBOARD, 'free_limit'));
$currencyName = Option::get(DBOARD, 'currency_name');

Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/jquery-ui.js');

$mapType = Option::get(DBOARD, 'defaultMap');

switch ($mapType) {
    case 'google':
        Asset::getInstance()->addJs('https://maps.googleapis.com/maps/api/js?language=' . ((USER_LANG == 'ru') ? 'ru' : 'en') . '&key='
            . Option::get(DBOARD, 'google_maps_api_key'));
        break;
    default:
        Asset::getInstance()->addJs(
            'https://api-maps.yandex.ru/2.1/?load=package.full&apikey=' . Option::get(DBOARD, 'yandex_maps_api_key') . '&lang=' . ((USER_LANG == 'ru') ? 'ru_RU' : 'en_US')
        );
}

Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . '/app/css/select2.min.css');
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/select2.js');

Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/create-' . $mapType . '-map.js');
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/lib/dropzone/dropzone.js');

$cityCoordinates = [];
$citiesCoordinates = [];
$regionsCount = count($arResult['REGIONS']);
$regionId = $arResult['REGION_ID'];
$cityId = $arResult['CITY_ID'];

foreach ($arResult['CITIES'] as $k => $v) {
    $citiesCoordinates[$k] = $v['coordinates'];
}

?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('USER_CREATE_COMPONENT_TITLE') ?></h1>
        <form class="edit-form" method="post" action="<?= $APPLICATION->GetCurPage(false) ?>">
            <h4>
                <?= Loc::getMessage('USER_CREATE_COMPONENT_TITLE_IMAGES', ['#MAX_QTY#' => $allowImageQuantity]) ?>
            </h4>
            <div id="files-previews" class="images"></div>
            <div class="upload-files dropzone-files__files">
                <div class="dz-default dz-message">
                    <?= Loc::getMessage('USER_CREATE_COMPONENT_DROPZONE_PLACEHOLDER2', ['#QTY#' => $allowImageQuantity]) ?>
                </div>
            </div>
            <div class="upload-files__hidden" id="dropzone-files-hidden__files"></div>
            <div class="delimiter"></div>
            <div class="row">
                <div class="col-sm-6 col-xs-12">
                    <div class="group">
                        <label>
                            <?= Loc::getMessage('USER_CREATE_COMPONENT_TITLE_PRODUCT') ?>
                            <span class="required-field">*</span>
                        </label>
                        <input class="required" type="text" required name="name">
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="group">
                        <label>
                            <?= Loc::getMessage('USER_CREATE_COMPONENT_TITLE_PRICE') ?>
                            <span class="required-field">*</span>
                        </label>
                        <input class="required" type="text" required name="price" data-type="integer">
                    </div>
                </div>
            </div>
            <div class="row">
                <?php
                if ($regionsCount > 1) {
                    ?>
                    <div class="col-sm-6 col-xs-12">
                        <div class="group">
                            <label>
                                <?= Loc::getMessage('USER_CREATE_COMPONENT_TITLE_REGION') ?>
                                <span class="required-field">*</span>
                            </label>
                            <select class="js-select required" name="region" required="" style="width: 100%"
                                    onchange="__getRegionCities(this.value)">
                                <?php
                                $i = 0;
                                foreach ($arResult['REGIONS'] as $region) {
                                    $i++;
                                    $selected = '';
                                    if ($regionId > 0) {
                                        if (intval($region['ID']) == $regionId) {
                                            $selected = ' selected';
                                        }
                                    } else {
                                        if ($i == 1) {
                                            $selected = ' selected';
                                            $regionId = intval($region['ID']);
                                        }
                                    }
                                    ?>
                                    <option value="<?= $region['ID'] ?>"<?= $selected ?>><?= $region['NAME'] ?></option>
                                    <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <?php
                }
                ?>
                <div class="col-sm-<?= (($regionsCount > 1) ? '6' : '12') ?> col-xs-12">
                    <div class="group">
                        <label>
                            <?= Loc::getMessage('USER_CREATE_COMPONENT_TITLE_CITY') ?>
                            <span class="required-field">*</span>
                        </label>
                        <select id="changeCity" class="js-select required disabled" name="city"
																required="" style="width: 100%">
                            <?php
                            $i = 0;
                            foreach ($arResult['CITIES'] as $city) {
                                $selected = '';

                                if ($regionId > 0) {
                                    if ($city['regionId'] == $regionId) {
                                        $i++;
                                        if ($cityId > 0) {
                                            if ($city['id'] == $cityId) {
                                                $selected = ' selected';
                                                $cityCoordinates = $city['coordinates'];
                                            }
                                        }

                                        if (!count($cityCoordinates)) {
                                            if ($city['default'] > 0) {
                                                $selected = ' selected';
                                                $cityCoordinates = $city['coordinates'];
                                            } else {
                                                if ($i == 1) {
                                                    $selected = ' selected';
                                                    $cityCoordinates = $city['coordinates'];
                                                }
                                            }
                                        }

                                        echo '<option value="' . $city['id'] . '"' . $selected . '>' . $city['name'] . '</option>';
                                    }
                                } else {
                                    $i++;
                                    if ($arResult['CITY_ID'] > 0) {
                                        if (!count($cityCoordinates)) {
                                            $cityCoordinates = $city['coordinates'];
                                        }

                                        if ($city['id'] == $arResult['CITY_ID']) {
                                            $selected = ' selected';
                                            $cityCoordinates = $city['coordinates'];
                                        }
                                    } else {
                                        if (!count($cityCoordinates)) {
                                            $cityCoordinates = $city['coordinates'];
                                        }
                                        if ($city['default'] > 0) {
                                            $selected = ' selected';
                                            $cityCoordinates = $city['coordinates'];
                                        }
                                    }
                                    echo '<option value="' . $city['id'] . '"' . $selected . '>' . $city['name'] . '</option>';
                                }
                            }
                            ?>
                        </select>
                    </div>
                </div>
            </div>

            <h4>
                <?= Loc::getMessage('USER_CREATE_COMPONENT_TITLE_CATEGORY') ?>
                <span class="required-field">*</span>
            </h4>
            <div class="row category-str">
                <div class="col col-md-3 col-sm-6 col-xs-12">
                    <div class="group">
                        <select class="js-select category-select required" required style="width: 100%">
                            <option value="0"><?= Loc::getMessage('USER_CREATE_COMPONENT_SELECT_VARIANT') ?></option>
                            <?php
                            foreach ($arResult['IBLOCK_TYPES'] as $key => $item) {
                                ?>
                                <option value="<?= $key ?>"><?= $item['name'] ?></option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="col col-md-3 col-sm-6 col-xs-12">
                    <div class="group"></div>
                </div>
                <div class="col col-md-3 col-sm-6 col-xs-12">
                    <div class="group"></div>
                </div>
                <div class="col col-md-3 col-sm-6 col-xs-12">
                    <div class="group"></div>
                </div>
            </div>
            <div class="row properties-list" id="properties"></div>

            <div class="delimiter"></div>
            <div class="map-container">
                <input id="map-location" type="hidden" name="location">
                <?php
                if ($mapType == 'google') {
                    ?>
                    <div id="search-map" class="search-map tbl">
                        <div class="tbc">
                            <input id="map-address" class="form-control" type="textbox"
                                   placeholder="<?= Loc::getMessage('USER_CREATE_COMPONENT_SEARCH_IN_MAP') ?>" value="">
                        </div>
                        <div class="tbc">
                            <button id="map-submit" class="btn btn-orange btn-fluid">
                                <?= Loc::getMessage('USER_CREATE_COMPONENT_FIND') ?>
                            </button>
                        </div>
                    </div>
                    <?php
                }
                ?>
                <div id="<?= $mapType ?>-map" class="map"></div>
            </div>
            <div class="delimiter"></div>

            <h4><?= Loc::getMessage('USER_CREATE_COMPONENT_YOUTUBE') ?></h4>
            <input type="text" name="youtube" value=""
                   placeholder="<?= Loc::getMessage('USER_CREATE_COMPONENT_YOUTUBE_PLACEHOLDER') ?>">

            <h4><?= Loc::getMessage('USER_CREATE_COMPONENT_TITLE_DESC') ?></h4>
            <textarea rows="8" name="description"
                      placeholder="<?= Loc::getMessage('USER_CREATE_COMPONENT_TITLE_DESC') ?>"></textarea>
            <div id="check-required" class="warning-message _mt --dn">
                <?= Loc::getMessage('USER_CREATE_COMPONENT_ERROR') ?>
            </div>
            <div class="buttons _mt">
                <button type="submit" class="save">
                    <?php
                    $currentLimit = $freeLimit;
                    if (intval($arResult['USER']['UF_BOARD_LIMIT']) > 0) {
                        $currentLimit = intval($arResult['USER']['UF_BOARD_LIMIT']);
                    }

                    if (($arResult['USER_ITEMS_COUNT'] + 1) > $currentLimit) {
                        echo Loc::getMessage('USER_CREATE_COMPONENT_BTN_SUBMIT_WITH_PAYMENT', [
                            '#SUM#' => $upperLimitCost,
                            '#CURRENCY#' => $currencyName,
                        ]);
                    } else {
                        echo Loc::getMessage('USER_CREATE_COMPONENT_BTN_SUBMIT');
                    }
                    ?>
                </button>
            </div>
        </form>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:user.menu',
            ''
        );
        ?>
    </div>
    <script>
        var __path = '<?=$APPLICATION->GetCurPage(false)?>',
            siteTemplatePath = '<?= SITE_TEMPLATE_PATH ?>',
            __allowImageQuantity = <?=$allowImageQuantity?>,
            __maxImageSize = parseInt('<?=intval(Option::get(DBOARD, 'max_image_size'))?>'),
            __types = JSON.parse('<?= Json::encode($arResult['IBLOCK_TYPES'])?>'),
            __defaultLocation = JSON.parse('<?= Json::encode($cityCoordinates)?>'),
            __citiesCoordinates = JSON.parse('<?= Json::encode($citiesCoordinates)?>'),
            __ajaxPath = '<?=$this->GetFolder()?>/ajax.php',
            __mainImage = '<?=Loc::getMessage('USER_CREATE_COMPONENT_MAIN_IMAGE')?>',
            __selectVariant = '<?=Loc::getMessage('USER_CREATE_COMPONENT_SELECT_VARIANT')?>';
    </script>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}