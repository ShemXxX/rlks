<?php
/*
 * Date and Time: 17.11.2020, 9:29
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

\Bitrix\Main\Loader::includeModule('democontent2.board');

use Bitrix\Main\Context;
use Bitrix\Main\Engine\Response\Json;
use Bitrix\Main\SystemException;
use Democontent2\Board\Iblock\City;
use Democontent2\Board\Iblock\Properties;
use Democontent2\Board\Iblock\Section;

$request = Context::getCurrent()->getRequest();
$error = 1;
$result = [];

global $USER;

if ($USER->IsAuthorized() && $request->isAjaxRequest() && $request->isPost()) {
    if ($request->getPost('type')) {
        switch ($request->getPost('type')) {
            case 'section':
                if ($request->getPost('depthLevel') && intval($request->getPost('iblock')) > 0) {
                    $section = new Section();
                    if (intval($request->getPost('parentId')) > 0) {
                        $result = $section->getSections(
                            $request->getPost('iblock'),
                            $request->getPost('depthLevel'),
                            $request->getPost('parentId')
                        );
                        if (count($result) > 0) {
                            $error = 0;
                        }
                    } else {
                        $result = $section->getSections(
                            $request->getPost('iblock'),
                            $request->getPost('depthLevel')
                        );
                        if (count($result) > 0) {
                            $error = 0;
                        }
                    }
                }
                break;
            case 'properties':
                if (intval($request->getPost('iblock')) > 0) {
                    $properties = new Properties(intval($request->getPost('iblock')));
                    try {
                        $result = $properties->all();
                        if (count($result) > 0) {
                            $error = 0;
                        }
                    } catch (SystemException $e) {
                    }
                }
                break;
            case 'cities':
                if ($request->getPost('regionId') && intval($request->getPost('regionId')) > 0) {
                    $city = new City();
                    $result = $city->getList(0, intval($request->getPost('regionId')), false, false);

                    if (count($result) > 0) {
                        $error = 0;
                    }
                }
                break;
        }
    }
}

$r = new Json([
    'error' => $error,
    'result' => $result
]);
$r->send();
