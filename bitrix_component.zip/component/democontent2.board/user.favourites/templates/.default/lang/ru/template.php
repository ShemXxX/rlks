<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 08.10.2018
 * Time: 21:25
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['USER_FAVOURITES_COMPONENT_H1'] = 'Избранное';
$MESS['USER_FAVOURITES_COMPONENT_BTN_MORE'] = 'Подробнее';
$MESS['USER_FAVOURITES_COMPONENT_EMTPTY'] = 'У вас нет избранных объявлений';