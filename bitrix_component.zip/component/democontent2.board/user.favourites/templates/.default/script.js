$(document).ready(function () {
    $('.favourite').click(function () {
        let $this = $(this);
        let id = $this.attr('data-id');
        let i = $this.attr('data-i');
        let $items = $('.items-list');

        $.ajax({
            type: 'POST',
            url: __ajaxPath + '/ajax.php',
            dataType: "json",
            data: 'id=' + id + '&i=' + i + '&type=like',
            success: function (data) {
                if (!data.error) {
                    $this.parent().parent().remove();
                    if (!$items.find('.item').length) {
                        $items.parent().html('<div class="info-message _mt">' + emptyTxt + '</div>');
                    }
                }
            }
        });
    });
});