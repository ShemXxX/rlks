<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 08.10.2018
 * Time: 21:24
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;

$currencyName = Option::get(DBOARD, 'currency_name');
$emptyTxt = Loc::getMessage('USER_FAVOURITES_COMPONENT_EMTPTY');
?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('USER_FAVOURITES_COMPONENT_H1') ?></h1>
        <?php
        if (!$arResult['ITEMS']->current()) {
            ?>
            <div class="info-message _mb"><?= $emptyTxt ?></div>
            <?php
        } else {
            ?>
            <div class="items-list">
                <?php
                foreach ($arResult['ITEMS'] as $product) {
                    $arButtons = \CIBlock::GetPanelButtons(
                        $product['UF_IBLOCK_ID'],
                        $product['UF_ID'],
                        0,
                        ["SECTION_BUTTONS" => false, "SESSID" => false]
                    );
                    $arItem["EDIT_LINK"] = $arButtons["edit"]["edit_element"]["ACTION_URL"];
                    $arItem["DELETE_LINK"] = $arButtons["edit"]["delete_element"]["ACTION_URL"];
                    $this->AddEditAction(
                        $product['UF_ID'],
                        $arItem['EDIT_LINK'],
                        CIBlock::GetArrayByID(
                            $product['UF_IBLOCK_ID'],
                            "ELEMENT_EDIT"
                        )
                    );
                    $this->AddDeleteAction(
                        $product['UF_ID'],
                        $arItem['DELETE_LINK'],
                        CIBlock::GetArrayByID(
                            $product['UF_IBLOCK_ID'],
                            "ELEMENT_DELETE"
                        ),
                        ["CONFIRM" => Loc::getMessage('CONFIRM_DELETE')]
                    );

                    $pict = null;
                    if (intval($product['UF_IMAGE_ID'])) {
                        $pict = intval($product['UF_IMAGE_ID']);
                        $pict = CFile::ResizeImageGet(
                            $pict,
                            [
                                'width' => 199,
                                'height' => 151
                            ],
                            BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
                            true
                        );
                    }
                    ?>
                    <div class="item" id="<?= $this->GetEditAreaId($product['UF_ID']) ?>">
                        <div class="image">
                            <div class="favourite active"
                                 data-id="<?= $product['UF_ID'] ?>" data-i="<?= $product['UF_IBLOCK_ID'] ?>">
                        <span class="wenk--right" data-wenk-pos="right"
                              data-wenk="<?= Loc::getMessage('LIST_COMPONENT_REMOVE_FAV') ?>">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                    <g>
                                        <path d="M9 15.8812L7.9125 14.8912C4.05 11.3887 1.5 9.07874 1.5 6.24374C1.5 3.93374 3.315 2.11874 5.625 2.11874C6.93 2.11874 8.1825 2.72624 9 3.68624C9.8175 2.72624 11.07 2.11874 12.375 2.11874C14.685 2.11874 16.5 3.93374 16.5 6.24374C16.5 9.07874 13.95 11.3887 10.0875 14.8987L9 15.8812Z"
                                              fill="#EB5757"/>
                                    </g>
                                </svg>
                        </span>
                            </div>
                            <a href="<?= $product['URL'] ?>" title="<?= $product['UF_NAME'] ?>">
                                <div class="fotorama _mb" data-width="100%" data-height="151px" data-maxheight="151px"
                                     data-allowfullscreen="false" data-loop="false">
                                    <?php
                                    if (!is_null($pict)) {
                                        ?>
                                        <div data-img="<?= $pict['src'] ?>">
                                            <div class="fotorama__blur"
                                                 style="background:url(<?= $pict['src'] ?>)"></div>
                                        </div>
                                        <?php
                                    } else {
                                        ?>
                                        <svg class="stub" width="40" height="40" viewBox="0 0 40 40" fill="none"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <g>
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                      d="M35 1.66666H11.6667C9.83335 1.66666 8.33335 3.16666 8.33335 4.99999V28.3333C8.33335 30.1667 9.83335 31.6667 11.6667 31.6667H35C36.8334 31.6667 38.3334 30.1667 38.3334 28.3333V4.99999C38.3334 3.16666 36.8334 1.66666 35 1.66666ZM1.66669 8.33332H5.00002V35H31.6667V38.3333H5.00002C3.16669 38.3333 1.66669 36.8333 1.66669 35V8.33332ZM22.0167 23.05L26.6 17.15L32.5 25H14.1667L18.75 19.1167L22.0167 23.05ZM11.6667 28.3333H35V4.99999H11.6667V28.3333Z"
                                                      fill="#BDBDBD"
                                                / >
                                            </g>
                                        </svg>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </a>
                        </div>
                        <div class="content">
                            <div class="link">
                                <a href="<?= $product['URL'] ?>"><?= $product['UF_NAME'] ?></a>
                            </div>
                            <div class="location">
                                <div class="icon">
                                    <svg width="17" height="17" viewBox="0 0 17 17" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                              d="M2.125 7.45875L14.875 2.125L9.53417 14.875H8.84L6.97 10.03L2.125 8.15292V7.45875ZM9.22958 11.9425L12.2329 4.76708L5.0575 7.76333L7.48708 8.70541L8.06791 8.93208L8.29458 9.52L9.22958 11.9425Z"
                                              fill="#999999"/>
                                    </svg>
                                </div>
                                <?php
                                if (intval($product['UF_CITY'])) {
                                    ?>
                                    <div class="text">
                                        <?= $arResult['CITIES'][$product['UF_CITY']]['name'] ?>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
            <?php
        }
        ?>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:user.menu',
            ''
        );
        ?>
    </div>
    <script>
        var __ajaxPath = '<?=$this->GetFolder()?>',
            emptyTxt = '<?=$emptyTxt?>';
    </script>
<?
if (method_exists($this, 'createFrame')) {
    $frame->end();
}