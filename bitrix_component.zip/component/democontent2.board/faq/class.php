<?php
/**
 * Date and Time: 22.07.2020, 9:14
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

use Bitrix\Main\Application;
use Bitrix\Main\Loader;
use Bitrix\Main\LoaderException;
use Bitrix\Main\SystemException;

class FaqComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        $this->arResult['ITEMS'] = [];
        try {
            if (Loader::includeModule('iblock') && Loader::includeModule('democontent2.board')) {
                if (isset($this->arParams['IBLOCK_ID']) && intval($this->arParams['IBLOCK_ID']) > 0) {
                    $cache = Application::getInstance()->getCache();
                    $cache_time = intval($this->arParams['CACHE_TIME']);
                    $cache_id = md5(DBOARD . 'faq');
                    $cache_path = '/' . DBOARD . '/faq';

                    $taggedCache = Application::getInstance()->getTaggedCache();

                    if ($cache_time > 0 && $cache->initCache($cache_time, $cache_id, $cache_path)) {
                        $res = $cache->getVars();

                        if (is_array($res[$cache_id]) && (count($res[$cache_id]) > 0)) {
                            $this->arResult['ITEMS'] = $res[$cache_id];
                        }
                    } else {
                        $taggedCache->startTagCache($cache_path);
                        $taggedCache->registerTag('iblock_id_' . intval($this->arParams['IBLOCK_ID']));

                        $get = CIBlockElement::GetList(
                            [
                                'SORT' => 'ASC',
                                'NAME' => 'ASC'
                            ],
                            [
                                '=IBLOCK_ID' => intval($this->arParams['IBLOCK_ID']),
                                '=ACTIVE' => 'Y'
                            ],
                            false,
                            false,
                            [
                                'ID',
                                'NAME',
                                'DETAIL_TEXT'
                            ]
                        );
                        while ($res = $get->GetNextElement()) {
                            $this->arResult['ITEMS'][] = $res->GetFields();
                        }

                        if ($cache_time > 0) {
                            $cache->startDataCache($cache_time, $cache_id, $cache_path);
                            if (!count($this->arResult['ITEMS'])) {
                                $cache->abortDataCache();
                                $taggedCache->abortTagCache();
                            }
                            $cache->endDataCache([$cache_id => $this->arResult['ITEMS']]);
                            $taggedCache->endTagCache();
                        }
                    }
                }
            }
        } catch (LoaderException $e) {
        } catch (SystemException $e) {
        }

        $this->includeComponentTemplate();
    }
}
