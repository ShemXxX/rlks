<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 27.09.2018
 * Time: 11:49
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (!count($arResult['ITEMS'])) {
    return;
}
if (method_exists($this, 'setFrameMode')) {
    $this->setFrameMode(true);
}

use Bitrix\Main\Localization\Loc;

?>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <h1><?= Loc::getMessage('FAQ_COMPONENT_TITLE_H1') ?></h1>
    <?php
    foreach ($arResult['ITEMS'] as $item) {
        ?>
        <div class="_box _mb">
            <h2><?= $item['NAME'] ?></h2>
            <div class="_mt">
                <?= $item['DETAIL_TEXT'] ?>
            </div>
        </div>
        <?php
    }
    ?>
</div>
