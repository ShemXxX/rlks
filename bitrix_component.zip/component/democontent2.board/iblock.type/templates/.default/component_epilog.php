<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 09.10.2018
 * Time: 14:55
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
global $APPLICATION;

if (isset($arResult['META']['UF_BREADCRUMB']) && strlen($arResult['META']['UF_BREADCRUMB'])) {
    $APPLICATION->AddChainItem($arResult['META']['UF_BREADCRUMB']);
} else {
    if (isset($arResult['META']['UF_TITLE']) && strlen($arResult['META']['UF_TITLE'])) {
        $APPLICATION->AddChainItem($arResult['META']['UF_TITLE']);
    }
}

foreach ($arResult['META'] as $metaKey => $metaValue) {
    switch ($metaKey) {
        case 'UF_TITLE':
            if (strlen($metaValue) > 0) {
                $APPLICATION->SetTitle($metaValue);
                $APPLICATION->SetPageProperty('title', $metaValue);
            }
            break;
        case 'UF_DESCRIPTION':
            if (strlen($metaValue) > 0) {
                $APPLICATION->SetPageProperty('description', $metaValue);
            }
            break;
        case 'UF_KEYWORDS':
            if (strlen($metaValue) > 0) {
                $APPLICATION->SetPageProperty('keywords', $metaValue);
            }
            break;
    }
}