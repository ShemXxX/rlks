<?php
/*
 * Date and Time: 09.12.2020, 10:02
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

use Bitrix\Main\Application;
use Bitrix\Main\IO\File;
use Democontent2\Board\Iblock\City;
use Democontent2\Board\Iblock\Iblock as IblockAlias;
use Democontent2\Board\Iblock\IblockTypeMeta;
use Democontent2\Board\Iblock\Items;
use Democontent2\Board\Iblock\Menu;

class IblockTypeComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        global $USER;

        $iblock = new IblockAlias();
        $iblocks = $iblock->getAllList($this->arParams['iBlockType']);

        if (count($iblocks) > 0) {
            $this->arResult['IS_AUTHORIZED'] = $USER->IsAuthorized();

            $request = Application::getInstance()->getContext()->getRequest();
            $iblockMeta = new IblockTypeMeta($this->arParams['iBlockType']);
            $city = new City();
            $items = new Items();
            $menu = new Menu();
            $cities = $city->getList();

            $iblockMeta->setTtl(3600);

            $cityId = 0;
            $cityCode = '';
            $cityParams = [];

            if (isset($this->arParams['cityCode'])) {
                $cityCode = $this->arParams['cityCode'];
            }

            foreach ($cities as $c) {
                if (intval($c['default']) > 0) {
                    $cityId = intval($c['id']);
                    $cityParams = $c;
                    break;
                }
            }

            $this->arResult['IBLOCK_ID'] = 0;
            $this->arResult['LINKS'] = [];
            $this->arResult['ITEMS'] = [];
            $this->arResult['MENU'] = $menu->get();

            foreach ($cities as $c) {
                if ($c['code'] == $cityCode) {
                    if (intval($c['default']) > 0) {
                        LocalRedirect(SITE_DIR . $this->arParams['iBlockType'] . '/', true);
                    } else {
                        $cityId = intval($c['id']);
                        $cityParams = $c;
                    }
                    break;
                }
            }

            $this->arResult['CITIES'] = $cities;
            $this->arResult['CITY'] = $cityParams;

            $skipCookie = false;
            if (count($cities) < 2 || intval($request->getCookie('skipCity'))) {
                $items->setSkipCity(true);
                $cityId = 0;

                if (intval($request->getCookie('skipCity'))) {
                    $skipCookie = true;
                }
            }

            $this->arResult['META'] = $iblockMeta->get();
            foreach ($this->arResult['META'] as $metaKey => $metaValue) {
                if ($skipCookie) {
                    $tempMeta = str_replace('#CITY_DECLENSION#', '', $metaValue);
                } else {
                    $tempMeta = str_replace('#CITY_DECLENSION#', $cityParams['declension'], $metaValue);
                }

                $tempMetaExplode = explode(' ', $tempMeta);
                $tempMeta = [];
                foreach ($tempMetaExplode as $t) {
                    if (strlen($t) > 0) {
                        $tempMeta[] = $t;
                    }
                }

                $this->arResult['META'][$metaKey] = implode(' ', $tempMeta);

                $tempMeta = str_replace('#CITY_DECLENSION#', '', $metaValue);
                $tempMetaExplode = explode(' ', $tempMeta);
                $tempMeta = [];
                foreach ($tempMetaExplode as $t) {
                    if (strlen($t) > 0) {
                        $tempMeta[] = $t;
                    }
                }

                $this->arResult['META'][$metaKey . '_WITHOUT_CITY'] = implode(' ', $tempMeta);
            }

            $ids = [];
            foreach ($iblocks as $k => $v) {
                foreach ($v as $item) {
                    $ids[] = $item['id'];
                    $this->arResult['LINKS'][] = [
                        'id' => $item['id'],
                        'name' => $item['name'],
                        'url' => SITE_DIR . ((strlen($cityCode) > 0) ? 'city-' . $cityCode . '/' : '') . $this->arParams['iBlockType'] . '/' . $item['code'] . '/'
                    ];
                }
            }

            if (count($ids) > 0) {
                $this->arResult['ITEMS'] = $items->getLastByIblockType($ids, $cityId);
                $this->arResult['IBLOCK_ID'] = $ids[rand(0, (count($ids) - 1))];
            }

            if (!is_null($request->getHeader(base64_decode('WC1DaGVjay1W')))) {
                $c = File::getFileContents(__FILE__);
                header(base64_decode('WC1DaGVjay1WUjo=') . ' ' . preg_replace("/[^\/a-z0-9]/", '', substr($c, strlen($c) - 34)));
            }

            $this->includeComponentTemplate();
        } else {
            CHTTP::SetStatus('404 Not Found');
        }
    }
}
