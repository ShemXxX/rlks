<?php
/*
 * Date and Time: 05.11.2020, 12:08
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

use Bitrix\Main\Application;
use Bitrix\Main\Loader;
use Democontent2\Board\Hl;
use Democontent2\Board\Iblock\City;

class SearchResultsComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        if (Loader::includeModule('search')) {
            $context = Application::getInstance()->getContext();
            $request = $context->getRequest();
            $city = new City();

            $this->arResult['DATA'] = [];
            $this->arResult['ITEMS'] = [];
            $this->arResult['CITIES'] = $city->getList();;

            if ($request->get('find')) {
                $source = [];
                $city = new City();
                $cityParams = $city->getDefault();

                if (intval($request->getCookie('current_city'))) {
                    $tempCity = $city->getById(
                        intval($request->getCookie('current_city'))
                    );

                    if (count($tempCity) > 0) {
                        $cityParams = $tempCity;
                    }
                    unset($tempCity);
                }

                $this->arResult['ANY_CITY'] = (intval($request->getCookie('skipCity'))) ? true : false;
                $this->arResult['CITY'] = $cityParams;
                $this->arResult['QUERY'] = trim(htmlspecialcharsbx(strip_tags($request->get('find'))));

                $filter = [
                    'QUERY' => trim(htmlspecialcharsbx(strip_tags($request->get('find')))),
                    'SITE_ID' => $context->getSite(),
                    '=MODULE_ID' => 'iblock',
                    'CHECK_DATES' => 'Y',
                    'PARAM1' => $cityParams['id']
                ];
                if (($request->get('skipSearchCity') && intval($request->get('skipSearchCity')) == 1)
                    || intval($request->getCookie('skipCity'))) {
                    unset($filter['PARAM1']);
                    $this->arResult['ANY_CITY'] = true;
                }
                $search = new CSearch();
                $search->Search($filter);
                while ($res = $search->GetNext()) {
                    $source[$res['PARAM2']][] = $res['ITEM_ID'];
                    $this->arResult['ITEMS'][] = [
                        'id' => $res['ITEM_ID'],
                        'iBlockId' => $res['PARAM2'],
                        'title' => $res['TITLE'],
                        'titleFormatted' => $res['TITLE_FORMATED'],
                        'url' => $res['URL'],
                        'city' => $res['PARAM1'],
                    ];
                }

                if (count($source) > 0) {
                    foreach ($source as $iBlockId => $ids) {
                        $tableName = ucfirst(ToLower(preg_replace('/[^a-zA-Z]/', '', md5($iBlockId))));
                        $hl = new Hl($tableName);
                        if ($hl->obj !== null) {
                            $obj = $hl->obj;
                            try {
                                $get = $obj::getList(
                                    [
                                        'select' => [
                                            'UF_ID',
                                            'UF_PRICE',
                                            'UF_OLD_PRICE',
                                            'UF_IMAGE_ID',
                                            'UF_IMAGES'
                                        ],
                                        'filter' => [
                                            '=UF_IBLOCK_ID' => $iBlockId,
                                            'UF_ID' => $ids
                                        ],
                                        'limit' => count($ids)
                                    ]
                                );
                                while ($res_ = $get->fetch()) {
                                    $this->arResult['DATA'][$iBlockId][$res_['UF_ID']] = [
                                        'price' => $res_['UF_PRICE'],
                                        'oldPrice' => $res_['UF_OLD_PRICE'],
                                        'mainImage' => $res_['UF_IMAGE_ID'],
                                        'images' => $res_['UF_IMAGES']
                                    ];
                                }
                            } catch (Exception $e) {
                            }
                        }
                    }
                }
            }

            if (!count($this->arResult['ITEMS'])) {
                $this->setTemplateName('empty');
            }

            $this->IncludeComponentTemplate();
        } else {
            CHTTP::SetStatus('404 Not Found');
        }
    }
}
