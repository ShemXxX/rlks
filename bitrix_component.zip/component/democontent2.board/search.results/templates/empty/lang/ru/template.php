<?php
/*
 * Date and Time: 05.11.2020, 12:11
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

$MESS['SEARCH_COMPONENT_EMPTY_TITLE'] = 'По вашему запросу ничего не найдено';
$MESS['SEARCH_COMPONENT_EMPTY_DESK'] = 'Попробуйте сократить или задать запрос по-другому. Установите более мягкие ограничения.<br>Можно поискать на другом рынке, или перейдите на <a href="#SITE_DIR#">главную страницу</a>.';
$MESS['SEARCH_COMPONENT_SEARCH_MESSAGE'] = 'На рынке <b>#CITY#</b> не найдено подходящих результатов по данному запросу.<br><a href="#URL#">Показать результаты без учета рынка</a>';
$MESS['SEARCH_COMPONENT_SEARCH_MESSAGE_NOT_CITY'] = 'Показаны результаты без учёта рынка';