<?php
/*
 * Date and Time: 05.11.2020, 12:10
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Application;
use Bitrix\Main\Localization\Loc;

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}
?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('SEARCH_COMPONENT_EMPTY_TITLE') ?></h1>
        <?php
        if ($arResult['ANY_CITY']) {
            ?>
            <div class="info-message _mb">
                <?= Loc::getMessage('SEARCH_COMPONENT_SEARCH_MESSAGE_NOT_CITY') ?>
            </div>
            <?php
        } else {
            ?>
            <div class="info-message _mb">
                <?= Loc::getMessage('SEARCH_COMPONENT_SEARCH_MESSAGE', [
                    '#CITY#' => $arResult['CITY']['name'],
                    '#URL#' => $APPLICATION->GetCurPage(false) . '?find=' . $arResult['QUERY'] . '&skipSearchCity=1'
                ]) ?>
            </div>
            <?php
        }
        ?>
        <div class="warning-message">
            <?= Loc::getMessage('SEARCH_COMPONENT_EMPTY_DESK', ['#SITE_DIR#' => SITE_DIR]) ?>
        </div>
    </div>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}