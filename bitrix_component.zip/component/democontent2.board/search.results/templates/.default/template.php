<?php
/*
 * Date and Time: 05.11.2020, 12:10
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

$iblocks = [];

?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('SEARCH_COMPONENT_TITLE') ?></h1>
        <?php
        if ($arResult['ANY_CITY']) {
            ?>
            <div class="success-message _mb">
                <?= Loc::getMessage('SEARCH_COMPONENT_SEARCH_MESSAGE_NOT_CITY') ?>
            </div>
            <?php
        } else {
            ?>
            <div class="success-message _mb">
                <?= Loc::getMessage('SEARCH_COMPONENT_SEARCH_MESSAGE', [
                    '#CITY#' => $arResult['CITY']['name'],
                    '#URL#' => $APPLICATION->GetCurPage(false) . '?find=' . $arResult['QUERY'] . '&skipSearchCity=1'
                ]) ?>
            </div>
            <?php
        }
        ?>
        <div class="items-list">
            <?php
            foreach ($arResult['ITEMS'] as $key => $product) {
                if (!strlen($product['url'])) {
                    continue;
                }
                $iblocks[$product['iBlockId']] = $product['iBlockId'];
                $pict = null;
                $price = (isset($arResult['DATA'][$product['iBlockId']][$product['id']]['price'])) ? $arResult['DATA'][$product['iBlockId']][$product['id']]['price'] : '';
                $oldPrice = (isset($arResult['DATA'][$product['iBlockId']][$product['id']]['oldPrice'])) ? $arResult['DATA'][$product['iBlockId']][$product['id']]['oldPrice'] : '';
                if (isset($arResult['DATA'][$product['iBlockId']][$product['id']]['mainImage']) && $arResult['DATA'][$product['iBlockId']][$product['id']]['mainImage'] > 0) {
                    $pict = $arResult['DATA'][$product['iBlockId']][$product['id']]['mainImage'];
                    $pict = CFile::ResizeImageGet(
                        $pict,
                        [
                            'width' => 199,
                            'height' => 151
                        ],
                        BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
                        true
                    );
                }
                ?>
                <div class="item">
                    <div class="image">
                        <a href="<?= $product['url'] ?>" title="<?= $product['titleFormatted'] ?>">
                            <div class="fotorama _mb" data-width="100%" data-height="151px" data-maxheight="151px"
                                 data-allowfullscreen="false" data-loop="false">
                                <?php
                                if (!is_null($pict)) {
                                    ?>
                                    <div data-img="<?= $pict['src'] ?>">
                                        <div class="fotorama__blur"
                                             style="background:url(<?= $pict['src'] ?>)"></div>
                                    </div>
                                    <?php
                                } else {
                                    ?>
                                    <svg class="stub" width="40" height="40" viewBox="0 0 40 40" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <g>
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                  d="M35 1.66666H11.6667C9.83335 1.66666 8.33335 3.16666 8.33335 4.99999V28.3333C8.33335 30.1667 9.83335 31.6667 11.6667 31.6667H35C36.8334 31.6667 38.3334 30.1667 38.3334 28.3333V4.99999C38.3334 3.16666 36.8334 1.66666 35 1.66666ZM1.66669 8.33332H5.00002V35H31.6667V38.3333H5.00002C3.16669 38.3333 1.66669 36.8333 1.66669 35V8.33332ZM22.0167 23.05L26.6 17.15L32.5 25H14.1667L18.75 19.1167L22.0167 23.05ZM11.6667 28.3333H35V4.99999H11.6667V28.3333Z"
                                                  fill="#BDBDBD"
                                            / >
                                        </g>
                                    </svg>
                                    <?php
                                }
                                ?>
                            </div>
                        </a>
                    </div>
                    <div class="content">
                        <div class="link">
                            <a href="<?= $product['url'] ?>"><?= $product['titleFormatted'] ?></a>
                        </div>
                        <?php
                        if (intval($product['city'])) {
                            ?>
                            <div class="location">
                                <div class="icon">
                                    <svg width="17" height="17" viewBox="0 0 17 17" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                              d="M2.125 7.45875L14.875 2.125L9.53417 14.875H8.84L6.97 10.03L2.125 8.15292V7.45875ZM9.22958 11.9425L12.2329 4.76708L5.0575 7.76333L7.48708 8.70541L8.06791 8.93208L8.29458 9.52L9.22958 11.9425Z"
                                              fill="#999999"/>
                                    </svg>
                                </div>
                                <div class="text">
                                    <?= $arResult['CITIES'][$product['city']]['name'] ?>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </div>
                <?
            }
            ?>
        </div>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12 right-col">
        <?php
        if (count($iblocks)) {
            $APPLICATION->IncludeComponent(
                'democontent2.board:vip',
                'vertical',
                [
                    'IBLOCK_ID' => array_rand($iblocks),
                ]
            );
        }
        ?>
    </div>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}
