<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 12.10.2018
 * Time: 19:45
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['USER_ITEMS_TITLE'] = 'Мои объявления';