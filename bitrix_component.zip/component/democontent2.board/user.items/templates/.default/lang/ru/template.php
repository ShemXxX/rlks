<?php
/*
 * Date and Time: 18.02.2021, 9:48
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

$MESS['USER_ITEMS_COMPONENT_H1'] = 'Мои объявления';
$MESS['USER_ITEMS_SORT_ACTIVE'] = 'Активные';
$MESS['USER_ITEMS_SORT_COMPLETED'] = 'Завершенные';
$MESS['USER_ITEMS_SORT_MODERATION'] = 'На модерации и отклонённые';
$MESS['USER_ITEMS_BTN_EDIT'] = 'Редактировать';
$MESS['USER_ITEMS_BTN_UP'] = 'Поднять';
$MESS['USER_ITEMS_BTN_ACTIVATE'] = 'Актировать ';
$MESS['USER_ITEMS_BTN_ACTIVATE_PERIOD'] = 'Актировать и поднять';
$MESS['USER_ITEMS_BTN_DELETE'] = 'Удалить';
$MESS['USER_ITEMS_ACTIVE_EMPTY'] = 'У вас нет активных объявлений';
$MESS['USER_ITEMS_COMPLETED_EMPTY'] = 'У вас нет завершённых объявлений';
$MESS['USER_ITEMS_MODERATION_EMPTY'] = 'У вас нет объявлений ожидающих проверки модератором';
$MESS['USER_ITEMS_SERVICE_ACTIVE_TO'] = 'Услуга активна до';
$MESS['USER_ITEMS_SERVICE_VIP'] = 'VIP';
$MESS['USER_ITEMS_SERVICE_PREMIUM'] = 'Premium';
$MESS['USER_ITEMS_SERVICE_TURBO'] = 'Турбо';
$MESS['USER_ITEMS_COLORS'] = 'Выделить';
$MESS['USER_ITEMS_COLORS_STATUS'] = 'Выделение цветом';

$MESS['USER_ITEMS_BUTTON_UP'] = 'Поднять';
$MESS['USER_ITEMS_BUTTON_VIP'] = 'VIP';
$MESS['USER_ITEMS_BUTTON_COLOR'] = 'Выделить';
$MESS['USER_ITEMS_BUTTON_PREMIUM'] = 'Премиум';
$MESS['USER_ITEMS_BUTTON_TURBO'] = 'Турбо';

