<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 03.10.2018
 * Time: 10:53
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}
$myAdsActive = 0;
$myAdsCompleted = 0;
$myAdsModeration = 0;

foreach ($arResult['ITEMS'] as $key => $product) {
    if ($product['UF_MODERATION']) {
        $myAdsModeration++;
    } else {
        if ($product['ACTIVE'] === 1) {
            $myAdsActive++;
        } else {
            $myAdsCompleted++;
        }
    }
}
?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('USER_ITEMS_COMPONENT_H1') ?></h1>
        <div class="items-list__sort">
            <div class="item">
                <a href="<?= SITE_DIR ?>user/items/">
                    <?= Loc::getMessage('USER_ITEMS_SORT_ACTIVE') ?>
                </a>
                <?php
                if ($myAdsActive) {
                    ?>
                    <div class="counter"><?= $myAdsActive ?></div>
                    <?php
                }
                ?>
            </div>
            <div class="item">
                <a href="<?= SITE_DIR ?>user/items/?completed=1">
                    <?= Loc::getMessage('USER_ITEMS_SORT_COMPLETED') ?>
                </a>
                <?php
                if ($myAdsCompleted) {
                    ?>
                    <div class="counter"><?= $myAdsCompleted ?></div>
                    <?php
                }
                ?>
            </div>
            <div class="item active">
                <a href="<?= SITE_DIR ?>user/items/?moderation=1">
                    <?= Loc::getMessage('USER_ITEMS_SORT_MODERATION') ?>
                </a>
                <?php
                if ($myAdsModeration) {
                    ?>
                    <div class="counter"><?= $myAdsModeration ?></div>
                    <?php
                }
                ?>
            </div>
        </div>
        <?php
        if (!$myAdsModeration) {
            ?>
            <div class="info-message _mb"><?= Loc::getMessage('USER_ITEMS_MODERATION_EMPTY') ?></div>
            <?php
        } else {
            ?>
            <div class="items-list">
                <?php
                foreach ($arResult['ITEMS'] as $key => $product) {
                    if (!intval($product['UF_MODERATION'])) {
                        continue;
                    }
                    $arButtons = \CIBlock::GetPanelButtons(
                        $product['UF_IBLOCK_ID'],
                        $product['UF_ID'],
                        0,
                        ["SECTION_BUTTONS" => false, "SESSID" => false]
                    );
                    $arItem["EDIT_LINK"] = $arButtons["edit"]["edit_element"]["ACTION_URL"];
                    $arItem["DELETE_LINK"] = $arButtons["edit"]["delete_element"]["ACTION_URL"];
                    $this->AddEditAction(
                        $product['UF_ID'],
                        $arItem['EDIT_LINK'],
                        CIBlock::GetArrayByID(
                            $product['UF_IBLOCK_ID'],
                            "ELEMENT_EDIT"
                        )
                    );
                    $this->AddDeleteAction(
                        $product['UF_ID'],
                        $arItem['DELETE_LINK'],
                        CIBlock::GetArrayByID(
                            $product['UF_IBLOCK_ID'],
                            "ELEMENT_DELETE"
                        ),
                        ["CONFIRM" => Loc::getMessage('CONFIRM_DELETE')]
                    );

                    $pict = null;
                    if (intval($product['UF_IMAGE_ID'])) {
                        $pict = intval($product['UF_IMAGE_ID']);
                        $pict = CFile::ResizeImageGet(
                            $pict,
                            [
                                'width' => 199,
                                'height' => 151
                            ],
                            BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
                            true
                        );
                    }

                    $imagesCounter = 0;
                    $unserializedImages = [];
                    if (strlen($product['UF_IMAGES'])) {
                        $unserializedImages = unserialize($product['UF_IMAGES']);
                        $imagesCounter = count($unserializedImages);
                    }

                    $vip = false;
                    $premium = false;
                    $color = false;
                    if (!empty($product['VIP_END'])) {
                        if (strtotime(date('d.m.Y H:i')) < strtotime($product['VIP_END'])) {
                            $vip = true;
                        }
                    }
                    if (!empty($product['PREMIUM_END'])) {
                        if (strtotime(date('d.m.Y H:i')) < strtotime($product['PREMIUM_END'])) {
                            $premium = true;
                        }
                    }
                    if (!empty($product['COLOR_END'])) {
                        if (strtotime(date('d.m.Y H:i')) < strtotime($product['COLOR_END'])) {
                            $color = true;
                        }
                    }
                    ?>
                    <div class="item<?= $color ? ' color' : '' ?>" id="<?= $this->GetEditAreaId($product['UF_ID']) ?>">
                        <div class="image">
                            <?php
                            if ($imagesCounter) {
                                ?>
                                <div class="counter">
                                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <g>
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                  d="M12.25 0.583328H4.08334C3.44168 0.583328 2.91668 1.10833 2.91668 1.74999V9.91666C2.91668 10.5583 3.44168 11.0833 4.08334 11.0833H12.25C12.8917 11.0833 13.4167 10.5583 13.4167 9.91666V1.74999C13.4167 1.10833 12.8917 0.583328 12.25 0.583328ZM0.583344 2.91666H1.75001V12.25H11.0833V13.4167H1.75001C1.10834 13.4167 0.583344 12.8917 0.583344 12.25V2.91666ZM7.70584 8.0675L9.31001 6.0025L11.375 8.75H4.95834L6.56251 6.69083L7.70584 8.0675ZM4.08334 9.91666H12.25V1.74999H4.08334V9.91666Z"
                                                  fill="#4F4F4F"/>
                                        </g>
                                    </svg>
                                    <span><?= $imagesCounter + 1 ?></span>
                                </div>
                                <?php
                            }

                            if ($vip || $premium || $color) {
                                ?>
                                <div class="labels no-auth">
                                    <?php
                                    if ($vip) {
                                        ?>
                                        <div class="item vip"></div>
                                        <?php
                                    }
                                    if ($premium) {
                                        ?>
                                        <div class="item premium"></div>
                                        <?php
                                    }
                                    if ($color) {
                                        ?>
                                        <div class="item color"></div>
                                        <?php
                                    }
                                    ?>
                                </div>
                                <?php
                            }

                            if ($imagesCounter) {
                                ?>
                                <div class="images">
                                    <div class="nav">
                                        <?php
                                        if (!is_null($pict)) {
                                            ?>
                                            <a class="item" href="<?= $product['URL'] ?>"
                                               data-img="<?= $pict['src'] ?>">
                                                <div class="line"></div>
                                            </a>
                                            <?php
                                        }
                                        $imgI = 0;
                                        foreach ($unserializedImages as $img) {
                                            if ($imgI++ == 3) {
                                                break;
                                            }
                                            $pict = CFile::ResizeImageGet(
                                                $img,
                                                [
                                                    'width' => 199,
                                                    'height' => 151
                                                ],
                                                BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
                                                true
                                            );
                                            if (!is_null($pict)) {
                                                ?>
                                                <a class="item" href="<?= $product['URL'] ?>"
                                                   data-img="<?= $pict['src'] ?>">
                                                    <div class="line"></div>
                                                </a>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                            <a href="<?= $product['URL'] ?>" title="<?= $product['UF_NAME'] ?>">
                                <div class="fotorama _mb" data-width="100%" data-height="151px" data-maxheight="151px"
                                     data-allowfullscreen="false" data-loop="false">
                                    <?php
                                    if (!is_null($pict)) {
                                        ?>
                                        <div data-img="<?= $pict['src'] ?>">
                                            <div class="fotorama__blur"
                                                 style="background:url(<?= $pict['src'] ?>)"></div>
                                        </div>
                                        <?php
                                    } else {
                                        ?>
                                        <svg class="stub" width="40" height="40" viewBox="0 0 40 40" fill="none"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <g>
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                      d="M35 1.66666H11.6667C9.83335 1.66666 8.33335 3.16666 8.33335 4.99999V28.3333C8.33335 30.1667 9.83335 31.6667 11.6667 31.6667H35C36.8334 31.6667 38.3334 30.1667 38.3334 28.3333V4.99999C38.3334 3.16666 36.8334 1.66666 35 1.66666ZM1.66669 8.33332H5.00002V35H31.6667V38.3333H5.00002C3.16669 38.3333 1.66669 36.8333 1.66669 35V8.33332ZM22.0167 23.05L26.6 17.15L32.5 25H14.1667L18.75 19.1167L22.0167 23.05ZM11.6667 28.3333H35V4.99999H11.6667V28.3333Z"
                                                      fill="#BDBDBD"
                                                / >
                                            </g>
                                        </svg>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </a>
                        </div>
                        <div class="content">
                            <div class="link">
                                <a href="<?= $product['URL'] ?>"><?= $product['UF_NAME'] ?></a>
                            </div>
                            <div class="location">
                                <div class="icon">
                                    <svg width="17" height="17" viewBox="0 0 17 17" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                              d="M2.125 7.45875L14.875 2.125L9.53417 14.875H8.84L6.97 10.03L2.125 8.15292V7.45875ZM9.22958 11.9425L12.2329 4.76708L5.0575 7.76333L7.48708 8.70541L8.06791 8.93208L8.29458 9.52L9.22958 11.9425Z"
                                              fill="#999999"/>
                                    </svg>
                                </div>
                                <?php
                                if (intval($product['UF_CITY'])) {
                                    ?>
                                    <div class="text">
                                        <?= $arResult['CITIES'][$product['UF_CITY']]['name'] ?>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
            <?php
        }
        ?>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:user.menu',
            ''
        );
        ?>
    </div>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}