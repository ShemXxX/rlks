<?php
/**
 * Date and Time: 22.07.2020, 9:17
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

use Bitrix\Main\Application;
use Bitrix\Main\ArgumentNullException;
use Bitrix\Main\ArgumentOutOfRangeException;
use Democontent2\Board\Iblock\City;
use Democontent2\Board\Iblock\Items;
use Democontent2\Board\Iblock\Section;
use Democontent2\Board\Utils as UtilsAlias;

class ListComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        $request = Application::getInstance()->getContext()->getRequest();
        $city = new City();
        $items = new Items();
        $items->setIBlockType($this->arParams['iBlockType']);
        $items->setIBlockCode($this->arParams['iBlockCode']);
        $cities = $city->getList();
        $cityCode = '';
        $cityParams = [];

        if ($request->get('map') == 1) {
            $cityParams = $city->getDefault();
        }

        if (count($cities) < 2 || intval($request->getCookie('skipCity'))) {
            $items->setSkipCity(true);
        }

        if (isset($this->arParams['cityCode'])) {
            $cityCode = $this->arParams['cityCode'];
            $items->setCityCode($this->arParams['cityCode']);

            if ($request->get('map') == 1) {
                $cityParams = $city->getByCode($this->arParams['cityCode']);
            }
        }

        foreach ($cities as $c) {
            if (intval($c['default']) > 0) {
                $cityParams = $c;
                break;
            }
        }

        $redirect = [];
        $redirect[] = $this->arParams['iBlockType'];
        $redirect[] = $this->arParams['iBlockCode'];

        if (isset($this->arParams['sectionOne'])) {
            $items->setSectionOne($this->arParams['sectionOne']);
            $redirect[] = $this->arParams['sectionOne'];
        }

        if (isset($this->arParams['sectionTwo'])) {
            $items->setSectionTwo($this->arParams['sectionTwo']);
            $redirect[] = $this->arParams['sectionTwo'];
        }

        foreach ($cities as $c) {
            if ($c['code'] == $cityCode) {
                if (intval($c['default']) > 0) {
                    LocalRedirect(SITE_DIR . implode('/', $redirect) . '/', true);
                } else {
                    $cityParams = $c;
                }
                break;
            }
        }

        $currentPage = 1;
        if ($request->get('page')) {
            if (intval($request->get('page')) > 1) {
                $currentPage = intval($request->get('page'));
                $items->setOffset((intval($request->get('page')) - 1) * $items->getLimit());
            }
        }

        if ($request->get('onlyPhoto')) {
            $items->setWithPhotosOnly(1);
        }

        if ($request->get('prop') && is_array($request->get('prop'))) {
            $items->setFilterProperties($request->get('prop'));
        }

        $this->arResult['ITEMS'] = [];
        $iblock = new \Democontent2\Board\Iblock\Iblock();


        if ($request->get('map') == 1) {
            $items->setWithCoords(true);
            $items->setLimit(1000);
        }

        $this->arResult['ORDER'] = 'new';

        if ($request->get('order')) {
            switch ($request->get('order')) {
                case 'old':
                    $items->setOrder(
                        [
                            'UF_TIMESTAMP' => 'ASC'
                        ]
                    );
                    $this->arResult['ORDER'] = $request->get('order');
                    break;
                case 'expensive':
                    $items->setOrder(
                        [
                            'UF_PRICE' => 'DESC'
                        ]
                    );
                    $this->arResult['ORDER'] = $request->get('order');
                    break;
                case 'cheap':
                    $items->setOrder(
                        [
                            'UF_PRICE' => 'ASC'
                        ]
                    );
                    $this->arResult['ORDER'] = $request->get('order');
                    break;
                case 'popular':
                    $items->setOrder(
                        [
                            'UF_COUNTER' => 'ASC'
                        ]
                    );
                    $this->arResult['ORDER'] = $request->get('order');
                    break;
            }
        }

        $itemsList = $items->get();

        $this->arResult['CITIES'] = $cities;
        $this->arResult['LINKS'] = [];
        $this->arResult['IBLOCK_TYPE_NAME'] = $iblock->getTypeName('democontent2_board_' . str_replace('-', '_', $items->getIBlockType()));
        $this->arResult['IBLOCK_NAME'] = $iblock->getIblockName($items->getIBlockId());
        $this->arResult['CITY'] = $cityParams;
        $this->arResult['META'] = $items->getMeta();
        $this->arResult['SECTIONS_PATH'] = $items->getSectionsParams();
        $this->arResult['LIMIT'] = $items->getLimit();
        $this->arResult['OFFSET'] = $items->getOffset();
        $this->arResult['TOTAL'] = $items->getTotal();
        $this->arResult['IBLOCK_ID'] = $items->getIBlockId();
        $this->arResult['CURRENT_PAGE'] = $currentPage;
        $this->arResult['CURRENT_URL'] = SITE_DIR . ((!$this->arResult['CITY']['default']) ? 'city-' . $this->arResult['CITY']['code'] . '/' : false)
            . $items->getIBlockType() . '/' . $items->getIBlockCode() . '/';

        if (count($this->arResult['SECTIONS_PATH']) > 0) {
            foreach ($this->arResult['SECTIONS_PATH'] as $s) {
                $this->arResult['CURRENT_URL'] .= $s['CODE'] . '/';
            }
        }

        if (isset($this->arParams['sectionOne'])) {
            $sectionOne = new Section(0);
            $sectionOneId = $sectionOne->getByCode($items->getIBlockId(), $this->arParams['sectionOne'], 1);

            if (intval($sectionOneId['ID']) > 0) {
                $section = new Section();
                $sections = $section->getSections($items->getIBlockId(), 2, intval($sectionOneId['ID']));
                foreach ($sections as $s) {
                    /*$this->arResult['LINKS'][] = array(
                        'name' => $s['NAME'],
                        'url' => $this->arResult['CURRENT_URL'] . $s['CODE'] . '/'
                    );*/
                    if (isset($this->arParams['sectionTwo'])) {
                        if ($this->arParams['sectionTwo'] == $s['CODE']) {
                            continue;
                        }
                    }

                    $this->arResult['LINKS'][] = [
                        'name' => $s['NAME'],
                        'url' => SITE_DIR . ((strlen($cityCode) > 0) ? 'city-' . $cityCode . '/' : '')
                            . $this->arParams['iBlockType'] . '/' . $this->arParams['iBlockCode'] . '/'
                            . $this->arParams['sectionOne'] . '/' . $s['CODE'] . '/'
                    ];
                }
            }
        }

        if (count($itemsList) > 0) {
            if ($request->get('map') == 1) {
                $coordinates = (strlen($cityParams['coordinates']) > 0) ? explode(',', $cityParams['coordinates']) : [];
                $this->arResult['COORDINATES'] = $coordinates;

                foreach ($itemsList as $item) {
                    $this->arResult['ITEMS'][] = [
                        'id' => $item['UF_ID'],
                        'name' => preg_replace('/\\\\{1,}/', '', $item['UF_NAME']),
                        'imageId' => intval($item['UF_IMAGE_ID']),
                        'price' => UtilsAlias::price($item['UF_PRICE']),
                        'oldPrice' => UtilsAlias::price($item['UF_OLD_PRICE']),
                        'lat' => floatval($item['UF_LAT']),
                        'long' => floatval($item['UF_LONG']),
                        'vip' => $item['VIP'],
                        'premium' => $item['PREMIUM'],
                        'color' => $item['COLOR'],
                        'url' => $item['URL']
                    ];
                }
            } else {
                $this->arResult['ITEMS'] = $itemsList;
            }

            unset($itemsList);
        } else {
            CHTTP::SetStatus('404 Not Found');
        }

        if ($request->get('map') == 1) {
            $this->setTemplateName('map');
        }

        $ut = new UtilsAlias();
        try {
            if ($ut->getView($request) == 'list') {
                $this->setTemplateName('list');
            }
        } catch (ArgumentNullException $e) {
        } catch (ArgumentOutOfRangeException $e) {
        }

        $this->includeComponentTemplate();
    }
}
