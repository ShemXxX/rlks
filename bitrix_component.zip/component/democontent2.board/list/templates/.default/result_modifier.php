<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 09.10.2018
 * Time: 13:24
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Democontent2\Board\Iblock\Favourites;

global $USER;

$arResult['FAVOURITES'] = [];
if ($USER->IsAuthorized()) {
    $ids = [];
    foreach ($arResult['ITEMS'] as $item) {
        $ids[] = $item['UF_ID'];
    }
    $favourites = new Favourites(intval($USER->GetID()));
    $arResult['FAVOURITES'] = $favourites->checkIdsByUser($ids);
}