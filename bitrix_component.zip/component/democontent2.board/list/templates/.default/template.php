<?php
/*
 * Date and Time: 25.02.2021, 9:22
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

if (method_exists($this, 'setFrameMode')) {
    $this->setFrameMode(true);
}

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ModuleManager;
use Bitrix\Main\IO\File;
use Bitrix\Main\IO\Path;
use Bitrix\Main\Application;
use Bitrix\Main\Loader;
use Bitrix\Main\Web\Json;
use Democontent2\Board\Utils as UtilsAlias;

$categories = [];
foreach ($arResult['LINKS'] as $item) {
    $categories[] = [
        'name' => $item['name'],
        'url' => $item['url'],
    ];
}

$filterParams = UtilsAlias::getFilterParamsString(Application::getInstance()->getContext()->getRequest());
$showPrices = intval(Option::get(DBOARD, 'show_prices'));
$currencyName = Option::get(DBOARD, 'currency_name');

?>

<div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
    <h1><?= $arResult['META']['SECTION_PAGE_TITLE'] ?></h1>

    <?php
    if (ModuleManager::isModuleInstalled('advertising')) {
        if (Loader::includeModule('advertising')) {
            ?>
            <div class="delimiter"></div>
            <?php
            $APPLICATION->IncludeComponent(
                'democontent2.board:banner',
                'list.top',
                ['TYPE' => 'DBOARD_DETAIL_LIST_TOP']
            );
            ?>
            <div class="delimiter"></div>
            <?php
        }
    } else {
        if (File::isFileExists(
            Path::normalize(Application::getDocumentRoot() . SITE_TEMPLATE_PATH . "/inc/lang/" . USER_LANG_PATH . "advert/list.top.php")
        )) {
            ?>
            <div class="delimiter"></div>
            <?php
            $APPLICATION->IncludeComponent(
                "bitrix:main.include", "",
                [
                    "AREA_FILE_SHOW" => "file",
                    "PATH" => SITE_TEMPLATE_PATH . "/inc/lang/" . USER_LANG_PATH . "advert/list.top.php",
                    "EDIT_TEMPLATE" => "include_areas_template.php",
                    'MODE' => 'php'
                ],
                false
            );
            ?>
            <div class="delimiter"></div>
            <?php
        } else {
            ?>
            <div class="delimiter"></div>
            <?php
            $APPLICATION->IncludeComponent(
                "bitrix:main.include", "",
                [
                    "AREA_FILE_SHOW" => "file",
                    "PATH" => SITE_TEMPLATE_PATH . "/inc/advert/list.top.php",
                    "EDIT_TEMPLATE" => "include_areas_template.php",
                    'MODE' => 'php'
                ],
                false
            );
            ?>
            <div class="delimiter"></div>
            <?php
        }
    }
    ?>
    <div class="items-list__sort">
        <div class="item<?= (($arResult['ORDER'] == 'new') ? ' active' : false) ?>">
            <a href="<?= $arResult['CURRENT_URL'] ?>?<?= $filterParams ?>">
                <?= Loc::getMessage('LIST_SORT_DATE_UP') ?>
            </a>
        </div>
        <div class="item<?= (($arResult['ORDER'] == 'old') ? ' active' : false) ?>">
            <a href="<?= $arResult['CURRENT_URL'] ?>?order=old&<?= $filterParams ?>">
                <?= Loc::getMessage('LIST_SORT_DATE_DOWN') ?>
            </a>
        </div>
        <div class="item<?= (($arResult['ORDER'] == 'cheap') ? ' active' : false) ?>">
            <a href="<?= $arResult['CURRENT_URL'] ?>?order=cheap&<?= $filterParams ?>">
                <?= Loc::getMessage('LIST_SORT_PRICE_DOWN') ?>
            </a>
        </div>
        <div class="item<?= (($arResult['ORDER'] == 'expensive') ? ' active' : false) ?>">
            <a href="<?= $arResult['CURRENT_URL'] ?>?order=expensive&<?= $filterParams ?>">
                <?= Loc::getMessage('LIST_SORT_PRICE_UP') ?>
            </a>
        </div>
        <div class="item<?= (($arResult['ORDER'] == 'popular') ? ' active' : false) ?>">
            <a href="<?= $arResult['CURRENT_URL'] ?>?order=popular&<?= $filterParams ?>">
                <?= Loc::getMessage('LIST_SORT_POPULAR') ?>
            </a>
        </div>
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:view.switch',
            ''
        );
        ?>
    </div>
    <div class="items-list">
        <?php
        foreach ($arResult['ITEMS'] as $key => $product) {
            $isFavourite = in_array($product['UF_ID'], $arResult['FAVOURITES']);
            $arButtons = CIBlock::GetPanelButtons(
                $product['UF_IBLOCK_ID'],
                $product['UF_ID'],
                0,
                ["SECTION_BUTTONS" => false, "SESSID" => false]
            );
            $arItem["EDIT_LINK"] = $arButtons["edit"]["edit_element"]["ACTION_URL"];
            $arItem["DELETE_LINK"] = $arButtons["edit"]["delete_element"]["ACTION_URL"];
            $this->AddEditAction(
                $product['UF_ID'],
                $arItem['EDIT_LINK'],
                CIBlock::GetArrayByID(
                    $product['UF_IBLOCK_ID'],
                    "ELEMENT_EDIT"
                )
            );
            $this->AddDeleteAction(
                $product['UF_ID'],
                $arItem['DELETE_LINK'],
                CIBlock::GetArrayByID(
                    $product['UF_IBLOCK_ID'],
                    "ELEMENT_DELETE"
                ),
                ["CONFIRM" => Loc::getMessage('CONFIRM_DELETE')]
            );

            $pict = null;
            if (intval($product['UF_IMAGE_ID'])) {
                $pict = intval($product['UF_IMAGE_ID']);
                $pict = CFile::ResizeImageGet(
                    $pict,
                    [
                        'width' => 199,
                        'height' => 151
                    ],
                    BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
                    true
                );
            }

            $imagesCounter = 0;
            $unserializedImages = [];
            if (strlen($product['UF_IMAGES'])) {
                $unserializedImages = unserialize($product['UF_IMAGES']);
                $imagesCounter = count($unserializedImages);
            }

            $vip = false;
            $premium = false;
            $color = false;
            if (!empty($product['UF_VIP_END'])) {
                if (strtotime(date('d.m.Y H:i')) < strtotime($product['UF_VIP_END'])) {
                    $vip = true;
                }
            }
            if (!empty($product['UF_PREMIUM_END'])) {
                if (strtotime(date('d.m.Y H:i')) < strtotime($product['UF_PREMIUM_END'])) {
                    $premium = true;
                }
            }
            if (!empty($product['UF_COLOR_END'])) {
                if (strtotime(date('d.m.Y H:i')) < strtotime($product['UF_COLOR_END'])) {
                    $color = true;
                }
            }
            ?>
            <div class="item<?= $color ? ' color' : '' ?>" id="<?= $this->GetEditAreaId($product['UF_ID']) ?>">
                <div class="image">
                    <?php
                    if ($imagesCounter) {
                        ?>
                        <div class="counter">
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g>
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                          d="M12.25 0.583328H4.08334C3.44168 0.583328 2.91668 1.10833 2.91668 1.74999V9.91666C2.91668 10.5583 3.44168 11.0833 4.08334 11.0833H12.25C12.8917 11.0833 13.4167 10.5583 13.4167 9.91666V1.74999C13.4167 1.10833 12.8917 0.583328 12.25 0.583328ZM0.583344 2.91666H1.75001V12.25H11.0833V13.4167H1.75001C1.10834 13.4167 0.583344 12.8917 0.583344 12.25V2.91666ZM7.70584 8.0675L9.31001 6.0025L11.375 8.75H4.95834L6.56251 6.69083L7.70584 8.0675ZM4.08334 9.91666H12.25V1.74999H4.08334V9.91666Z"
                                          fill="#4F4F4F"/>
                                </g>
                            </svg>
                            <span><?= $imagesCounter + 1 ?></span>
                        </div>
                        <?php
                    }

                    if ($showPrices) {
                        ?>
                        <div class="price">
                            <?= UtilsAlias::price($product['UF_PRICE']) ?>
                            <?= $currencyName ?>
                        </div>
                        <?php
                    }
                    ?>
                    <div class="favourite<?= ($isFavourite ? ' active' : '') ?>"
                         data-id="<?= $product['UF_ID'] ?>" data-i="<?= $product['UF_IBLOCK_ID'] ?>">
                        <span class="wenk--right" data-wenk-pos="right"
                              data-wenk="<?= ($isFavourite ? Loc::getMessage('LIST_COMPONENT_REMOVE_FAV') : Loc::getMessage('LIST_COMPONENT_ADD_FAV')) ?>">
                            <?php
                            if ($isFavourite) {
                                ?>
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <g>
                                        <path d="M9 15.8812L7.9125 14.8912C4.05 11.3887 1.5 9.07874 1.5 6.24374C1.5 3.93374 3.315 2.11874 5.625 2.11874C6.93 2.11874 8.1825 2.72624 9 3.68624C9.8175 2.72624 11.07 2.11874 12.375 2.11874C14.685 2.11874 16.5 3.93374 16.5 6.24374C16.5 9.07874 13.95 11.3887 10.0875 14.8987L9 15.8812Z"
                                              fill="#EB5757"/>
                                    </g>
                                </svg>
                                <?php
                            } else {
                                ?>
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <g>
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                              d="M9 3.68624C9.8175 2.72624 11.07 2.11874 12.375 2.11874C14.685 2.11874 16.5 3.93374 16.5 6.24374C16.5 9.07642 13.9542 11.385 10.097 14.8826L10.0875 14.8912L9 15.8812L7.9125 14.8987L7.88289 14.8718C4.03697 11.3769 1.5 9.07149 1.5 6.24374C1.5 3.93374 3.315 2.11874 5.625 2.11874C6.93 2.11874 8.1825 2.72624 9 3.68624ZM9 13.8562L9.075 13.7812C12.645 10.5487 15 8.41124 15 6.24374C15 4.74374 13.875 3.61874 12.375 3.61874C11.22 3.61874 10.095 4.36124 9.705 5.38874H8.3025C7.905 4.36124 6.78 3.61874 5.625 3.61874C4.125 3.61874 3 4.74374 3 6.24374C3 8.41124 5.355 10.5487 8.925 13.7812L9 13.8562Z"
                                              fill="#4F4F4F"/>
                                    </g>
                                </svg>
                                <?php
                            }
                            ?>
                        </span>
                    </div>
                    <?php
                    if ($vip || $premium || $color) {
                        ?>
                        <div class="labels<?= (!$arResult['IS_AUTHORIZED']) ? ' no-auth' : '' ?>">
                            <?php
                            if ($vip) {
                                ?>
                                <div class="item vip"></div>
                                <?php
                            }
                            if ($premium) {
                                ?>
                                <div class="item premium"></div>
                                <?php
                            }
                            if ($color) {
                                ?>
                                <div class="item color"></div>
                                <?php
                            }
                            ?>
                        </div>
                        <?php
                    }

                    if ($imagesCounter) {
                        ?>
                        <div class="images">
                            <div class="nav">
                                <?php
                                if (!is_null($pict)) {
                                    ?>
                                    <a class="item" href="<?= $product['URL'] ?>"
                                       data-img="<?= $pict['src'] ?>">
                                        <div class="line"></div>
                                    </a>
                                    <?php
                                }
                                $imgI = 0;
                                foreach ($unserializedImages as $img) {
                                    if ($imgI++ >= 3) {
                                        break;
                                    }
                                    $pict = CFile::ResizeImageGet(
                                        $img,
                                        [
                                            'width' => 199,
                                            'height' => 151
                                        ],
                                        BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
                                        true
                                    );
                                    if (!is_null($pict)) {
                                        $_class = 'class="item"';
                                        if ($imgI == 3) {
                                            if (($imagesCounter - $imgI) > 0) {
                                                $_class = ' class="item more" data-text="' . Loc::getMessage('MORE_IMAGES', ['#QTY#' => ($imagesCounter - $imgI)]) . '"';
                                            }
                                        }
                                        ?>
                                        <a href="<?= $product['URL'] ?>"
                                           data-img="<?= $pict['src'] ?>"<?= $_class ?>>
                                            <div class="line"></div>
                                        </a>
                                        <?php
                                    }
                                }
                                ?>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                    <a href="<?= $product['URL'] ?>" title="<?= $product['UF_NAME'] ?>">
                        <div class="fotorama _mb" data-width="100%" data-height="151px" data-maxheight="151px"
                             data-allowfullscreen="false" data-loop="false">
                            <?php
                            if (!is_null($pict)) {
                                ?>
                                <div data-img="<?= $pict['src'] ?>">
                                    <div class="fotorama__blur"
                                         style="background:url(<?= $pict['src'] ?>)"></div>
                                </div>
                                <?php
                            } else {
                                ?>
                                <svg class="stub" width="40" height="40" viewBox="0 0 40 40" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <g>
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                              d="M35 1.66666H11.6667C9.83335 1.66666 8.33335 3.16666 8.33335 4.99999V28.3333C8.33335 30.1667 9.83335 31.6667 11.6667 31.6667H35C36.8334 31.6667 38.3334 30.1667 38.3334 28.3333V4.99999C38.3334 3.16666 36.8334 1.66666 35 1.66666ZM1.66669 8.33332H5.00002V35H31.6667V38.3333H5.00002C3.16669 38.3333 1.66669 36.8333 1.66669 35V8.33332ZM22.0167 23.05L26.6 17.15L32.5 25H14.1667L18.75 19.1167L22.0167 23.05ZM11.6667 28.3333H35V4.99999H11.6667V28.3333Z"
                                              fill="#BDBDBD"
                                        / >
                                    </g>
                                </svg>
                                <?php
                            }
                            ?>
                        </div>
                    </a>
                </div>
                <div class="content">
                    <div class="link">
                        <?php
                        if (floatval($product['UF_OLD_PRICE']) > floatval($product['UF_PRICE'])) {
                            ?>
                            <svg width="15" height="15" viewBox="0 0 15 15" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g>
                                    <path d="M8.12314 1.49401L6.87687 1.49401V11.7382L3.96447 8.82583L3.08059 9.70971L7.50001 14.1291L11.9194 9.70971L11.0355 8.82583L8.12314 11.7382L8.12314 1.49401Z"
                                          fill="#27AE60"/>
                                </g>
                            </svg>
                            <?php
                        } else {
                            if ($product['USER_PRO']) {
                                ?>
                                <svg width="15" height="15" viewBox="0 0 15 15" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="7.5" cy="7.5" r="7.5" fill="#27AE60"/>
                                    <path d="M6.03334 9.2875L4.10834 7.3625L3 8.5L6 11.5L12 5.5L10.8917 4.42916L6.03334 9.2875Z"
                                          fill="#F2F2F2"/>
                                </svg>
                                <?php
                            }
                        }
                        ?>
                        <a href="<?= $product['URL'] ?>"><?= $product['UF_NAME'] ?></a>
                    </div>
                    <div class="location">
                        <?php
                        if (intval($product['UF_CITY'])) {
                            ?>
                            <div class="text">
                                <?= $arResult['CITIES'][$product['UF_CITY']]['name'] ?>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                    <div class="location">
                        <div class="text">
                            <?php
                            echo UtilsAlias::dateForHumans($product['UF_DATE_CREATE']);
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
    </div>

    <? if (!count($arResult['ITEMS'])): ?>
        <div class="info-message">
            <?= Loc::getMessage('LIST_FILTER_RESULT_EMPTY') ?>
        </div>
    <? else: ?>
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:pagination',
            '',
            [
                'TOTAL' => $arResult['TOTAL'],
                'LIMIT' => $arResult['LIMIT'],
                'CURRENT_PAGE' => $arResult['CURRENT_PAGE'],
                'URL' => $APPLICATION->GetCurPage(false)
            ]
        );
        ?>
    <? endif ?>
</div>
<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
    <?php
    if (count($arResult['LINKS'])) {
        ?>
        <div class="_box _mb">
            <div class="inner-menu collapse active">
                <div class="title collapse active">
                    <?= Loc::getMessage('LIST_COMPONENT_CATEGORIES_TITLE') ?>
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g>
                            <path d="M7.41 8.295L12 12.875L16.59 8.295L18 9.705L12 15.705L6 9.705L7.41 8.295Z"
                                  fill="#4F4F4F"/>
                        </g>
                    </svg>
                </div>
                <div class="title__description active">
                    <?= Loc::getMessage('LIST_COMPONENT_CATEGORIES_TITLE_DESCRIPTION') ?>
                </div>
                <?php
                if (count($arResult['LINKS']) > 8) {
                    ?>
                    <input class="_mb" id="cat-filter" placeholder="<?= Loc::getMessage('LIST_INPUT_NAME') ?>">
                    <?php
                }
                ?>
                <div id="categories-nav">
                    <?php
                    foreach ($arResult['LINKS'] as $item) {
                        ?>
                        <div class="item">
                            <a href="<?= $item['url'] ?>"><?= $item['name'] ?></a>
                        </div>
                        <?
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
    }

    $APPLICATION->IncludeComponent(
        'democontent2.board:filter',
        '',
        [
            'IBLOCK_ID' => $arResult['IBLOCK_ID']
        ]
    );
    $APPLICATION->IncludeComponent(
        'democontent2.board:vip',
        'vertical',
        [
            'IBLOCK_ID' => $arResult['IBLOCK_ID'],
            'CITY_ID' => $arResult['CITY']['id']
        ]
    );
    ?>
</div>
<script>
    var siteTemplatePath = '<?= SITE_TEMPLATE_PATH ?>',
        __ajaxPath = '<?=$this->GetFolder()?>/ajax.php';
    BX.message({
        categoriesFilter: JSON.parse('<?=Json::encode($categories)?>')
    });
</script>
