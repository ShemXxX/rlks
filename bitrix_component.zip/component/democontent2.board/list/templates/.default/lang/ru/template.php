<?php
/*
 * Date and Time: 25.08.2020, 11:54
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

$MESS['LIST_BTN_MORE'] = 'Подробнее';
$MESS['LIST_SHOW_FILTER'] = 'Показать фильтр';
$MESS['LIST_SORT_PRICE_UP'] = 'Дороже';
$MESS['LIST_SORT_PRICE_DOWN'] = 'Дешевле';
$MESS['LIST_SORT_DATE_UP'] = 'Новые';
$MESS['LIST_SORT_DATE_DOWN'] = 'Старые';
$MESS['LIST_SORT_POPULAR'] = 'Популярные';
$MESS['LIST_FILTER_RESULT_EMPTY'] = 'По данным параметрам ничего не найдено';
$MESS['CONFIRM_DELETE'] = 'Вы действительно хотите удалить этот элемент?';
$MESS['LIST_COMPONENT_CATEGORIES_TITLE'] = 'Категории';
$MESS['LIST_COMPONENT_CATEGORIES_TITLE_DESCRIPTION'] = 'Нажмите, чтобы открыть список';
$MESS['LIST_COMPONENT_ADD_FAV'] = 'Добавить в избранное';
$MESS['LIST_COMPONENT_REMOVE_FAV'] = 'Удалить из избранного';
$MESS['LIST_INPUT_NAME'] = 'Введите название';
$MESS['MORE_IMAGES'] = 'Ещё #QTY# фото';
