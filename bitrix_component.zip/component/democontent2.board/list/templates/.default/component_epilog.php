<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 01.10.2018
 * Time: 09:29
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

if (count($arResult) > 0) {
    $request = \Bitrix\Main\Application::getInstance()->getContext()->getRequest();
    $title = '';
    $description = '';
    $keywords = '';
    $tempPath = [];
    if (isset($arResult['CITY']['id']) && !$arResult['CITY']['default']) {
        if (!intval($request->getCookie('skipCity'))) {
            $tempPath[] = 'city-' . $arResult['CITY']['code'];
        }
    }

    $tempPath[] = $arParams['iBlockType'];
    $APPLICATION->AddChainItem($arResult['IBLOCK_TYPE_NAME'], SITE_DIR . implode('/', $tempPath) . '/');

    $tempPath[] = $arParams['iBlockCode'];
    $APPLICATION->AddChainItem($arResult['IBLOCK_NAME'], SITE_DIR . implode('/', $tempPath) . '/');

    if (isset($arResult['SECTIONS_PATH'])) {
        $i = 0;
        $c = count($arResult['SECTIONS_PATH']);
        foreach ($arResult['SECTIONS_PATH'] as $s) {
            $i++;
            $tempPath[] = $s['CODE'];
            if ($i !== $c) {
                $APPLICATION->AddChainItem($s['NAME'], SITE_DIR . implode('/', $tempPath) . '/');
            } else {
                $APPLICATION->AddChainItem($s['NAME']);
            }
        }
    }

    if (isset($arResult['META']['SECTION_META_TITLE'])) {
        $title = $arResult['META']['SECTION_META_TITLE'];
    }

    if (isset($arResult['META']['SECTION_META_DESCRIPTION'])) {
        $description = $arResult['META']['SECTION_META_DESCRIPTION'];
    }

    if (isset($arResult['META']['SECTION_META_KEYWORDS'])) {
        $keywords = $arResult['META']['SECTION_META_KEYWORDS'];
    }

    $APPLICATION->SetTitle($title);
    $APPLICATION->SetPageProperty('title', $title);

    if (strlen($description) > 0) {
        $APPLICATION->SetPageProperty('description', $description);
    }

    if (strlen($keywords) > 0) {
        $APPLICATION->SetPageProperty('keywords', $keywords);
    }

    unset($tempPath);
}
