<?php
/*
 * Date and Time: 17.11.2020, 9:27
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

use Bitrix\Main\Context;
use Bitrix\Main\Engine\Response\Json;

$request = Context::getCurrent()->getRequest();
$error = 1;
$result = '';

if ($request->isAjaxRequest() && $request->isPost()) {
    if ($request->getPost('imageId') && intval($request->getPost('imageId')) > 0) {
        try {
            $image = CFile::ResizeImageGet(
                intval($request->getPost('imageId')),
                [
                    'width' => 294,
                    'height' => 220
                ],
                BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
                true
            );
            if (isset($image['src'])) {
                $error = 0;
                $result = $image['src'];
            }
        } catch (Exception $e) {
        }
    }
}

$r = new Json([
    'error' => $error,
    'result' => $result
]);
$r->send();
