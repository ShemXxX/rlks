<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 01.10.2018
 * Time: 09:29
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['LIST_BTN_MORE'] = 'Подробнее';
$MESS['LIST_SHOW_FILTER'] = 'Показать фильтр';
$MESS['LIST_SORT_PRICE_UP'] = 'Дороже';
$MESS['LIST_SORT_PRICE_DOWN'] = 'Дешевле';
$MESS['LIST_SORT_DATE_UP'] = 'Новые';
$MESS['LIST_SORT_DATE_DOWN'] = 'Старые';
$MESS['LIST_SORT_POPULAR'] = 'Популярные';
$MESS['LIST_FILTER_RESULT_EMPTY'] = 'По данным параметрам ничего не найдено';
$MESS['CONFIRM_DELETE'] = 'Вы действительно хотите удалить этот элемент?';
$MESS['LIST_COMPONENT_CATEGORIES_TITLE'] = 'Категории';
$MESS['LIST_COMPONENT_CATEGORIES_TITLE_DESCRIPTION'] = 'Нажмите, чтобы открыть список';
$MESS['LIST_COMPONENT_ADD_FAV'] = 'Добавить в избранное';
$MESS['LIST_COMPONENT_REMOVE_FAV'] = 'Удалить из избранного';
$MESS['LIST_INPUT_NAME'] = 'Введите название';