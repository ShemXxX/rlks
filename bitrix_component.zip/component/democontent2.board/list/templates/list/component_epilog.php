<?php
/**
 * Date and Time: 28.07.2020, 9:18
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Application;

if (count($arResult) > 0) {
    $request = Application::getInstance()->getContext()->getRequest();
    $title = '';
    $description = '';
    $keywords = '';
    $tempPath = [];
    if (isset($arResult['CITY']['id']) && !$arResult['CITY']['default']) {
        if (!intval($request->getCookie('skipCity'))) {
            $tempPath[] = 'city-' . $arResult['CITY']['code'];
        }
    }

    $tempPath[] = $arParams['iBlockType'];
    $APPLICATION->AddChainItem($arResult['IBLOCK_TYPE_NAME'], SITE_DIR . implode('/', $tempPath) . '/');

    $tempPath[] = $arParams['iBlockCode'];
    $APPLICATION->AddChainItem($arResult['IBLOCK_NAME'], SITE_DIR . implode('/', $tempPath) . '/');

    if (isset($arResult['SECTIONS_PATH'])) {
        $i = 0;
        $c = count($arResult['SECTIONS_PATH']);
        foreach ($arResult['SECTIONS_PATH'] as $s) {
            $i++;
            $tempPath[] = $s['CODE'];
            if ($i !== $c) {
                $APPLICATION->AddChainItem($s['NAME'], SITE_DIR . implode('/', $tempPath) . '/');
            } else {
                $APPLICATION->AddChainItem($s['NAME']);
            }
        }
    }

    if (isset($arResult['META']['SECTION_META_TITLE'])) {
        $title = $arResult['META']['SECTION_META_TITLE'];
    }

    if (isset($arResult['META']['SECTION_META_DESCRIPTION'])) {
        $description = $arResult['META']['SECTION_META_DESCRIPTION'];
    }

    if (isset($arResult['META']['SECTION_META_KEYWORDS'])) {
        $keywords = $arResult['META']['SECTION_META_KEYWORDS'];
    }

    $APPLICATION->SetTitle($title);
    $APPLICATION->SetPageProperty('title', $title);

    if (strlen($description) > 0) {
        $APPLICATION->SetPageProperty('description', $description);
    }

    if (strlen($keywords) > 0) {
        $APPLICATION->SetPageProperty('keywords', $keywords);
    }

    unset($tempPath);
}
