<?php
/**
 * Date and Time: 22.07.2020, 9:22
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Democontent2\Board\Balance\Account;
use Democontent2\Board\Iblock\Items;
use Democontent2\Board\User;
use Democontent2\Board\Utils as UtilsAlias;

class TopMenuComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        global $USER;

        $this->arResult['AUTHORIZED'] = $USER->IsAuthorized();
        $this->arResult['IS_MODERATOR'] = ($USER->IsAdmin() || ($USER->IsAuthorized() && UtilsAlias::isModerator($USER->GetGroups())));
        $this->arResult['EMAIL'] = ($this->arResult['AUTHORIZED']) ? $USER->GetEmail() : false;
        $this->arResult['BALANCE'] = 0;
        $this->arResult['ON_MODERATION'] = 0;

        if ($this->arResult['AUTHORIZED']) {
            $us = new User($USER->GetID());
            $this->arResult['USER'] = $us->get();

            $account = new Account($USER->GetID());
            if (!$account->checkAccount()) {
                $account->create();
            }

            $this->arResult['BALANCE'] = $account->getAmount();
        }

        if ($this->arResult['IS_MODERATOR']) {
            $items = new Items();
            $this->arResult['ON_MODERATION'] = $items->onModerationQuantity();
        }

        $this->includeComponentTemplate();
    }
}
