<?php
/**
 * Date: 16.04.2020
 * Time: 15:00
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Democontent2\Board\Utils;

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

$currencyName = Option::get(DBOARD, 'currency_name');

if ($arResult['AUTHORIZED']) {
    $pict = null;
    if (intval($arResult['USER']['PERSONAL_PHOTO'])) {
        $pict = CFile::ResizeImageGet(
            $arResult['USER']['PERSONAL_PHOTO'],
            [
                'width' => 30,
                'height' => 30
            ],
            BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
            true
        );
    }

    if ($arResult['IS_MODERATOR']) {
        ?>
        <div class="header-top__link">
            <a href="<?= SITE_DIR ?>user/moderation/">
                <div class="icon">
                    <?php
                    if ($arResult['ON_MODERATION'] > 0) {
                        ?>
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g>
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                      d="M8.9925 1.5C4.8525 1.5 1.5 4.86 1.5 9C1.5 13.14 4.8525 16.5 8.9925 16.5C13.14 16.5 16.5 13.14 16.5 9C16.5 4.86 13.14 1.5 8.9925 1.5ZM9.75 9.75V5.25H8.25V9.75H9.75ZM9.75 12.75V11.25H8.25V12.75H9.75ZM3 9C3 12.315 5.685 15 9 15C12.315 15 15 12.315 15 9C15 5.685 12.315 3 9 3C5.685 3 3 5.685 3 9Z"
                                      fill="#EB5757"/>
                            </g>
                        </svg>
                        <?php
                    } else {
                        ?>
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                  d="M8.9925 1.5C4.8525 1.5 1.5 4.86 1.5 9C1.5 13.14 4.8525 16.5 8.9925 16.5C13.14 16.5 16.5 13.14 16.5 9C16.5 4.86 13.14 1.5 8.9925 1.5ZM9.75 9.75V5.25H8.25V9.75H9.75ZM9.75 12.75V11.25H8.25V12.75H9.75ZM3 9C3 12.315 5.685 15 9 15C12.315 15 15 12.315 15 9C15 5.685 12.315 3 9 3C5.685 3 3 5.685 3 9Z"
                                  fill="#4F4F4F"/>
                        </svg>
                        <?php
                    }
                    ?>
                </div>
                <span>
                    <?= Loc::getMessage('TOP_MENU_COMPONENT_MODERATION') ?>
                    <?php
                    if ($arResult['ON_MODERATION'] > 0) {
                        echo ' (' . $arResult['ON_MODERATION'] . ')';
                    }
                    ?>
                </span>
            </a>
        </div>
        <?php
    }
    ?>
    <div class="header-top__link">
        <a href="<?= SITE_DIR ?>user/favourites/">
            <div class="icon">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                     xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd"
                          d="M9 3.68624C9.8175 2.72624 11.07 2.11874 12.375 2.11874C14.685 2.11874 16.5 3.93374 16.5 6.24374C16.5 9.07642 13.9542 11.385 10.097 14.8826L10.0875 14.8912L9 15.8812L7.9125 14.8987L7.88289 14.8718C4.03697 11.3769 1.5 9.07149 1.5 6.24374C1.5 3.93374 3.315 2.11874 5.625 2.11874C6.93 2.11874 8.1825 2.72624 9 3.68624ZM9 13.8562L9.075 13.7812C12.645 10.5487 15 8.41124 15 6.24374C15 4.74374 13.875 3.61874 12.375 3.61874C11.22 3.61874 10.095 4.36124 9.705 5.38874H8.3025C7.905 4.36124 6.78 3.61874 5.625 3.61874C4.125 3.61874 3 4.74374 3 6.24374C3 8.41124 5.355 10.5487 8.925 13.7812L9 13.8562Z"
                          fill="#4F4F4F"/>
                </svg>
            </div>
            <span><?= Loc::getMessage('TOP_MENU_COMPONENT_FAVOURITES') ?></span>
        </a>
    </div>
    <?php
    if (intval(Option::get(DBOARD, 'chatEnabled'))) {
        ?>
        <div class="header-top__link">
            <div class="messages indicator"></div>
            <a href="<?= SITE_DIR ?>user/direct/">
                <div class="icon">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                         xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                              d="M15 3H3C2.175 3 1.5075 3.675 1.5075 4.5L1.5 13.5C1.5 14.325 2.175 15 3 15H15C15.825 15 16.5 14.325 16.5 13.5V4.5C16.5 3.675 15.825 3 15 3ZM3 6L9 9.75L15 6V13.5H3V6ZM3 4.5L9 8.25L15 4.5H3Z"
                              fill="#4F4F4F"/>
                    </svg>
                </div>
                <span><?= Loc::getMessage('TOP_MENU_COMPONENT_MESSAGES') ?></span>
            </a>
        </div>
        <?php
    }
    ?>


<?
	/** DECODE START
	 *  if User is seller -> show ballance
	 */
?>

	<? if (CSite::InGroup( array(6) )) { ?>
    <div class="header-top__link">
			<a href="<?= SITE_DIR ?>user/balance/">
				<div class="icon">
					<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
						<g>
							<path fill-rule="evenodd" clip-rule="evenodd"
										d="M15.375 3.75V5.46C15.8175 5.7225 16.125 6.195 16.125 6.75V11.25C16.125 11.805 15.8175 12.2775 15.375 12.54V14.25C15.375 15.075 14.7 15.75 13.875 15.75H3.375C2.5425 15.75 1.875 15.075 1.875 14.25V3.75C1.875 2.925 2.5425 2.25 3.375 2.25H13.875C14.7 2.25 15.375 2.925 15.375 3.75ZM9.375 11.25H14.625V6.75H9.375V11.25ZM3.375 14.25V3.75H13.875V5.25H9.375C8.55 5.25 7.875 5.925 7.875 6.75V11.25C7.875 12.075 8.55 12.75 9.375 12.75H13.875V14.25H3.375ZM10.5 9C10.5 8.37868 11.0037 7.875 11.625 7.875C12.2463 7.875 12.75 8.37868 12.75 9C12.75 9.62132 12.2463 10.125 11.625 10.125C11.0037 10.125 10.5 9.62132 10.5 9Z"
										fill="#4F4F4F"/>
						</g>
					</svg>

				</div>
				<span>
					<?= Utils::price($arResult['BALANCE']) ?>
					<?= $currencyName ?>
				</span>
			</a>
    </div>
	<? } ?>

<? /** DECODE END */ ?>

    <div class="header-top__link">
			<? // check seller
      if (!CSite::InGroup( array(5) )) {
      	$userlink = SITE_DIR."user/favourites/";
      } else {
        $userlink = SITE_DIR."user/items/";
      }
			?>

        <a href="<?=$userlink?>">
					<div class="icon">
						<?php if (!is_null($pict)) { ?>
						<div class="image">
								<img src="<?= $pict['src'] ?>" alt="">
						</div>
						<?php } else { ?>
						<svg width="18" height="18" viewBox="0 0 18 18" fill="none"
								 xmlns="http://www.w3.org/2000/svg">
							<g id="account_circle_24px">
									<path id="icon/action/account_circle_24px" fill-rule="evenodd"
												clip-rule="evenodd"
												d="M9 1.5C4.86 1.5 1.5 4.86 1.5 9C1.5 13.14 4.86 16.5 9 16.5C13.14 16.5 16.5 13.14 16.5 9C16.5 4.86 13.14 1.5 9 1.5ZM5.3025 13.71C5.625 13.035 7.59 12.375 9 12.375C10.41 12.375 12.3825 13.035 12.6975 13.71C11.6775 14.52 10.395 15 9 15C7.605 15 6.3225 14.52 5.3025 13.71ZM9 10.875C10.095 10.875 12.6975 11.3175 13.77 12.6225C14.535 11.6175 15 10.365 15 9C15 5.6925 12.3075 3 9 3C5.6925 3 3 5.6925 3 9C3 10.365 3.465 11.6175 4.23 12.6225C5.3025 11.3175 7.905 10.875 9 10.875ZM9 4.5C7.545 4.5 6.375 5.67 6.375 7.125C6.375 8.58 7.545 9.75 9 9.75C10.455 9.75 11.625 8.58 11.625 7.125C11.625 5.67 10.455 4.5 9 4.5ZM7.875 7.125C7.875 7.7475 8.3775 8.25 9 8.25C9.6225 8.25 10.125 7.7475 10.125 7.125C10.125 6.5025 9.6225 6 9 6C8.3775 6 7.875 6.5025 7.875 7.125Z"
												fill="#4F4F4F"/>
							</g>
						</svg>
						<?php } ?>
					</div>
					<span><?= $arResult['EMAIL'] ?></span>
        </a>
    </div>
    <div class="header-top__link">
        <a href="<?= SITE_DIR ?>user/exit/">
            <div class="icon">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                     xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd"
                          d="M12.75 6.375H13.5C14.325 6.375 15 7.05 15 7.875V15.375C15 16.2 14.325 16.875 13.5 16.875H4.5C3.675 16.875 3 16.2 3 15.375V7.875C3 7.05 3.675 6.375 4.5 6.375H5.25V4.875C5.25 2.805 6.93 1.125 9 1.125C11.07 1.125 12.75 2.805 12.75 4.875V6.375ZM9 2.625C7.755 2.625 6.75 3.63 6.75 4.875V6.375H11.25V4.875C11.25 3.63 10.245 2.625 9 2.625ZM4.5 15.375V7.875H13.5V15.375H4.5ZM10.5 11.625C10.5 12.45 9.825 13.125 9 13.125C8.175 13.125 7.5 12.45 7.5 11.625C7.5 10.8 8.175 10.125 9 10.125C9.825 10.125 10.5 10.8 10.5 11.625Z"
                          fill="#4F4F4F"/>
                </svg>
            </div>
            <span><?= Loc::getMessage('TOP_MENU_COMPONENT_LOGOUT') ?></span>
        </a>
    </div>
    <?php
} else {
    ?>
    <div class="header-top__link">
			<a href="<?= SITE_DIR ?>user/login/">
				<div class="icon">
					<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
						<g>
							<path fill-rule="evenodd" clip-rule="evenodd"
										d="M13.5 6.375H12.75V4.875C12.75 2.805 11.07 1.125 9 1.125C6.93 1.125 5.25 2.805 5.25 4.875H6.75C6.75 3.63 7.755 2.625 9 2.625C10.245 2.625 11.25 3.63 11.25 4.875V6.375H4.5C3.675 6.375 3 7.05 3 7.875V15.375C3 16.2 3.675 16.875 4.5 16.875H13.5C14.325 16.875 15 16.2 15 15.375V7.875C15 7.05 14.325 6.375 13.5 6.375ZM4.5 15.375V7.875H13.5V15.375H4.5ZM10.5 11.625C10.5 12.45 9.825 13.125 9 13.125C8.175 13.125 7.5 12.45 7.5 11.625C7.5 10.8 8.175 10.125 9 10.125C9.825 10.125 10.5 10.8 10.5 11.625Z"
										fill="#4F4F4F"/>
						</g>
					</svg>
				</div>
				<span><?= Loc::getMessage('TOP_MENU_COMPONENT_LOGIN') ?></span>
			</a>
    </div>
    <div class="header-top__link">
        <a href="<?= SITE_DIR ?>user/register/">
            <div class="icon">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g>
                        <path fill-rule="evenodd" clip-rule="evenodd"
                              d="M9 1.5C4.86 1.5 1.5 4.86 1.5 9C1.5 13.14 4.86 16.5 9 16.5C13.14 16.5 16.5 13.14 16.5 9C16.5 4.86 13.14 1.5 9 1.5ZM9.3825 7.4925C9.3825 6.255 8.37 5.2425 7.1325 5.2425C5.895 5.2425 4.8825 6.255 4.8825 7.4925C4.8825 8.73 5.895 9.7425 7.1325 9.7425C8.37 9.7425 9.3825 8.73 9.3825 7.4925ZM7.1325 8.2425C6.72 8.2425 6.3825 7.905 6.3825 7.4925C6.3825 7.08 6.72 6.7425 7.1325 6.7425C7.545 6.7425 7.8825 7.08 7.8825 7.4925C7.8825 7.905 7.545 8.2425 7.1325 8.2425ZM13.5075 8.2425C13.5075 9.075 12.84 9.7425 12.0075 9.7425C11.175 9.7425 10.5075 9.075 10.5075 8.2425C10.5 7.41 11.175 6.7425 12.0075 6.7425C12.84 6.7425 13.5075 7.41 13.5075 8.2425ZM7.1325 12C6.09 12 4.8975 12.4275 4.3875 12.8325C5.415 14.07 6.93 14.88 8.6325 14.9775V12.8925C8.6325 11.475 10.8675 10.8675 12.0075 10.8675C12.6675 10.8675 13.6875 11.0775 14.4375 11.52C14.7975 10.7475 15 9.8925 15 8.9925C15 5.685 12.3075 2.9925 9 2.9925C5.6925 2.9925 3 5.685 3 8.9925C3 9.915 3.21 10.785 3.585 11.565C4.59 10.83 6.1575 10.4925 7.1325 10.4925C7.4625 10.4925 7.86 10.5375 8.28 10.6125C7.8075 11.04 7.485 11.5275 7.305 12.0075C7.274 12.0075 7.243 12.0055 7.21303 12.0036C7.185 12.0018 7.15787 12 7.1325 12Z"
                              fill="#4F4F4F"/>
                    </g>
                </svg>
            </div>
            <span><?= Loc::getMessage('TOP_MENU_COMPONENT_REGISTER') ?></span>
        </a>
    </div>
    <?php
}
?>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}

