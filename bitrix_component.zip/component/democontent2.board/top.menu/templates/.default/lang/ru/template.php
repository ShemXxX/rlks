<?php
/**
 * Date: 16.04.2020
 * Time: 15:00
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
$MESS['TOP_MENU_COMPONENT_FAVOURITES'] = 'Избранное';
$MESS['TOP_MENU_COMPONENT_MESSAGES'] = 'Сообщения';
$MESS['TOP_MENU_COMPONENT_LOGIN'] = 'Войти';
$MESS['TOP_MENU_COMPONENT_REGISTER'] = 'Зарегистрироваться';
$MESS['TOP_MENU_COMPONENT_LOGOUT'] = 'Выйти';
$MESS['TOP_MENU_COMPONENT_MODERATION'] = 'Модерация';
