<?php
/**
 * Date and Time: 22.07.2020, 9:20
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

use Bitrix\Main\Application;
use Democontent2\Board\Iblock\City;

class SearchComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        $request = Application::getInstance()->getContext()->getRequest();
        if (!intval($request->getCookie('skipCity'))) {
            $city = new City();
            $cityParams = $city->getDefault();
            if (intval($request->getCookie('current_city'))) {
                $tempCity = $city->getById(
                    intval($request->getCookie('current_city'))
                );

                if (count($tempCity) > 0) {
                    $cityParams = $tempCity;
                }
                unset($tempCity);
            }

            $this->arResult['CITY_DECLENSION'] = $cityParams['declension'];
        } else {
            $this->arResult['CITY_DECLENSION'] = '';
        }
        $this->IncludeComponentTemplate();
    }
}
