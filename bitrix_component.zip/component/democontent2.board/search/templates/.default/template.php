<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 24.09.2018
 * Time: 14:17
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}
?>
    <div class="search">
        <form action="<?= SITE_DIR ?>search/" method="get">
            <input placeholder="<?= Loc::getMessage('SEARCH_COMPONENT_PLACEHOLDER') ?> <?= $arResult['CITY_DECLENSION'] ?>"
                   name="find">
            <button type="submit">
                <?= Loc::getMessage('SEARCH_COMPONENT_FIND') ?>
            </button>
        </form>
    </div>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}