<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 24.09.2018
 * Time: 14:17
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (method_exists($this, 'createFrame')) {
  $frame = $this->createFrame()->begin();
}
?>

  <a class="favorite-products"
     href="<?= ($USER->IsAuthorized() ? SITE_DIR . 'user/favourites/' : '#popup-registration') ?>" <?= ($USER->IsAuthorized() ? '' : 'data-fancybox') ?>>
    <svg class="icon icon_heart">
      <use xlink:href="<?= SITE_TEMPLATE_PATH ?>/images/sprite-svg.svg#heart"></use>
    </svg>
  </a>

<?php
if (method_exists($this, 'createFrame')) {
  $frame->end();
}