<?php
/*
 * Date and Time: 06.08.2020, 9:19
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (!($arResult['ITEMS'] instanceof Generator)) {
    return;
}
if (!$arResult['ITEMS']->current()) {
    return;
}

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Config\Option;
use Democontent2\Board\Utils;

$id = randString();

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame($id)->begin();
    $frame->setAutoUpdate(false);
}
$currencyName = Option::get(DBOARD, 'currency_name');

?>
    <div class=" _box _mt vip-vertical">
        <div class="vip-block" id="<?= $id ?>">
            <h3><?= Loc::getMessage('VIP_COMPONENT_TITLE') ?></h3>
            <?php
            foreach ($arResult['ITEMS'] as $item) {
                $arButtons = CIBlock::GetPanelButtons(
                    $item['UF_IBLOCK_ID'],
                    $item['UF_ID'],
                    0,
                    ["SECTION_BUTTONS" => false, "SESSID" => false]
                );
                $arItem["EDIT_LINK"] = $arButtons["edit"]["edit_element"]["ACTION_URL"];
                $arItem["DELETE_LINK"] = $arButtons["edit"]["delete_element"]["ACTION_URL"];
                $this->AddEditAction(
                    $item['UF_ID'],
                    $arItem['EDIT_LINK'],
                    CIBlock::GetArrayByID(
                        $item['UF_IBLOCK_ID'],
                        "ELEMENT_EDIT"
                    )
                );
                $this->AddDeleteAction(
                    $item['UF_ID'],
                    $arItem['DELETE_LINK'],
                    CIBlock::GetArrayByID(
                        $item['UF_IBLOCK_ID'],
                        "ELEMENT_DELETE"
                    ),
                    [
                        "CONFIRM" => Loc::getMessage('CONFIRM_DELETE')
                    ]
                );
                $image = null;
                if ($item['imageId'] > 0) {
                    $image = CFile::ResizeImageGet(
                        $item['imageId'],
                        [
                            'width' => 80,
                            'height' => 80
                        ],
                        BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
                        true
                    );
                }
                ?>
                <div class="item" id="<?= $this->GetEditAreaId($item['UF_ID']) ?>">
                    <div class="image">
                        <a href="<?= SITE_DIR ?><?= $item['iBlockType'] ?>/<?= $item['iBlockCode'] ?>/<?= $item['code'] ?>/">
                            <div class="fotorama _mb" data-width="80px" data-height="80px" data-maxheight="80px"
                                 data-allowfullscreen="false" data-loop="false">
                                <?php
                                if (!is_null($image)) {
                                    ?>
                                    <div data-img="<?= $image['src'] ?>">
                                        <div class="fotorama__blur" style="background:url(<?= $image['src'] ?>)"></div>
                                    </div>
                                    <?php
                                } else {
                                    //TODO no image
                                }
                                ?>
                            </div>
                        </a>
                    </div>
                    <div class="content">
                        <div class="name">
                            <a href="<?= SITE_DIR ?><?= $item['iBlockType'] ?>/<?= $item['iBlockCode'] ?>/<?= $item['code'] ?>/">
                                <?= $item['name'] ?>
                            </a>
                        </div>
                        <div class="price">
                            <?= Utils::price($item['price']) ?>
                            <?= $currencyName ?>
                        </div>
                        <div class="city">
                            <?= $arResult['CITIES'][$item['UF_CITY_ID']]['name'] ?>
                        </div>
                    </div>
                </div>
                <?php
            }
            ?>
        </div>
    </div>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}