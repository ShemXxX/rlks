<?php
/**
 * Date and Time: 22.07.2020, 9:30
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

use Bitrix\Main\Application;
use Bitrix\Main\IO\Directory as DirectoryAlias;
use Bitrix\Main\IO\File;
use Bitrix\Main\IO\Path;
use Democontent2\Board\Iblock\City;
use Democontent2\Board\Iblock\IblockIdMeta;
use Democontent2\Board\Iblock\IblockTypeMeta;
use Democontent2\Board\Iblock\Properties;
use Democontent2\Board\Iblock\Section;
use Democontent2\Board\Translate\Cities;
use Democontent2\Board\Translate\Components;
use Democontent2\Board\Translate\IblockMeta;
use Democontent2\Board\Translate\Iblocks;
use Democontent2\Board\Translate\IblockTypeMeta as IblockTypeMetaAlias;
use Democontent2\Board\Translate\Lang;
use Democontent2\Board\Translate\Properties as PropertiesAlias;
use Democontent2\Board\Translate\PropertyValues;
use Democontent2\Board\Translate\Regions;
use Democontent2\Board\Translate\Sections;
use Democontent2\Board\Translate\Types;

class UserTranslationsComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        global $USER;

        if ($USER->IsAdmin()) {
            $request = Application::getInstance()->getContext()->getRequest();
            $lang = new Lang();
            $components = new Components();
            $iblock = new \Democontent2\Board\Iblock\Iblock(0);
            $city = new City();

            $docRoot = Application::getDocumentRoot();
            $this->arResult['CURRENT_LANGUAGE'] = '';
            $this->arResult['LANGUAGES'] = $lang->getLanguages();
            $this->arResult['COMPONENTS'] = $components->getList();
            $this->arResult['IBLOCK_TYPES'] = $iblock->getTypes(true);
            $this->arResult['REGIONS'] = $city->getRegions(true);
            $this->arResult['CITIES'] = $city->getList(0, 0, true);
            $this->arResult['IBLOCK_TYPES_META'] = [];
            $this->arResult['IBLOCK_ID_META'] = [];
            $this->arResult['IBLOCK_PROPERTIES'] = [];
            $this->arResult['SECTIONS'] = [];
            $this->arResult['TRANSLATE'] = [
                'IBLOCK_TYPES' => [],
                'IBLOCKS' => [],
                'SECTIONS' => [],
                'IBLOCK_PROPERTIES' => [],
                'IBLOCK_PROPERTY_VALUES' => [],
                'IBLOCK_TYPES_META' => [],
                'IBLOCK_ID_META' => [],
                'REGIONS' => [],
                'CITIES' => [],
            ];
            $this->arResult['DIR'] = $components->getDir();

            foreach ($this->arResult['IBLOCK_TYPES'] as $k => $v) {
                $iblockTypesMeta = new IblockTypeMeta(str_replace('democontent2_board_', '', $k));
                $this->arResult['IBLOCK_TYPES_META'][$k] = $iblockTypesMeta->get();

                foreach ($v['iblocks'] as $iblockParams) {
                    $iblockIdMeta = new IblockIdMeta($iblockParams['id']);
                    $this->arResult['IBLOCK_ID_META'][$iblockParams['id']] = $iblockIdMeta->get();

                    $properties = new Properties($iblockParams['id']);
                    $this->arResult['IBLOCK_PROPERTIES'][$iblockParams['id']] = $properties->all(true);

                    $hiddenProperries = $properties->hidden();

                    if (isset($hiddenProperries['__hidden_price'])) {
                        $this->arResult['IBLOCK_PROPERTIES'][$iblockParams['id']][$hiddenProperries['__hidden_price']['id']] = $hiddenProperries['__hidden_price'];
                    }

                    $sections = new Section(0);
                    $this->arResult['SECTIONS'][$iblockParams['id']] = $sections->getSections($iblockParams['id'], 0, 0, true);
                }
            }

            if ($request->isPost()) {
                if ($request->getPost('languageCode') && $request->getPost('languageName')) {
                    if (strlen($request->getPost('languageCode')) == 2 && !isset($this->arResult['LANGUAGES'][$request->getPost('languageCode')])) {
                        $lang->setCode($request->getPost('languageCode'));
                        $lang->setName($request->getPost('languageName'));
                        $lang->addLanguage();
                    }
                }

                if ($request->getPost('currentLanguage') && $request->getPost('currentLanguage') !== 'ru'
                    && isset($this->arResult['LANGUAGES'][$request->getPost('currentLanguage')])) {
                    if ($request->getPost('iBlockTypes')) {
                        $types = new Types(0);
                        foreach ($request->getPost('iBlockTypes') as $k => $v) {
                            $types->setIBlockType($k);
                            $types->setLang($request->getPost('currentLanguage'));
                            $types->setTranslate($v);
                            $types->change();
                        }
                    }

                    if ($request->getPost('iblocks')) {
                        $iblocks = new Iblocks(0);
                        foreach ($request->getPost('iblocks') as $k => $v) {
                            $iblocks->setIBlockId($k);
                            $iblocks->setLang($request->getPost('currentLanguage'));
                            $iblocks->setTranslate($v);
                            $iblocks->change();
                        }
                    }

                    if ($request->getPost('propertyNames')) {
                        $iblocks = new PropertiesAlias(0);
                        foreach ($request->getPost('propertyNames') as $k => $v) {
                            $iblocks->setIBlockId($k);
                            $iblocks->setLang($request->getPost('currentLanguage'));

                            foreach ($v as $propId => $propValue) {
                                $iblocks->setPropertyId($propId);
                                $iblocks->setTranslate($propValue);
                                $iblocks->change();
                            }
                        }
                    }

                    if ($request->getPost('sections')) {
                        $iblocks = new Sections(0);
                        foreach ($request->getPost('sections') as $k => $v) {
                            $iblocks->setIBlockId($k);
                            $iblocks->setLang($request->getPost('currentLanguage'));

                            foreach ($v as $sectionId => $sectionValue) {
                                $iblocks->setSectionId($sectionId);
                                $iblocks->setTranslate($sectionValue);
                                $iblocks->change();
                            }
                        }
                    }

                    if ($request->getPost('propertyValues')) {
                        $iblocks = new PropertyValues(0);
                        foreach ($request->getPost('propertyValues') as $k => $v) {
                            $iblocks->setIBlockId($k);
                            $iblocks->setLang($request->getPost('currentLanguage'));

                            foreach ($v as $propId => $propValue) {
                                $iblocks->setPropertyId($propId);

                                foreach ($propValue as $propValueId => $propValueValue) {
                                    $iblocks->setPropertyValueId($propValueId);
                                    $iblocks->setTranslate($propValueValue);
                                    $iblocks->change();
                                }
                            }
                        }
                    }

                    if ($request->getPost('iBlockTypesMeta')) {
                        $types = new IblockTypeMetaAlias();
                        foreach ($request->getPost('iBlockTypesMeta') as $k => $v) {
                            $types->setIBlockType($k);
                            $types->setLang($request->getPost('currentLanguage'));
                            $types->change($v['h1'], $v['title'], $v['breadcrumb']);
                        }
                    }

                    if ($request->getPost('iBlockIdMeta')) {
                        $types = new IblockMeta();
                        foreach ($request->getPost('iBlockIdMeta') as $k => $v) {
                            $types->setIBlockId($k);
                            $types->setLang($request->getPost('currentLanguage'));
                            $types->change($v['h1'], $v['title'], $v['breadcrumb']);
                        }
                    }

                    if ($request->getPost('components')) {
                        foreach ($request->getPost('components') as $k => $templates) {
                            foreach ($templates as $templateName => $templatePhrases) {
                                switch ($templateName) {
                                    case 'class.php':
                                        if (DirectoryAlias::isDirectoryExists(
                                            Path::normalize(
                                                $docRoot . '/' . $components->getDir() . '/components/' . DBOARD . '/' . $k . '/lang'
                                            )
                                        )) {
                                            $put = "<?php\n";

                                            foreach ($templatePhrases as $phraseKey => $phraseValue) {
                                                $put .= '$MESS[\'' . $phraseKey . '\']=\'' . "" . addslashes($phraseValue) . "';\n";
                                            }

                                            if (DirectoryAlias::isDirectoryExists(
                                                Path::normalize(
                                                    $docRoot . '/' . $components->getDir() . '/components/' . DBOARD . '/' . $k . '/lang/' . $request->getPost('currentLanguage')
                                                )
                                            )) {
                                                File::putFileContents(
                                                    Path::normalize(
                                                        $docRoot . '/' . $components->getDir() . '/components/' . DBOARD . '/' . $k . '/lang/' . $request->getPost('currentLanguage') . '/class.php'
                                                    ),
                                                    $put
                                                );
                                            } else {
                                                $createDirectory = DirectoryAlias::createDirectory(
                                                    Path::normalize(
                                                        $docRoot . '/' . $components->getDir() . '/components/' . DBOARD . '/' . $k . '/lang/' . $request->getPost('currentLanguage')
                                                    )
                                                );

                                                if (strlen($createDirectory->getPath())) {
                                                    File::putFileContents(
                                                        Path::normalize($createDirectory->getPath() . '/class.php'),
                                                        $put
                                                    );
                                                }
                                            }
                                        }
                                        break;
                                    default:
                                        if (DirectoryAlias::isDirectoryExists(
                                            Path::normalize(
                                                $docRoot . '/' . $components->getDir() . '/components/' . DBOARD . '/' . $k . '/templates'
                                            )
                                        )) {
                                            foreach ($templatePhrases as $placeType => $phrase) {
                                                switch ($placeType) {
                                                    case 'template.php':
                                                    case 'component_epilog.php':
                                                        $put = "<?php\n";

                                                        foreach ($phrase as $phraseKey => $phraseValue) {
                                                            $put .= '$MESS[\'' . $phraseKey . '\']=\'' . "" . addslashes($phraseValue) . "';\n";
                                                        }

                                                        if (DirectoryAlias::isDirectoryExists(
                                                            Path::normalize(
                                                                $docRoot . '/' . $components->getDir() . '/components/' . DBOARD . '/' . $k . '/templates/' . $templateName . '/lang'
                                                            )
                                                        )) {
                                                            if (DirectoryAlias::isDirectoryExists(
                                                                Path::normalize(
                                                                    $docRoot . '/' . $components->getDir() . '/components/' . DBOARD . '/' . $k . '/templates/' . $templateName . '/lang/' . $request->getPost('currentLanguage')
                                                                )
                                                            )) {
                                                                File::putFileContents(
                                                                    Path::normalize(
                                                                        $docRoot . '/' . $components->getDir() . '/components/' . DBOARD . '/' . $k . '/templates/' . $templateName . '/lang/' . $request->getPost('currentLanguage') . '/' . $placeType
                                                                    ),
                                                                    $put
                                                                );
                                                            } else {
                                                                $createDirectory = DirectoryAlias::createDirectory(
                                                                    Path::normalize(
                                                                        $docRoot . '/' . $components->getDir() . '/components/' . DBOARD . '/' . $k . '/templates/' . $templateName . '/lang/' . $request->getPost('currentLanguage')
                                                                    )
                                                                );

                                                                if (strlen($createDirectory->getPath())) {
                                                                    File::putFileContents(
                                                                        Path::normalize($createDirectory->getPath() . '/' . $placeType),
                                                                        $put
                                                                    );
                                                                }
                                                            }
                                                        }
                                                        break;
                                                }
                                            }
                                        }
                                }
                            }
                        }
                    }

                    if ($request->getPost('regions')) {
                        $iblocks = new Regions(0);
                        foreach ($request->getPost('regions') as $k => $v) {
                            $iblocks->setRegionId($k);
                            $iblocks->setLang($request->getPost('currentLanguage'));
                            $iblocks->setTranslate($v);
                            $iblocks->change();
                        }
                    }

                    if ($request->getPost('cities')) {
                        $iblocks = new Cities(0);
                        foreach ($request->getPost('cities') as $k => $v) {
                            $iblocks->setCityId($k);
                            $iblocks->setLang($request->getPost('currentLanguage'));
                            $iblocks->setTranslate($v);
                            $iblocks->change();
                        }
                    }

                    LocalRedirect(SITE_DIR . 'user/translations/?lang=' . $request->getPost('currentLanguage'), true);
                }

                LocalRedirect(SITE_DIR . 'user/translations/', true);
            }

            if ($request->get('lang')) {
                if (isset($this->arResult['LANGUAGES'][$request->get('lang')])) {
                    $this->arResult['CURRENT_LANGUAGE'] = $request->get('lang');

                    $translateIblocks = new Iblocks();
                    $translateProperties = new PropertiesAlias();
                    $translatePropertyValues = new PropertyValues();
                    $translateTypes = new Types();
                    $translateSections = new Sections(0);
                    $translateIblockMeta = new IblockMeta(0);
                    $translateIblockTypeMeta = new IblockTypeMetaAlias(0);
                    $translateRegions = new Regions(0);
                    $translateCities = new Cities(0);

                    $this->arResult['TRANSLATE'] = [
                        'IBLOCK_TYPES' => $translateTypes->getList($this->arResult['CURRENT_LANGUAGE']),
                        'IBLOCKS' => $translateIblocks->getList($this->arResult['CURRENT_LANGUAGE']),
                        'IBLOCK_PROPERTIES' => $translateProperties->getList($this->arResult['CURRENT_LANGUAGE']),
                        'IBLOCK_PROPERTY_VALUES' => $translatePropertyValues->getList($this->arResult['CURRENT_LANGUAGE']),
                        'SECTIONS' => $translateSections->getList($this->arResult['CURRENT_LANGUAGE']),
                        'IBLOCK_TYPES_META' => $translateIblockTypeMeta->getList($this->arResult['CURRENT_LANGUAGE']),
                        'IBLOCK_ID_META' => $translateIblockMeta->getList($this->arResult['CURRENT_LANGUAGE']),
                        'REGIONS' => $translateRegions->getList($this->arResult['CURRENT_LANGUAGE']),
                        'CITIES' => $translateCities->getList($this->arResult['CURRENT_LANGUAGE'])
                    ];
                }

                if ($request->get('tab')) {
                    switch (intval($request->get('tab'))) {
                        case 2:
                        case 3:
                        case 4:
                        case 5:
                        case 6:
                            $this->setTemplateName('tab-' . intval($request->get('tab')));
                            break;
                    }
                }
            }

            $this->includeComponentTemplate();
        } else {
            LocalRedirect(SITE_DIR, true);
        }
    }
}
