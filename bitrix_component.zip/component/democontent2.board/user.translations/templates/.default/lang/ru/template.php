<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 03.11.2018
 * Time: 21:18
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['USER_TRANSLATIONS_COMPONENT_H1'] = 'Настройка мультиязычности';
$MESS['USER_TRANSLATIONS_COMPONENT_CODE_LBL'] = 'Код языка (два символа, например )';
$MESS['USER_TRANSLATIONS_COMPONENT_CODE_TTL_LBL'] = 'Название языка';
$MESS['USER_TRANSLATIONS_COMPONENT_CODE_ADD_BTN'] = 'Добавить язык';
$MESS['USER_TRANSLATIONS_COMPONENT_LIST_LANGUAGES'] = 'Список языков';
$MESS['USER_TRANSLATIONS_COMPONENT_TAB1_TTL'] = 'Компоненты';
$MESS['USER_TRANSLATIONS_COMPONENT_TAB2_TTL'] = 'Инфоблоки';
$MESS['USER_TRANSLATIONS_COMPONENT_TAB3_TTL'] = 'Разделы';
$MESS['USER_TRANSLATIONS_COMPONENT_TAB4_TTL'] = 'Мета-данные';
$MESS['USER_TRANSLATIONS_COMPONENT_TAB5_TTL'] = 'Регионы';
$MESS['USER_TRANSLATIONS_COMPONENT_TAB6_TTL'] = 'Города';
$MESS['USER_TRANSLATIONS_COMPONENT_TTL_CMP'] = 'Название компонента';
$MESS['USER_TRANSLATIONS_COMPONENT_TRL_PLC'] = 'Перевод';
$MESS['USER_TRANSLATIONS_COMPONENT_SAVE'] = 'Сохранить';
$MESS['USER_TRANSLATIONS_COMPONENT_PROPERTIES_TTL'] = 'Свойства компонента';
$MESS['USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS'] = 'Перевести';
$MESS['USER_TRANSLATIONS_COMPONENT_TRANSLATE_ALL'] = 'Перевести раздел';

