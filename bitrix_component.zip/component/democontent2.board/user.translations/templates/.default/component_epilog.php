<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 21.03.2019
 * Time: 11:06
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;

$APPLICATION->SetTitle(Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TITLE'));
$APPLICATION->SetPageProperty('title', Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TITLE'));