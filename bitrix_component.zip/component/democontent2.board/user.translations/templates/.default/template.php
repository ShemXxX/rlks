<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 03.10.2018
 * Time: 10:53
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Application;
use Bitrix\Main\IO\File;
use Bitrix\Main\IO\Path;

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}
$docRoot = Application::getDocumentRoot();
$translateEnabled = (strlen(Option::get(DBOARD, 'google_translate_key'))) ? true : false;
?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_H1') ?></h1>
        <div class="flags _mt">
            <?php
            foreach ($arResult['LANGUAGES'] as $language) {
                $active = '';
                if ($_REQUEST['lang'] == $language['UF_CODE']) {
                    $active = ' active';
                }
                ?>
                <a class="flag-icon flag-icon-<?= ($language['UF_CODE'] == 'en') ? 'gb' : $language['UF_CODE'] ?><?= $active ?>"
                   href="<?= SITE_DIR ?>user/translations/?lang=<?= $language['UF_CODE'] ?>"></a>
                <?php
            }
            ?>
        </div>
        <form action="<?= SITE_DIR ?>user/translations/" method="post"
              class="edit-form">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div>
                    <label for="languageCode">
                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_CODE_LBL') ?>
                    </label>
                    <input placeholder="en" type="text" maxlength="2" name="languageCode" id="languageCode"
                           class="required">
                </div>
                <div>
                    <label for="languageName">
                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_CODE_TTL_LBL') ?>
                    </label>
                    <input type="text" name="languageName" id="languageName" placeholder="English" class="required">
                </div>
                <div class="_mt">
                    <button class="apply" type="submit">
                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_CODE_ADD_BTN') ?>
                    </button>
                </div>
            </div>
        </form>

        <?php
        if ($arResult['CURRENT_LANGUAGE']) {
            ?>
            <div class="items-list__sort _mt">
                <div class="item active">
                    <a href="<?= SITE_DIR ?>user/translations/?lang=<?= $_REQUEST['lang'] ?>">
                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TAB1_TTL') ?>
                    </a>
                </div>
                <div class="item">
                    <a href="<?= SITE_DIR ?>user/translations/?tab=2&lang=<?= $_REQUEST['lang'] ?>">
                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TAB2_TTL') ?>
                    </a>
                </div>
                <div class="item">
                    <a href="<?= SITE_DIR ?>user/translations/?tab=3&lang=<?= $_REQUEST['lang'] ?>">
                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TAB3_TTL') ?>
                    </a>
                </div>
                <div class="item">
                    <a href="<?= SITE_DIR ?>user/translations/?tab=4&lang=<?= $_REQUEST['lang'] ?>">
                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TAB4_TTL') ?>
                    </a>
                </div>
                <div class="item">
                    <a href="<?= SITE_DIR ?>user/translations/?tab=5&lang=<?= $_REQUEST['lang'] ?>">
                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TAB5_TTL') ?>
                    </a>
                </div>
                <div class="item">
                    <a href="<?= SITE_DIR ?>user/translations/?tab=6&lang=<?= $_REQUEST['lang'] ?>">
                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TAB6_TTL') ?>
                    </a>
                </div>
            </div>
            <form action="<?= SITE_DIR ?>user/translations/" method="post" class="edit-form">
                <input type="hidden" name="currentLanguage"
                       value="<?= (strlen($arResult['CURRENT_LANGUAGE']) == 2) ? $arResult['CURRENT_LANGUAGE'] : '' ?>">
                <?php
                if ($translateEnabled) {
                    ?>
                    <div class="btn-translations-wrap text-right">
                        <div class="btn btn-green btn-translations btn-sm translateAll"
                             data-type="components"
                             style="display: none">
                            <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                 alt="">
                            <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_ALL') ?>
                        </div>
                    </div>
                    <?php
                }
                ?>
                <?php
                $i = 0;
                $MESS = [];
                foreach ($arResult['COMPONENTS'] as $k => $v) {
                    ?>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><h3><?= $k ?></h3></div>
                    </div>
                    <?php
                    if (File::isFileExists(Path::normalize($docRoot . '/' . $arResult['DIR'] . '/components/' . DBOARD . '/' . $k . '/lang/ru/class.php'))) {
                        include Path::normalize($docRoot . '/' . $arResult['DIR'] . '/components/' . DBOARD . '/' . $k . '/lang/ru/class.php');

                        $ru = $MESS;
                        $translate = [];
                        unset($MESS);

                        if (File::isFileExists(Path::normalize($docRoot . '/' . $arResult['DIR'] . '/components/' . DBOARD . '/' . $k . '/lang/' . $arResult['CURRENT_LANGUAGE'] . '/class.php'))) {
                            include Path::normalize($docRoot . '/' . $arResult['DIR'] . '/components/' . DBOARD . '/' . $k . '/lang/' . $arResult['CURRENT_LANGUAGE'] . '/class.php');

                            $translate = $MESS;
                            unset($MESS);
                        }

                        foreach ($ru as $messageKey => $messageValue) {
                            ?>
                            <div class="row">
                                <div class="col-sm-6 col-xxs-12">
                                    <div class="form-group">
                                        <?= ++$i ?>.
                                        <span class="componentsOriginal"
                                              data-id="<?= md5('components[' . $k . '][class.php][' . $messageKey . ']') ?>"
                                              data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                                <?= $messageValue ?>
                                                            </span>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-xxs-12">
                                    <div class="form-group">
                                        <label for="inp-id1">
                                            <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_LBL') ?>
                                        </label>
                                        <div class="input-translate">
                                            <input type="text"
                                                   id="<?= md5('components[' . $k . '][class.php][' . $messageKey . ']') ?>"
                                                   name="components[<?= $k ?>][class.php][<?= $messageKey ?>]"
                                                   placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                                   class="form-control"
                                                   value='<?= (isset($translate[$messageKey])) ? $translate[$messageKey] : $messageValue ?>'>
                                            <?php
                                            if ($translateEnabled) {
                                                ?>
                                                <div class="translate"
                                                     data-tooltip=""
                                                     data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                     data-id="<?= md5('components[' . $k . '][class.php][' . $messageKey . ']') ?>"
                                                     data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                     data-phrase="<?= strip_tags($messageValue) ?>">
                                                    <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                         alt="">
                                                </div>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                    }

                    if ($handle = opendir(Path::normalize($docRoot . '/' . $arResult['DIR'] . '/components/' . DBOARD . '/' . $k . '/templates'))) {
                        while ($entry = readdir($handle)) {
                            if ($entry != "." && $entry != "..") {
                                //template.php
                                if (File::isFileExists(Path::normalize($docRoot . '/' . $arResult['DIR'] . '/components/' . DBOARD . '/' . $k . '/templates/' . $entry . '/lang/ru/template.php'))) {
                                    $inc = include Path::normalize($docRoot . '/' . $arResult['DIR'] . '/components/' . DBOARD . '/' . $k . '/templates/' . $entry . '/lang/ru/template.php');

                                    $ru = $MESS;
                                    $translate = [];
                                    unset($MESS);

                                    if (File::isFileExists(Path::normalize($docRoot . '/' . $arResult['DIR'] . '/components/' . DBOARD . '/' . $k . '/templates/' . $entry . '/lang/' . $arResult['CURRENT_LANGUAGE'] . '/template.php'))) {
                                        include Path::normalize($docRoot . '/' . $arResult['DIR'] . '/components/' . DBOARD . '/' . $k . '/templates/' . $entry . '/lang/' . $arResult['CURRENT_LANGUAGE'] . '/template.php');

                                        $translate = $MESS;
                                        unset($MESS);
                                    }

                                    foreach ($ru as $messageKey => $messageValue) {
                                        ?>
                                        <div class="row">
                                            <div class="col-sm-6 col-xxs-12">
                                                <div class="form-group">
                                                    <?= ++$i ?>.
                                                    <span class="componentsOriginal"
                                                          data-id="<?= md5('components[' . $k . '][' . $entry . '][template.php][' . $messageKey . ']') ?>"
                                                          data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                                            <?= $messageValue ?>
                                                                        </span>
                                                </div>
                                            </div>
                                            <div class="col-sm-6 col-xxs-12">
                                                <div class="form-group">
                                                    <label for="inp-id1">
                                                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_LBL') ?>
                                                    </label>
                                                    <div class="input-translate">
                                                        <input type="text"
                                                               id="<?= md5('components[' . $k . '][' . $entry . '][template.php][' . $messageKey . ']') ?>"
                                                               name="components[<?= $k ?>][<?= $entry ?>][template.php][<?= $messageKey ?>]"
                                                               placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                                               class="form-control"
                                                               value='<?= (isset($translate[$messageKey])) ? $translate[$messageKey] : $messageValue ?>'>
                                                        <?php
                                                        if ($translateEnabled) {
                                                            ?>
                                                            <div class="translate"
                                                                 data-tooltip=""
                                                                 data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                                 data-id="<?= md5('components[' . $k . '][' . $entry . '][template.php][' . $messageKey . ']') ?>"
                                                                 data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                                 data-phrase="<?= strip_tags($messageValue) ?>">
                                                                <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                                     alt="">
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                }

                                //component_epilog.php
                                if (File::isFileExists(Path::normalize($docRoot . '/' . $arResult['DIR'] . '/components/' . DBOARD . '/' . $k . '/templates/' . $entry . '/lang/ru/component_epilog.php'))) {
                                    $inc = include Path::normalize($docRoot . '/' . $arResult['DIR'] . '/components/' . DBOARD . '/' . $k . '/templates/' . $entry . '/lang/ru/component_epilog.php');

                                    $ru = $MESS;
                                    $translate = [];
                                    unset($MESS);

                                    if (File::isFileExists(Path::normalize($docRoot . '/' . $arResult['DIR'] . '/components/' . DBOARD . '/' . $k . '/templates/' . $entry . '/lang/' . $arResult['CURRENT_LANGUAGE'] . '/component_epilog.php'))) {
                                        include Path::normalize($docRoot . '/' . $arResult['DIR'] . '/components/' . DBOARD . '/' . $k . '/templates/' . $entry . '/lang/' . $arResult['CURRENT_LANGUAGE'] . '/component_epilog.php');

                                        $translate = $MESS;
                                        unset($MESS);
                                    }

                                    foreach ($ru as $messageKey => $messageValue) {
                                        ?>
                                        <div class="row">
                                            <div class="col-sm-6 col-xxs-12">
                                                <div class="form-group">
                                                    <?= ++$i ?>.
                                                    <span class="componentsOriginal"
                                                          data-id="<?= md5('components[' . $k . '][' . $entry . '][component_epilog.php][' . $messageKey . ']') ?>"
                                                          data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                                            <?= $messageValue ?>
                                                                        </span>
                                                </div>
                                            </div>
                                            <div class="col-sm-6 col-xxs-12">
                                                <div class="form-group">
                                                    <label for="inp-id1">
                                                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_LBL') ?>
                                                    </label>
                                                    <div class="input-translate">
                                                        <input type="text"
                                                               id="<?= md5('components[' . $k . '][' . $entry . '][component_epilog.php][' . $messageKey . ']') ?>"
                                                               name="components[<?= $k ?>][<?= $entry ?>][component_epilog.php][<?= $messageKey ?>]"
                                                               placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                                               class="form-control"
                                                               value='<?= (isset($translate[$messageKey])) ? $translate[$messageKey] : $messageValue ?>'>
                                                        <?php
                                                        if ($translateEnabled) {
                                                            ?>
                                                            <div class="translate"
                                                                 data-tooltip=""
                                                                 data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                                 data-id="<?= md5('components[' . $k . '][' . $entry . '][component_epilog.php][' . $messageKey . ']') ?>"
                                                                 data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                                 data-phrase="<?= strip_tags($messageValue) ?>">
                                                                <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                                     alt="">
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                }
                            }
                        }
                        closedir($handle);
                    }

                    ?>
                    <div class="seporate"></div>
                    <?php
                }
                ?>
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <button type="submit" class="apply _mt">
                            <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_SAVE') ?>
                        </button>
                    </div>
                </div>
            </form>
            <?php
        }
        ?>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:user.menu',
            ''
        );
        ?>
    </div>

    <div class="main-column">
        <div class="row">
            <div class="col-md-8 col-lg-9">
                <div class="white-block">
                    <?php
                    if ($arResult['CURRENT_LANGUAGE']) {
                        ?>
                        <div class="tabs-wrap translations-tabs">
                            <div class="tab" id="translation-tab2">
                                <form action="<?= SITE_DIR ?>user/translations/" method="post">
                                    <input type="hidden" name="currentLanguage"
                                           value="<?= (strlen($arResult['CURRENT_LANGUAGE']) == 2) ? $arResult['CURRENT_LANGUAGE'] : '' ?>">
                                    <?php
                                    if ($translateEnabled) {
                                        ?>
                                        <div class="btn-translations-wrap text-right">
                                            <div class="btn btn-green btn-translations btn-sm translateAll"
                                                 data-type="types"
                                                 style="display: none">
                                                <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                     alt="">
                                                <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_ALL') ?>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                    <?php
                                    $i = 0;
                                    foreach ($arResult['IBLOCK_TYPES'] as $typeKey => $typeValue) {
                                        ?>
                                        <h4 class="text-center">
                                            <?= $typeValue['name'] ?>
                                            (<?= $typeKey ?>)
                                        </h4>
                                        <div class="row">
                                            <div class="col-sm-6 col-xxs-12">
                                                <div class="form-group bold">
                                                    <?= ++$i ?>.
                                                    <a href="/' . $arResult['DIR'] . '/admin/iblock_type_edit.php?lang=ru&ID=<?= $typeKey ?>"
                                                       target="_blank">
                                                        <span class="typesOriginal"
                                                              data-id="<?= md5('iBlockTypes[' . $typeKey . ']') ?>"
                                                              data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                            <?= $typeValue['name'] ?>
                                                        </span>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-sm-6 col-xxs-12">
                                                <div class="form-group">
                                                    <div class="input-translate">
                                                        <input type="text"
                                                               placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                                               class="form-control"
                                                               id="<?= md5('iBlockTypes[' . $typeKey . ']') ?>"
                                                               name="iBlockTypes[<?= $typeKey ?>]"
                                                               value="<?= (isset($arResult['TRANSLATE']['IBLOCK_TYPES'][$typeKey])) ? $arResult['TRANSLATE']['IBLOCK_TYPES'][$typeKey] : $typeValue['name'] ?>">
                                                        <?php
                                                        if ($translateEnabled) {
                                                            ?>
                                                            <div class="translate"
                                                                 data-tooltip=""
                                                                 data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                                 data-id="<?= md5('iBlockTypes[' . $typeKey . ']') ?>"
                                                                 data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                                 data-phrase="<?= strip_tags($typeValue['name']) ?>">
                                                                <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                                     alt="">
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        foreach ($typeValue['iblocks'] as $iblock) {
                                            ?>
                                            <div class="row">
                                                <div class="col-sm-6 col-xxs-12">
                                                    <div class="form-group">
                                                        <?= ++$i ?>.
                                                        <a href="/' . $arResult['DIR'] . '/admin/iblock_edit.php?type=<?= $typeKey ?>&lang=ru&ID=<?= $iblock['id'] ?>&admin=Y"
                                                           target="_blank">
                                                            <span class="typesOriginal"
                                                                  data-id="<?= md5('iblocks[' . $iblock['id'] . ']') ?>"
                                                                  data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                                <?= $iblock['name'] ?>
                                                            </span>
                                                        </a>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-xxs-12">
                                                    <div class="form-group">
                                                        <div class="input-translate">
                                                            <input type="text"
                                                                   placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                                                   class="form-control"
                                                                   id="<?= md5('iblocks[' . $iblock['id'] . ']') ?>"
                                                                   name="iblocks[<?= $iblock['id'] ?>]"
                                                                   value="<?= (isset($arResult['TRANSLATE']['IBLOCKS'][$iblock['id']])) ? $arResult['TRANSLATE']['IBLOCKS'][$iblock['id']] : $iblock['name'] ?>">
                                                            <?php
                                                            if ($translateEnabled) {
                                                                ?>
                                                                <div class="translate"
                                                                     data-tooltip=""
                                                                     data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                                     data-id="<?= md5('iblocks[' . $iblock['id'] . ']') ?>"
                                                                     data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                                     data-phrase="<?= strip_tags($iblock['name']) ?>">
                                                                    <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                                         alt="">
                                                                </div>
                                                                <?php
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <?php
                                            if (isset($arResult['IBLOCK_PROPERTIES'][$iblock['id']])) {
                                                foreach ($arResult['IBLOCK_PROPERTIES'][$iblock['id']] as $property) {
                                                    switch ($property['type']) {
                                                        case 'list':
                                                            ?>
                                                            <div class="row">
                                                                <div class="col-sm-6 col-xxs-12">
                                                                    <div class="form-group">
                                                                        <?= ++$i ?>.
                                                                        <span class="typesOriginal"
                                                                              data-id="<?= md5('propertyNames[' . $iblock['id'] . '][' . $property['id'] . ']') ?>"
                                                                              data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                                            <?= $property['name'] ?>
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-6 col-xxs-12">
                                                                    <div class="form-group">
                                                                        <div class="input-translate">
                                                                            <input type="text"
                                                                                   placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                                                                   class="form-control"
                                                                                   id="<?= md5('propertyNames[' . $iblock['id'] . '][' . $property['id'] . ']') ?>"
                                                                                   name="propertyNames[<?= $iblock['id'] ?>][<?= $property['id'] ?>]"
                                                                                   value="<?= (isset($arResult['TRANSLATE']['IBLOCK_PROPERTIES'][$property['id']])) ? $arResult['TRANSLATE']['IBLOCK_PROPERTIES'][$property['id']] : $property['name'] ?>">
                                                                            <?php
                                                                            if ($translateEnabled) {
                                                                                ?>
                                                                                <div class="translate"
                                                                                     data-tooltip=""
                                                                                     data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                                                     data-id="<?= md5('propertyNames[' . $iblock['id'] . '][' . $property['id'] . ']') ?>"
                                                                                     data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                                                     data-phrase="<?= strip_tags($property['name']) ?>">
                                                                                    <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                                                         alt="">
                                                                                </div>
                                                                                <?php
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <?php
                                                            foreach ($property['values'] as $variant) {
                                                                ?>
                                                                <div class="row">
                                                                    <div class="col-sm-6 col-xxs-12">
                                                                        <div class="form-group">
                                                                            <?= ++$i ?>.
                                                                            <span class="typesOriginal"
                                                                                  data-id="<?= md5('propertyValues[' . $iblock['id'] . '][' . $property['id'] . '][' . $variant['id'] . ']') ?>"
                                                                                  data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                                                <?= $variant['name'] ?>
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-6 col-xxs-12">
                                                                        <div class="form-group">
                                                                            <div class="input-translate">
                                                                                <input type="text"
                                                                                       placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                                                                       class="form-control"
                                                                                       id="<?= md5('propertyValues[' . $iblock['id'] . '][' . $property['id'] . '][' . $variant['id'] . ']') ?>"
                                                                                       name="propertyValues[<?= $iblock['id'] ?>][<?= $property['id'] ?>][<?= $variant['id'] ?>]"
                                                                                       value="<?= (isset($arResult['TRANSLATE']['IBLOCK_PROPERTY_VALUES'][$iblock['id']][$variant['id']])) ? $arResult['TRANSLATE']['IBLOCK_PROPERTY_VALUES'][$iblock['id']][$variant['id']] : $variant['name'] ?>">
                                                                                <?php
                                                                                if ($translateEnabled) {
                                                                                    ?>
                                                                                    <div class="translate"
                                                                                         data-tooltip=""
                                                                                         data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                                                         data-id="<?= md5('propertyValues[' . $iblock['id'] . '][' . $property['id'] . '][' . $variant['id'] . ']') ?>"
                                                                                         data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                                                         data-phrase="<?= strip_tags($variant['name']) ?>">
                                                                                        <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                                                             alt="">
                                                                                    </div>
                                                                                    <?php
                                                                                }
                                                                                ?>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <?php
                                                            }
                                                            break;
                                                        default:
                                                            ?>
                                                            <div class="row">
                                                                <div class="col-sm-6 col-xxs-12">
                                                                    <div class="form-group">
                                                                        <?= ++$i ?>.
                                                                        <span class="typesOriginal"
                                                                              data-id="<?= md5('propertyNames[' . $iblock['id'] . '][' . $property['id'] . ']') ?>"
                                                                              data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                                            <?= $property['name'] ?>
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-6 col-xxs-12">
                                                                    <div class="form-group">
                                                                        <div class="input-translate">
                                                                            <input type="text"
                                                                                   placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                                                                   class="form-control"
                                                                                   id="<?= md5('propertyNames[' . $iblock['id'] . '][' . $property['id'] . ']') ?>"
                                                                                   name="propertyNames[<?= $iblock['id'] ?>][<?= $property['id'] ?>]"
                                                                                   value="<?= (isset($arResult['TRANSLATE']['IBLOCK_PROPERTIES'][$property['id']])) ? $arResult['TRANSLATE']['IBLOCK_PROPERTIES'][$property['id']] : $property['name'] ?>">
                                                                            <?php
                                                                            if ($translateEnabled) {
                                                                                ?>
                                                                                <div class="translate"
                                                                                     data-tooltip=""
                                                                                     data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                                                     data-id="<?= md5('propertyNames[' . $iblock['id'] . '][' . $property['id'] . ']') ?>"
                                                                                     data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                                                     data-phrase="<?= strip_tags($property['name']) ?>">
                                                                                    <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                                                         alt="">
                                                                                </div>
                                                                                <?php
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php
                                                    }
                                                }
                                            }
                                            ?>
                                            <?php
                                        }
                                        ?>
                                        <div class="seporate"></div>
                                        <?php
                                    }
                                    ?>
                                    <div class="text-right">
                                        <button type="submit" class="btn btn-green">
                                            <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_SAVE') ?>
                                        </button>
                                    </div>
                                </form>
                            </div>
                            <div class="tab" id="translation-tab3">
                                <form action="<?= SITE_DIR ?>user/translations/" method="post">
                                    <input type="hidden" name="currentLanguage"
                                           value="<?= (strlen($arResult['CURRENT_LANGUAGE']) == 2) ? $arResult['CURRENT_LANGUAGE'] : '' ?>">
                                    <?php
                                    if ($translateEnabled) {
                                        ?>
                                        <div class="btn-translations-wrap text-right">
                                            <div class="btn btn-green btn-translations btn-sm translateAll"
                                                 data-type="sections"
                                                 style="display: none">
                                                <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                     alt="">
                                                <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_ALL') ?>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                    <?php
                                    $i = 0;
                                    foreach ($arResult['SECTIONS'] as $iblockId => $section) {
                                        foreach ($section as $sect) {
                                            ?>
                                            <div class="row">
                                                <div class="col-sm-6 col-xxs-12">
                                                    <div class="form-group">
                                                        <?= ++$i ?>.
                                                        <span class="sectionsOriginal"
                                                              data-id="<?= md5('sections[' . $iblockId . '][' . $sect['ID'] . ']') ?>"
                                                              data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                            <?= $sect['NAME'] ?>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-xxs-12">
                                                    <div class="form-group">
                                                        <div class="input-translate">
                                                            <input type="text"
                                                                   placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                                                   class="form-control"
                                                                   id="<?= md5('sections[' . $iblockId . '][' . $sect['ID'] . ']') ?>"
                                                                   name="sections[<?= $iblockId ?>][<?= $sect['ID'] ?>]"
                                                                   value="<?= (isset($arResult['TRANSLATE']['SECTIONS'][$sect['ID']])) ? $arResult['TRANSLATE']['SECTIONS'][$sect['ID']] : $sect['NAME'] ?>">
                                                            <?php
                                                            if ($translateEnabled) {
                                                                ?>
                                                                <div class="translate"
                                                                     data-tooltip=""
                                                                     data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                                     data-id="<?= md5('sections[' . $iblockId . '][' . $sect['ID'] . ']') ?>"
                                                                     data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                                     data-phrase="<?= strip_tags($sect['NAME']) ?>">
                                                                    <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                                         alt="">
                                                                </div>
                                                                <?php
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                    }
                                    ?>
                                    <div class="text-right">
                                        <button type="submit" class="btn btn-green">
                                            <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_SAVE') ?>
                                        </button>
                                    </div>
                                </form>
                            </div>
                            <div class="tab" id="translation-tab4">
                                <form action="<?= SITE_DIR ?>user/translations/" method="post">
                                    <input type="hidden" name="currentLanguage"
                                           value="<?= (strlen($arResult['CURRENT_LANGUAGE']) == 2) ? $arResult['CURRENT_LANGUAGE'] : '' ?>">
                                    <?php
                                    if ($translateEnabled) {
                                        ?>
                                        <div class="btn-translations-wrap text-right">
                                            <div class="btn btn-green btn-translations btn-sm translateAll"
                                                 data-type="iBlockMeta"
                                                 style="display: none">
                                                <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                     alt="">
                                                <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_ALL') ?>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                    <?php
                                    $i = 0;
                                    foreach ($arResult['IBLOCK_TYPES'] as $typeKey => $typeValue) {
                                        ?>
                                        <h4 class="text-center">
                                            <?= $typeValue['name'] ?>
                                            (<?= $typeKey ?>)
                                        </h4>
                                        <div class="row">
                                            <div class="col-sm-6 col-xxs-12">
                                                <div class="form-group">
                                                    <?= ++$i ?>.
                                                    <a href="/' . $arResult['DIR'] . '/admin/iblock_type_edit.php?lang=ru&ID=<?= $typeKey ?>"
                                                       target="_blank">
                                                        <span class="iBlockMetaOriginal"
                                                              data-id="<?= md5('iBlockTypesMeta[' . $typeKey . '][h1]') ?>"
                                                              data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                            <?= $typeValue['name'] ?>
                                                        </span>
                                                        (H1)
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-sm-6 col-xxs-12">
                                                <div class="form-group">
                                                    <div class="input-translate">
                                                        <input type="text"
                                                               placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                                               class="form-control"
                                                               id="<?= md5('iBlockTypesMeta[' . $typeKey . '][h1]') ?>"
                                                               name="iBlockTypesMeta[<?= $typeKey ?>][h1]"
                                                               value="<?= (isset($arResult['TRANSLATE']['IBLOCK_TYPES_META'][$typeKey]['UF_H1'])) ? $arResult['TRANSLATE']['IBLOCK_TYPES_META'][$typeKey]['UF_H1'] : $arResult['IBLOCK_TYPES_META'][$typeKey]['UF_H1'] ?>">
                                                        <?php
                                                        if ($translateEnabled) {
                                                            ?>
                                                            <div class="translate"
                                                                 data-tooltip=""
                                                                 data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                                 data-id="<?= md5('iBlockTypesMeta[' . $typeKey . '][h1]') ?>"
                                                                 data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                                 data-phrase="<?= strip_tags($typeValue['name']) ?>">
                                                                <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                                     alt="">
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-6 col-xxs-12">
                                                <div class="form-group">
                                                    <?= ++$i ?>.
                                                    <a href="/' . $arResult['DIR'] . '/admin/iblock_type_edit.php?lang=ru&ID=<?= $typeKey ?>"
                                                       target="_blank">
                                                        <span class="iBlockMetaOriginal"
                                                              data-id="<?= md5('iBlockTypesMeta[' . $typeKey . '][title]') ?>"
                                                              data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                            <?= $typeValue['name'] ?>
                                                        </span>
                                                        (TITLE)
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-sm-6 col-xxs-12">
                                                <div class="form-group">
                                                    <div class="input-translate">
                                                        <input type="text"
                                                               placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                                               class="form-control"
                                                               id="<?= md5('iBlockTypesMeta[' . $typeKey . '][title]') ?>"
                                                               name="iBlockTypesMeta[<?= $typeKey ?>][title]"
                                                               value="<?= (isset($arResult['TRANSLATE']['IBLOCK_TYPES_META'][$typeKey]['UF_TITLE'])) ? $arResult['TRANSLATE']['IBLOCK_TYPES_META'][$typeKey]['UF_TITLE'] : $arResult['IBLOCK_TYPES_META'][$typeKey]['UF_TITLE'] ?>">
                                                        <?php
                                                        if ($translateEnabled) {
                                                            ?>
                                                            <div class="translate"
                                                                 data-tooltip=""
                                                                 data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                                 data-id="<?= md5('iBlockTypesMeta[' . $typeKey . '][title]') ?>"
                                                                 data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                                 data-phrase="<?= strip_tags($typeValue['name']) ?>">
                                                                <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                                     alt="">
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-6 col-xxs-12">
                                                <div class="form-group">
                                                    <?= ++$i ?>.
                                                    <a href="/' . $arResult['DIR'] . '/admin/iblock_type_edit.php?lang=ru&ID=<?= $typeKey ?>"
                                                       target="_blank">
                                                        <span class="iBlockMetaOriginal"
                                                              data-id="<?= md5('iBlockTypesMeta[' . $typeKey . '][breadcrumb]') ?>"
                                                              data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                            <?= $typeValue['name'] ?>
                                                        </span>
                                                        (BREADCRUMB)
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-sm-6 col-xxs-12">
                                                <div class="form-group">
                                                    <div class="input-translate">
                                                        <input type="text"
                                                               placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                                               class="form-control"
                                                               id="<?= md5('iBlockTypesMeta[' . $typeKey . '][breadcrumb]') ?>"
                                                               name="iBlockTypesMeta[<?= $typeKey ?>][breadcrumb]"
                                                               value="<?= (isset($arResult['TRANSLATE']['IBLOCK_TYPES_META'][$typeKey]['UF_BREADCRUMB'])) ? $arResult['TRANSLATE']['IBLOCK_TYPES_META'][$typeKey]['UF_BREADCRUMB'] : $arResult['IBLOCK_TYPES_META'][$typeKey]['UF_BREADCRUMB'] ?>">
                                                        <?php
                                                        if ($translateEnabled) {
                                                            ?>
                                                            <div class="translate"
                                                                 data-tooltip=""
                                                                 data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                                 data-id="<?= md5('iBlockTypesMeta[' . $typeKey . '][breadcrumb]') ?>"
                                                                 data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                                 data-phrase="<?= strip_tags($typeValue['name']) ?>">
                                                                <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                                     alt="">
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        foreach ($typeValue['iblocks'] as $iblock) {
                                            ?>
                                            <div class="row">
                                                <div class="col-sm-6 col-xxs-12">
                                                    <div class="form-group">
                                                        <?= ++$i ?>.
                                                        <a href="/' . $arResult['DIR'] . '/admin/iblock_edit.php?type=<?= $typeKey ?>&lang=ru&ID=<?= $iblock['id'] ?>&admin=Y"
                                                           target="_blank">
                                                            <span class="iBlockMetaOriginal"
                                                                  data-id="<?= md5('iBlockIdMeta[' . $iblock['id'] . '][h1]') ?>"
                                                                  data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                                <?= $iblock['name'] ?>
                                                            </span>,ID: <?= $iblock['id'] ?> (H1)
                                                        </a>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-xxs-12">
                                                    <div class="form-group">
                                                        <div class="input-translate">
                                                            <input type="text"
                                                                   placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                                                   class="form-control"
                                                                   id="<?= md5('iBlockIdMeta[' . $iblock['id'] . '][h1]') ?>"
                                                                   name="iBlockIdMeta[<?= $iblock['id'] ?>][h1]"
                                                                   value="<?= (isset($arResult['TRANSLATE']['IBLOCK_ID_META'][$iblock['id']]['UF_H1'])) ? $arResult['TRANSLATE']['IBLOCK_ID_META'][$iblock['id']]['UF_H1'] : $arResult['IBLOCK_ID_META'][$iblock['id']]['UF_H1'] ?>">
                                                            <?php
                                                            if ($translateEnabled) {
                                                                ?>
                                                                <div class="translate"
                                                                     data-tooltip=""
                                                                     data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                                     data-id="<?= md5('iBlockIdMeta[' . $iblock['id'] . '][h1]') ?>"
                                                                     data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                                     data-phrase="<?= strip_tags($iblock['name']) ?>">
                                                                    <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                                         alt="">
                                                                </div>
                                                                <?php
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-sm-6 col-xxs-12">
                                                    <div class="form-group">
                                                        <?= ++$i ?>.
                                                        <a href="/' . $arResult['DIR'] . '/admin/iblock_edit.php?type=<?= $typeKey ?>&lang=ru&ID=<?= $iblock['id'] ?>&admin=Y"
                                                           target="_blank">
                                                            <span class="iBlockMetaOriginal"
                                                                  data-id="<?= md5('iBlockIdMeta[' . $iblock['id'] . '][title]') ?>"
                                                                  data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                                <?= $iblock['name'] ?>
                                                            </span>,ID: <?= $iblock['id'] ?> (TITLE)
                                                        </a>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-xxs-12">
                                                    <div class="form-group">
                                                        <div class="input-translate">
                                                            <input type="text"
                                                                   placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                                                   class="form-control"
                                                                   id="<?= md5('iBlockIdMeta[' . $iblock['id'] . '][title]') ?>"
                                                                   name="iBlockIdMeta[<?= $iblock['id'] ?>][title]"
                                                                   value="<?= (isset($arResult['TRANSLATE']['IBLOCK_ID_META'][$iblock['id']]['UF_TITLE'])) ? $arResult['TRANSLATE']['IBLOCK_ID_META'][$iblock['id']]['UF_TITLE'] : $arResult['IBLOCK_ID_META'][$iblock['id']]['UF_TITLE'] ?>">
                                                            <?php
                                                            if ($translateEnabled) {
                                                                ?>
                                                                <div class="translate"
                                                                     data-tooltip=""
                                                                     data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                                     data-id="<?= md5('iBlockIdMeta[' . $iblock['id'] . '][title]') ?>"
                                                                     data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                                     data-phrase="<?= strip_tags($iblock['name']) ?>">
                                                                    <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                                         alt="">
                                                                </div>
                                                                <?php
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-sm-6 col-xxs-12">
                                                    <div class="form-group">
                                                        <?= ++$i ?>.
                                                        <a href="/' . $arResult['DIR'] . '/admin/iblock_edit.php?type=<?= $typeKey ?>&lang=ru&ID=<?= $iblock['id'] ?>&admin=Y"
                                                           target="_blank">
                                                            <span class="iBlockMetaOriginal"
                                                                  data-id="<?= md5('iBlockIdMeta[' . $iblock['id'] . '][breadcrumb]') ?>"
                                                                  data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                                <?= $iblock['name'] ?>
                                                            </span>,ID: <?= $iblock['id'] ?> (BREADCRUMB)
                                                        </a>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-xxs-12">
                                                    <div class="form-group">
                                                        <div class="input-translate">
                                                            <input type="text"
                                                                   placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                                                   class="form-control"
                                                                   id="<?= md5('iBlockIdMeta[' . $iblock['id'] . '][breadcrumb]') ?>"
                                                                   name="iBlockIdMeta[<?= $iblock['id'] ?>][breadcrumb]"
                                                                   value="<?= (isset($arResult['TRANSLATE']['IBLOCK_ID_META'][$iblock['id']]['UF_BREADCRUMB'])) ? $arResult['TRANSLATE']['IBLOCK_ID_META'][$iblock['id']]['UF_BREADCRUMB'] : $arResult['IBLOCK_ID_META'][$iblock['id']]['UF_BREADCRUMB'] ?>">
                                                            <?php
                                                            if ($translateEnabled) {
                                                                ?>
                                                                <div class="translate"
                                                                     data-tooltip=""
                                                                     data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                                     data-id="<?= md5('iBlockIdMeta[' . $iblock['id'] . '][breadcrumb]') ?>"
                                                                     data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                                     data-phrase="<?= strip_tags($iblock['name']) ?>">
                                                                    <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                                         alt="">
                                                                </div>
                                                                <?php
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                        <div class="seporate"></div>
                                        <?php
                                    }
                                    ?>
                                    <div class="text-right">
                                        <button type="submit" class="btn btn-green">
                                            <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_SAVE') ?>
                                        </button>
                                    </div>
                                </form>
                            </div>
                            <div class="tab" id="translation-tab5">
                                <form action="<?= SITE_DIR ?>user/translations/" method="post">
                                    <input type="hidden" name="currentLanguage"
                                           value="<?= (strlen($arResult['CURRENT_LANGUAGE']) == 2) ? $arResult['CURRENT_LANGUAGE'] : '' ?>">
                                    <?php
                                    if ($translateEnabled) {
                                        ?>
                                        <div class="btn-translations-wrap text-right">
                                            <div class="btn btn-green btn-translations btn-sm translateAll"
                                                 data-type="regions"
                                                 style="display: none">
                                                <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                     alt="">
                                                <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_ALL') ?>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                    <?php
                                    $i = 0;
                                    foreach ($arResult['REGIONS'] as $region) {
                                        ?>
                                        <div class="row">
                                            <div class="col-sm-6 col-xxs-12">
                                                <div class="form-group">
                                                    <?= ++$i ?>.
                                                    <span class="regionsOriginal"
                                                          data-id="<?= md5('regions[' . $region['ID'] . ']') ?>"
                                                          data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                            <?= $region['NAME'] ?>
                                                        </span>
                                                </div>
                                            </div>
                                            <div class="col-sm-6 col-xxs-12">
                                                <div class="form-group">
                                                    <div class="input-translate">
                                                        <input type="text"
                                                               placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                                               class="form-control"
                                                               id="<?= md5('regions[' . $region['ID'] . ']') ?>"
                                                               name="regions[<?= $region['ID'] ?>]"
                                                               value="<?= (isset($arResult['TRANSLATE']['REGIONS'][$region['ID']])) ? $arResult['TRANSLATE']['REGIONS'][$region['ID']] : $region['NAME'] ?>">
                                                        <?php
                                                        if ($translateEnabled) {
                                                            ?>
                                                            <div class="translate"
                                                                 data-tooltip=""
                                                                 data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                                 data-id="<?= md5('regions[' . $region['ID'] . ']') ?>"
                                                                 data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                                 data-phrase="<?= strip_tags($region['NAME']) ?>">
                                                                <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                                     alt="">
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                    <div class="text-right">
                                        <button type="submit" class="btn btn-green">
                                            <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_SAVE') ?>
                                        </button>
                                    </div>
                                </form>
                            </div>
                            <div class="tab" id="translation-tab6">
                                <form action="<?= SITE_DIR ?>user/translations/" method="post">
                                    <input type="hidden" name="currentLanguage"
                                           value="<?= (strlen($arResult['CURRENT_LANGUAGE']) == 2) ? $arResult['CURRENT_LANGUAGE'] : '' ?>">
                                    <?php
                                    if ($translateEnabled) {
                                        ?>
                                        <div class="btn-translations-wrap text-right">
                                            <div class="btn btn-green btn-translations btn-sm translateAll"
                                                 data-type="cities"
                                                 style="display: none">
                                                <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                     alt="">
                                                <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_ALL') ?>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                    <?php
                                    $i = 0;
                                    foreach ($arResult['CITIES'] as $item) {
                                        ?>
                                        <div class="row">
                                            <div class="col-sm-6 col-xxs-12">
                                                <div class="form-group">
                                                    <?= ++$i ?>.
                                                    <span class="citiesOriginal"
                                                          data-id="<?= md5('cities[' . $item['id'] . ']') ?>"
                                                          data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                            <?= $item['name'] ?>
                                                        </span>
                                                </div>
                                            </div>
                                            <div class="col-sm-6 col-xxs-12">
                                                <div class="form-group">
                                                    <div class="input-translate">
                                                        <input type="text"
                                                               placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                                               class="form-control"
                                                               id="<?= md5('cities[' . $item['id'] . ']') ?>"
                                                               name="cities[<?= $item['id'] ?>]"
                                                               value="<?= (isset($arResult['TRANSLATE']['CITIES'][$item['id']])) ? $arResult['TRANSLATE']['CITIES'][$item['id']] : $item['name'] ?>">
                                                        <?php
                                                        if ($translateEnabled) {
                                                            ?>
                                                            <div class="translate"
                                                                 data-tooltip=""
                                                                 data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                                 data-id="<?= md5('cities[' . $item['id'] . ']') ?>"
                                                                 data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                                 data-phrase="<?= strip_tags($item['name']) ?>">
                                                                <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                                     alt="">
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                    <div class="text-right">
                                        <button type="submit" class="btn btn-green">
                                            <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_SAVE') ?>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
    <script>
        BX.message({translatePath: '<?=$this->GetFolder()?>'});
    </script>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}