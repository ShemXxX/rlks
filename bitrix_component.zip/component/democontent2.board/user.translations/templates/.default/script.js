$(document).ready(function () {
    $('.translateAll').show();
    $('.translate').click(function () {
        let $this = this;
        $.ajax({
            type: 'POST',
            url: BX.message('translatePath') + "/ajax.php",
            dataType: "json",
            data: 'lang=' + $($this).data('lang') + '&phrase=' + encodeURI($($this).data('phrase')),
            success: function (data) {
                if (!data.error) {
                    $('#' + $($this).data('id')).val(data.result);
                }
            },
            error: function (data) {
            }
        });
    });

    $('.translateAll').click(function () {
        let $translateAll = this;
        let $type = $($translateAll).data('type');
        $('.' + $type + 'Original').each(function () {
            let $t = this;
            $.ajax({
                type: 'POST',
                url: BX.message('translatePath') + "/ajax.php",
                dataType: "json",
                data: 'lang=' + $($t).data('lang') + '&phrase=' + encodeURI($($t).text()),
                success: function (data) {
                    if (!data.error) {
                        $('#' + $($t).data('id')).val(data.result);
                    }
                },
                error: function (data) {
                }
            });
        });
    });
});