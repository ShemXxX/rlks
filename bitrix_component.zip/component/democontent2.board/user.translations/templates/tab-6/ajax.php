<?php
/*
 * Date and Time: 17.11.2020, 9:36
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

use Bitrix\Main\Config\Option;
use Bitrix\Main\Context;
use Bitrix\Main\Engine\Response\Json;
use Bitrix\Main\Loader;

$request = Context::getCurrent()->getRequest();
$error = 1;
$result = '';

global $USER;

if ($request->isAjaxRequest() && $request->isPost() && $USER->IsAdmin()) {
    if (Loader::includeModule('democontent2.board')
        && strlen(Option::get('democontent2.board', 'google_translate_key'))) {
        if ($request->getPost('lang') && $request->getPost('phrase')) {
            $langCode = $request->getPost('lang');

            $lang = new \Democontent2\Board\Translate\Lang();
            $languages = $lang->getLanguages();

            if (isset($languages[$langCode])) {
                switch ($langCode) {
                    case 'kz':
                        $langCode = 'kk';
                        break;
                    case 'ua':
                        $langCode = 'uk';
                        break;
                }
                $tr = new \Democontent2\Board\Translate\Google();
                $tr->setQ($request->getPost('phrase'));
                $tr->setSource('ru');
                $tr->setTarget($langCode);
                $data = \Bitrix\Main\Web\Json::decode($tr->translate());

                if (isset($data['data']['translations'][0]['translatedText'])) {
                    $error = 0;

                    $re = '/# ([A-Z-_]+) #/m';
                    $str = $data['data']['translations'][0]['translatedText'];

                    preg_match_all($re, $str, $matches, PREG_SET_ORDER, 0);
                    foreach ($matches as $match) {
                        if (count($match) == 2) {
                            $data['data']['translations'][0]['translatedText'] = str_replace($match[0], '#' . $match[1] . '#', $data['data']['translations'][0]['translatedText']);
                        }
                    }

                    $result = \Democontent2\Board\Utils::cutQuotes($data['data']['translations'][0]['translatedText']);
                }
            }
        }
    }
}

$r = new Json([
    'error' => $error,
    'result' => $result
]);
$r->send();
