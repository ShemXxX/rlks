<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 03.10.2018
 * Time: 10:53
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Application;
use Bitrix\Main\IO\File;
use Bitrix\Main\IO\Path;

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}
$docRoot = Application::getDocumentRoot();
$translateEnabled = (strlen(Option::get(DBOARD, 'google_translate_key'))) ? true : false;
?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_H1') ?></h1>
        <div class="flags _mt">
            <?php
            foreach ($arResult['LANGUAGES'] as $language) {
                $active = '';
                if ($_REQUEST['lang'] == $language['UF_CODE']) {
                    $active = ' active';
                }
                ?>
                <a class="flag-icon flag-icon-<?= ($language['UF_CODE'] == 'en') ? 'gb' : $language['UF_CODE'] ?><?= $active ?>"
                   href="<?= SITE_DIR ?>user/translations/?lang=<?= $language['UF_CODE'] ?>"></a>
                <?php
            }
            ?>
        </div>
        <form action="<?= SITE_DIR ?>user/translations/" method="post"
              class="edit-form">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div>
                    <label for="languageCode">
                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_CODE_LBL') ?>
                    </label>
                    <input placeholder="en" type="text" maxlength="2" name="languageCode" id="languageCode"
                           class="required">
                </div>
                <div>
                    <label for="languageName">
                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_CODE_TTL_LBL') ?>
                    </label>
                    <input type="text" name="languageName" id="languageName" placeholder="English" class="required">
                </div>
                <div class="_mt">
                    <button class="apply" type="submit">
                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_CODE_ADD_BTN') ?>
                    </button>
                </div>
            </div>
        </form>

        <?php
        if ($arResult['CURRENT_LANGUAGE']) {
            ?>
            <div class="items-list__sort _mt">
                <div class="item">
                    <a href="<?= SITE_DIR ?>user/translations/?lang=<?= $_REQUEST['lang'] ?>">
                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TAB1_TTL') ?>
                    </a>
                </div>
                <div class="item">
                    <a href="<?= SITE_DIR ?>user/translations/?tab=2&lang=<?= $_REQUEST['lang'] ?>">
                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TAB2_TTL') ?>
                    </a>
                </div>
                <div class="item">
                    <a href="<?= SITE_DIR ?>user/translations/?tab=3&lang=<?= $_REQUEST['lang'] ?>">
                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TAB3_TTL') ?>
                    </a>
                </div>
                <div class="item active">
                    <a href="<?= SITE_DIR ?>user/translations/?tab=4&lang=<?= $_REQUEST['lang'] ?>">
                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TAB4_TTL') ?>
                    </a>
                </div>
                <div class="item">
                    <a href="<?= SITE_DIR ?>user/translations/?tab=5&lang=<?= $_REQUEST['lang'] ?>">
                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TAB5_TTL') ?>
                    </a>
                </div>
                <div class="item">
                    <a href="<?= SITE_DIR ?>user/translations/?tab=6&lang=<?= $_REQUEST['lang'] ?>">
                        <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TAB6_TTL') ?>
                    </a>
                </div>
            </div>
            <form action="<?= SITE_DIR ?>user/translations/" method="post" class="edit-form">
                <input type="hidden" name="currentLanguage"
                       value="<?= (strlen($arResult['CURRENT_LANGUAGE']) == 2) ? $arResult['CURRENT_LANGUAGE'] : '' ?>">
                <?php
                if ($translateEnabled) {
                    ?>
                    <div class="btn-translations-wrap text-right">
                        <div class="btn btn-green btn-translations btn-sm translateAll"
                             data-type="iBlockMeta"
                             style="display: none">
                            <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                 alt="">
                            <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_ALL') ?>
                        </div>
                    </div>
                    <?php
                }
                ?>
                <?php
                $i = 0;
                $MESS = [];
                foreach ($arResult['IBLOCK_TYPES'] as $typeKey => $typeValue) {
                    ?>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <h3>
                                <?= $typeValue['name'] ?>
                                (<?= $typeKey ?>)
                            </h3>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-xxs-12">
                            <div class="form-group">
                                <?= ++$i ?>.
                                <a href="/' . $arResult['DIR'] . '/admin/iblock_type_edit.php?lang=ru&ID=<?= $typeKey ?>"
                                   target="_blank">
                                                        <span class="iBlockMetaOriginal"
                                                              data-id="<?= md5('iBlockTypesMeta[' . $typeKey . '][h1]') ?>"
                                                              data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                            <?= $typeValue['name'] ?>
                                                        </span>
                                    (H1)
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xxs-12">
                            <div class="form-group">
                                <div class="input-translate">
                                    <input type="text"
                                           placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                           class="form-control"
                                           id="<?= md5('iBlockTypesMeta[' . $typeKey . '][h1]') ?>"
                                           name="iBlockTypesMeta[<?= $typeKey ?>][h1]"
                                           value="<?= (isset($arResult['TRANSLATE']['IBLOCK_TYPES_META'][$typeKey]['UF_H1'])) ? $arResult['TRANSLATE']['IBLOCK_TYPES_META'][$typeKey]['UF_H1'] : $arResult['IBLOCK_TYPES_META'][$typeKey]['UF_H1'] ?>">
                                    <?php
                                    if ($translateEnabled) {
                                        ?>
                                        <div class="translate"
                                             data-tooltip=""
                                             data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                             data-id="<?= md5('iBlockTypesMeta[' . $typeKey . '][h1]') ?>"
                                             data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                             data-phrase="<?= strip_tags($typeValue['name']) ?>">
                                            <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                 alt="">
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-xxs-12">
                            <div class="form-group">
                                <?= ++$i ?>.
                                <a href="/' . $arResult['DIR'] . '/admin/iblock_type_edit.php?lang=ru&ID=<?= $typeKey ?>"
                                   target="_blank">
                                                        <span class="iBlockMetaOriginal"
                                                              data-id="<?= md5('iBlockTypesMeta[' . $typeKey . '][title]') ?>"
                                                              data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                            <?= $typeValue['name'] ?>
                                                        </span>
                                    (TITLE)
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xxs-12">
                            <div class="form-group">
                                <div class="input-translate">
                                    <input type="text"
                                           placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                           class="form-control"
                                           id="<?= md5('iBlockTypesMeta[' . $typeKey . '][title]') ?>"
                                           name="iBlockTypesMeta[<?= $typeKey ?>][title]"
                                           value="<?= (isset($arResult['TRANSLATE']['IBLOCK_TYPES_META'][$typeKey]['UF_TITLE'])) ? $arResult['TRANSLATE']['IBLOCK_TYPES_META'][$typeKey]['UF_TITLE'] : $arResult['IBLOCK_TYPES_META'][$typeKey]['UF_TITLE'] ?>">
                                    <?php
                                    if ($translateEnabled) {
                                        ?>
                                        <div class="translate"
                                             data-tooltip=""
                                             data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                             data-id="<?= md5('iBlockTypesMeta[' . $typeKey . '][title]') ?>"
                                             data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                             data-phrase="<?= strip_tags($typeValue['name']) ?>">
                                            <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                 alt="">
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-xxs-12">
                            <div class="form-group">
                                <?= ++$i ?>.
                                <a href="/' . $arResult['DIR'] . '/admin/iblock_type_edit.php?lang=ru&ID=<?= $typeKey ?>"
                                   target="_blank">
                                                        <span class="iBlockMetaOriginal"
                                                              data-id="<?= md5('iBlockTypesMeta[' . $typeKey . '][breadcrumb]') ?>"
                                                              data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                            <?= $typeValue['name'] ?>
                                                        </span>
                                    (BREADCRUMB)
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xxs-12">
                            <div class="form-group">
                                <div class="input-translate">
                                    <input type="text"
                                           placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                           class="form-control"
                                           id="<?= md5('iBlockTypesMeta[' . $typeKey . '][breadcrumb]') ?>"
                                           name="iBlockTypesMeta[<?= $typeKey ?>][breadcrumb]"
                                           value="<?= (isset($arResult['TRANSLATE']['IBLOCK_TYPES_META'][$typeKey]['UF_BREADCRUMB'])) ? $arResult['TRANSLATE']['IBLOCK_TYPES_META'][$typeKey]['UF_BREADCRUMB'] : $arResult['IBLOCK_TYPES_META'][$typeKey]['UF_BREADCRUMB'] ?>">
                                    <?php
                                    if ($translateEnabled) {
                                        ?>
                                        <div class="translate"
                                             data-tooltip=""
                                             data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                             data-id="<?= md5('iBlockTypesMeta[' . $typeKey . '][breadcrumb]') ?>"
                                             data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                             data-phrase="<?= strip_tags($typeValue['name']) ?>">
                                            <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                 alt="">
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                    foreach ($typeValue['iblocks'] as $iblock) {
                        ?>
                        <div class="row">
                            <div class="col-sm-6 col-xxs-12">
                                <div class="form-group">
                                    <?= ++$i ?>.
                                    <a href="/' . $arResult['DIR'] . '/admin/iblock_edit.php?type=<?= $typeKey ?>&lang=ru&ID=<?= $iblock['id'] ?>&admin=Y"
                                       target="_blank">
                                                            <span class="iBlockMetaOriginal"
                                                                  data-id="<?= md5('iBlockIdMeta[' . $iblock['id'] . '][h1]') ?>"
                                                                  data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                                <?= $iblock['name'] ?>
                                                            </span>,ID: <?= $iblock['id'] ?> (H1)
                                    </a>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xxs-12">
                                <div class="form-group">
                                    <div class="input-translate">
                                        <input type="text"
                                               placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                               class="form-control"
                                               id="<?= md5('iBlockIdMeta[' . $iblock['id'] . '][h1]') ?>"
                                               name="iBlockIdMeta[<?= $iblock['id'] ?>][h1]"
                                               value="<?= (isset($arResult['TRANSLATE']['IBLOCK_ID_META'][$iblock['id']]['UF_H1'])) ? $arResult['TRANSLATE']['IBLOCK_ID_META'][$iblock['id']]['UF_H1'] : $arResult['IBLOCK_ID_META'][$iblock['id']]['UF_H1'] ?>">
                                        <?php
                                        if ($translateEnabled) {
                                            ?>
                                            <div class="translate"
                                                 data-tooltip=""
                                                 data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                 data-id="<?= md5('iBlockIdMeta[' . $iblock['id'] . '][h1]') ?>"
                                                 data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                 data-phrase="<?= strip_tags($iblock['name']) ?>">
                                                <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                     alt="">
                                            </div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-xxs-12">
                                <div class="form-group">
                                    <?= ++$i ?>.
                                    <a href="/' . $arResult['DIR'] . '/admin/iblock_edit.php?type=<?= $typeKey ?>&lang=ru&ID=<?= $iblock['id'] ?>&admin=Y"
                                       target="_blank">
                                                            <span class="iBlockMetaOriginal"
                                                                  data-id="<?= md5('iBlockIdMeta[' . $iblock['id'] . '][title]') ?>"
                                                                  data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                                <?= $iblock['name'] ?>
                                                            </span>,ID: <?= $iblock['id'] ?> (TITLE)
                                    </a>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xxs-12">
                                <div class="form-group">
                                    <div class="input-translate">
                                        <input type="text"
                                               placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                               class="form-control"
                                               id="<?= md5('iBlockIdMeta[' . $iblock['id'] . '][title]') ?>"
                                               name="iBlockIdMeta[<?= $iblock['id'] ?>][title]"
                                               value="<?= (isset($arResult['TRANSLATE']['IBLOCK_ID_META'][$iblock['id']]['UF_TITLE'])) ? $arResult['TRANSLATE']['IBLOCK_ID_META'][$iblock['id']]['UF_TITLE'] : $arResult['IBLOCK_ID_META'][$iblock['id']]['UF_TITLE'] ?>">
                                        <?php
                                        if ($translateEnabled) {
                                            ?>
                                            <div class="translate"
                                                 data-tooltip=""
                                                 data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                 data-id="<?= md5('iBlockIdMeta[' . $iblock['id'] . '][title]') ?>"
                                                 data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                 data-phrase="<?= strip_tags($iblock['name']) ?>">
                                                <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                     alt="">
                                            </div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-xxs-12">
                                <div class="form-group">
                                    <?= ++$i ?>.
                                    <a href="/' . $arResult['DIR'] . '/admin/iblock_edit.php?type=<?= $typeKey ?>&lang=ru&ID=<?= $iblock['id'] ?>&admin=Y"
                                       target="_blank">
                                                            <span class="iBlockMetaOriginal"
                                                                  data-id="<?= md5('iBlockIdMeta[' . $iblock['id'] . '][breadcrumb]') ?>"
                                                                  data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>">
                                                                <?= $iblock['name'] ?>
                                                            </span>,ID: <?= $iblock['id'] ?> (BREADCRUMB)
                                    </a>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xxs-12">
                                <div class="form-group">
                                    <div class="input-translate">
                                        <input type="text"
                                               placeholder="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRL_PLC') ?>"
                                               class="form-control"
                                               id="<?= md5('iBlockIdMeta[' . $iblock['id'] . '][breadcrumb]') ?>"
                                               name="iBlockIdMeta[<?= $iblock['id'] ?>][breadcrumb]"
                                               value="<?= (isset($arResult['TRANSLATE']['IBLOCK_ID_META'][$iblock['id']]['UF_BREADCRUMB'])) ? $arResult['TRANSLATE']['IBLOCK_ID_META'][$iblock['id']]['UF_BREADCRUMB'] : $arResult['IBLOCK_ID_META'][$iblock['id']]['UF_BREADCRUMB'] ?>">
                                        <?php
                                        if ($translateEnabled) {
                                            ?>
                                            <div class="translate"
                                                 data-tooltip=""
                                                 data-title="<?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_TRANSLATE_THIS') ?>"
                                                 data-id="<?= md5('iBlockIdMeta[' . $iblock['id'] . '][breadcrumb]') ?>"
                                                 data-lang="<?= $arResult['CURRENT_LANGUAGE'] ?>"
                                                 data-phrase="<?= strip_tags($iblock['name']) ?>">
                                                <img src="<?= SITE_TEMPLATE_PATH ?>/app/images/google-translate.png"
                                                     alt="">
                                            </div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                    <div class="seporate"></div>
                    <?php
                }
                ?>
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <button type="submit" class="apply _mt">
                            <?= Loc::getMessage('USER_TRANSLATIONS_COMPONENT_SAVE') ?>
                        </button>
                    </div>
                </div>
            </form>
            <?php
        }
        ?>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:user.menu',
            ''
        );
        ?>
    </div>
    <script>
        BX.message({translatePath: '<?=$this->GetFolder()?>'});
    </script>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}