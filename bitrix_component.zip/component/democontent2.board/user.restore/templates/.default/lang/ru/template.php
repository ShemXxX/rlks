<?php
/**
 * Date: 25.04.2020
 * Time: 17:41
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
$MESS['USER_RESTORE_COMPONENT_H1'] = 'Восстановление пароля';
$MESS['USER_RESTORE_COMPONENT_EMAIL'] = 'Email';
$MESS['USER_RESTORE_COMPONENT_PHONE'] = 'Номер телефона';
$MESS['USER_RESTORE_COMPONENT_SUBMIT'] = 'Восстановить пароль';
