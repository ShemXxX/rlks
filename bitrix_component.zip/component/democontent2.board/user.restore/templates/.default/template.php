<?php
/**
 * Date: 25.04.2020
 * Time: 17:42
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Page\Asset;

if (Option::get(DBOARD, 'reCaptchaPublic')
    && Option::get(DBOARD, 'reCaptchaSecret')) {
    Asset::getInstance()->addString('<script src="https://www.google.com/recaptcha/api.js?onload=onLoadReCaptcha&render=explicit" async defer></script>');
}
?>
<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12"></div>
<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
    <h1><?= Loc::getMessage('USER_RESTORE_COMPONENT_H1') ?></h1>
    <div class=" _box">
        <?php
        if (strlen($arResult['SUCCESS'])) {
            ?>
            <div class="success-message"><?= $arResult['SUCCESS'] ?></div>
            <?php
        } else {
            if (strlen($arResult['ERROR'])) {
                ?>
                <div class="danger-message"><?= $arResult['ERROR'] ?></div>
                <?php
            }
            ?>
            <form action="<?= SITE_DIR ?>user/restore/" class="edit-form" method="post">
                <label><?= Loc::getMessage('USER_RESTORE_COMPONENT_EMAIL') ?></label>
                <input type="text" placeholder="<?= Loc::getMessage('USER_RESTORE_COMPONENT_EMAIL') ?>" name="email"
                       autocomplete="off" autofocus>
                <label><?= Loc::getMessage('USER_RESTORE_COMPONENT_PHONE') ?></label>
                <input type="phone" placeholder="<?= Loc::getMessage('USER_RESTORE_COMPONENT_PHONE') ?>" name="phone"
                       autocomplete="off">
                <div id="reCaptcha" class="_mt _mb"></div>
                <button class="apply" type="submit">
                    <?= Loc::getMessage('USER_RESTORE_COMPONENT_SUBMIT') ?>
                </button>
            </form>
            <?php
        }
        ?>
    </div>
</div>
<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12"></div>
<script>
    BX.message({
        phoneFormat: parseInt('<?=intval(Option::get(DBOARD, 'phone_code_mask'))?>'),
        phoneMask: '<?=Option::get(DBOARD, 'phone_mask')?>'
    });
    var __reCaptchaInit = 0;
    <?php
    if (Option::get(DBOARD, 'reCaptchaPublic') && Option::get(DBOARD, 'reCaptchaSecret')) {
    ?>
    __reCaptchaInit = 1;
    var reCaptchaPublicKey = '<?=Option::get(DBOARD, 'reCaptchaPublic')?>';
    var reCaptcha = null;
    var onLoadReCaptcha = function () {
        reCaptcha = grecaptcha.render('reCaptcha', {
            'sitekey': reCaptchaPublicKey,
            'theme': 'light'
        });
    };
    <?php
    }
    ?>
</script>
