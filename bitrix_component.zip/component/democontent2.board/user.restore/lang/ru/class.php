<?php
/**
 * Date: 25.04.2020
 * Time: 17:41
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
$MESS['USER_RESTORE_COMPONENT_CLASS_RECAPTCHA_ERROR'] = 'Подтвердите что вы не робот, поставьте галочку в форме ниже';
$MESS['USER_RESTORE_COMPONENT_CLASS_RESTORE_ERROR'] = 'Пользователь не найден';
$MESS['USER_RESTORE_COMPONENT_CLASS_RESTORE_SUCCESS'] = 'Вам отправлен новый пароль для авторизации на сайте';
$MESS['FIELDS_ERROR'] = 'Заполните все поля формы';
