$(document).ready(function () {
    $('input[type="phone"]').mask('+' + __phoneFormat + __phoneMask);
});
