<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 25.09.2018
 * Time: 09:34
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Application;
use Bitrix\Main\IO\File;
use Bitrix\Main\Localization\Loc;

if (File::isFileExists(Application::getDocumentRoot() . SITE_TEMPLATE_PATH . '/inc/' . USER_LANG_PATH . '404/default.php')) {
    $APPLICATION->IncludeComponent(
        "bitrix:main.include", "",
        [
            "AREA_FILE_SHOW" => "file",
            "PATH" => SITE_TEMPLATE_PATH . '/inc/' . USER_LANG_PATH . '404/default.php',
            "EDIT_TEMPLATE" => "include_areas_template.php",
            'MODE' => 'php'
        ],
        false
    );
} else {
    ?>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="not-found">
            <div class="title">404</div>
            <div class="content"><?= Loc::getMessage('404_COMPONENT_CONTENT', ['#SITE_DIR#' => SITE_DIR]) ?></div>
        </div>
    </div>
    <?php
}