<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 03.10.2018
 * Time: 10:53
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('USER_ITEMS_FEEDBACK_H1') ?></h1>
        <div class="items-list__sort">
            <div class="item active">
                <a href="<?= SITE_DIR ?>user/feedback/">
                    <?= Loc::getMessage('USER_ITEMS_FEEDBACK_MY') ?>
                </a>
            </div>
            <div class="item">
                <a href="<?= SITE_DIR ?>user/feedback/?about_me=1">
                    <?= Loc::getMessage('USER_ITEMS_FEEDBACK_ABOUT') ?>
                </a>
            </div>
        </div>
        <div class="reviews _mb">
            <?php
            $myFeedback = 0;
            foreach ($arResult['ITEMS'] as $key => $feedback) {
                if ($arResult['USER_ID'] == $feedback['UF_FROM']) {
                    $myFeedback++;
                    $image = null;
                    if (intval($feedback['USER_TO_PHOTO'])) {
                        $image = CFile::ResizeImageGet(
                            $feedback['USER_TO_PHOTO'],
                            [
                                'width' => 100,
                                'height' => 100
                            ],
                            BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
                            true
                        );
                    }
                    ?>
                    <div class="item">
                        <div class="author">
                            <?php
                            if (!is_null($image)) {
                                ?>
                                <div class="image">
                                    <a href="<?= SITE_DIR ?>user/<?= $feedback['UF_FROM'] ?>/">
                                        <img src="<?= $image['src'] ?>" alt="<?= $feedback['USER_FROM_NAME'] ?>">
                                    </a>
                                </div>
                                <?php
                            } else {
                                ?>
                                <div class="colored-name"
                                     style="background: <?= strlen($feedback['USER_FROM_NAME']) ? \Democontent2\Board\Utils::userBgColor($feedback['USER_FROM_NAME']) : '#ffffff' ?>">
                                    <?= strlen($feedback['USER_FROM_NAME']) ? \Democontent2\Board\Utils::userNamePrefix($feedback['USER_FROM_NAME']) : '' ?>
                                </div>
                                <?php
                            }
                            ?>
                            <div class="data">
                                <a class="name" href="<?= SITE_DIR ?>user/<?= $feedback['UF_FROM'] ?>/">
                                    <?= $feedback['USER_FROM_NAME'] ?>
                                </a>
                                <div title="<?= date('Y-m-d H:i', strtotime($feedback['UF_TEXT_TIME'])) ?>"
                                     class="date timestamp"></div>
                                <div class="rating"><?= Loc::getMessage('USER_PUBLIC_PROFILE_RATING') ?>
                                    <span>
                                <?php
                                foreach ([1, 2, 3, 4, 5] as $chunk) {
                                    if ($feedback['UF_RATING'] >= $chunk) {
                                        ?>
                                        <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <g>
                                                <path d="M7 10.713L11.3283 14L9.67167 8.69217L14 5.47826H8.69167L7 0L5.30833 5.47826H0L4.32833 8.69217L2.67167 14L7 10.713Z"
                                                      fill="#F2994A"/>
                                            </g>
                                        </svg>
                                        <?php
                                    } else {
                                        ?>
                                        <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <g>
                                                <path d="M7 10.713L11.3283 14L9.67167 8.69217L14 5.47826H8.69167L7 0L5.30833 5.47826H0L4.32833 8.69217L2.67167 14L7 10.713Z"
                                                      fill="#BDBDBD"/>
                                            </g>
                                        </svg>
                                        <?php
                                    }
                                }
                                ?>
                            </span>
                                </div>
                            </div>
                        </div>
                        <div class="content"><?= $feedback['UF_TEXT'] ?></div>
                        <?php
                        if (strlen($feedback['UF_ANSWER'])) {
                            ?>
                            <div class="response">
                                <div class="date timestamp"
                                     title="<?= date('Y-m-d H:i', strtotime($feedback['UF_ANSWER_TIME'])) ?>"></div>
                                <div class="content"><?= $feedback['UF_ANSWER'] ?></div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                    <?
                }
            }
            if ($myFeedback === 0) {
                ?>
                <div class="info-message">
                    <?= Loc::getMessage('USER_ITEMS_FEEDBACK_EMPTY') ?>
                </div>
                <?
            }
            ?>
        </div>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:user.menu',
            ''
        );
        ?>
    </div>
    <script>
        var __ajaxPath = '<?=$this->GetFolder()?>/ajax.php';
    </script>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}