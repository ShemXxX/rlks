$(document).ready(function(){
    $('.feedback-block .edit-btn').click(function (e) {
        e.preventDefault();
        var block = $(this).closest('.feedback-block');
        block.find('.edit-block .form-control').height(block.find('.desc').outerHeight());
        block.find('>.desc').hide().siblings('.edit-block').show().find('.form-control').focus();
        $(this).closest('.bottom').hide()
    });
    $('.feedback-block  .btn-answer').click(function (e) {
        e.preventDefault();
        $(this).closest('.bottom').stop().slideUp().siblings('.feedback-block').stop().slideDown();
    });
    $('.assessment-box label').hover(
        function(){ //over
            $(this).addClass('active').prevAll().addClass('active');
            $(this).nextAll().removeClass('active');
        },
        function(){ //out
            checkAssement($(this).closest('.assessment-box'))
        }
    );
    $('.assessment-box').each(function () {
        checkAssement($(this));
    });
    function checkAssement(el) {
        if ($(el).find('input:checked').length>0) {
            $('[for="'+$(el).find('input:checked').attr('id')+'"]').addClass('active').prevAll().addClass('active');
            $('[for="'+$(el).find('input:checked').attr('id')+'"]').nextAll().removeClass('active');
        } else {
            $(el).find('label').removeClass('active');
        }
    }
    $(".timestamp").timeago();

    $('.edit-answer-btn').click(function (e) {
        e.preventDefault();
        var $this = $(this),
            id = $(this).data('id'),
            text = $(this).closest('form').find('textarea').val();
        if (text !== '') {
            $.ajax({
                type: 'POST',
                url: __ajaxPath,
                dataType: "json",
                data: 'type=editAnswer&id=' + id + '&text=' + text,
                success: function (data) {
                    if (!data.error) {
                        $this.closest('.edit-block').hide().siblings('.desc').text(text);
                        $this.closest('.edit-block').hide().siblings('.desc, .bottom').show();

                    }
                },
                error: function (data) {
                }
            });
        } else {
            $(this).closest('form').find('.form-group').addClass('error');
        }
    });
    $('.save-answer-btn').click(function (e) {
        e.preventDefault();
        var $this = $(this),
            id = $(this).data('id'),
            text = $(this).closest('form').find('textarea').val();
        if (text !== '') {
            $.ajax({
                type: 'POST',
                url: __ajaxPath,
                dataType: "json",
                data: 'type=answer&id=' + id + '&text=' + text,
                success: function (data) {
                    if (!data.error) {
                        $this.closest('.edit-block').hide().siblings('.desc').text(text);
                        $this.closest('.edit-block').hide().siblings('.desc, .bottom').show();

                    }
                },
                error: function (data) {
                }
            });
        } else {
            $(this).closest('form').find('.form-group').addClass('error');
        }
    });
    $('.edit-review-btn').click(function (e) {
        e.preventDefault();
        var $this = $(this),
            id = $(this).data('id'),
            rating = $(this).closest('form').find('input[type="radio"]:checked').val(),
            text = $(this).closest('form').find('textarea').val();
        if (text !== '') {
            $.ajax({
                type: 'POST',
                url: __ajaxPath,
                dataType: "json",
                data: 'type=editReview&id=' + id + '&text=' + text+ '&rating=' + rating,
                success: function (data) {
                    if (!data.error) {
                        $this.closest('.edit-block').hide().siblings('.desc').text(text);
                        $this.closest('.edit-block').hide().siblings('.desc, .bottom').show();
                        $this.closest('.feedback-block').find('>.top .assessment-box .assessment-in').css('width', rating*20+'%');

                    }
                },
                error: function (data) {
                }
            });
        } else {
            $(this).closest('form').find('.form-group').addClass('error');
        }
    });
});