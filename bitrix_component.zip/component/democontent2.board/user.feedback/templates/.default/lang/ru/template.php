<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 03.10.2018
 * Time: 10:53
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['USER_ITEMS_FEEDBACK_H1'] = 'Отзывы';
$MESS['USER_ITEMS_FEEDBACK_MY'] = 'Мои отзывы';
$MESS['USER_ITEMS_FEEDBACK_ABOUT'] = 'Обо мне';
$MESS['USER_ITEMS_FEEDBACK_EMPTY'] = 'У вас нет отзывов';
$MESS['USER_ITEMS_FEEDBACK_REPLY'] = 'Ответить';
$MESS['USER_ITEMS_FEEDBACK_SAVE'] = 'Сохранить';
$MESS['USER_ITEMS_FEEDBACK_EDIT'] = 'Редактировать';
$MESS['USER_PUBLIC_PROFILE_RATING'] = 'Оценка';


