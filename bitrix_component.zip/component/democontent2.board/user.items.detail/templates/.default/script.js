var dropZone;
$(document).ready(function () {
    Dropzone.autoDiscover = false;
    $('button.cancel').click(function (e) {
        e.preventDefault();
        if (confirm(__cancelConfirmMessage)) {
            $(this).closest('form').find('[name="cancel"]').val('1');
            $(this).closest('form').submit();
        }
    });
    $('button.remove').click(function (e) {
        e.preventDefault();
        if (confirm(__removeConfirmMessage)) {
            $(this).closest('form').find('[name="cancel"]').val('2');
            $(this).closest('form').submit();
        }
    });
    $('#files-previews').sortable({
        stop: function (event, ui) {
            setCounter();
        }
    });
    $('#files-previews').disableSelection();
    $(".dropzone-files__files").each(function () {
        var i = 0;
        dropZone = new Dropzone(
            this,
            {
                url: __path,
                paramName: '__files',
                maxFilesize: __maxImageSize,
                acceptedFiles: "image/*",
                addRemoveLinks: true,
                maxFiles: __allowImageQuantity,
                accept: function (file, done) {
                    var fileLenght = dropZone.files.length + $('.preview-pict').length;
                    if (fileLenght > __allowImageQuantity) {
                        done('maxFiles');
                    } else {
                        done();
                    }
                },
                init: function () {

                },
                success: function (file, response) {
                    $('#dropzone-files-hidden__files').append('<textarea class="__files" name="__files[]" id="' + file.upload.uuid + '">' + file.dataURL + '</textarea>');
                    $('.dropzone-files__files .error').remove();
                    $(document).find(file.previewElement).remove();

                    $('<div class="item preview-pict" data-id="' + file.upload.uuid + '"><div class="remove"><svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.115 12L6 8.115L9.885 12L12 9.885L8.115 6L12 2.115L9.885 0L6 3.885L2.115 0L0 2.115L3.885 6L0 9.885L2.115 12Z" fill="#EB5757"/></svg></div><div class="fotorama _mb" data-width="100%" data-height="80px" data-maxheight="80px" data-allowfullscreen="false" data-loop="false"><div data-img="' + file.dataURL + '"><div class="fotorama__blur" style="background:url(' + file.dataURL + ')"></div></div></div></div>').appendTo('#files-previews');
                    $('.fotorama').fotorama();

                    setCounter();
                    $('#files-previews').sortable({
                        stop: function (event, ui) {
                            setCounter();
                        }
                    });
                    $('#files-previews').disableSelection();
                },
                error: function (file, response) {
                    $('.dropzone-files__files .error').remove();
                    $(document).find(file.previewElement).remove();
                    $(".dropzone-files__files").addClass('dz-limit');
                },
                removedfile: function (file) {
                    $("#" + file.upload.uuid).remove();
                    $(document).find(file.previewElement).remove();
                },
                uploadprogress: function (file, progress) {
                    progress = parseInt(progress);
                    if (progress >= 10) {
                        $(file.previewElement).find('.dz-progress').css('width', '7px').html(progress + '%');
                    }
                    if (progress >= 20) {
                        $(file.previewElement).find('.dz-progress').css('width', '14px').html(progress + '%');
                    }
                    if (progress >= 30) {
                        $(file.previewElement).find('.dz-progress').css('width', '21px').html(progress + '%');
                    }
                    if (progress >= 40) {
                        $(file.previewElement).find('.dz-progress').css('width', '28px').html(progress + '%');
                    }
                    if (progress >= 50) {
                        $(file.previewElement).find('.dz-progress').css('width', '35px').html(progress + '%');
                    }
                    if (progress >= 60) {
                        $(file.previewElement).find('.dz-progress').css('width', '42px').html(progress + '%');
                    }
                    if (progress >= 70) {
                        $(file.previewElement).find('.dz-progress').css('width', '49px').html(progress + '%');
                    }
                    if (progress >= 80) {
                        $(file.previewElement).find('.dz-progress').css('width', '56px').html(progress + '%');
                    }
                    if (progress >= 90) {
                        $(file.previewElement).find('.dz-progress').css('width', '63px').html(progress + '%');
                    }
                    if (progress === 100) {
                        $(file.previewElement).find('.dz-progress').css('width', '78px').html(progress + '%');
                    }
                },
                queuecomplete: function () {
                    $(".dropzone-files__files").removeClass('dz-started');
                },
            }
        );
    });

    $(document).on('click', '.preview-pict .remove', function (e) {
        e.preventDefault();
        removePict($(this).closest('.preview-pict').data('id'));
    });
    $(document).on('focus', 'input.required', function () {
        var errors = $(this).closest('form').find('.group.error').length;
        if (errors === 0 && !$(this).closest('form').hasClass('disable')) {
            $('#check-required').addClass('--dn');
        }
    });
    $(document).on('change', 'select.required', function () {
        var errors = $(this).closest('form').find('.group.error').length;
        if (errors === 0 && !$(this).closest('form').hasClass('disable')) {
            $('#check-required').addClass('--dn');
        }
    });
    $('.buttons button[type="submit"]').click(function (e) {
        e.preventDefault();
        checkInput($(this).closest('form'));
        var errors = $(this).closest('form').find('.group.error').length;
        if (errors === 0 && !$(this).closest('form').hasClass('disable')) {
            $(this).closest('form').addClass('disable').submit();
            $('#check-required').addClass('--dn');
        } else {
            $('#check-required').removeClass('--dn');
        }
    });

    var options = {
        maintainAspectRatio: false,
        spanGaps: false,
        elements: {
            line: {
                tension: 0.000001
            }
        },
        plugins: {
            filler: {
                propagate: false
            }
        },
        scales: {
            xAxes: [{
                ticks: {
                    autoSkip: false,
                }
            }]
        },
        title: {
            text: lineChartTitle,
            display: true
        }
    };
    if ($('#chart').length > 0) {
        var lineChartDays = new Array(),
            lineChartPoints = new Array(),
            lineChartPhonePoints = new Array();
        $.each(chartData, function (index, value) {
            lineChartDays.push(index);
            lineChartPoints.push(value.shows);
            lineChartPhonePoints.push(value.phone);
        });
        var lineChart = new Chart($('#chart'), {
            type: 'line',
            data: {
                labels: lineChartDays,
                datasets: [{
                    data: lineChartPoints,
                    backgroundColor: 'rgba(255,152,0,.3)',
                    borderColor: '#FF9800',
                    label: lineChartLableText,
                    fill: 'start'
                }, {
                    data: lineChartPhonePoints,
                    backgroundColor: 'rgba(0,78,136,.7)',
                    borderColor: '#004e88',
                    label: lineChartLablePhoneText,
                    fill: 'start'
                }]
            },
            options: options
        });
    }
});

function checkInput(form) {
    var $form = $(form);
    $form.find('select.required').each(function () {
        if ($(this).val() === '0') {
            $(this).parents('.group').addClass('error');
        } else {
            $(this).parents('.group').removeClass('error');
        }
    });
    $form.find('input[type=text].required').each(function () {
        if ($(this).val() !== '') {
            $(this).parents('.group').removeClass('error');
        } else {
            $(this).parents('.group').addClass('error');
        }
    });
}

function removePict(id) {
    $('#' + id + ', [data-id="' + id + '"]').remove();
    $('.dropzone-files__files').removeClass('dz-limit');
    if (dropZone.files.length > 10) {
        dropZone.files.length = 9;
    } else {
        if (dropZone.files.length) {
            dropZone.files.length--;
        }
    }
    setCounter();
}

function setCounter() {
    let counter = 0;
    $('.preview-pict').removeClass('main');
    $('.preview-pict').each(function () {
        counter++;
        $(this).attr('data-counter', counter);
        $('#' + $(this).data('id')).attr('name', '__files[' + counter + ']');
        if (counter === 1) {
            $(this).addClass('main');
        }
    });
}
