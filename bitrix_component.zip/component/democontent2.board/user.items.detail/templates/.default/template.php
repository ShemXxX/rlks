<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 06.10.2018
 * Time: 14:10
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}




use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Page\Asset;
use Bitrix\Main\Web\Json;
use Bitrix\Main\Loader;
use Bitrix\Main;
use Bitrix\Iblock;
use Democontent2\Board\Utils;




Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/jquery-ui.js');
if (count($arResult['ITEM']['location']) > 0) {
    $mapType = Option::get(DBOARD, 'defaultMap');
    switch ($mapType) {
        case 'google':
            Asset::getInstance()->addJs('https://maps.googleapis.com/maps/api/js?language=' . ((USER_LANG == 'ru') ? 'ru' : 'en') . '&key='
                . Option::get(DBOARD, 'google_maps_api_key'));
            break;
        default:
            Asset::getInstance()->addJs(
                'https://api-maps.yandex.ru/2.1/?load=package.full&apikey=' . Option::get(DBOARD, 'yandex_maps_api_key') . '&lang=' . ((USER_LANG == 'ru') ? 'ru_RU' : 'en_US')
            );
    }

    Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/create-' . $mapType . '-map.js');
}

Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . '/app/css/select2.min.css');
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/select2.js');

Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/lib/dropzone/dropzone.js');
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/Chart.min.js');

$currencyName = Option::get(DBOARD, 'currency_name');
$images = [];
$allowImageQuantity = intval(Option::get(DBOARD, 'max_images'));
$currentImageQty = 0;
$moderation = intval($arResult['ITEM']['moderation']);

if (!empty($arResult['ITEM']['mainImage'])) {
    $images[] = $arResult['ITEM']['mainImage'];
}

if (!empty($arResult['ITEM']['images'])) {
    $images = array_merge($images, $arResult['ITEM']['images']);
}

$activationCost = intval(Option::get(DBOARD, 'activation_option_cost'));
$dateEnd = strtotime($arResult['ITEM']['activeTo']);
$dateNow = strtotime(date('Y-m-d H:i:s'));
$datediff = ($dateEnd - $dateNow) / (60 * 60 * 24);

$vip = $arResult['ITEM']['vip'];
$premium = $arResult['ITEM']['premium'];
$color = $arResult['ITEM']['color'];
?>

    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('USER_ITEM_DETAIL_TITLE') ?></h1>
        <? if ($moderation > 0): ?>
            <?php
            if ($moderation == 1) {
                ?>
                <div class="info-message _mt">
                    <?= Loc::getMessage('USER_ITEM_DETAIL_IN_MODERATION') ?>
                </div>
                <?php
            } else {
                if (strlen($arResult['ITEM']['moderationCancelReason']) > 0) {
                    ?>
                    <div class="danger-message _mt">
                        <?= $arResult['ITEM']['moderationCancelReason'] ?>
                    </div>
                    <?php
                } else {
                    ?>
                    <div class="danger-message _mt">
                        <?= Loc::getMessage('USER_ITEM_DETAIL_TITLE_MODERATION_REJECTED') ?>
                    </div>
                    <?php
                }
            }
            ?>
        <? else: ?>
            <?php
            if ($datediff <= 0) {
                ?>
                <div class="danger-message _mt">
                    <?php
                    if ($activationCost) {
                        echo Loc::getMessage('USER_ITEM_DETAIL_COMPONENT_EXPIRED_PAYMENT', [
                            '#SUM#' => $activationCost,
                            '#CURRENCY#' => $currencyName,
                        ]);
                    } else {
                        echo Loc::getMessage('USER_ITEM_DETAIL_COMPONENT_EXPIRED');
                    }
                    ?>
                </div>
                <?php
            } elseif ($datediff >= 0 && $datediff < 5) {
                ?>
                <div class="warning-message _mt">
                    <?= Loc::getMessage('USER_ITEM_DETAIL_COMPONENT_CONTINUE', ['#DATE#' => date('d.m.Y H:i', $dateEnd)]) ?>
                    <a href="<?= $arResult['ITEM']['path'] ?>" target="_blank">
                        <?= Loc::getMessage('USER_ITEM_DETAIL_COMPONENT_SHOW_IN_SITE') ?>
                    </a>
                </div>
                <?php
            } elseif ($datediff >= 5) {
                ?>
                <div class="success-message _mt">
                    <?= Loc::getMessage('USER_ITEM_DETAIL_COMPONENT_ACITVE', ['#DATE#' => date('d.m.Y H:i', $dateEnd)]) ?>
                    <a href="<?= $arResult['ITEM']['path'] ?>" target="_blank">
                        <?= Loc::getMessage('USER_ITEM_DETAIL_COMPONENT_SHOW_IN_SITE') ?>
                    </a>
                </div>
                <?php
            }
            ?>
        <? endif; ?>

        <?php
        if ($vip || $premium || $color) {
            ?>
            <div class="detail-labels _mt">
                <?php
                if ($vip) {
                    ?>
                    <div class="item vip"><?= Loc::getMessage('DETAIL_COMPONENT_SERVICE_VIP') ?></div>
                    <?php
                }
                if ($premium) {
                    ?>
                    <div class="item premium"><?= Loc::getMessage('DETAIL_COMPONENT_SERVICE_PREMIUM') ?></div>
                    <?php
                }
                if ($color) {
                    ?>
                    <div class="item color"><?= Loc::getMessage('DETAIL_COMPONENT_SERVICE_COLORS_STATUS') ?></div>
                    <?php
                }
                ?>
            </div>
            <?php
        }
        ?>

        <? if ($arResult['SHOW_GRAPH'] > 0): ?>
            <h4><?= Loc::getMessage('USER_ITEM_DETAIL_STATISTICS_TITLE') ?></h4>
            <div class="chart _mt">
                <canvas id="chart"></canvas>
            </div>
        <? endif ?>

        <form class="edit-form<?= ($moderation > 0) ? ' on-moderation' : '' ?>"
              method="post" action="<?= $APPLICATION->GetCurPage(false) ?>">
            <input type="hidden" name="cancel" value="0">
            <h4><?= Loc::getMessage('USER_ITEM_DETAIL_TITLE_CATEGORY') ?> *</h4>
            <div class="row">
                <div class="col col-md-3 col-sm-6 col-xs-12">
                    <div class="group">
                        <input type="text" name="" placeholder="<?= $arResult['ITEM']['iBlockTypeName'] ?>" disabled
                               class="form-control">
                    </div>
                </div>
                <div class="col col-md-3 col-sm-6 col-xs-12">
                    <div class="group">
                        <input type="text" name="" placeholder="<?= $arResult['ITEM']['iBlockName'] ?>" disabled
                               class="form-control">
                    </div>
                </div>
                <? if (strlen($arResult['ITEM']['depthLevel1Name']) > 0): ?>
                    <div class="col col-md-3 col-sm-6 col-xs-12">
                        <div class="group">
                            <input type="text" name="" placeholder="<?= $arResult['ITEM']['depthLevel1Name'] ?>"
                                   disabled class="form-control">
                        </div>
                    </div>
                <? endif ?>
                <? if (strlen($arResult['ITEM']['depthLevel2Name']) > 0): ?>
                    <div class="col col-md-3 col-sm-6 col-xs-12">
                        <div class="group">
                            <input type="text" name="" placeholder="<?= $arResult['ITEM']['depthLevel2Name'] ?>"
                                   disabled class="form-control">
                        </div>
                    </div>
                <? endif ?>
            </div>
            <div class="delimiter"></div>
            <h4><?= Loc::getMessage('USER_ITEM_DETAIL_TITLE_IMAGES') ?> <?= $allowImageQuantity ?></h4>
            <div id="files-previews" class="images">
                <?php
                foreach ($images as $key => $value) {
                    $file = CFile::ResizeImageGet(
                        $value,
                        [
                            'width' => 150,
                            'height' => 150
                        ],
                        BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
                        true
                    );
                    ?>
                    <div class="item<?= ($key == 0) ? ' main' : '' ?> preview-pict"
                         data-id="<?= md5($value) ?>">
                        <div class="remove">
                            <svg width="12" height="12" viewBox="0 0 12 12" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path d="M2.115 12L6 8.115L9.885 12L12 9.885L8.115 6L12 2.115L9.885 0L6 3.885L2.115 0L0 2.115L3.885 6L0 9.885L2.115 12Z"
                                      fill="#EB5757"/>
                            </svg>
                        </div>
                        <div class="fotorama _mb" data-width="100%" data-height="80px" data-maxheight="80px"
                             data-allowfullscreen="false" data-loop="false">
                            <div data-img="<?= $file['src'] ?>">
                                <div class="fotorama__blur" style="background:url(<?= $file['src'] ?>)"></div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
            <div class="upload-files dropzone-files__files">
                <div class="dz-default dz-message">
                    <?= Loc::getMessage('USER_ITEM_DETAIL_DROPZONE_PLACEHOLDER2', ['#QTY#' => $allowImageQuantity]) ?>
                </div>
            </div>
            <div class="upload-files__hidden" id="dropzone-files-hidden__files">
                <?php
                foreach ($images as $key => $value) {
                    $currentImageQty++;
                    ?>
                    <textarea class="__files" name="__files[<?= $key ?>]"
                              id="<?= md5($value) ?>"><?= $value ?></textarea>
                    <?
                }
                ?>
            </div>
            <div class="delimiter"></div>
            <div class="row">
                <div class="col-sm-4 col-xs-12">
                    <div class="group">
                        <label>
                            <?= Loc::getMessage('USER_ITEM_DETAIL_TITLE_PRODUCT') ?>
                            <span class="required-field">*</span>
                        </label>
                        <input class="form-control required" value='<?= $arResult['ITEM']['name'] ?>' type="text"
                               required name="name"<?= (($moderation == 1) ? ' disabled' : false) ?>>
                    </div>
                </div>
                <div class="col-sm-4 col-xs-12">
                    <div class="group">
                        <label>
                            <?= Loc::getMessage('USER_ITEM_DETAIL_TITLE_CITY') ?>
                            <span class="required-field">*</span>
                        </label>
                        <input class="form-control required" value="<?= $arResult['ITEM']['city'] ?>" type="text"
                               disabled required name="name">
                    </div>
                </div>
                <div class="col-sm-4 col-xs-12">
                    <div class="group">
                        <label>
                            <?= Loc::getMessage('USER_ITEM_DETAIL_TITLE_PRICE') ?>
                            <span class="required-field">*</span>
                        </label>
                        <input class="form-control required number-float" type="text" data-type="integer"
                               value="<?= $arResult['ITEM']['price'] ?>" required
                               name="price"<?= (($moderation == 1) ? ' disabled' : false) ?>>
                    </div>
                </div>
            </div>
            <div class="delimiter"></div>
            <div class="row" id="properties">
                <?php
                foreach ($arResult['PROPERTIES'] as $key => $item) {
                    switch ($item['type']) {
                        case 'string':
                            ?>
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="group">
                                    <label>
                                        <?= $item['name'] ?>
                                        <? if ($item['required']): ?>
                                            <span class="required-field">*</span>
                                        <? endif ?>
                                    </label>
                                    <input<?= (($moderation == 1) ? ' disabled' : false) ?>
                                            type="text"
                                            class="form-control"
                                            name="prop[<?= $item['id'] ?>]" <?= ($item['required']) ? 'required' : '' ?>
                                            value='<?= (array_key_exists($item['id'], $arResult['ITEM']['properties'])) ? $arResult['ITEM']['properties'][$item['id']] : '' ?>'>
                                </div>
                            </div>

                            <?
                            break;
                        case 'integer':
                            ?>
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="group">
                                    <label>
                                        <?= $item['name'] ?>
                                        <? if ($item['required']): ?>
                                            <span class="required-field">*</span>
                                        <? endif ?>
                                    </label>
                                    <input<?= (($moderation == 1) ? ' disabled' : false) ?>
                                            type="text" data-type="integer"
                                            class="form-control number-float"
                                            name="prop[<?= $item['id'] ?>]" <?= ($item['required']) ? 'required' : '' ?>
                                            value="<?= (array_key_exists($item['id'], $arResult['ITEM']['properties'])) ? $arResult['ITEM']['properties'][$item['id']] : '' ?>">
                                </div>
                            </div>
                            <?
                            break;
                        case 'list':
                            ?>
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="group">
                                    <label>
                                        <?= $item['name'] ?>
                                        <? if ($item['isRequired']): ?>
                                            <span class="required-field">*</span>
                                        <? endif ?>
                                    </label>
                                    <select<?= (($moderation == 1) ? ' disabled' : false) ?><?= ($item['isMultiple'] ? ' multiple' : '') ?>
                                            class="js-select"
                                            style="width: 100%"
                                            name="prop[<?= $item['id'] ?>]<?= ($item['isMultiple'] ? '[]' : '') ?>" <?= ($item['isRequired']) ? 'required' : '' ?>>
                                        <? if (!$item['isRequired']): ?>
                                            <option value="0"><?= Loc::getMessage('USER_ITEM_DETAIL_SELECT_VARIANT') ?></option>
                                        <? endif ?>
                                        <?
                                        foreach ($item['values'] as $k => $itm) {
                                            $selected = '';
                                            if (isset($arResult['ITEM']['properties'][$item['id']])) {
                                                if ($item['isMultiple']) {
                                                    if (in_array(intval($itm['id']), $arResult['ITEM']['properties'][$item['id']])) {
                                                        $selected = ' selected';
                                                    }
                                                } else {
                                                    if (intval($arResult['ITEM']['properties'][$item['id']]) == intval($itm['id'])) {
                                                        $selected = ' selected';
                                                    }
                                                }
                                            }
                                            ?>
                                            <option value="<?= $itm['id'] ?>"<?= $selected ?>><?= $itm['name'] ?></option>
                                            <?
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <?
                            break;
                    }
                }
                ?>
            </div>
            <div class="delimiter"></div>
            <? if (count($arResult['ITEM']['location']) > 0): ?>
                <div class="map _mt">
                    <input id="map-location" type="hidden" name="location"
                           value="<?= implode(',', $arResult['ITEM']['location']) ?>">
                    <?php
                    if ($mapType == 'google') {
                        ?>
                        <div id="search-map" class="search-map group tbl">
                            <div class="tbc">
                                <input id="map-address" class="form-control" type="textbox"
                                       placeholder="<?= Loc::getMessage('USER_ITEM_DETAIL_SEARCH_IN_MAP') ?>" value="">
                            </div>
                            <div class="tbc">
                                <button id="map-submit" class="btn btn-orange btn-fluid">
                                    <?= Loc::getMessage('USER_ITEM_DETAIL_FIND') ?>
                                </button>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                    <div id="<?= $mapType ?>-map" class="map"></div>
                </div>
                <div class="delimiter"></div>
            <? endif ?>

            <h4><?= Loc::getMessage('USER_ITEM_DETAIL_COMPONENT_YOUTUBE') ?></h4>
            <input type="text" name="youtube" value="<?= $arResult['VIDEO'] ?>"
                   placeholder="<?= Loc::getMessage('USER_ITEM_DETAIL_COMPONENT_YOUTUBE_PLACEHOLDER') ?>">

            <h4><?= Loc::getMessage('USER_ITEM_DETAIL_TITLE_DESC') ?></h4>
            <div class="group">
                <textarea<?= (($moderation == 1) ? ' disabled' : false) ?>
                        rows="6" class="form-control"
                        name="description"><?= $arResult['ITEM']['description'] ?></textarea>
            </div>
            <div id="check-required" class="warning-message _mt --dn">
                <?= Loc::getMessage('USER_ITEM_DETAIL_COMPONENT_ERROR') ?>
            </div>
            <?php
            if (!$moderation) {
                ?>
                <div class="buttons _mt">
                    <?php
                    if ($activationCost && $datediff <= 0) {
                        ?>
                        <button type="submit" class="save">
                            <?= Loc::getMessage('USER_ITEM_DETAIL_BTN_SUBMIT_PAYMENT', ['#SUM#' => $activationCost, '#CURRENCY#' => $currencyName]) ?>
                        </button>
                        <?php
                    } else {
                        ?>
                        <button type="submit" class="save">
                            <?= Loc::getMessage('USER_ITEM_DETAIL_BTN_SUBMIT') ?>
                        </button>
                        <?php
                    }
                    ?>
                    <button class="remove">
                        <?= Loc::getMessage('USER_ITEM_DETAIL_BTN_REMOVE') ?>
                    </button>
                    <?php
                    if ($datediff > 0) {
                        ?>
                        <button class="cancel">
                            <?= Loc::getMessage('USER_ITEM_DETAIL_BTN_CANCEL') ?>
                        </button>
                        <?php
                    }
                    ?>
                </div>
                <?php
            } else {
                if ($moderation == 2) {
                    ?>
                    <div class="buttons _mt">
                        <button type="submit" class="save">
                            <?= Loc::getMessage('USER_ITEM_DETAIL_COMPONENT_REPEAT_MODERATION') ?>
                        </button>
                    </div>
                    <?php
                }
            }
            ?>
        </form>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:user.menu',
            ''
        );

        if ($datediff > 0 && !$moderation) {
            ?>
            <div class="_box _mt">
                <div class="detail-actions">
                    <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post">
                        <input type="text" name="promo" value="" autocomplete="off"
                               placeholder="<?= Loc::getMessage('DETAIL_COMPONENT_PROMOCODE') ?>">
                        <button type="submit" class="_mt">
                            <?= Loc::getMessage('DETAIL_COMPONENT_PROMOCODE_APPLY') ?>
                        </button>
                        <div class="detail-attention">
                            <?= Loc::getMessage('DETAIL_COMPONENT_PROMOCODE_DESCRIPTION') ?>
                        </div>
                    </form>
                </div>
            </div>
            <div class="_box _mt">
                <div class="detail-actions">
                    <?php
                    if (intval(Option::get(DBOARD, 'up_option_cost')) > 0) {
                        ?>
                        <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post">
                            <input type="hidden" name="setOption" value="up">
                            <button type="submit">
                                <?php
                                echo Loc::getMessage(
                                    'DETAIL_COMPONENT_RAISE_AD',
                                    [
                                        '#SUM#' => intval(Option::get(DBOARD, 'up_option_cost')),
                                        '#CURRENCY#' => $currencyName
                                    ]
                                );
                                ?>
                            </button>
                        </form>
                        <?php
                    }

                    if (intval(Option::get(DBOARD, 'color_option_cost')) > 0) {
                        ?>
                        <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post">
                            <input type="hidden" name="setOption" value="color">
                            <button type="submit">
                                <?php
                                echo Loc::getMessage(
                                    'DETAIL_COMPONENT_COLOR_AD',
                                    [
                                        '#SUM#' => intval(Option::get(DBOARD, 'color_option_cost')),
                                        '#CURRENCY#' => $currencyName,
                                        '#DAYS#' => Utils::declension(
                                            intval(Option::get(DBOARD, 'color_option_period')),
                                            [
                                                Loc::getMessage('DETAIL_COMPONENT_DAYS_1'),
                                                Loc::getMessage('DETAIL_COMPONENT_DAYS_2'),
                                                Loc::getMessage('DETAIL_COMPONENT_DAYS_3')
                                            ]
                                        )
                                    ]
                                );
                                ?>
                            </button>
                        </form>
                        <?php
                    }

                    if (intval(Option::get(DBOARD, 'vip_option_cost')) > 0) {
                        ?>
                        <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post">
                            <input type="hidden" name="setOption" value="vip">
                            <button type="submit">
                                <?php
                                echo Loc::getMessage(
                                    'DETAIL_COMPONENT_VIP_AD',
                                    [
                                        '#SUM#' => intval(Option::get(DBOARD, 'vip_option_cost')),
                                        '#CURRENCY#' => $currencyName,
                                        '#DAYS#' => Utils::declension(
                                            intval(Option::get(DBOARD, 'vip_option_period')),
                                            [
                                                Loc::getMessage('DETAIL_COMPONENT_DAYS_1'),
                                                Loc::getMessage('DETAIL_COMPONENT_DAYS_2'),
                                                Loc::getMessage('DETAIL_COMPONENT_DAYS_3')
                                            ]
                                        )
                                    ]
                                );
                                ?>
                            </button>
                        </form>
                        <?php
                    }

                    if (intval(Option::get(DBOARD, 'premium_option_cost')) > 0) {
                        ?>
                        <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post">
                            <input type="hidden" name="setOption" value="premium">
                            <button type="submit">
                                <?php
                                echo Loc::getMessage(
                                    'DETAIL_COMPONENT_PREMIUM_AD',
                                    [
                                        '#SUM#' => intval(Option::get(DBOARD, 'premium_option_cost')),
                                        '#CURRENCY#' => $currencyName,
                                        '#DAYS#' => Utils::declension(
                                            intval(Option::get(DBOARD, 'premium_option_period')),
                                            [
                                                Loc::getMessage('DETAIL_COMPONENT_DAYS_1'),
                                                Loc::getMessage('DETAIL_COMPONENT_DAYS_2'),
                                                Loc::getMessage('DETAIL_COMPONENT_DAYS_3')
                                            ]
                                        )
                                    ]
                                );
                                ?>
                            </button>
                        </form>
                        <?php
                    }

                    if (intval(Option::get(DBOARD, 'turbo_option_cost')) > 0) {
                        ?>
                        <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post">
                            <input type="hidden" name="setOption" value="turbo">
                            <button type="submit">
                                <?php
                                echo Loc::getMessage(
                                    'DETAIL_COMPONENT_TURBO_AD',
                                    [
                                        '#SUM#' => intval(Option::get(DBOARD, 'turbo_option_cost')),
                                        '#CURRENCY#' => $currencyName
                                    ]
                                );
                                ?>
                            </button>
                        </form>
                        <?php
                    }
                    ?>
                </div>
            </div>
            <?php
        }
        ?>
    </div>

    <script>
        var __path = '<?=$APPLICATION->GetCurPage(false)?>',
            siteTemplatePath = '<?= SITE_TEMPLATE_PATH ?>',
            __currentImageQuantity = <?=$currentImageQty?>,
            __allowImageQuantity = <?=$allowImageQuantity?>,
            __maxImageSize = parseInt('<?=intval(Option::get(DBOARD, 'max_image_size'))?>'),
            __defaultLocation = JSON.parse('<?= Json::encode($arResult['ITEM']['location'])?>'),
            __ajaxPath = '<?=$this->GetFolder()?>/ajax.php',
            __mainImage = '<?=Loc::getMessage('USER_ITEM_DETAIL_MAIN_IMAGE')?>',
            __cancelConfirmMessage = '<?=Loc::getMessage('USER_ITEM_DETAIL_CANCEL_CONFIRM')?>',
            __removeConfirmMessage = '<?=Loc::getMessage('USER_ITEM_DETAIL_REMOVE_CONFIRM')?>',
            chartData = JSON.parse('<?= Json::encode($arResult['COMBINED_STAT']) ?>'),
            lineChartLableText = '<?= Loc::getMessage('USER_ITEM_DETAIL_CHART_LABLE_TEXT') ?>',
            lineChartLablePhoneText = '<?= Loc::getMessage('USER_ITEM_DETAIL_CHART_LABLE_PHONE_TEXT') ?>',
            lineChartTitle = '<?= Loc::getMessage('USER_ITEM_DETAIL_CHART_TITLE') ?>';
    </script>
<?
if (method_exists($this, 'createFrame')) {
    $frame->end();
}
