<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 06.10.2018
 * Time: 14:11
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['USER_ITEM_DETAIL_TITLE'] = 'Редактирование объявления';
$MESS['USER_ITEM_DETAIL_TITLE_MODERATION'] = 'На модерации';
$MESS['USER_ITEM_DETAIL_TITLE_MODERATION_REJECTED'] = 'Данное объявление отклонено модератором';
$MESS['USER_ITEM_DETAIL_DROPZONE_PLACEHOLDER1'] = 'Выберите фотографии';
$MESS['USER_ITEM_DETAIL_DROPZONE_PLACEHOLDER2'] = 'Вы можете добавить до #QTY# фото. Допустимые форматы: .jpg, .png';
$MESS['USER_ITEM_DETAIL_DROPZONE_PLACEHOLDER3'] = 'Вы можете добавить максимум #QTY# фото.';
$MESS['USER_ITEM_DETAIL_TITLE_IMAGES'] = 'Изображения до';
$MESS['USER_ITEM_DETAIL_TITLE_CATEGORY'] = 'Категория';
$MESS['USER_ITEM_DETAIL_CATEGORY_NOTSELECTED'] = 'Не выбрана';
$MESS['USER_ITEM_DETAIL_MAIN_IMAGE'] = 'Главное фото';
$MESS['USER_ITEM_DETAIL_TITLE_DESC'] = 'Описание товара';
$MESS['USER_ITEM_DETAIL_BTN_SUBMIT'] = 'Сохранить и опубликовать';
$MESS['USER_ITEM_DETAIL_BTN_SUBMIT_PAYMENT'] = 'Сохранить и опубликовать за #SUM# #CURRENCY#';
$MESS['USER_ITEM_DETAIL_TITLE_PRODUCT'] = 'Название';
$MESS['USER_ITEM_DETAIL_TITLE_PRICE'] = 'Цена';
$MESS['USER_ITEM_DETAIL_TITLE_CITY'] = 'Рынок';
$MESS['USER_ITEM_DETAIL_SELECT_VARIANT'] = '--Выберите вариант--';
$MESS['USER_ITEM_DETAIL_TITLE_MAP'] = 'Местоположение';
$MESS['USER_ITEM_DETAIL_HIDE'] = 'Скрыть';
$MESS['USER_ITEM_DETAIL_SEARCH_IN_MAP'] = 'Искать на карте';
$MESS['USER_ITEM_DETAIL_FIND'] = 'Найти';
$MESS['USER_ITEM_DETAIL_IN_MODERATION'] = 'В настоящий момент это объявление проверяется модератором.<br>В случае успешной проверки модератором, объявление будет опубликовано в каталоге.';
$MESS['USER_ITEM_DETAIL_STATISTICS_TITLE'] = 'Статистика объявления';
$MESS['USER_ITEM_DETAIL_CHART_LABLE_TEXT'] = 'Просмотров';
$MESS['USER_ITEM_DETAIL_CHART_LABLE_PHONE_TEXT'] = 'Просмотров телефона';
$MESS['USER_ITEM_DETAIL_CHART_TITLE'] = 'Статистика просмотров за 30 дней';
$MESS['USER_ITEM_DETAIL_CANCEL_CONFIRM'] = 'Вы действительно хотите снять объявление с публикации? Объявление будет недоступно в каталоге, и все имеющиеся опции будут отменены!';
$MESS['USER_ITEM_DETAIL_REMOVE_CONFIRM'] = 'Вы действительно хотите полностью удалить это объявление? Восстановление невозможно!';
$MESS['USER_ITEM_DETAIL_BTN_CANCEL'] = 'Снять с публикации';
$MESS['USER_ITEM_DETAIL_BTN_REMOVE'] = 'Удалить';
$MESS['USER_ITEM_DETAIL_COMPONENT_EXPIRED'] = 'Срок публикации этого объявления истёк. В случае необходимости, Вы можете опубликовать его повторно.';
$MESS['USER_ITEM_DETAIL_COMPONENT_EXPIRED_PAYMENT'] = 'Срок публикации этого объявления истёк. В случае необходимости, Вы можете опубликовать его повторно за #SUM# #CURRENCY#';
$MESS['USER_ITEM_DETAIL_COMPONENT_CONTINUE'] = 'Срок публикации истекает #DATE# ';
$MESS['USER_ITEM_DETAIL_COMPONENT_CONTINUE_BTN'] = 'Продлить за #PRICE# #CURRENCY#';
$MESS['USER_ITEM_DETAIL_COMPONENT_ACITVE'] = 'Объявление опубликовано до #DATE#';
$MESS['USER_ITEM_DETAIL_COMPONENT_ERROR'] = 'Заполните обязательные поля';
$MESS['USER_ITEM_DETAIL_COMPONENT_SHOW_IN_SITE'] = 'Просмотреть на сайте';
$MESS['USER_ITEM_DETAIL_COMPONENT_REPEAT_MODERATION'] = 'Отправить на проверку';

$MESS['DROPZONE_ERROR_LIMIT'] = 'Вы добавили максимальное количество изображений';

$MESS['DETAIL_COMPONENT_RAISE_AD'] = 'Поднять объявление за #SUM# #CURRENCY#';
$MESS['DETAIL_COMPONENT_COLOR_AD'] = 'Выделить цветом за #SUM# #CURRENCY# на #DAYS#';
$MESS['DETAIL_COMPONENT_VIP_AD'] = 'VIP объявление за #SUM# #CURRENCY# на #DAYS#';
$MESS['DETAIL_COMPONENT_PREMIUM_AD'] = 'Премиум объявление за #SUM# #CURRENCY# на #DAYS#';
$MESS['DETAIL_COMPONENT_TURBO_AD'] = 'ТУРБО (все услуги сразу) за #SUM# #CURRENCY#';
$MESS['DETAIL_COMPONENT_DAYS_1'] = 'день';
$MESS['DETAIL_COMPONENT_DAYS_2'] = 'дня';
$MESS['DETAIL_COMPONENT_DAYS_3'] = 'дней';
$MESS['DETAIL_COMPONENT_SERVICE_VIP'] = 'VIP';
$MESS['DETAIL_COMPONENT_SERVICE_PREMIUM'] = 'Premium';
$MESS['DETAIL_COMPONENT_SERVICE_COLORS_STATUS'] = 'Выделение цветом';
$MESS['DETAIL_COMPONENT_PROMOCODE'] = 'XXXXXXXXXX';
$MESS['DETAIL_COMPONENT_PROMOCODE_APPLY'] = 'Применить промокод';
$MESS['DETAIL_COMPONENT_PROMOCODE_DESCRIPTION'] = 'Если у Вас есть промокод, Вы можете применить его к этому объявлению';
$MESS['USER_ITEM_DETAIL_COMPONENT_YOUTUBE'] = 'Видео из YouTube';
$MESS['USER_ITEM_DETAIL_COMPONENT_YOUTUBE_PLACEHOLDER'] = 'Вставьте ссылку на видео в это поле';