<?php
/**
 * Date: 21.04.2020
 * Time: 09:07
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
$MESS['CLASS_SERVICE_ACTIVATION_DESCRIPTION'] = 'Повторная активация объявления ID:#ID#';
$MESS['CLASS_SERVICE_UP_DESCRIPTION'] = 'Услуга разового поднятия в каталоге для объявления ID:#ID#';
$MESS['CLASS_SERVICE_COLOR_DESCRIPTION'] = 'Услуга выделения цветом в каталоге для объявления ID:#ID#';
$MESS['CLASS_SERVICE_VIP_DESCRIPTION'] = 'Услуга "VIP" для объявления ID:#ID#';
$MESS['CLASS_SERVICE_PREMIUM_DESCRIPTION'] = 'Услуга "Premium" для объявления ID:#ID#';
$MESS['CLASS_SERVICE_TURBO_DESCRIPTION'] = 'Пакет "Турбо" для объявления ID:#ID#';
