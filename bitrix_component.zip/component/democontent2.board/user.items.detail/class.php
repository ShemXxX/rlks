<?php
/**
 * Date and Time: 22.07.2020, 9:26
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

use Bitrix\Main\Application;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Democontent2\Board\Balance\Account;
use Democontent2\Board\Iblock\Item;
use Democontent2\Board\Iblock\Properties;
use Democontent2\Board\Iblock\Stat;
use Democontent2\Board\Iblock\YouTube;
use Democontent2\Board\Order;
use Democontent2\Board\Promo;

class UserItemDetailComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        global $USER;
        global $APPLICATION;
        if ($USER->IsAuthorized()) {
            $request = Application::getInstance()->getContext()->getRequest();
            $item = new Item(0);
            $item->setUserId(intval($USER->GetID()));
            $item->setIBlockId(intval($this->arParams['iBlockId']));
            $item->setItemId(intval($this->arParams['itemId']));

            $this->arResult['ITEM'] = $item->getItem();


            if(empty($this->arResult['ITEM']['location'])) {

            // get market from item
          $itemId = $arResult['ITEM']['id'];
          $db_props = CIBlockElement::GetProperty($this->arParams['iBlockId'], $this->arParams['itemId'], array("sort" => "asc"), Array("CODE"=>"__hidden_city"));
          if($ar_props = $db_props->Fetch())
            $marketId = $ar_props['VALUE'];
          else
            $marketId = false;

          if ($marketId) {
            // get market coordinates
            $db_props = CIBlockElement::GetProperty(IntVal(1), $marketId, array("sort" => "asc"), Array
            ("CODE"=>"hidden_coordinates"));
            if($ar_props = $db_props->Fetch())
              $coordinates = $ar_props['VALUE'];
            else
              $coordinates = false;

          }
          $this->arResult['ITEM']['location'] = explode(',',$coordinates);
            }



            if (count($this->arResult['ITEM']) > 0) {
                if ($request->isPost()) {
                    if (!intval($this->arResult['ITEM']['moderation'])) {
                        $dateEnd = strtotime($this->arResult['ITEM']['activeTo']);
                        $dateNow = strtotime(date('Y-m-d H:i:s'));
                        $datediff = ($dateEnd - $dateNow) / (60 * 60 * 24);

                        if ($request->getPost('cancel') && intval($request->getPost('cancel')) > 0) {
                            switch (intval($request->getPost('cancel'))) {
                                case 1:
                                    if ($datediff > 0) {
                                        $item->cancel();
                                    }
                                    break;
                                case 2:
                                    $item->remove();
                                    break;
                            }
                            LocalRedirect(SITE_DIR . 'user/items/', true);
                        } else {
                            if ($datediff > 0) {
                                if ($request->getPost('promo')) {
                                    $promo = new Promo(
                                        $request->getPost('promo'),
                                        $item->getUserId(),
                                        $item->getItemId()
                                    );
                                    $promo->setIBlockId($item->getIBlockId());
                                    $promo->apply();
                                    LocalRedirect($APPLICATION->GetCurPage(false), true);
                                }

                                if ($request->getPost('setOption')) {
                                    $order = new Order($item->getUserId());
                                    $order->setItemId($item->getItemId());
                                    $order->setAdditionalParams(
                                        [
                                            $item->getIBlockId() => [
                                                $item->getItemId()
                                            ]
                                        ]
                                    );

                                    switch ($request->getPost('setOption')) {
                                        case 'up':
                                        case 'color':
                                        case 'vip':
                                        case 'premium':
                                        case 'turbo':
                                            $order->setType($request->getPost('setOption'));
                                            $order->setSum(intval(Option::get(
                                                    DBOARD,
                                                    $request->getPost('setOption') . '_option_cost'))
                                            );
                                            $order->setDescription(
                                                Loc::getMessage(
                                                    'CLASS_SERVICE_' . ToUpper($request->getPost('setOption')) . '_DESCRIPTION',
                                                    [
                                                        '#ID#' => $item->getItemId()
                                                    ]
                                                )
                                            );
                                            break;
                                    }

                                    $account = new Account($item->getUserId());
                                    $balance = $account->getAmount();

                                    if ($balance >= $order->getSum()) {
                                        if ($order->make(true)) {
                                            $order->setPayed(true);

                                            $account->setAmount($order->getSum());
                                            $account->setDescription(
                                                Loc::getMessage(
                                                    'CLASS_SERVICE_' . ToUpper($request->getPost('setOption')) . '_DESCRIPTION',
                                                    [
                                                        '#ID#' => $item->getItemId()
                                                    ]
                                                )
                                            );
                                            $account->withdrawal();
                                        }
                                    } else {
                                        $order->make();
                                        if ($order->getRedirect()) {
                                            LocalRedirect($order->getRedirect(), true);
                                        }
                                    }
                                    LocalRedirect($APPLICATION->GetCurPage(false), true);
                                }
                                $item->save($_POST);
                            } else {
                                $activationCost = intval(Option::get(DBOARD, 'activation_option_cost'));
                                if (!$activationCost) {
                                    $item->activation();
                                    $item->save($_POST);
                                } else {
                                    $order = new Order($item->getUserId());
                                    $order->setType('activation');
                                    $order->setSum($activationCost);
                                    $order->setItemId($item->getItemId());
                                    $order->setAdditionalParams([
                                        $item->getIBlockId() => [$item->getItemId()]
                                    ]);
                                    $order->setDescription(Loc::getMessage('CLASS_SERVICE_ACTIVATION_DESCRIPTION'));

                                    $account = new Account($item->getUserId());
                                    $balance = $account->getAmount();
                                    if ($balance >= $order->getSum()) {
                                        if ($order->make(true)) {
                                            $order->setPayed(true);
                                            $account->setAmount($order->getSum());
                                            $account->setDescription(
                                                Loc::getMessage(
                                                    'CLASS_SERVICE_ACTIVATION_DESCRIPTION',
                                                    ['#ID#' => $item->getItemId()]
                                                )
                                            );
                                            $account->withdrawal();
                                        }
                                    } else {
                                        $order->make();
                                        if ($order->getRedirect()) {
                                            LocalRedirect($order->getRedirect(), true);
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        if (intval($this->arResult['ITEM']['moderation']) == 2) {
                            $item->save($_POST, true);
                        }
                    }
                    LocalRedirect($APPLICATION->GetCurPage(false), true);
                }

                $ytb = new YouTube($item->getItemId());
                $this->arResult['VIDEO'] = $ytb->getVideo();

                $stat = new Stat($item->getItemId(), $item->getIBlockId());
                $properties = new Properties(intval($this->arParams['iBlockId']));
                $stat->setTtl(3600);
                $properties->setTtl(0);
                $this->arResult['PROPERTIES'] = $properties->all();
                $this->arResult['STAT'] = $stat->month();

                $stat->setTablePostfix('phone');
                $this->arResult['PHONE_STAT'] = $stat->month();

                $graphCounter = 0;
                $time = time();
                $days = [];
                for ($i = 0; $i < 30; $i++) {
                    if ($i == 0) {
                        $d = date('d.m', $time);
                        $days[$d] = array(
                            'shows' => 0,
                            'phone' => 0
                        );

                        foreach ($this->arResult['STAT'] as $stat) {
                            if (date('d.m', strtotime($stat['UF_DATE'])) == $d) {
                                $days[$d]['shows'] = intval($stat['CNT']);
                                $graphCounter++;
                                break;
                            }
                        }

                        foreach ($this->arResult['PHONE_STAT'] as $stat) {
                            if (date('d.m', strtotime($stat['UF_DATE'])) == $d) {
                                $days[$d]['phone'] = intval($stat['CNT']);
                                $graphCounter++;
                                break;
                            }
                        }
                    } else {
                        $d = date('d.m', ($time - (86400 * $i)));
                        $days[$d] = array(
                            'shows' => 0,
                            'phone' => 0
                        );

                        foreach ($this->arResult['STAT'] as $stat) {
                            if (date('d.m', strtotime($stat['UF_DATE'])) == $d) {
                                $days[$d]['shows'] = intval($stat['CNT']);
                                $graphCounter++;
                                break;
                            }
                        }

                        foreach ($this->arResult['PHONE_STAT'] as $stat) {
                            if (date('d.m', strtotime($stat['UF_DATE'])) == $d) {
                                $days[$d]['phone'] = intval($stat['CNT']);
                                $graphCounter++;
                                break;
                            }
                        }
                    }
                }

                $this->arResult['SHOW_GRAPH'] = $graphCounter;
                $this->arResult['COMBINED_STAT'] = array_reverse($days);

                $this->includeComponentTemplate();
            } else {
                LocalRedirect(SITE_DIR, true);
            }
        } else {
            LocalRedirect(SITE_DIR, true);
        }
    }
}
