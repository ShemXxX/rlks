$(document).ready(function () {
    if ($('.slider-range').length > 0) {
        $('.slider-range').each(function () {
            var min = $(this).data('min'),
                max = $(this).data('max');
            var minV = $(this).data('min-value'),
                maxV = $(this).data('max-value'),
                step = $($(this).data('step') === '') ? 1 : $(this).data('step'),
                inpMin = $(this).closest('.item').find('.inp-min'),
                inpMax = $(this).closest('.item').find('.inp-max');
            var sl = $(this).slider({
                range: true,
                min: min,
                max: max,
                step: step,
                values: [minV, maxV],
                create: function () {
                    inpMin.val($(this).slider('values', 0))
                    inpMax.val($(this).slider('values', 1))
                },
                slide: function (event, ui) {
                    inpMin.val(sl.slider('values', 0))
                    inpMax.val(sl.slider('values', 1))
                },
                stop: function (event, ui) {
                    inpMin.val(sl.slider('values', 0))
                    inpMax.val(sl.slider('values', 1))
                },
            });
            $(inpMin, inpMax).bind("keydown", function (e) {
                var ths = $(this);
                var keyKode = e.keyCode;
                if (keyKode > 95 && keyKode < 106 || keyKode > 47 && keyKode < 58 || keyKode === 8 || keyKode === 46 || keyKode === 9) {
                } else return false;
            });
            $(inpMin).change(function () {
                var val = parseInt($(this).val()),
                    slMaxVal = sl.slider('values', 1);
                if (val < slMaxVal) {
                    sl.slider('values', 0, val)
                } else {
                    sl.slider('values', 0, slMaxVal)
                    $(this).val(slMaxVal)
                }

            });
            $(inpMax).change(function () {
                var val = parseInt($(this).val()),
                    slMinVal = sl.slider('values', 0);
                if (val > slMinVal) {
                    sl.slider('values', 1, val)
                } else {
                    sl.slider('values', 1, slMinVal)
                    $(this).val(slMinVal)
                }
            });
        });
    }
});