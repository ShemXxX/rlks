<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 01.10.2018
 * Time: 11:53
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['FILTER_BTN_RESET'] = 'Сбросить';
$MESS['FILTER_BTN_SEND'] = 'Применить';
$MESS['FILTER_TITLE'] = 'Фильтр';
$MESS['FILTER_FROM'] = 'от';
$MESS['FILTER_TO'] = 'до';
$MESS['FILTER_PHOTOS_ONLY'] = 'Только с фото';
$MESS['FILTER_MAP'] = 'Показать на карте';
$MESS['FILTER_LIST'] = 'Показать списком';