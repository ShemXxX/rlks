<?php
/*
 * Date and Time: 19.02.2021, 10:52
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

if (!count($arResult['ITEMS'])) {
    return;
}

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Application;

$request = Application::getInstance()->getContext()->getRequest();
$filterProperties = [];
if ($request->get('prop') && is_array($request->get('prop'))) {
    $filterProperties = $request->get('prop');
}

?>
    <form>
        <div class="filter">
            <?php
            foreach ($arResult['ITEMS'] as $key => $item) {
                $i++;
                switch ($item['type']) {
                    case 'integer':
                        $min = $item['min'];
                        $max = $item['max'];
                        if ($min == $max) {
                            $min = 0;
                        }

                        $currentMin = $min;
                        $currentMax = $max;

                        if (isset($filterProperties[$item['id']]) && is_array($filterProperties[$item['id']])) {
                            if (isset($filterProperties[$item['id']][0])) {
                                if (intval($filterProperties[$item['id']][0]) >= $min) {
                                    $currentMin = intval($filterProperties[$item['id']][0]);
                                }
                            }

                            if (isset($filterProperties[$item['id']][1])) {
                                if (intval($filterProperties[$item['id']][1]) <= $max) {
                                    $currentMax = intval($filterProperties[$item['id']][1]);
                                }
                            }
                        }
                        ?>
                        <div class="item" data-id="<?= $item['id'] ?>" data-type="input">
                            <div class="title">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <g>
                                        <path d="M7.41 8.295L12 12.875L16.59 8.295L18 9.705L12 15.705L6 9.705L7.41 8.295Z"
                                              fill="#4F4F4F"/>
                                    </g>
                                </svg>
                                <div class="name"><?= $item['name'] ?>
                                    <div id="input-ind-<?= $item['id'] ?>"></div>
                                </div>
                            </div>
                            <div class="inputs" id="inputs-<?= $item['id'] ?>">
                                <div>
                                    <div class="close">
                                        <div></div>
                                        <div></div>
                                    </div>
                                    <input placeholder="<?= Loc::getMessage('FILTER_FROM') ?> <?= $min ?>"
                                           data-type="integer" data-min="<?= $min ?>" data-max="<?= $max ?>"
                                           name="prop[<?= $item['id'] ?>][]" value="<?= $currentMin ?>">
                                </div>
                                <div>
                                    <div class="close">
                                        <div></div>
                                        <div></div>
                                    </div>
                                    <input placeholder="<?= Loc::getMessage('FILTER_TO') ?> <?= $max ?>"
                                           data-type="integer" data-min="<?= $min ?>" data-max="<?= $max ?>"
                                           name="prop[<?= $item['id'] ?>][]" value="<?= $currentMax ?>">
                                </div>
                            </div>
                        </div>
                        <?php
                        break;
                    case 'list':
                        ?>
                        <div class="item" data-id="<?= $item['id'] ?>" data-type="dropdown">
                            <div class="title">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <g>
                                        <path d="M7.41 8.295L12 12.875L16.59 8.295L18 9.705L12 15.705L6 9.705L7.41 8.295Z"
                                              fill="#4F4F4F"/>
                                    </g>
                                </svg>
                                <div class="name"><?= $item['name'] ?>
                                    <div id="dropdown-ind-<?= $item['id'] ?>"></div>
                                </div>
                            </div>
                            <div class="dropdown" id="dropdown-<?= $item['id'] ?>">
                                <ul>
                                    <li>
                                        <?php
                                        foreach ($item['values'] as $property) {
                                            $checked = '';
                                            if (isset($filterProperties[$item['id']])) {
                                                if (in_array($property['id'], $filterProperties[$item['id']])) {
                                                    $checked = ' checked';
                                                }
                                            }
                                            ?>
                                            <label class="filter-checkbox-label-<?= $item['id'] ?>"><?= $property['name'] ?>
                                                <input type="checkbox" id="input-<?= $property['id'] ?>"
                                                       name="prop[<?= $item['id'] ?>][]"
                                                       value="<?= $property['id'] ?>"<?= $checked ?>>
                                                <span class="checkbox" data-id="<?= $item['id'] ?>"></span>
                                            </label>
                                            <?php
                                        }
                                        ?>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <?php
                        break;
                }
            }
            ?>
            <div class="item">
                <div class="dropdown active">
                    <ul>
                        <li>
                            <label><?= Loc::getMessage('FILTER_PHOTOS_ONLY') ?>
                                <input type="checkbox" name="onlyPhoto" id="onlyPhoto"
                                    <?= ((Application::getInstance()->getContext()->getRequest()->get('onlyPhoto')) ? ' checked' : '') ?>>
                                <span class="checkbox"></span>
                            </label>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <button class="apply _mt" type="submit">
            <?= Loc::getMessage('FILTER_BTN_SEND') ?>
        </button>
    </form>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}