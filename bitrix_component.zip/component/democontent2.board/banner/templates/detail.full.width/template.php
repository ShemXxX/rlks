<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 18.10.2018
 * Time: 14:25
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}
$banner = CAdvBanner::Show($arParams['TYPE']);
if (strlen($banner) > 0) {
    ?>
    <div class="product-info">
        <div class="white-block" style="text-align: center;">
            <?= $banner ?>
        </div>
    </div>
    <?php
} else {
    if (\Bitrix\Main\IO\File::isFileExists(
        \Bitrix\Main\IO\Path::normalize(
            \Bitrix\Main\Application::getDocumentRoot() . SITE_TEMPLATE_PATH . "/inc/lang/" . USER_LANG_PATH . "advert/detail.full.width.php"
        )
    )) {
        $APPLICATION->IncludeComponent(
            "bitrix:main.include", "",
            array(
                "AREA_FILE_SHOW" => "file",
                "PATH" => SITE_TEMPLATE_PATH . "/inc/lang/" . USER_LANG_PATH . "advert/detail.full.width.php",
                "EDIT_TEMPLATE" => "include_areas_template.php",
                'MODE' => 'php'
            ),
            false
        );
    } else {
        $APPLICATION->IncludeComponent(
            "bitrix:main.include", "",
            array(
                "AREA_FILE_SHOW" => "file",
                "PATH" => SITE_TEMPLATE_PATH . "/inc/advert/detail.full.width.php",
                "EDIT_TEMPLATE" => "include_areas_template.php",
                'MODE' => 'php'
            ),
            false
        );
    }
}
if (method_exists($this, 'createFrame')) {
    $frame->end();
}