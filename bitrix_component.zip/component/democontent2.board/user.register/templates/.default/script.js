$(document).ready(function () {
    $('input[type="phone"]').mask('+' + BX.message('phoneFormat') + BX.message('phoneMask'));
});