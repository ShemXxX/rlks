<?php
/**
 * Date and Time: 27.07.2020, 15:02
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Application;
use Bitrix\Main\ArgumentNullException;
use Bitrix\Main\ArgumentOutOfRangeException;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Page\Asset;

if (Option::get(DBOARD, 'reCaptchaPublic')
    && Option::get(DBOARD, 'reCaptchaSecret')) {
    Asset::getInstance()->addString('<script src="https://www.google.com/recaptcha/api.js?onload=onLoadReCaptcha&render=explicit" async defer></script>');
}

$request = Application::getInstance()->getContext()->getRequest();
$verifyCodeLength = 4;
try {
    $_length = intval(Option::get(DBOARD, 'sms_verify_length'));
    if ($_length > 4 && $_length < 11) {
        $verifyCodeLength = $_length;
    }
} catch (ArgumentNullException $e) {
} catch (ArgumentOutOfRangeException $e) {
}

?>
<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12"></div>
<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
    <h1><?= Loc::getMessage('USER_REGISTER_COMPONENT_H1') ?></h1>
    <div class=" _box">
        <?php
        if ($request->get('error')) {
            ?>
            <div class="danger-message _mb">
                <?= Loc::getMessage('USER_REGISTER_COMPONENT_ERROR') ?>
            </div>
            <?php
        }
        ?>
        <form action="<?= SITE_DIR ?>user/register/" class="edit-form" method="post">
            <input type="hidden" name="verify" value="<?= $request->get('verify') ?>">
            <input type="hidden" name="hash" value="<?= $request->get('hash') ?>">
            <div class="info-message">
                <?= Loc::getMessage('USER_REGISTER_COMPONENT_NAME') ?>
            </div>
            <div class="delimiter"></div>
            <div class="digits">
                <?php
                $i = 0;
                while ($i < $verifyCodeLength) {
                    $i++;
                    ?>
                    <div class="item">
                        <input id="code<?= $i ?>" class="verify-code" data-i="<?= $i ?>" type="text" maxlength="1"
                               name="code[]"
                               placeholder="X"<?= ($i == 1) ? ' autofocus' : '' ?><?= ($i > 1) ? ' disabled' : '' ?>>
                    </div>
                    <?php
                }
                ?>
            </div>
            <div id="reCaptcha" class="_mt _mb"></div>
            <button class="apply" type="submit">
                <?= Loc::getMessage('USER_REGISTER_COMPONENT_SUBMIT') ?>
            </button>
            <label>
                <?= Loc::getMessage('USER_REGISTER_COMPONENT_AGREEMENT') ?>
            </label>
        </form>
    </div>
</div>
<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12"></div>
<script>
    var __reCaptchaInit = 0;
    <?php
    if (Option::get(DBOARD, 'reCaptchaPublic') && Option::get(DBOARD, 'reCaptchaSecret')) {
    ?>
    __reCaptchaInit = 1;
    var reCaptchaPublicKey = '<?=Option::get(DBOARD, 'reCaptchaPublic')?>';
    var reCaptcha = null;
    var onLoadReCaptcha = function () {
        reCaptcha = grecaptcha.render('reCaptcha', {
            'sitekey': reCaptchaPublicKey,
            'theme': 'light'
        });
    };
    <?php
    }
    ?>
</script>
