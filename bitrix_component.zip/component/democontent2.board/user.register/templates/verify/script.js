let codeCounter = 0;
$(document).ready(function () {
    $('input[class="verify-code"]').mask('9');

    $('.verify-code').each(function () {
        codeCounter++;
    });

    $('.verify-code').on('keyup', function (e) {
        let id = parseInt($(this).data('i'));
        let val = parseInt($(this).val())

        if (!isNaN(val)) {
            if (id < codeCounter) {
                $('#code' + (id + 1)).prop('disabled', false).focus();
            }
        } else {
            if (e.keyCode === 8) {
                if (id > 1) {
                    $('#code' + (id - 1)).focus();
                    $('.verify-code').each(function () {
                        let _id = parseInt($(this).data('i'));
                        if (_id > (id - 1)) {
                            $('#code' + _id).prop('disabled', true).val('');
                        }
                    });
                }
            } else {
                $('.verify-code').each(function () {
                    let _id = parseInt($(this).data('i'));
                    if (_id > id) {
                        $('#code' + _id).prop('disabled', true).val('');
                    }
                });
            }
        }
    });
});