<?php
/**
 * Date and Time: 27.07.2020, 15:03
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

$MESS['USER_REGISTER_COMPONENT_ERROR'] = 'Не верный код подтверждения.<br>Попробуйте ещё раз.';
$MESS['USER_REGISTER_COMPONENT_H1'] = 'Активация аккаунта';
$MESS['USER_REGISTER_COMPONENT_NAME'] = 'Введите код подтверждения отправленный Вам ранее в СМС сообщении';
$MESS['USER_REGISTER_COMPONENT_SUBMIT'] = 'Подтвердить';
$MESS['USER_REGISTER_COMPONENT_AGREEMENT'] = 'Регистрируясь на сайте, Вы подтверждаете что ознакомились и принимаете условия изложенные в пользовательском соглашении';

