<?php
/**
 * Date and Time: 28.07.2020, 11:27
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Application;
use Bitrix\Main\ArgumentNullException;
use Bitrix\Main\ArgumentOutOfRangeException;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\SystemException;
use Bitrix\Main\Type\ParameterDictionary;
use Democontent2\Board\Sign;
use Democontent2\Board\Sms;
use Democontent2\Board\User;
use ReCaptcha\ReCaptcha;

class UserRegisterComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        global $USER;

        if ($USER->IsAuthorized()) {
            LocalRedirect(SITE_DIR, true);
        }

        $request = Application::getInstance()->getContext()->getRequest();

        $this->arResult['ERROR'] = '';

        if ($request->isPost()) {
            $requestData = $request->getPostList();

            try {
                $this->activateAccount($requestData, $USER);
                $this->register($requestData, $USER);
            } catch (ArgumentNullException $e) {
            } catch (ArgumentOutOfRangeException $e) {
            } catch (SystemException $e) {
            }
        }

        if ($request->get('verify') && $request->get('hash')) {
            if (Option::get(DBOARD, 'defaultSmsGate')
                && intval(Option::get(DBOARD, 'sms_verify'))) {
                if (intval($request->get('verify')) > 0 && strlen($request->get('hash')) == 32) {
                    $this->setTemplateName('verify');
                }
            }
        }

        $this->includeComponentTemplate();
    }

    /**
     * @param ParameterDictionary $requestData
     * @param CUser $USER
     * @throws ArgumentNullException
     * @throws ArgumentOutOfRangeException
     * @throws SystemException
     */
    private function activateAccount(ParameterDictionary $requestData, CUser $USER): void
    {
        if ($requestData->get('verify') && $requestData->get('hash') && $requestData->get('code')) {
            if (intval($requestData->get('verify')) > 0 && strlen($requestData->get('hash')) == 32) {
                $allow = true;
                if (Option::get(DBOARD, 'reCaptchaPublic')
                    && Option::get(DBOARD, 'reCaptchaSecret')) {
                    $secret = Option::get(DBOARD, 'reCaptchaSecret');
                    $reCaptcha = new ReCaptcha($secret);
                    $response = $reCaptcha->verify(
                        $requestData->get('g-recaptcha-response'),
                        Application::getInstance()->getContext()->getServer()->get('REMOTE_ADDR')
                    );

                    $allow = $response->isSuccess();
                }

                if ($allow) {
                    $us = new User(0);
                    if (count($requestData->get('code')) == $us->getVerifyCodeLength()) {
                        $code = implode('', $requestData->get('code'));
                        $us->setVerifyId(intval($requestData->get('verify')));
                        $us->setVerifyCode($code);

                        if (md5(Sign::getInstance()->get() . $us->getVerifyId() . $us->getVerifyCode()) == $requestData->get('hash')) {
                            $id = $us->verifyAndActivate();
                            if ($id > 0) {
                                $USER->Authorize($id);
                                LocalRedirect(SITE_DIR, true);
                            } else {
                                LocalRedirect(SITE_DIR . 'user/register/?error=1&verify=' . $us->getVerifyId()
                                    . '&hash=' . md5(Sign::getInstance()->get() . $us->getVerifyId() . $us->getVerifyCode()));
                            }
                        } else {
                            LocalRedirect(SITE_DIR . 'user/register/?error=1&verify=' . $us->getVerifyId()
                                . '&hash=' . md5(Sign::getInstance()->get() . $us->getVerifyId() . $us->getVerifyCode()));
                        }
                    }
                }
            }
        }
    }

    /**
     * @param ParameterDictionary $requestData
     * @param CUser $USER
     * @throws ArgumentNullException
     * @throws ArgumentOutOfRangeException
     * @throws SystemException
     */
    private function register(ParameterDictionary $requestData, CUser $USER): void
    {
        if ($requestData->get('name') && $requestData->get('email') && $requestData->get('phone')) {
            $allow = true;
            if (Option::get(DBOARD, 'reCaptchaPublic')
                && Option::get(DBOARD, 'reCaptchaSecret')) {
                $secret = Option::get(DBOARD, 'reCaptchaSecret');
                $reCaptcha = new ReCaptcha($secret);
                $response = $reCaptcha->verify(
                    $requestData->get('g-recaptcha-response'),
                    Application::getInstance()->getContext()->getServer()->get('REMOTE_ADDR')
                );

                $allow = $response->isSuccess();
            }

            if ($allow) {
                $us = new User(0);
                $us->setName($requestData->get('name'));
                $us->setEmail($requestData->get('email'));
                $us->setPhone($requestData->get('phone'));
                $userId = $us->register();
                if ($userId > 0) {
                    if ($us->getVerifyId() == $userId) {
                        if (Option::get(DBOARD, 'defaultSmsGate')) {
                            try {
                                $sms = new Sms();
                                $sms->setUserId($userId);
                                $sms->setPhone($us->getPhone());
                                $sms->setText(Loc::getMessage('USER_REGISTER_COMPONENT_SEND_CODE', [
                                    '#CODE#' => $us->getVerifyCode()
                                ]));
                                $sms->make();

                                if (strlen($sms->getError())) {
                                    $us->verifyAndActivate();
                                } else {
                                    LocalRedirect(SITE_DIR . 'user/register/?verify=' . $us->getVerifyId()
                                        . '&hash=' . md5(Sign::getInstance()->get() . $us->getVerifyId() . $us->getVerifyCode()));
                                }
                            } catch (ArgumentNullException $e) {
                            } catch (ArgumentOutOfRangeException $e) {
                            }
                        } else {
                            $us->verifyAndActivate();
                        }
                    }

                    $USER->Authorize($userId);
                    LocalRedirect(SITE_DIR, true);
                } else {
                    $this->arResult['ERROR'] = Loc::getMessage('USER_REGISTER_COMPONENT_CLASS_REGISTER_ERROR');

                    if ($us->getVerifyId() && $us->getVerifyCode()) {
                        LocalRedirect(SITE_DIR . 'user/register/?verify=' . $us->getVerifyId()
                            . '&hash=' . md5(Sign::getInstance()->get() . $us->getVerifyId() . $us->getVerifyCode()));
                    }
                }
            } else {
                $this->arResult['ERROR'] = Loc::getMessage('USER_REGISTER_COMPONENT_CLASS_RECAPTCHA_ERROR');
            }
        } else {
            $this->arResult['ERROR'] = Loc::getMessage('FIELDS_ERROR');
        }
    }
}
