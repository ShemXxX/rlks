<?php
/*
 * Date and Time: 26.08.2020, 9:55
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

$MESS['SIMILAR_COMPONENT_TITLE'] = 'Похожие объявления';
$MESS['CONFIRM_DELETE'] = 'Вы действительно хотите удалить этот элемент?';
$MESS['MORE_IMAGES'] = 'Ещё #QTY# фото';
