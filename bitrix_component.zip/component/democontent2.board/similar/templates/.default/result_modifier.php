<?php
/**
 * Date: 27.04.2020
 * Time: 13:18
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Democontent2\Board\Iblock\Favourites;

global $USER;

$arResult['FAVOURITES'] = [];
if ($USER->IsAuthorized()) {
    $ids = [];
    foreach ($arResult['ITEMS'] as $item) {
        $ids[] = $item['UF_ID'];
    }
    $favourites = new Favourites(intval($USER->GetID()));
    $arResult['FAVOURITES'] = $favourites->checkIdsByUser($ids);
}
