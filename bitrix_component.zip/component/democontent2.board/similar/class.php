<?php
/*
 * Date and Time: 09.12.2020, 10:07
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

use Bitrix\Main\Application;
use Bitrix\Main\ArgumentNullException;
use Bitrix\Main\ArgumentOutOfRangeException;
use Democontent2\Board\Iblock\City;
use Democontent2\Board\Iblock\Similar;
use Democontent2\Board\Utils as UtilsAlias;

class SimilarComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        global $USER;

        $request = Application::getInstance()->getContext()->getRequest();
        $this->arResult['IS_AUTHORIZED'] = $USER->IsAuthorized();
        $this->arResult['CITIES'] = [];
        if (isset($this->arParams['CITIES'])) {
            $this->arResult['CITIES'] = $this->arParams['CITIES'];
        }
        if (!intval($request->getCookie('skipCity'))) {
            $city = new City();
            $cityParams = [];

            if (isset($this->arParams['CITY_ID']) && intval($this->arParams['CITY_ID']) > 0) {
                $cityParams = $city->getById(intval($this->arParams['CITY_ID']));
            } else {
                if (intval($request->getCookie('current_city')) > 0) {
                    $cityParams = $city->getById(intval($request->getCookie('current_city')));
                }
            }

            if (!count($cityParams)) {
                $cityParams = $city->getDefault();
            }

            $items = new Similar(intval($cityParams['id']));
            $items->setExcludeId(intval($this->arParams['EXCLUDE_ID']));
            $items->setIBlockId(intval($this->arParams['IBLOCK_ID']));
            $items->setDepth1(intval($this->arParams['SECTION_DEPTH_1']));
            $items->setSectionId(intval($this->arParams['SECTION_ID']));
            $this->arResult['ITEMS'] = $items->get();
        } else {
            $items = new Similar(0);
            $items->setExcludeId(intval($this->arParams['EXCLUDE_ID']));
            $items->setIBlockId(intval($this->arParams['IBLOCK_ID']));
            $items->setDepth1(intval($this->arParams['SECTION_DEPTH_1']));
            $items->setSectionId(intval($this->arParams['SECTION_ID']));
            $items->setSkipCity(true);
            $this->arResult['ITEMS'] = $items->get();
        }

        $ut = new UtilsAlias();
        try {
            if ($ut->getView($request) == 'list') {
                $this->setTemplateName('list');
            }
        } catch (ArgumentNullException $e) {
        } catch (ArgumentOutOfRangeException $e) {
        }

        $this->includeComponentTemplate();
    }
}
