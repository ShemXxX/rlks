<?php
/*
 * Date and Time: 17.11.2020, 9:25
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

use Bitrix\Main\Application;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Context;
use Bitrix\Main\Engine\Response\Json;
use Bitrix\Main\IO\File;
use Bitrix\Main\IO\Path;
use Bitrix\Main\Loader;

$request = Context::getCurrent()->getRequest();
$result = 0;

global $USER;

if ($request->isAjaxRequest() && $request->isPost() && $USER->IsAuthorized()) {
    if ($request->getPost('unreaded') && intval($request->getPost('unreaded')) > 0) {
        if (Loader::includeModule('democontent2.board')) {
            $uidHash = md5($USER->GetID());
            $login = Option::get(DBOARD, 'mongoAdminLogin');
            $password = Option::get(DBOARD, 'mongoAdminPassword');

            if ($login && $password) {
                if (!class_exists('ComposerAutoloaderInitb3b8815b1cff1dcd9b07af68330d7c45')) {
                    if (File::isFileExists(Path::normalize(Application::getDocumentRoot() . '/local/lib/MongoDB/vendor/autoload.php'))) {
                        include_once Path::normalize(Application::getDocumentRoot() . '/local/lib/MongoDB/vendor/autoload.php');
                    }
                }

                $client = new \MongoDB\Client(\Democontent2\Board\Utils::__mongoDbConnectString());
                $db = $client->selectDatabase(\Democontent2\Board\Utils::__mongoDbName())->selectCollection('rooms');
                $rooms = $db->find(
                    [
                        '$or' => [
                            [
                                'user1' => $uidHash
                            ],
                            [
                                'user2' => $uidHash
                            ]
                        ]
                    ],
                    [
                        'sort' => [
                            'time' => -1
                        ]
                    ]
                );
                foreach ($rooms as $room) {
                    $room['unread'] = 0;
                    $db = $client->selectDatabase(\Democontent2\Board\Utils::__mongoDbName())->selectCollection('messages');
                    $unreadCounter = $db->aggregate(
                        [
                            [
                                '$match' => [
                                    'roomId' => (string)$room->_id,
                                    'userId' => (($room->user1 == $uidHash) ? $room->user2 : $room->user1),
                                    'status' => 0
                                ],
                            ],
                            [
                                '$group' => [
                                    '_id' => 1,
                                    'count' => [
                                        '$sum' => 1
                                    ]
                                ]
                            ]
                        ]
                    );
                    foreach ($unreadCounter as $unread) {
                        $result += intval($unread->count);
                    }
                }
            }
        }
    }
}

$r = new Json([
    'result' => $result
]);
$r->send();
