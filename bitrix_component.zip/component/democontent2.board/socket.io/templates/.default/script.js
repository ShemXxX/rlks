var socket;
var chatNotification = true;
$(document).ready(function () {
    socket = io.connect(__nodeJsHost, {query: 'username=' + username});
    socket.emit('add user', username);
    socket.on(username + ' new message', (data) => {
        if (chatNotification) {
            mediaMessage();
            $.notify({
                title: decodeURIComponent(data.userName),
                message: decodeURIComponent(data.message),
                url: __siteDir + 'user/direct/#!' + data.roomId,
            }, {
                position: 'fixed',
                placement: {
                    from: "bottom",
                    align: "right"
                },
                animate: {
                    enter: 'animated fadeInUp',
                    exit: 'animated fadeOutDown'
                },
                type: 'success',
                delay: 5000,
                template: '<div data-notify="container" class="col-xs-11 col-sm-3 alert alert-{0}" role="alert">' +
                    '<button type="button" aria-hidden="true" class="close" data-notify="dismiss">×</button>' +
                    '<div data-notify="title" class="bold">{1}</div> ' +
                    '<div data-notify="message">{2}</div>' +
                    '<div class="progress" data-notify="progressbar">' +
                    '<div class="progress-bar progress-bar-{0}" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>' +
                    '</div>' +
                    '<a href="{3}" target="{4}" data-notify="url"></a>' +
                    '</div>'
            });

            getUnreadedMessages();
        }
    });

    getUnreadedMessages();
});

function getUnreadedMessages() {
    $.ajax({
        type: 'POST',
        url: __socketIoTemplatePath + "/ajax.php",
        dataType: "json",
        data: 'unreaded=1',
        success: function (data) {
            if (data.result > 0) {
                $('.messages.indicator').addClass('active');
            } else {
                $('.messages.indicator').removeClass('active');
            }
        },
    });
}

function ChatLnk(count) {
    var regex = __siteDir + 'user/direct/',
        url = document.location.href;
    if (!url.match(regex)) {
        if ($('.chat-lnk').length > 0) {
            $('.chat-lnk').remove();
        }
        $('body').append('<a class="chat-lnk btn btn-round btn-blue" target="_blank" href="/user/direct/"><div class="icon-wrap"><div class="count">' + count + '</div><svg class="icon icon_chat"> <use xlink:href="' + __siteTemplatePath + '/images/sprite-svg.svg#chat"></use></svg> </div>Чат</a>');
    }
}

function mediaMessage() {
    var audio = new Audio();
    audio.src = __socketIoTemplatePath + '/mediaNewMessage.mp3';
    audio.autoplay = true;
}

function mediaMessageShipped() {
    var audio = new Audio();
    audio.src = __socketIoTemplatePath + '/shipped.mp3';
    audio.autoplay = true;
}