<?php
/**
 * Date: 27.04.2020
 * Time: 09:14
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Web\Json;

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

$cityCode = '';
if (defined('DBOARD_CITY')) {
    $cityCode = 'city-' . DBOARD_CITY . '/';
}

$categories = [];
foreach ($arResult['ITEMS'] as $k => $v) {
    $categories[] = [
        'name' => $v['name'],
        'url' => SITE_DIR . $cityCode . $k . '/',
    ];
}
?>
    <div class="_box">
        <div class="inner-menu collapse active">
            <div class="title collapse active">
                <?= Loc::getMessage('CATEGORIES_COMPONENT_USER_MENU') ?>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g>
                        <path d="M7.41 8.295L12 12.875L16.59 8.295L18 9.705L12 15.705L6 9.705L7.41 8.295Z"
                              fill="#4F4F4F"/>
                    </g>
                </svg>
            </div>
            <div class="title__description">
                <?= Loc::getMessage('CATEGORIES_COMPONENT_USER_MENU_OPEN') ?>
            </div>
            <?php
            if (count($arResult['ITEMS']) > 8) {
                ?>
                <input class="_mb" id="cat-filter" placeholder="<?= Loc::getMessage('LIST_INPUT_NAME') ?>">
                <?php
            }
            ?>
            <div id="categories-nav">
                <?php
                foreach ($arResult['ITEMS'] as $k => $v) {
                    ?>
                    <div class="item">
                        <a href="<?= SITE_DIR ?><?= $cityCode ?><?= $k ?>/">
                            <?= $v['name'] ?>
                        </a>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>
    <script>
        BX.message({
            categoriesFilter: JSON.parse('<?=Json::encode($categories)?>')
        });
    </script>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}

