<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 25.09.2018
 * Time: 10:35
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Democontent2\Board\Utils as UtilsAlias;
/**
 * sgraf start
 */

// получаем группу пользователя
global $USER;
$userId = $USER->GetID();
$rsUser = CUser::GetByID($userId);
$arUser = $rsUser->Fetch();
$seller = true;
if (in_array(5, $USER->GetUserGroupArray())) {
  $seller = false;
} else if (in_array(6, $USER->GetUserGroupArray())) {
  $seller = true;

}

/**
 * sgraf end
 */


if (method_exists($this, 'createFrame')) {
	$frame = $this->createFrame()->begin();
}
?>
<div class="_box _mt">
	<div class="inner-menu collapse active">
		<div class="title collapse active">
			<?= Loc::getMessage('USER_MENU_COMPONENT_USER_MENU') ?>
			<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
				<g>
					<path d="M7.41 8.295L12 12.875L16.59 8.295L18 9.705L12 15.705L6 9.705L7.41 8.295Z"
								fill="#4F4F4F"/>
				</g>
			</svg>
		</div>

		<div class="title__description">
			<?= Loc::getMessage('USER_MENU_COMPONENT_USER_MENU_OPEN') ?>
		</div>
		<? if (($USER->IsAdmin() || UtilsAlias::isModerator($USER->GetGroups())) && $USER->IsAuthorized
		()) { ?>
		<div class="item">
			<a href="<?= SITE_DIR ?>user/moderation/">
				<?= Loc::getMessage('USER_MENU_COMPONENT_MODERATION') ?>
			</a>
		</div>
		<? }

		if ($USER->IsAdmin()) { ?>
		<div class="item">
			<a href="<?= SITE_DIR ?>user/translations/">
				<?= Loc::getMessage('USER_MENU_COMPONENT_TRANSLATIONS') ?>
			</a>
		</div>
		<div class="item">
			<a href="<?= SITE_DIR ?>user/complains/">
				<?= Loc::getMessage('USER_MENU_COMPLAINS') ?>
			</a>
		</div>
		<div class="item">
			<a href="<?= SITE_DIR ?>user/promo/">
				<?= Loc::getMessage('USER_MENU_COMPONENT_PROMO') ?>
			</a>
		</div>
		<? } ?>


		<? /** user is seller  */
		if ($seller === true) { ?>

		<div class="item">
			<a href="<?= SITE_DIR ?>user/items/">
				<?= Loc::getMessage('USER_MENU_COMPONENT_USER_MENU_ADV') ?>
			</a>
		</div>

		<div class="item">
			<a href="<?= SITE_DIR ?>user/pro/">
				<?= Loc::getMessage('USER_MENU_COMPONENT_USER_MENU_PRO') ?>
			</a>
		</div>

		<div class="item">
			<a href="<?= SITE_DIR ?>user/balance/">
				<?= Loc::getMessage('USER_MENU_COMPONENT_BALANCE') ?>
			</a>
		</div>
		<? if (intval(Option::get(DBOARD, 'chatEnabled')) > 0) { ?>
		<div class="item">
			<div class="messages indicator"></div>
			<a href="<?= SITE_DIR ?>user/direct/">
				<?= Loc::getMessage('USER_MENU_COMPONENT_USER_MENU_MESSAGES') ?>
			</a>
		</div>
		<? } ?>
		<div class="item">
			<a href="<?= SITE_DIR ?>user/feedback/">
				<?= Loc::getMessage('USER_MENU_COMPONENT_REVIEWS') ?>
			</a>
		</div>
		<div class="item">
			<a href="<?= SITE_DIR ?>user/favourites/">
				<?= Loc::getMessage('USER_MENU_COMPONENT_USER_MENU_FAVORITES') ?>
			</a>
		</div>
		<div class="item">
			<a href="<?= SITE_DIR ?>user/seller-data/">
				<?= Loc::getMessage('USER_MENU_SELLER_DATA') ?>
			</a>
		</div>



		<? } else { ?>
		<div class="item">
			<a href="<?= SITE_DIR ?>user/favourites/">
				<?= Loc::getMessage('USER_MENU_COMPONENT_USER_MENU_FAVORITES') ?>
			</a>
		</div>
		<div class="item">
			<a href="<?= SITE_DIR ?>user/feedback/">
				<?= Loc::getMessage('USER_MENU_COMPONENT_REVIEWS') ?>
			</a>
		</div>
		<? if ($arUser['UF_IS_SELLER'] == "1") { ?>
		<div class="item">
			<a href="<?= SITE_DIR ?>user/be-seller/">
        <?= Loc::getMessage('USER_MENU_BE_SELLER') ?>
			</a>
		</div>
    <? } ?>
		<? } ?>
		<div class="item">
			<a href="<?= SITE_DIR ?>user/settings/">
				<?= Loc::getMessage('USER_MENU_COMPONENT_USER_MENU_SETTINGS') ?>
			</a>
		</div>
		<div class="item">
			<a href="<?= SITE_DIR ?>user/exit/">
				<?= Loc::getMessage('USER_MENU_COMPONENT_USER_MENU_EXIT') ?>
			</a>
		</div>
	</div>
</div>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}