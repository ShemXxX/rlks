<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 25.09.2018
 * Time: 10:35
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Democontent2\Board\Utils as UtilsAlias;

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}
?>
    <section>
        <h5><?= Loc::getMessage('USER_MENU_COMPONENT_USER_MENU') ?></h5>
        <?php
        if (($USER->IsAdmin() || UtilsAlias::isModerator($USER->GetGroups())) && $USER->IsAuthorized()) {
            ?>
            <div class="side-menu__item">
                <a href="<?= SITE_DIR ?>user/moderation/" class="menu-second">
                    <?= Loc::getMessage('USER_MENU_COMPONENT_MODERATION') ?>
                </a>
            </div>
            <?php
        }

        if ($USER->IsAdmin()) {
            ?>
            <div class="side-menu__item">
                <a href="<?= SITE_DIR ?>user/translations/" class="menu-second">
                    <?= Loc::getMessage('USER_MENU_COMPONENT_TRANSLATIONS') ?>
                </a>
            </div>
            <div class="side-menu__item">
                <a href="<?= SITE_DIR ?>user/complains/" class="menu-second">
                    <?= Loc::getMessage('USER_MENU_COMPLAINS') ?>
                </a>
            </div>
            <div class="side-menu__item">
                <a href="<?= SITE_DIR ?>user/promo/" class="menu-second">
                    <?= Loc::getMessage('USER_MENU_COMPONENT_PROMO') ?>
                </a>
            </div>
            <?php
        }
        ?>
        <div class="side-menu__item">
            <a href="<?= SITE_DIR ?>user/balance/" class="menu-second">
                <?= Loc::getMessage('USER_MENU_COMPONENT_BALANCE') ?>
            </a>
        </div>
        <div class="side-menu__item">
            <a href="<?= SITE_DIR ?>user/pro/" class="menu-second">
                <?= Loc::getMessage('USER_MENU_COMPONENT_USER_MENU_PRO') ?>
            </a>
        </div>
        <?php
        if (intval(Option::get(DBOARD, 'chatEnabled')) > 0) {
            ?>
            <div class="side-menu__item">
                <a href="<?= SITE_DIR ?>user/direct/" class="menu-second">
                    <?= Loc::getMessage('USER_MENU_COMPONENT_USER_MENU_MESSAGES') ?>
                </a>
            </div>
            <?php
        }
        ?>
        <div class="side-menu__item">
            <a href="<?= SITE_DIR ?>user/feedback/" class="menu-second">
                <?= Loc::getMessage('USER_MENU_COMPONENT_REVIEWS') ?>
            </a>
        </div>
        <div class="side-menu__item">
            <a href="<?= SITE_DIR ?>user/items/" class="menu-second">
                <?= Loc::getMessage('USER_MENU_COMPONENT_USER_MENU_ADV') ?>
            </a>
        </div>
        <div class="side-menu__item">
            <a href="<?= SITE_DIR ?>user/favourites/" class="menu-second">
                <?= Loc::getMessage('USER_MENU_COMPONENT_USER_MENU_FAVORITES') ?>
            </a>
        </div>
        <div class="side-menu__item">
            <a href="<?= SITE_DIR ?>user/settings/" class="menu-second">
                <?= Loc::getMessage('USER_MENU_COMPONENT_USER_MENU_SETTINGS') ?>
            </a>
        </div>
        <div class="side-menu__item">
            <a href="<?= SITE_DIR ?>user/exit/" class="menu-second">
                <?= Loc::getMessage('USER_MENU_COMPONENT_USER_MENU_EXIT') ?>
            </a>
        </div>
    </section>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}