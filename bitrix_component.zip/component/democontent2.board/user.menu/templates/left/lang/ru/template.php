<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 25.09.2018
 * Time: 10:36
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['USER_MENU_COMPONENT_USER_MENU'] = 'Навигация';
$MESS['USER_MENU_COMPONENT_USER_MENU_OPEN'] = 'Нажмите, чтобы открыть';
$MESS['USER_MENU_COMPONENT_USER_MENU_ADV'] = 'Мои объявления';
$MESS['USER_MENU_COMPONENT_USER_MENU_PURCHASES'] = 'Мои покупки';
$MESS['USER_MENU_COMPONENT_USER_MENU_MESSAGES'] = 'Мои сообщения';
$MESS['USER_MENU_COMPONENT_USER_MENU_FEEDBACK'] = 'Отзывы';
$MESS['USER_MENU_COMPONENT_USER_MENU_SETTINGS'] = 'Настройки';
$MESS['USER_MENU_COMPONENT_USER_MENU_FAVORITES'] = 'Избранное';
$MESS['USER_MENU_COMPONENT_USER_MENU_HELP'] = 'Помощь';
$MESS['USER_MENU_COMPONENT_USER_MENU_EXIT'] = 'Выход';
$MESS['USER_MENU_COMPONENT_USER_MENU_PRO'] = 'PRO аккаунт';
$MESS['USER_MENU_COMPONENT_MODERATION'] = 'Модерация';
$MESS['USER_MENU_COMPONENT_PROMO'] = 'Промокоды';
$MESS['USER_MENU_COMPONENT_REVIEWS'] = 'Отзывы';
$MESS['USER_MENU_COMPONENT_BALANCE'] = 'Пополнение счёта';
$MESS['USER_MENU_BALANCE'] = 'Баланс:';
$MESS['USER_MENU_COMPONENT_TRANSLATIONS'] = 'Настройка мультиязычности';
$MESS['USER_MENU_COMPLAINS'] = 'Жалобы на объявления';