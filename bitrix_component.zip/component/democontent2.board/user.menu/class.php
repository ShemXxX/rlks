<?php
/**
 * Date and Time: 22.07.2020, 9:27
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

use Democontent2\Board\User;

class UserMenuComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        global $USER;

        $this->arResult['AUTHORIZED'] = $USER->IsAuthorized();
        $this->arResult['EMAIL'] = ($this->arResult['AUTHORIZED']) ? $USER->GetEmail() : false;

        if ($this->arResult['AUTHORIZED']) {
            $us = new User($USER->GetID());
            $this->arResult['USER'] = $us->get();
        }

        $this->includeComponentTemplate();
    }
}
