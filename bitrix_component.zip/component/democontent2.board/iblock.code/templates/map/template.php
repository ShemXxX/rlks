<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 08.10.2018
 * Time: 21:24
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}
$mapType = \Bitrix\Main\Config\Option::get(DBOARD, 'defaultMap');
switch ($mapType) {
    case 'google':

        \Bitrix\Main\Page\Asset::getInstance()->addJs('//developers.google.com/maps/documentation/javascript/examples/markerclusterer/markerclusterer.js');
        \Bitrix\Main\Page\Asset::getInstance()->addJs('//maps.googleapis.com/maps/api/js?key='
            . \Bitrix\Main\Config\Option::get(DBOARD, 'google_maps_api_key'));
        \Bitrix\Main\Page\Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/infobubble.js');
        break;
    default:
        \Bitrix\Main\Page\Asset::getInstance()->addJs('//api-maps.yandex.ru/2.1/?load=package.full&lang=ru-RU');
}


\Bitrix\Main\Page\Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/' . $mapType . '-search-map.js');
$currencyName = \Bitrix\Main\Config\Option::get(DBOARD, 'currency_name');
use Bitrix\Main\Localization\Loc;

?>
<?php
$APPLICATION->IncludeComponent(
    'democontent2.board:filter',
    '',
    array(
        'IBLOCK_ID' => $arResult['IBLOCK_ID']
    )
);
?>
    <div class="map-container" id="map"></div>
    <script>
        var locationLat = parseFloat(<?=$arResult['COORDINATES'][0]?>),
            locationLong = parseFloat(<?=$arResult['COORDINATES'][1]?>),
            ajaxPath = '<?=$this->GetFolder()?>/ajax.php',
            currencyName = '<?=$currencyName?>',
            premiumTxt = '<?=Loc::getMessage('MAP_COMPONENT_PREMIUM')?>',
            vipTxt = '<?=Loc::getMessage('MAP_COMPONENT_VIP')?>',
            stpath = '<?=SITE_TEMPLATE_PATH?>',
            mapItems = JSON.parse('<?=\Bitrix\Main\Web\Json::encode($arResult['ITEMS'])?>');
    </script>
<?php
if (method_exists($this, 'createFrame')) {
    try {
        $frame->end();
    } catch (\Bitrix\Main\NotSupportedException $e) {
    }
}
