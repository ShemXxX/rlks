<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 08.10.2018
 * Time: 21:25
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['IBLOCKCODE_COMPONENT_BTN_MORE'] = 'Подробнее';
$MESS['IBLOCKCODE_COMPONENT_CATEGORIES_TITLE'] = 'Категории';
$MESS['IBLOCKCODE_COMPONENT_CATEGORIES_TITLE_DESCRIPTION'] = 'Нажмите, чтобы открыть список';
$MESS['IBLOCKCODE_COMPONENT_ITEMS_EMPTY'] = 'В данной категории пока нет объявлений';
$MESS['CONFIRM_DELETE'] = 'Вы действительно хотите удалить этот элемент?';
$MESS['LIST_SORT_PRICE_UP'] = 'Дороже';
$MESS['LIST_SORT_PRICE_DOWN'] = 'Дешевле';
$MESS['LIST_SORT_DATE_UP'] = 'Новые';
$MESS['LIST_SORT_DATE_DOWN'] = 'Старые';
$MESS['LIST_SORT_POPULAR'] = 'Популярные';
$MESS['LIST_INPUT_NAME'] = 'Введите название';