<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 09.10.2018
 * Time: 14:55
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
global $APPLICATION;

$tempPath = [];

if (isset($arResult['TYPE_META']['UF_BREADCRUMB']) && strlen($arResult['TYPE_META']['UF_BREADCRUMB'])) {
    if (isset($arResult['CITY']['id']) && !$arResult['CITY']['default']) {
        $tempPath[] = 'city-' . $arResult['CITY']['code'];
    }
    $tempPath[] = $arParams['iBlockType'];

    $APPLICATION->AddChainItem($arResult['TYPE_META']['UF_BREADCRUMB'], SITE_DIR . implode('/', $tempPath) . '/');
} else {
    if (isset($arResult['TYPE_META']['UF_TITLE'])) {
        if (isset($arResult['CITY']['id']) && !$arResult['CITY']['default']) {
            $tempPath[] = 'city-' . $arResult['CITY']['code'];
        }
        $tempPath[] = $arParams['iBlockType'];
        $APPLICATION->AddChainItem($arResult['TYPE_META']['UF_TITLE'], SITE_DIR . implode('/', $tempPath) . '/');
    }
}

if (isset($arResult['META']['UF_BREADCRUMB']) && strlen($arResult['META']['UF_BREADCRUMB'])) {
    $APPLICATION->AddChainItem($arResult['META']['UF_BREADCRUMB']);
} else {
    if (isset($arResult['META']['UF_TITLE']) && strlen($arResult['META']['UF_TITLE'])) {
        $APPLICATION->AddChainItem($arResult['META']['UF_TITLE']);
    }
}

foreach ($arResult['META'] as $metaKey => $metaValue) {
    switch ($metaKey) {
        case 'UF_TITLE':
            if (strlen($metaValue) > 0) {
                $APPLICATION->SetTitle($metaValue);
                $APPLICATION->SetPageProperty('title', $metaValue);
            }
            break;
        case 'UF_DESCRIPTION':
            if (strlen($metaValue) > 0) {
                $APPLICATION->SetPageProperty('description', $metaValue);
            }
            break;
        case 'UF_KEYWORDS':
            if (strlen($metaValue) > 0) {
                $APPLICATION->SetPageProperty('keywords', $metaValue);
            }
            break;
    }
}