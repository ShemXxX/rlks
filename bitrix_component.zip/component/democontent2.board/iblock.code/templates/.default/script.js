$(document).ready(function () {
    $('.favourite').click(function () {
        let $this = $(this);
        let id = $this.attr('data-id');
        let i = $this.attr('data-i');
        $.ajax({
            type: 'POST',
            url: __ajaxPath + '/ajax.php',
            dataType: "json",
            data: 'id=' + id + '&i=' + i + '&type=like',
        });
    });
});