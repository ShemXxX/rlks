<?php
/**
 * Date: 15.04.2020
 * Time: 08:29
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (method_exists($this, 'setFrameMode')) {
    $this->setFrameMode(true);
}

use Bitrix\Main\Localization\Loc;

$cityCode = '';
if (defined('DBOARD_CITY')) {
    $cityCode = 'city-' . DBOARD_CITY . '/';
}
?>

<nav class="side-menu --dn" id="menu">
    <?php
    if ($USER->IsAuthorized()) {
        try {
            $APPLICATION->IncludeComponent(
                'democontent2.board:user.menu',
                'left'
            );
        } catch (\Exception $e) {

        }
    }

    $APPLICATION->IncludeComponent(
        "bitrix:menu",
        "top",
        [
            "ROOT_MENU_TYPE" => "top",
            "MENU_CACHE_TYPE" => "Y",
            "MENU_CACHE_TIME" => 86400 * 10,
            "MENU_CACHE_USE_GROUPS" => "Y",
            "MENU_CACHE_GET_VARS" => [],
            "MAX_LEVEL" => "1",
            "CHILD_MENU_TYPE" => "left",
            "USE_EXT" => "Y",
            "ALLOW_MULTI_SELECT" => "N"
        ],
        false
    );

    foreach ($arResult['ITEMS'] as $menuKey => $menuData) {
        if (!isset($menuData['items'])) {
            continue;
        }
        if (!count($menuData['items'])) {
            continue;
        }
        ?>
        <section>
            <h5><?= $menuData['name'] ?></h5>
            <?php
            foreach ($menuData['items'] as $item) {
                ?>
                <div class="side-menu__item">
                    <a class="menu-second" href="<?= SITE_DIR ?><?= $cityCode ?><?= $menuKey ?>/<?= $item['code'] ?>/"
                       id="item-<?= $menuKey ?>_<?= $item['code'] ?>">
                        <?= $item['name'] ?>
                        <?php
                        if (isset($item['items']) && count($item['items'])) {
                            ?>
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g>
                                    <path d="M7.41 8.295L12 12.875L16.59 8.295L18 9.705L12 15.705L6 9.705L7.41 8.295Z"
                                          fill="#4F4F4F"/>
                                </g>
                            </svg>
                            <?php
                        }
                        ?>
                    </a>
                    <?php
                    if (isset($item['items']) && count($item['items'])) {
                        ?>
                        <div class="hidden" id="hidden-item-<?= $menuKey ?>_<?= $item['code'] ?>">
                            <a href="<?= SITE_DIR ?><?= $cityCode ?><?= $menuKey ?>/<?= $item['code'] ?>/">
                                <?= Loc::getMessage('MENU_COMPONENT_CATALOG_SHOW_ALL') ?>
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <g>
                                        <path d="M16.125 9L13.125 6V8.25H1.875V9.75H13.125V12L16.125 9Z"
                                              fill="#4F4F4F"/>
                                    </g>
                                </svg>
                            </a>
                            <?php
                            $i = 0;
                            foreach ($item['items'] as $_item) {
                                if ($i == 10) {
                                    break;
                                }
                                $i++;
                                ?>
                                <a href="<?= SITE_DIR ?><?= $cityCode ?><?= $menuKey ?>/<?= $item['code'] ?>/<?= $_item['code'] ?>/">
                                    <?= $_item['name'] ?>
                                </a>
                                <?php
                            }
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                </div>
                <?php
            }
            ?>
        </section>
        <?php
    }
    ?>
</nav>

