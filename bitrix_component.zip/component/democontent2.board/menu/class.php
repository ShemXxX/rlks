<?php
/*
 * Date and Time: 21.10.2020, 8:59
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

use Bitrix\Main\Application;
use Democontent2\Board\Iblock\City;
use Democontent2\Board\Iblock\Menu;

class MenuClass extends CBitrixComponent
{
    public function executeComponent()
    {
        $request = Application::getInstance()->getContext()->getRequest();
        $city = new City();
        $this->arResult['ALL_CITIES'] = $city->getList();
        $_ = '';

        if (intval($request->getCookie('current_city'))) {
            if (isset($this->arResult['ALL_CITIES'][intval($request->getCookie('current_city'))])) {
                if (!$this->arResult['ALL_CITIES'][intval($request->getCookie('current_city'))]['default']) {
                    $_ = $this->arResult['ALL_CITIES'][intval($request->getCookie('current_city'))]['code'];
                }
            }
        }

        $menu = new Menu();
        $this->arResult['ITEMS'] = $menu->get();

        if (strlen($_) > 0) {
            if (!defined('DBOARD_CITY')) {
                define('DBOARD_CITY', $_);
            }
        }

        $this->IncludeComponentTemplate();
    }
}
