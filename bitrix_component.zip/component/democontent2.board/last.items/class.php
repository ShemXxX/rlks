<?php
/*
 * Date and Time: 02.02.2021, 9:44
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

use Bitrix\Main\Application;
use Democontent2\Board\Iblock\City;
use Democontent2\Board\Iblock\Iblock as IblockAlias;
use Democontent2\Board\Iblock\Items;

class LastItemsComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        global $USER;

        $request = Application::getInstance()->getContext()->getRequest();

        $city = new City();
        $this->arResult['CITIES'] = $city->getList();
        $this->arResult['IS_AUTHORIZED'] = $USER->IsAuthorized();
        $this->arResult['ITEMS'] = [];
        $this->arResult['ANOTHER_CITIES_ITEMS'] = [];

        if (!intval($request->getCookie('skipCity'))) {
            $city = new City();
            $cityParams = [];

            if (intval($request->getCookie('current_city')) > 0) {
                $cityParams = $city->getById(intval($request->getCookie('current_city')));
            }

            if (!count($cityParams)) {
                $cityParams = $city->getDefault();
            }

            $iblock = new IblockAlias();
            $items = new Items();

            if (isset($this->arParams['LIMIT']) && intval($this->arParams['LIMIT']) > 0) {
                $items->setLimit(intval($this->arParams['LIMIT']));
            }

            if (isset($this->arParams['CACHE_TIME']) && intval($this->arParams['CACHE_TIME']) > 0) {
                $items->setTtl(intval($this->arParams['CACHE_TIME']));
            } else {
                $items->setTtl(3600);
            }

            $this->arResult['ITEMS'] = $items->lastItems($iblock->getAllIds(), intval($cityParams['id']));

            if (!count($this->arResult['ITEMS'])) {
                $this->arResult['ANOTHER_CITIES_ITEMS'] = $items->lastItems($iblock->getAllIds(), 0);
            }
        } else {
            $iblock = new IblockAlias();
            $items = new Items();

            if (isset($this->arParams['LIMIT']) && intval($this->arParams['LIMIT']) > 0) {
                $items->setLimit(intval($this->arParams['LIMIT']));
            }

            if (isset($this->arParams['CACHE_TIME']) && intval($this->arParams['CACHE_TIME']) > 0) {
                $items->setTtl(intval($this->arParams['CACHE_TIME']));
            } else {
                $items->setTtl(3600);
            }

            $this->arResult['ITEMS'] = $items->lastItems($iblock->getAllIds(), 0);
        }

        $this->includeComponentTemplate();
    }
}
