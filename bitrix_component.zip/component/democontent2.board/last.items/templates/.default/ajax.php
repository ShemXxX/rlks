<?php
/*
 * Date and Time: 17.11.2020, 9:25
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

use Bitrix\Main\Context;
use Bitrix\Main\Engine\Response\Json;
use Bitrix\Main\Loader;
use Democontent2\Board\Iblock\Favourites;

$request = Context::getCurrent()->getRequest();
$error = 1;

global $USER;

if ($request->isAjaxRequest() && $request->isPost()) {
    if (Loader::includeModule('democontent2.board')) {
        if ($request->getPost('id') && $request->getPost('i')) {
            if (intval($request->getPost('id')) > 0 && intval($request->getPost('i')) > 0) {
                switch ($request->getPost('type')) {
                    case 'like':
                        if ($USER->IsAuthorized() && $request->getPost('i')) {
                            if (intval($request->getPost('i')) > 0) {
                                $favourites = new Favourites(
                                    intval($USER->GetID()),
                                    intval($request->getPost('i'))
                                );
                                $favourites->change(intval($request->getPost('id')));
                                $error = 0;
                            }
                        }
                        break;
                }
            }
        }
    }
}

$r = new Json([
    'error' => $error,
]);
$r->send();
