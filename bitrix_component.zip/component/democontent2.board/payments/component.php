<?php
/**
 * Date and Time: 22.07.2020, 9:20
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\HttpRequest;
use Democontent2\Board\Payment;
use Democontent2\Board\Sign;

if ($arParams['hash'] == Sign::getInstance()->get()) {
    $payment = new Payment();
    $payment->setSource(HttpRequest::getInput());
    $payment->setParams($_REQUEST);
    $payment->log();
    $payment->verify();
    $payment->getResult();
} else {
    CHTTP::SetStatus("404 Not Found");
}
