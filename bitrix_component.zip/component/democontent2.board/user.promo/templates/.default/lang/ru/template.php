<?php
/**
 * Date: 25.05.2020
 * Time: 13:40
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
$MESS['USER_PROMO_COMPONENT_H1'] = 'Промокоды';
$MESS['USER_PROMO_COMPONENT_TTL1'] = 'Код';
$MESS['USER_PROMO_COMPONENT_TTL2'] = 'Кол-во применений';
$MESS['USER_PROMO_COMPONENT_TTL3'] = 'Действителен до';
$MESS['USER_PROMO_EMPTY'] = 'Не найдено ни одного активного промокода';
$MESS['USER_PROMO_ADD'] = 'Добавить промокод';
