<?php
/**
 * Date: 25.05.2020
 * Time: 13:40
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}
?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('USER_PROMO_COMPONENT_H1') ?></h1>
        <?php
        if (!count($arResult['ITEMS'])) {
            ?>
            <div class="info-message">
                <?= Loc::getMessage('USER_PROMO_EMPTY') ?>
            </div>
            <?php
        }
        ?>
        <a href="<?= SITE_DIR ?>user/promo/?add=1" class="edit _mt _mb">
            <?= Loc::getMessage('USER_PROMO_ADD') ?>
        </a>
        <?php
        if (count($arResult['ITEMS'])) {
            ?>
            <div class="table">
                <div class="item head">
                    <div class="column">
                        <?= Loc::getMessage('USER_PROMO_COMPONENT_TTL1') ?>
                    </div>
                    <div class="column">
                        <?= Loc::getMessage('USER_PROMO_COMPONENT_TTL2') ?>
                    </div>
                    <div class="column">
                        <?= Loc::getMessage('USER_PROMO_COMPONENT_TTL3') ?>
                    </div>
                </div>
                <?php
                foreach ($arResult['ITEMS'] as $item) {
                    ?>
                    <div class="item">
                        <div class="column">
                            <a href="/bitrix/admin/highloadblock_row_edit.php?ENTITY_ID=<?= $arResult['HL_ID'] ?>&ID=<?= $item['ID'] ?>">
                                <?= $item['UF_CODE'] ?>
                            </a>
                        </div>
                        <div class="column">
                            <?= $item['UF_COUNTER'] ?>
                        </div>
                        <div class="column">
                            <?php
                            if ($item['UF_VALID_TO']) {
                                echo date('d.m.Y H:i:s', strtotime($item['UF_VALID_TO']));
                            }
                            ?>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
            <?php
        }
        ?>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:user.menu',
            ''
        );
        ?>
    </div>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}

