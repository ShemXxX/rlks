<?php
/**
 * Date: 27.05.2020
 * Time: 12:04
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
$MESS['USER_PROMO_COMPONENT_H1'] = 'Новый промокод';
$MESS['USER_PROMO_COMPONENT_ADD'] = 'Добавить';
$MESS['USER_PROMO_COMPONENT_CODE'] = 'Код';
$MESS['USER_PROMO_COMPONENT_CODE_PLACEHOLDER'] = 'Если оставить пустым, код будет сгенерирован автоматически';
$MESS['USER_PROMO_COMPONENT_MAX_APPLY'] = 'Максимальное кол-во применений (0 - без ограничений)';
$MESS['USER_PROMO_COMPONENT_MAX_APPLY_PLACEHOLDER'] = '0 - без ограничений';
$MESS['USER_PROMO_COMPONENT_USER'] = 'ID пользователя (0 или пусто - любой)';
$MESS['USER_PROMO_COMPONENT_USER_PLACEHOLDER'] = '0 или пусто - любой';
$MESS['USER_PROMO_COMPONENT_ACTIVE_FROM'] = 'Действителен с';
$MESS['USER_PROMO_COMPONENT_ACTIVE_FROM_PLACEHOLDER'] = 'Выберите дату, или оставьте пустым';
$MESS['USER_PROMO_COMPONENT_ACTIVE_TO'] = 'Действителен до';
$MESS['USER_PROMO_COMPONENT_ACTIVE_TO_PLACEHOLDER'] = 'Выберите дату, или оставьте пустым';
$MESS['USER_PROMO_COMPONENT_OPTIONS'] = 'Применяет опции';
$MESS['USER_PROMO_COMPONENT_OPTIONS_VIP'] = 'VIP';
$MESS['USER_PROMO_COMPONENT_OPTIONS_PREMIUM'] = 'Premium';
$MESS['USER_PROMO_COMPONENT_OPTIONS_COLOR'] = 'Выделение цветом';
$MESS['USER_PROMO_COMPONENT_OPTIONS_UP'] = 'Разовое поднятие';
