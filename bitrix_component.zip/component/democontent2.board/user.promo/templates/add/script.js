$(document).ready(function () {
    console.log(BX.message('minDate'));
    const from = document.querySelector('input[name="from"]');
    const to = document.querySelector('input[name="to"]');
    const dFrom = new Datepicker(from, {
        clearBtn: true,
        format: 'dd.mm.yyyy',
        defaultViewDate: new Date(BX.message('today')),
        minDate: new Date(BX.message('today')),
    });
    const dTo = new Datepicker(to, {
        clearBtn: true,
        format: 'dd.mm.yyyy',
        defaultViewDate: new Date(BX.message('today')),
        minDate: new Date(BX.message('today')),
    });
});