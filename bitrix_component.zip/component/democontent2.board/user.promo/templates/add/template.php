<?php
/**
 * Date: 27.05.2020
 * Time: 12:04
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Page\Asset;

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . '/lib/datepicker/css/datepicker.min.css');
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/lib/datepicker/js/datepicker-full.min.js');
?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('USER_PROMO_COMPONENT_H1') ?></h1>
        <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post" class="edit-form">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <label><?= Loc::getMessage('USER_PROMO_COMPONENT_CODE') ?></label>
                <input type="text" class="required" name="code" autocomplete="off"
                       placeholder="<?= Loc::getMessage('USER_PROMO_COMPONENT_CODE_PLACEHOLDER') ?>">
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <label><?= Loc::getMessage('USER_PROMO_COMPONENT_MAX_APPLY') ?></label>
                <input type="text" class="required" name="max_apply" value="1" autocomplete="off"
                       placeholder="<?= Loc::getMessage('USER_PROMO_COMPONENT_MAX_APPLY_PLACEHOLDER') ?>">
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <label><?= Loc::getMessage('USER_PROMO_COMPONENT_USER') ?></label>
                <input type="text" class="required" name="user" autocomplete="off"
                       placeholder="<?= Loc::getMessage('USER_PROMO_COMPONENT_USER_PLACEHOLDER') ?>">
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <label><?= Loc::getMessage('USER_PROMO_COMPONENT_ACTIVE_FROM') ?></label>
                <input type="text" class="required" name="from" autocomplete="off"
                       placeholder="<?= Loc::getMessage('USER_PROMO_COMPONENT_ACTIVE_FROM_PLACEHOLDER') ?>">
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <label><?= Loc::getMessage('USER_PROMO_COMPONENT_ACTIVE_TO') ?></label>
                <input type="text" class="required" name="to" autocomplete="off"
                       placeholder="<?= Loc::getMessage('USER_PROMO_COMPONENT_ACTIVE_TO_PLACEHOLDER') ?>">
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <label><?= Loc::getMessage('USER_PROMO_COMPONENT_OPTIONS') ?></label>
                <div>
                    <label for="vip">
                        <?= Loc::getMessage('USER_PROMO_COMPONENT_OPTIONS_VIP') ?>
                    </label>
                    <input id="vip" type="checkbox" name="options[vip]">
                </div>
                <div>
                    <label for="premium">
                        <?= Loc::getMessage('USER_PROMO_COMPONENT_OPTIONS_PREMIUM') ?>
                    </label>
                    <input id="premium" type="checkbox" name="options[premium]">
                </div>
                <div>
                    <label for="color">
                        <?= Loc::getMessage('USER_PROMO_COMPONENT_OPTIONS_COLOR') ?>
                    </label>
                    <input id="color" type="checkbox" name="options[color]">
                </div>
                <div>
                    <label for="up">
                        <?= Loc::getMessage('USER_PROMO_COMPONENT_OPTIONS_UP') ?>
                    </label>
                    <input id="up" type="checkbox" name="options[up]">
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <button class="apply _mt">
                    <?= Loc::getMessage('USER_PROMO_COMPONENT_ADD') ?>
                </button>
            </div>
        </form>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:user.menu',
            ''
        );
        ?>
    </div>
    <script>
        BX.message({
            today: '<?=date('Y-m-d')?>',
        });
    </script>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}

