<?php
/**
 * Date and Time: 22.07.2020, 9:28
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Application;
use Democontent2\Board\Promo;

class UserPromoComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        global $USER;
        if (!$USER->IsAuthorized()) {
            LocalRedirect(SITE_DIR, true);
        }

        $request = Application::getInstance()->getContext()->getRequest();
        $promo = new Promo('', 0);
        $this->arResult['HL_ID'] = $promo->getHlId();
        $this->arResult['ITEMS'] = $promo->getList();

        if (intval($request->get('add')) == 1) {
            $this->setTemplateName('add');
        }

        if ($request->isPost()) {
            if ($request->getPostList()->get('options')) {
                $params = [];
                if (isset($request->getPostList()->get('options')['vip'])) {
                    $params[] = 'vip';
                }
                if (isset($request->getPostList()->get('options')['premium'])) {
                    $params[] = 'premium';
                }
                if (isset($request->getPostList()->get('options')['color'])) {
                    $params[] = 'color';
                }
                if (isset($request->getPostList()->get('options')['up'])) {
                    $params[] = 'up';
                }

                if (count($params)) {
                    if ($request->getPostList()->get('code')) {
                        $promo->setCode($request->getPostList()->get('code'));
                    }
                    $promo->setUserId(intval($request->getPostList()->get('user')));
                    $promo->create($request, $params);
                    LocalRedirect(SITE_DIR . 'user/promo/', true);
                }
            }
        }

        $this->includeComponentTemplate();
    }
}
