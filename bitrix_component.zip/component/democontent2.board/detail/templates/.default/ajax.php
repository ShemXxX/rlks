<?php
/*
 * Date and Time: 17.11.2020, 9:18
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

\Bitrix\Main\Loader::includeModule('democontent2.board');

use Bitrix\Main\Application;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Context;
use Bitrix\Main\Engine\Response\Json;
use Bitrix\Main\IO\File;
use Bitrix\Main\IO\Path;
use Bitrix\Main\Mail\Event;
use Democontent2\Board\Iblock\Favourites;
use Democontent2\Board\Iblock\Item;
use Democontent2\Board\Iblock\Stat;
use Democontent2\Board\User;
use MongoDB\Client;

$request = Context::getCurrent()->getRequest();
$error = 1;
$result = [];

global $USER;

if ($request->isAjaxRequest() && $request->isPost()) {
    if ($request->getPost('type') && $request->getPost('id') && intval($request->getPost('id')) > 0) {
        switch ($request->getPost('type')) {
            case 'phone':
                if ($request->getPost('i') && intval($request->getPost('i')) > 0) {
                    $stat = new Stat(
                        intval($request->getPost('id')),
                        intval($request->getPost('i'))
                    );
                    $stat->setTablePostfix('phone');
                    if ($USER->IsAuthorized()) {
                        $stat->setUserId(intval($USER->GetID()));
                    }
                    $stat->set();
                    $error = 0;
                }
                break;
            case 'like':
                if ($USER->IsAuthorized() && $request->getPost('i') && intval($request->getPost('i')) > 0) {
                    $favourites = new Favourites(
                        intval($USER->GetID()),
                        intval($request->getPost('i'))
                    );
                    $favourites->change(intval($request->getPost('id')));
                    $error = 0;
                }
                break;
            case 'write':
                if ($USER->IsAuthorized()) {
                    if ($request->getPost('id') && intval($request->getPost('id')) > 0
                        && $request->getPost('i') && intval($request->getPost('i')) > 0
                        && $request->getPost('message') && strlen($request->getPost('message')) > 0) {

                        $item = new Item();
                        $item->setIBlockId(intval($request->getPost('i')));
                        $item->setItemId(intval($request->getPost('id')));

                        $owner = $item->getOwner();
                        if ($owner > 0 && $owner !== intval($USER->GetID())) {
                            if (!class_exists('ComposerAutoloaderInitb3b8815b1cff1dcd9b07af68330d7c45')) {
                                if (File::isFileExists(Path::normalize(Application::getDocumentRoot() . '/local/lib/MongoDB/vendor/autoload.php'))) {
                                    include_once Path::normalize(Application::getDocumentRoot() . '/local/lib/MongoDB/vendor/autoload.php');
                                }
                            }

                            $login = Option::get(DBOARD, 'mongoAdminLogin');
                            $password = Option::get(DBOARD, 'mongoAdminPassword');

                            if ($login && $password && intval(Option::get(DBOARD, 'chatEnabled'))) {
                                $id = '';
                                $client = new Client(\Democontent2\Board\Utils::__mongoDbConnectString());
                                $db = $client->selectDatabase(\Democontent2\Board\Utils::__mongoDbName())->selectCollection('rooms');
                                $rooms = $db->find(
                                    [
                                        '$and' => [
                                            [
                                                '$or' => [
                                                    [
                                                        'user1' => md5($USER->GetID())
                                                    ],
                                                    [
                                                        'user2' => md5($USER->GetID())
                                                    ]
                                                ]
                                            ],
                                            [
                                                '$or' => [
                                                    [
                                                        'user1' => md5($owner)
                                                    ],
                                                    [
                                                        'user2' => md5($owner)
                                                    ]
                                                ]
                                            ]
                                        ]
                                    ]
                                );
                                foreach ($rooms as $room) {
                                    $id = (string)$room->_id;
                                }

                                if (strlen($id) == 24) {
                                    $result['id'] = $id;
                                    $error = 0;

                                    $db = $client->selectDatabase(\Democontent2\Board\Utils::__mongoDbName())->selectCollection('messages');
                                    try {
                                        $us = new User(intval($USER->GetID()));
                                        $userParams = $us->get();

                                        $add = $db->insertOne(
                                            [
                                                'roomId' => $id,
                                                'time' => (time() * 1000),
                                                'status' => 0,
                                                'userId' => md5($USER->GetID()),
                                                'userName' => $userParams['NAME'],
                                                'userEmail' => $userParams['EMAIL'],
                                                'message' => trim(htmlspecialcharsbx(strip_tags($request->getPost('message')))),
                                                'ip' => Application::getInstance()->getContext()->getServer()->get('REMOTE_ADDR')
                                            ]
                                        );
                                        if (strlen((string)$add->getInsertedId()) == 24) {
                                            $result['userName'] = $userParams['NAME'];
                                            $result['messageId'] = (string)$add->getInsertedId();
                                            $error = 0;
                                        } else {
                                            $error = 1;
                                        }
                                    } catch (Exception $e) {
                                    }
                                } else {
                                    $user1Name = '';
                                    $user2Name = '';
                                    $user1Email = '';
                                    $user2Email = '';

                                    $us = new User(intval($USER->GetID()));
                                    $userParams = $us->get();
                                    $user1Name = $userParams['NAME'];
                                    $user1Email = $userParams['EMAIL'];

                                    $us = new User($owner);
                                    $userParams = $us->get();
                                    $user2Name = $userParams['NAME'];
                                    $user2Email = $userParams['EMAIL'];

                                    try {
                                        $add = $db->insertOne(
                                            [
                                                'time' => (time() * 1000),
                                                'user1' => md5($USER->GetID()),
                                                'user2' => md5($owner),
                                                'user1Name' => $user1Name,
                                                'user2Name' => $user2Name,
                                                'user1Email' => $user1Email,
                                                'user2Email' => $user2Email,
                                                'user1RealId' => intval($USER->GetID()),
                                                'user2RealId' => $owner,
                                                'creatorIp' => Application::getInstance()->getContext()->getServer()->get('REMOTE_ADDR')
                                            ]
                                        );
                                        if (strlen((string)$add->getInsertedId()) == 24) {
                                            $result['id'] = (string)$add->getInsertedId();
                                            $error = 0;

                                            $db = $client->selectDatabase(\Democontent2\Board\Utils::__mongoDbName())->selectCollection('messages');
                                            $addMessage = $db->insertOne(
                                                [
                                                    'roomId' => $result['id'],
                                                    'time' => (time() * 1000),
                                                    'status' => 0,
                                                    'userId' => md5($USER->GetID()),
                                                    'userName' => $user1Name,
                                                    'userEmail' => $user1Email,
                                                    'message' => trim(htmlspecialcharsbx(strip_tags($request->getPost('message')))),
                                                    'ip' => Application::getInstance()->getContext()->getServer()->get('REMOTE_ADDR')
                                                ]
                                            );
                                            if (strlen((string)$addMessage->getInsertedId()) == 24) {
                                                $result['userName'] = $user1Name;
                                                $result['messageId'] = (string)$addMessage->getInsertedId();
                                                $error = 0;

                                                $paramsForEmail = $item->getParamsForEmail();
                                                if (count($paramsForEmail)) {
                                                    //email notification
                                                    $siteDir = Option::get(DBOARD, 'siteDir');
                                                    $siteId = Option::get(DBOARD, 'siteId');
                                                    $site = new \CSite();
                                                    $siteList = $site->GetList(
                                                        $by = "sort",
                                                        $order = "desc",
                                                        [
                                                            'ID' => $siteId
                                                        ]
                                                    );
                                                    while ($res = $siteList->Fetch()) {
                                                        if (strlen($res['SERVER_NAME'])) {
                                                            $paramsForEmail = $this->getParamsForEmail();
                                                            if (count($paramsForEmail)) {
                                                                Event::send([
                                                                    'EVENT_NAME' => 'DBOARD_FIRST_MESSAGE',
                                                                    'LID' => $siteId,
                                                                    'C_FIELDS' => [
                                                                        'USER_ID' => $paramsForEmail['UF_USER_ID'],
                                                                        'USER_NAME' => $paramsForEmail['USER_NAME'],
                                                                        'USER_EMAIL' => $paramsForEmail['USER_EMAIL'],
                                                                        'ITEM_NAME' => $paramsForEmail['UF_NAME'],
                                                                        'IMAGE' => (strlen($paramsForEmail['IMAGE_PATH'])) ? 'http://' . Path::normalize($res['SERVER_NAME'] . $paramsForEmail['IMAGE_PATH']) : '',
                                                                        'ITEM_URL' => 'http://' . Path::normalize($res['SERVER_NAME'] . $siteDir
                                                                                . '/' . $paramsForEmail['UF_IBLOCK_TYPE'] . '/' . $paramsForEmail['UF_IBLOCK_CODE'] . '/' . $paramsForEmail['UF_CODE']) . '/',
                                                                        'USER_AREA_URL' => 'http://' . Path::normalize($res['SERVER_NAME'] . $siteDir . 'user/direct') . '/',
                                                                    ]
                                                                ]);
                                                            }
                                                        }
                                                    }
                                                }
                                            } else {
                                                $error = 1;
                                            }
                                        }
                                    } catch (Exception $e) {
                                    }
                                }
                            }
                        }
                    }
                }
                break;
        }
    }
}

$r = new Json([
    'error' => $error,
    'result' => $result
]);
$r->send();
