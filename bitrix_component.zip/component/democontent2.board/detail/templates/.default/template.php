<?php
/*
 * Date and Time: 09.12.2020, 10:17
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

if (method_exists($this, 'setFrameMode')) {
    $this->setFrameMode(true);
}

use Bitrix\Main\Application;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Page\Asset;
use Bitrix\Main\Page\AssetLocation;
use Bitrix\Main\Config\Option;
use Bitrix\Main\ModuleManager;
use Bitrix\Main\IO\File;
use Bitrix\Main\Loader;
use Bitrix\Main\IO\Path;
use Democontent2\Board\Utils;

$mapType = Option::get(DBOARD, 'defaultMap');

switch ($mapType) {
    case 'google':
        Asset::getInstance()->addJs('https://maps.googleapis.com/maps/api/js?language=' . ((USER_LANG == 'ru') ? 'ru' : 'en') . '&key='
            . Option::get(DBOARD, 'google_maps_api_key'));
        break;
    default:
        Asset::getInstance()->addJs(
            'https://api-maps.yandex.ru/2.1/?load=package.full&apikey=' . Option::get(DBOARD, 'yandex_maps_api_key') . '&lang=' . ((USER_LANG == 'ru') ? 'ru_RU' : 'en_US')
        );
}

Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/' . $mapType . '-map.js');
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/lib/timeago/jquery.timeago.js');

Asset::getInstance()->addString(
    '<script defer src="https://yastatic.net/es5-shims/0.0.2/es5-shims.min.js"></script>',
    true,
    AssetLocation::AFTER_JS
);
Asset::getInstance()->addString(
    '<script defer src="https://yastatic.net/share2/share.js"></script>',
    true,
    AssetLocation::AFTER_JS
);

$currencyName = Option::get(DBOARD, 'currency_name');
$images = [];
$characteristics = [];

if (!empty($arResult['UF_IMAGE_ID'])) {
    $images[] = $arResult['UF_IMAGE_ID'];
}

if (strlen($arResult['UF_IMAGES']) > 0) {
    $images = array_merge($images, unserialize($arResult['UF_IMAGES']));
}

if (strlen($arResult['UF_PROPERTIES']) > 0) {
    $characteristics = unserialize($arResult['UF_PROPERTIES']);
}

$vip = false;
$premium = false;
$color = false;
if (!empty($arResult['UF_VIP_END'])) {
    if (strtotime(date('d.m.Y H:i')) < strtotime($arResult['UF_VIP_END'])) {
        $vip = true;
    }
}
if (!empty($arResult['UF_PREMIUM_END'])) {
    if (strtotime(date('d.m.Y H:i')) < strtotime($arResult['UF_PREMIUM_END'])) {
        $premium = true;
    }
}
if (!empty($arResult['UF_COLOR_END'])) {
    if (strtotime(date('d.m.Y H:i')) < strtotime($arResult['UF_COLOR_END'])) {
        $color = true;
    }
}

$arButtons = \CIBlock::GetPanelButtons(
    $arResult['UF_IBLOCK_ID'],
    $arResult['UF_ID'],
    0,
    ["SECTION_BUTTONS" => false, "SESSID" => false]
);
$arItem["EDIT_LINK"] = $arButtons["edit"]["edit_element"]["ACTION_URL"];
$arItem["DELETE_LINK"] = $arButtons["edit"]["delete_element"]["ACTION_URL"];
$this->AddEditAction(
    $arResult['UF_ID'],
    $arItem['EDIT_LINK'],
    CIBlock::GetArrayByID(
        $arResult['UF_IBLOCK_ID'],
        "ELEMENT_EDIT"
    )
);
$this->AddDeleteAction(
    $arResult['UF_ID'],
    $arItem['DELETE_LINK'],
    CIBlock::GetArrayByID(
        $arResult['UF_IBLOCK_ID'],
        "ELEMENT_DELETE"
    ),
    [
        "CONFIRM" => Loc::getMessage('CONFIRM_DELETE')
    ]
);

$dateEnd = strtotime($arResult['UF_ACTIVE_TO']);
$dateNow = strtotime(date('Y-m-d H:i:s'));
$datediff = ($dateEnd - $dateNow) / (60 * 60 * 24);

?>
<div class="col-lg-8 col-md-12 col-sm-12 col-xs-12" id="<?= $this->GetEditAreaId($arResult['UF_ID']) ?>">
    <?php
    if ($arResult['IS_OWNER']) {
        if ($datediff >= 0 && $datediff < 5) {
            ?>
            <div class="warning-message _mt">
                <?= Loc::getMessage('DETAIL_COMPONENT_EXPIRED_AT', ['#DATE#' => date('d.m.Y H:i', $dateEnd)]) ?>
            </div>
            <?php
        } elseif ($datediff >= 5) {
            ?>
            <div class="success-message _mt">
                <?= Loc::getMessage('DETAIL_COMPONENT_ACITVE_TO', ['#DATE#' => date('d.m.Y H:i', $dateEnd)]) ?>
            </div>
            <?php
        }
    }
    ?>
    <h1>
        <?php
        if (isset($arResult['META']['ELEMENT_PAGE_TITLE']) && strlen($arResult['META']['ELEMENT_PAGE_TITLE']) > 0) {
            echo $arResult['META']['ELEMENT_PAGE_TITLE'];
        } else {
            echo $arResult['UF_NAME'];
        }
        ?>
    </h1>
    <?php
    if ($vip || $premium || $color) {
        ?>
        <div class="detail-labels">
            <?php
            if ($vip) {
                ?>
                <div class="item vip"><?= Loc::getMessage('DETAIL_COMPONENT_SERVICE_VIP') ?></div>
                <?php
            }
            if ($premium) {
                ?>
                <div class="item premium"><?= Loc::getMessage('DETAIL_COMPONENT_SERVICE_PREMIUM') ?></div>
                <?php
            }
            if ($color) {
                ?>
                <div class="item color"><?= Loc::getMessage('DETAIL_COMPONENT_SERVICE_COLORS_STATUS') ?></div>
                <?php
            }
            ?>
        </div>
        <?php
    }
    ?>
    <div class="gallery fotorama _mb" data-nav="thumbs" data-width="100%" data-maxheight="350px"
         data-allowfullscreen="true" data-loop="true" data-thumbheight="40" data-transition="slide"
         data-clicktransition="crossfade">
        <?php
        foreach ($images as $value) {
            $img = CFile::ResizeImageGet(
                $value,
                [
                    'width' => 730,
                    'height' => 730
                ],
                BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
                true
            );
            ?>
            <div data-img="<?= $img['src'] ?>" data-thumb="<?= $img['src'] ?>" data-thumbwidth="<?= $img['width'] ?>"
                 data-thumbheight="<?= $img['height'] ?>">
                <div class="fotorama__blur" style="background:url(<?= $img['src'] ?>)"></div>
            </div>
            <?php
        }
        if ($arResult['VIDEO']) {
            ?>
            <a href="<?= $arResult['VIDEO'] ?>"></a>
            <?php
        }
        ?>
    </div>
    <?php
    if (ModuleManager::isModuleInstalled('advertising')) {
        if (Loader::includeModule('advertising')) {
            ?>
            <div class="delimiter"></div>
            <?php
            $APPLICATION->IncludeComponent(
                'democontent2.board:banner',
                'detail.full.width',
                ['TYPE' => 'DBOARD_DETAIL_FULL_WIDTH']
            );
            ?>
            <div class="delimiter"></div>
            <?php
        }
    } else {
        if (File::isFileExists(Path::normalize(
            Application::getDocumentRoot() . SITE_TEMPLATE_PATH . "/inc/lang/" . USER_LANG_PATH . "advert/detail.full.width.php"
        ))) {
            ?>
            <div class="delimiter"></div>
            <?php
            $APPLICATION->IncludeComponent(
                "bitrix:main.include", "",
                [
                    "AREA_FILE_SHOW" => "file",
                    "PATH" => SITE_TEMPLATE_PATH . "/inc/lang/" . USER_LANG_PATH . "advert/detail.full.width.php",
                    "EDIT_TEMPLATE" => "include_areas_template.php",
                    'MODE' => 'php'
                ],
                false
            );
            ?>
            <div class="delimiter"></div>
            <?php
        } else {
            ?>
            <div class="delimiter"></div>
            <?php
            $APPLICATION->IncludeComponent(
                "bitrix:main.include", "",
                [
                    "AREA_FILE_SHOW" => "file",
                    "PATH" => SITE_TEMPLATE_PATH . "/inc/advert/detail.full.width.php",
                    "EDIT_TEMPLATE" => "include_areas_template.php",
                    'MODE' => 'php'
                ],
                false
            );
        }
    }

    if ($arResult['UF_LAT'] != 0 && $arResult['UF_LONG'] != 0) {
        ?>
        <div class="delimiter"></div>
        <div id="map-container">
            <div id="<?= $mapType ?>-map" class="map"></div>
        </div>
        <?php
    }

    if (strlen($arResult['UF_DESCRIPTION'])) {
        ?>
        <div class="delimiter"></div>
        <div class="properties">
            <div class="item">
                <div class="name"><?= Loc::getMessage('DETAIL_COMPONENT_DESC') ?></div>
                <div class="value"><?= TxtToHTML($arResult['UF_DESCRIPTION'], false) ?></div>
            </div>
        </div>
        <?php
    }

    if (count($characteristics)) {
        ?>
        <div class="delimiter"></div>
        <div class="properties">
            <?php
            foreach ($characteristics as $key => $val) {
                ?>
                <div class="item">
                    <div class="name"><?= $val['name'] ?></div>
                    <div class="value">
                        <?php
                        if (is_array($val['value'])) {
                            echo implode(', ', $val['value']);
                        } else {
                            echo $val['value'];
                        }
                        ?>
                    </div>
                </div>
                <?php
            }
            ?>
        </div>
        <?php
    }
    ?>
    <div class="delimiter"></div>
    <div class="properties">
        <div class="item">
            <div class="name"><?= Loc::getMessage('DETAIL_COMPONENT_SHARE') ?></div>
            <div class="value ya-share2"
                 data-services="vkontakte,facebook,odnoklassniki,twitter,viber,whatsapp,skype,telegram"></div>
        </div>
    </div>
    <div class="delimiter"></div>
    <?php
    $APPLICATION->IncludeComponent(
        'democontent2.board:similar',
        '',
        [
            'IBLOCK_ID' => $arResult['UF_IBLOCK_ID'],
            'CITY_ID' => $arResult['UF_CITY_ID'],
            'SECTION_DEPTH_1' => $arResult['UF_SECTION_DEPTH_1'],
            'SECTION_ID' => $arResult['UF_SECTION_ID'],
            'EXCLUDE_ID' => $arResult['UF_ID'],
            'CITIES' => $arResult['CITIES'],
        ]
    );
    ?>
</div>
<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
    <?php
    if (method_exists($this, 'createFrame')) {
        $frame = $this->createFrame()->begin();
    }
    $isFavourite = in_array($arResult['UF_ID'], $arResult['FAVOURITES']);

    if ($arResult['IS_AUTHORIZED']) {
        ?>
        <div class="detail-favourite<?= ($isFavourite ? ' active' : '') ?>"
             data-id="<?= $arResult['UF_ID'] ?>" data-i="<?= $arResult['UF_IBLOCK_ID'] ?>">
        <span class="wenk--left" data-wenk-pos="left"
              data-wenk="<?= ($isFavourite ? Loc::getMessage('DETAIL_COMPONENT_REMOVE_FAV') : Loc::getMessage('DETAIL_COMPONENT_ADD_FAV')) ?>">
            <?php
            if ($isFavourite) {
                ?>
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g>
                        <path d="M9 15.8812L7.9125 14.8912C4.05 11.3887 1.5 9.07874 1.5 6.24374C1.5 3.93374 3.315 2.11874 5.625 2.11874C6.93 2.11874 8.1825 2.72624 9 3.68624C9.8175 2.72624 11.07 2.11874 12.375 2.11874C14.685 2.11874 16.5 3.93374 16.5 6.24374C16.5 9.07874 13.95 11.3887 10.0875 14.8987L9 15.8812Z"
                              fill="#EB5757"/>
                    </g>
                </svg>
                <?php
            } else {
                ?>
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g>
                        <path fill-rule="evenodd" clip-rule="evenodd"
                              d="M9 3.68624C9.8175 2.72624 11.07 2.11874 12.375 2.11874C14.685 2.11874 16.5 3.93374 16.5 6.24374C16.5 9.07642 13.9542 11.385 10.097 14.8826L10.0875 14.8912L9 15.8812L7.9125 14.8987L7.88289 14.8718C4.03697 11.3769 1.5 9.07149 1.5 6.24374C1.5 3.93374 3.315 2.11874 5.625 2.11874C6.93 2.11874 8.1825 2.72624 9 3.68624ZM9 13.8562L9.075 13.7812C12.645 10.5487 15 8.41124 15 6.24374C15 4.74374 13.875 3.61874 12.375 3.61874C11.22 3.61874 10.095 4.36124 9.705 5.38874H8.3025C7.905 4.36124 6.78 3.61874 5.625 3.61874C4.125 3.61874 3 4.74374 3 6.24374C3 8.41124 5.355 10.5487 8.925 13.7812L9 13.8562Z"
                              fill="#4F4F4F"/>
                    </g>
                </svg>
                <?php
            }
            ?>
        </span>
        </div>
        <?php
    }

    if (method_exists($this, 'createFrame')) {
        $frame->end();
    }
    ?>
    <?php
    $APPLICATION->IncludeComponent(
        'democontent2.board:complain',
        (!$USER->IsAuthorized()) ? 'unauthorized' : '',
        [
            'itemId' => $arResult['UF_ID'],
            'iblockType' => $arResult['UF_IBLOCK_TYPE'],
            'iblockId' => $arResult['UF_IBLOCK_ID'],
            //'isOwner' => $arResult['IS_OWNER'],
            'isOwner' => false,
        ]
    );

    if (intval($arResult['UF_OLD_PRICE'])) {
        ?>
        <div class="detail-price__old">
            <?= Utils::price($arResult['UF_OLD_PRICE']) ?>
            <?= $currencyName ?>
        </div>
        <?php
    }
    ?>
    <div class="detail-price">
        <?= Utils::price($arResult['UF_PRICE']) ?>
        <?= $currencyName ?>
    </div>
    <div id="complain" class=" _box _mt --dn">
        <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post" class="edit-form">
            <textarea id="complainText" name="complainText" rows="6"
                      placeholder="<?= Loc::getMessage('DETAIL_COMPONENT_COMPLAIN_PLACEHOLDER') ?>"></textarea>
            <button id="complainButton" type="submit" class="write _mt">
                <?= Loc::getMessage('DETAIL_COMPONENT_COMPLAIN_SUBMIT') ?>
            </button>
        </form>
    </div>
    <?php
    if ($arResult['IS_OWNER']) {
        ?>
        <a href="<?= SITE_DIR ?>user/items/<?= $arResult['UF_IBLOCK_ID'] ?>-<?= $arResult['UF_ID'] ?>/"
           class="edit _mt _mb">
            <?= Loc::getMessage('DETAIL_COMPONENT_EDIT') ?>
        </a>
        <?php
    } else {
        ?>
        <button class="apply _mt _mb showPhone" data-id="<?= $arResult['UF_ID'] ?>"
                data-i="<?= $arResult['UF_IBLOCK_ID'] ?>"
                data-phone="<?= $arResult['USER']['PERSONAL_PHONE'] ?>" data-show="0"
                data-phone-formatted="<?= Utils::formatPhone($arResult['USER']['PERSONAL_PHONE']) ?>">
            <?= Loc::getMessage('DETAIL_COMPONENT_LOOK_PHONE') ?>
        </button>
        <?php
    }
    ?>
    <div class="_box _mb">
        <div class="owner">
            <?php
            if (isset($arResult['USER']['AVATAR'])) {
                ?>
                <div class="image">
                    <img src="<?= $arResult['USER']['AVATAR']['src'] ?>" alt="<?= $arResult['USER']['NAME'] ?>">
                </div>
                <?php
            } else {
                ?>
                <div class="colored-name"
                     style="background: <?= strlen($arResult['USER']['NAME']) ? Utils::userBgColor($arResult['USER']['NAME']) : '#ffffff' ?>">
                    <?= strlen($arResult['USER']['NAME']) ? Utils::userNamePrefix($arResult['USER']['NAME'], $arResult['USER']['LAST_NAME']) : '' ?>
                </div>
                <?php
            }
            ?>
            <div class="data">
                <div class="name">
                    <a href="<?= SITE_DIR ?>user/<?= $arResult['USER']['ID'] ?>/">
                        <?= $arResult['USER']['NAME'] ?>
                    </a>
                    <?php
                    if ($USER->IsAuthorized() && intval(Option::get(DBOARD, 'chatEnabled')) > 0) {
                        ?>
                        <span class="status indicator"></span>
                        <?php
                    }
                    ?>
                </div>
                <div class="register">
                    <?= Loc::getMessage('DETAIL_COMPONENT_USER_DATE_REGISTER') ?>
                    : <?= date('d.m.Y', strtotime($arResult['USER']['DATE_REGISTER'])) ?>
                </div>
                <div class="rating">
                    <?php
                    foreach ([20, 40, 60, 80, 100] as $chunk) {
                        if ($arResult['CURRENT_RATING'] >= $chunk) {
                            ?>
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g>
                                    <path d="M7 10.713L11.3283 14L9.67167 8.69217L14 5.47826H8.69167L7 0L5.30833 5.47826H0L4.32833 8.69217L2.67167 14L7 10.713Z"
                                          fill="#F2994A"/>
                                </g>
                            </svg>
                            <?php
                        } else {
                            ?>
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g>
                                    <path d="M7 10.713L11.3283 14L9.67167 8.69217L14 5.47826H8.69167L7 0L5.30833 5.47826H0L4.32833 8.69217L2.67167 14L7 10.713Z"
                                          fill="#BDBDBD"/>
                                </g>
                            </svg>
                            <?php
                        }
                    }
                    ?>
                </div>
                <div class="reviews">
                    <a href="<?= SITE_DIR ?>user/<?= $arResult['USER']['ID'] ?>/?reviews=1">
                        <?php
                        if ($arResult['REVIEWS_COUNT'] > 0) {
                            echo Utils::declension(
                                $arResult['REVIEWS_COUNT'],
                                [
                                    Loc::getMessage('DETAIL_COMPONENT_REV_1'),
                                    Loc::getMessage('DETAIL_COMPONENT_REV_2'),
                                    Loc::getMessage('DETAIL_COMPONENT_REV_3')
                                ]
                            );
                        } else {
                            echo Loc::getMessage('DETAIL_COMPONENT_NO_REVIEWS');
                        }
                        ?>
                    </a>
                </div>
            </div>
        </div>
        <?php
        if (!$arResult['IS_OWNER']) {
            if (intval(Option::get(DBOARD, 'chatEnabled')) && $USER->IsAuthorized()) {
                ?>
                <div class="owner-add-review _mt" id="write-message-area">
                    <form id="send-message">
                        <textarea rows="6"
                                  placeholder="<?= Loc::getMessage('DETAIL_COMPONENT_SEND_MESSAGE_PLACEHOLDER') ?>"></textarea>
                        <button class="write send _mt" type="button"
                                data-id="<?= $arResult['UF_ID'] ?>" data-i="<?= $arResult['UF_IBLOCK_ID'] ?>">
                            <?= Loc::getMessage('DETAIL_COMPONENT_SEND_MESSAGE') ?>
                        </button>
                    </form>
                </div>
                <button class="write message _mt">
                    <?= Loc::getMessage('DETAIL_COMPONENT_WRITE_SELLER') ?>
                </button>
                <?php
            }

            if (File::isFileExists(
                Path::normalize(
                    Application::getDocumentRoot() . SITE_TEMPLATE_PATH . "/inc/lang/" . USER_LANG_PATH . "components/detail/attention.php"
                )
            )) {
                ?>
                <div class="detail-attention">
                    <?php
                    $APPLICATION->IncludeComponent(
                        "bitrix:main.include", "",
                        array(
                            "AREA_FILE_SHOW" => "file",
                            "PATH" => SITE_TEMPLATE_PATH . "/inc/lang/" . USER_LANG_PATH . "components/detail/attention.php",
                            "EDIT_TEMPLATE" => "include_areas_template.php",
                            'MODE' => 'php'
                        ),
                        false
                    );
                    ?>
                </div>
                <?php
            } else {
                ?>
                <div class="detail-attention">
                    <?php
                    $APPLICATION->IncludeComponent(
                        "bitrix:main.include", "",
                        array(
                            "AREA_FILE_SHOW" => "file",
                            "PATH" => SITE_TEMPLATE_PATH . "/inc/components/detail/attention.php",
                            "EDIT_TEMPLATE" => "include_areas_template.php",
                            'MODE' => 'php'
                        ),
                        false
                    );
                    ?>
                </div>
                <?php
            }
        }
        ?>
    </div>

    <? if ($arResult['IS_OWNER']): ?>
        <div class="_box _mb">
            <div class="detail-actions">
                <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post">
                    <input type="text" name="promo" value="" autocomplete="off"
                           placeholder="<?= Loc::getMessage('DETAIL_COMPONENT_PROMOCODE') ?>">
                    <button type="submit" class="_mt">
                        <?= Loc::getMessage('DETAIL_COMPONENT_PROMOCODE_APPLY') ?>
                    </button>
                    <div class="detail-attention">
                        <?= Loc::getMessage('DETAIL_COMPONENT_PROMOCODE_DESCRIPTION') ?>
                    </div>
                </form>
            </div>
        </div>
        <div class="_box _mb">
            <div class="detail-actions">
                <?php
                if (intval(Option::get(DBOARD, 'up_option_cost')) > 0) {
                    ?>
                    <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post">
                        <input type="hidden" name="setOption" value="up">
                        <button type="submit">
                            <?php
                            echo Loc::getMessage(
                                'DETAIL_COMPONENT_RAISE_AD',
                                [
                                    '#SUM#' => intval(Option::get(DBOARD, 'up_option_cost')),
                                    '#CURRENCY#' => $currencyName
                                ]
                            );
                            ?>
                        </button>
                    </form>
                    <?php
                }

                if (intval(Option::get(DBOARD, 'color_option_cost')) > 0) {
                    ?>
                    <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post">
                        <input type="hidden" name="setOption" value="color">
                        <button type="submit">
                            <?php
                            echo Loc::getMessage(
                                'DETAIL_COMPONENT_COLOR_AD',
                                [
                                    '#SUM#' => intval(Option::get(DBOARD, 'color_option_cost')),
                                    '#CURRENCY#' => $currencyName,
                                    '#DAYS#' => Utils::declension(
                                        intval(Option::get(DBOARD, 'color_option_period')),
                                        [
                                            Loc::getMessage('DETAIL_COMPONENT_DAYS_1'),
                                            Loc::getMessage('DETAIL_COMPONENT_DAYS_2'),
                                            Loc::getMessage('DETAIL_COMPONENT_DAYS_3')
                                        ]
                                    )
                                ]
                            );
                            ?>
                        </button>
                    </form>
                    <?php
                }

                if (intval(Option::get(DBOARD, 'vip_option_cost')) > 0) {
                    ?>
                    <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post">
                        <input type="hidden" name="setOption" value="vip">
                        <button type="submit">
                            <?php
                            echo Loc::getMessage(
                                'DETAIL_COMPONENT_VIP_AD',
                                [
                                    '#SUM#' => intval(Option::get(DBOARD, 'vip_option_cost')),
                                    '#CURRENCY#' => $currencyName,
                                    '#DAYS#' => Utils::declension(
                                        intval(Option::get(DBOARD, 'vip_option_period')),
                                        [
                                            Loc::getMessage('DETAIL_COMPONENT_DAYS_1'),
                                            Loc::getMessage('DETAIL_COMPONENT_DAYS_2'),
                                            Loc::getMessage('DETAIL_COMPONENT_DAYS_3')
                                        ]
                                    )
                                ]
                            );
                            ?>
                        </button>
                    </form>
                    <?php
                }

                if (intval(Option::get(DBOARD, 'premium_option_cost')) > 0) {
                    ?>
                    <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post">
                        <input type="hidden" name="setOption" value="premium">
                        <button type="submit">
                            <?php
                            echo Loc::getMessage(
                                'DETAIL_COMPONENT_PREMIUM_AD',
                                [
                                    '#SUM#' => intval(Option::get(DBOARD, 'premium_option_cost')),
                                    '#CURRENCY#' => $currencyName,
                                    '#DAYS#' => Utils::declension(
                                        intval(Option::get(DBOARD, 'premium_option_period')),
                                        [
                                            Loc::getMessage('DETAIL_COMPONENT_DAYS_1'),
                                            Loc::getMessage('DETAIL_COMPONENT_DAYS_2'),
                                            Loc::getMessage('DETAIL_COMPONENT_DAYS_3')
                                        ]
                                    )
                                ]
                            );
                            ?>
                        </button>
                    </form>
                    <?php
                }

                if (intval(Option::get(DBOARD, 'turbo_option_cost')) > 0) {
                    ?>
                    <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post">
                        <input type="hidden" name="setOption" value="turbo">
                        <button type="submit">
                            <?php
                            echo Loc::getMessage(
                                'DETAIL_COMPONENT_TURBO_AD',
                                [
                                    '#SUM#' => intval(Option::get(DBOARD, 'turbo_option_cost')),
                                    '#CURRENCY#' => $currencyName
                                ]
                            );
                            ?>
                        </button>
                    </form>
                    <?php
                }
                ?>
            </div>
        </div>
        <div class=" _box _mb">
            <div class="detail-actions">
                <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post">
                    <input type="hidden" name="cancel" value="1">
                    <button type="submit">
                        <?= Loc::getMessage('DETAIL_COMPONENT_CANCEL') ?>
                    </button>
                    <div class="detail-attention">
                        <?= Loc::getMessage('DETAIL_COMPONENT_CANCEL_DESCRIPTION') ?>
                    </div>
                </form>
            </div>
        </div>
    <? endif; ?>

    <div class="detail-stat _mb">
        <div class="item">
            <div class="icon">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g id="schedule_24px">
                        <path id="icon/action/schedule_24px" fill-rule="evenodd" clip-rule="evenodd"
                              d="M8.9925 1.5C4.8525 1.5 1.5 4.86 1.5 9C1.5 13.14 4.8525 16.5 8.9925 16.5C13.14 16.5 16.5 13.14 16.5 9C16.5 4.86 13.14 1.5 8.9925 1.5ZM9 15C5.685 15 3 12.315 3 9C3 5.685 5.685 3 9 3C12.315 3 15 5.685 15 9C15 12.315 12.315 15 9 15ZM8.25 5.25H9.375V9.1875L12.75 11.19L12.1875 12.1125L8.25 9.75V5.25Z"
                              fill="#4F4F4F"/>
                    </g>
                </svg>
            </div>
            <div class="value">
                <span title="<?= date('Y-m-d H:i', strtotime($arResult['UF_ACTIVE_FROM'])) ?>"
                      class="timestamp"></span>
            </div>
        </div>
        <div class="item">
            <div class="icon">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g id="remove_red_eye_24px">
                        <path id="icon/image/remove_red_eye_24px" fill-rule="evenodd" clip-rule="evenodd"
                              d="M0.75 9C2.0475 5.7075 5.25 3.375 9 3.375C12.75 3.375 15.9525 5.7075 17.25 9C15.9525 12.2925 12.75 14.625 9 14.625C5.25 14.625 2.0475 12.2925 0.75 9ZM15.615 9C14.3775 6.4725 11.8425 4.875 9 4.875C6.1575 4.875 3.6225 6.4725 2.385 9C3.6225 11.5275 6.15 13.125 9 13.125C11.85 13.125 14.3775 11.5275 15.615 9ZM9 7.125C10.035 7.125 10.875 7.965 10.875 9C10.875 10.035 10.035 10.875 9 10.875C7.965 10.875 7.125 10.035 7.125 9C7.125 7.965 7.965 7.125 9 7.125ZM5.625 9C5.625 7.14 7.14 5.625 9 5.625C10.86 5.625 12.375 7.14 12.375 9C12.375 10.86 10.86 12.375 9 12.375C7.14 12.375 5.625 10.86 5.625 9Z"
                              fill="#4F4F4F"/>
                    </g>
                </svg>
            </div>
            <div class="value">
                <?= Loc::getMessage('DETAIL_COMPONENT_VIEWS') ?>:
                <?= Loc::getMessage('DETAIL_COMPONENT_VIEWS_TOTAL') ?>: <?= $arResult['STAT']['TOTAL'] ?>,
                <?= Loc::getMessage('DETAIL_COMPONENT_VIEWS_TODAY') ?> <?= $arResult['STAT']['TODAY'] ?>
            </div>
        </div>
        <?php
        if (isset($arResult['SHOW_PHONE_STAT'])) {
            ?>
            <div class="item">
                <div class="icon">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g id="remove_red_eye_24px">
                            <path id="icon/image/remove_red_eye_24px" fill-rule="evenodd" clip-rule="evenodd"
                                  d="M0.75 9C2.0475 5.7075 5.25 3.375 9 3.375C12.75 3.375 15.9525 5.7075 17.25 9C15.9525 12.2925 12.75 14.625 9 14.625C5.25 14.625 2.0475 12.2925 0.75 9ZM15.615 9C14.3775 6.4725 11.8425 4.875 9 4.875C6.1575 4.875 3.6225 6.4725 2.385 9C3.6225 11.5275 6.15 13.125 9 13.125C11.85 13.125 14.3775 11.5275 15.615 9ZM9 7.125C10.035 7.125 10.875 7.965 10.875 9C10.875 10.035 10.035 10.875 9 10.875C7.965 10.875 7.125 10.035 7.125 9C7.125 7.965 7.965 7.125 9 7.125ZM5.625 9C5.625 7.14 7.14 5.625 9 5.625C10.86 5.625 12.375 7.14 12.375 9C12.375 10.86 10.86 12.375 9 12.375C7.14 12.375 5.625 10.86 5.625 9Z"
                                  fill="#4F4F4F"/>
                        </g>
                    </svg>
                </div>
                <div class="value">
                    <?= Loc::getMessage('DETAIL_COMPONENT_VIEWS_PHONE') ?>:
                    <?= Loc::getMessage('DETAIL_COMPONENT_VIEWS_TOTAL') ?>
                    : <?= $arResult['SHOW_PHONE_STAT']['TOTAL'] ?>,
                    <?= Loc::getMessage('DETAIL_COMPONENT_VIEWS_TODAY') ?> <?= $arResult['SHOW_PHONE_STAT']['TODAY'] ?>
                </div>
            </div>
            <?php
        }
        if (isset($arResult['CITY_PARAMS']['name'])) {
            ?>
            <div class="item">
                <div class="icon">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g id="pin_drop_24px">
                            <path id="icon/maps/pin_drop_24px" fill-rule="evenodd" clip-rule="evenodd"
                                  d="M9 1.5C11.4825 1.5 13.5 3.5175 13.5 6C13.5 9.375 9 14.25 9 14.25C9 14.25 4.5 9.375 4.5 6C4.5 3.5175 6.5175 1.5 9 1.5ZM14.25 16.5V15H3.75V16.5H14.25ZM6 6C6 4.3425 7.3425 3 9 3C10.6575 3 12 4.3425 12 6C12 7.5975 10.44 10.095 9 11.9325C7.56 10.1025 6 7.5975 6 6ZM7.5 6C7.5 5.175 8.175 4.5 9 4.5C9.825 4.5 10.5 5.175 10.5 6C10.5 6.825 9.8325 7.5 9 7.5C8.175 7.5 7.5 6.825 7.5 6Z"
                                  fill="#4F4F4F"/>
                        </g>
                    </svg>
                </div>
                <div class="value"><?= $arResult['CITY_PARAMS']['name'] ?></div>
            </div>
            <?php
        }
        ?>
    </div>
    <?php
    $APPLICATION->IncludeComponent(
        'democontent2.board:premium',
        '',
        [
            'IBLOCK_ID' => $arResult['UF_IBLOCK_ID'],
            'CITY_ID' => $arResult['UF_CITY_ID']
        ]
    );
    ?>
</div>
<script>
    var siteTemplatePath = '<?= SITE_TEMPLATE_PATH ?>',
        locationLat = '<?= $arResult['UF_LAT'] ?>',
        locationLong = '<?= $arResult['UF_LONG'] ?>',
        currentPath = '<?=$this->GetFolder()?>',
        __sendMessageSuccess = '<?=Loc::getMessage('DETAIL_COMPONENT_SEND_MESSAGE_SUCCESS')?>',
        __showAllProperties = '<?=Loc::getMessage('DETAIL_COMPONENT_LOOK_ALL')?>',
        __hideAllProperties = '<?=Loc::getMessage('DETAIL_COMPONENT_HIDE')?>';

    (function () {
        function numpf(n, f, s, t) {
            var n10 = n % 10;
            if ((n10 === 1) && ((n === 1) || (n > 20))) {
                return f;
            } else if ((n10 > 1) && (n10 < 5) && ((n > 20) || (n < 10))) {
                return s;
            } else {
                return t;
            }
        }

        jQuery.timeago.settings.strings = {
            prefixAgo: null,
            prefixFromNow: "<?=Loc::getMessage('TIME_ACROSS')?>",
            suffixAgo: "<?=Loc::getMessage('TIME_BACK')?>",
            suffixFromNow: null,
            seconds: "<?=Loc::getMessage('TIME_LESS_MINUTE')?>",
            minute: "<?=Loc::getMessage('TIME_MINUTE_4')?>",
            minutes: function (value) {
                return numpf(value, "%d <?=Loc::getMessage('TIME_MINUTE_1')?>", "%d <?=Loc::getMessage('TIME_MINUTE_2')?>", "%d <?=Loc::getMessage('TIME_MINUTE_3')?>");
            },
            hour: "<?=Loc::getMessage('TIME_HOUR_1')?>",
            hours: function (value) {
                return numpf(value, "%d <?=Loc::getMessage('TIME_HOUR_1')?>", "%d <?=Loc::getMessage('TIME_HOUR_2')?>", "%d <?=Loc::getMessage('TIME_HOUR_3')?>");
            },
            day: "<?=Loc::getMessage('TIME_DAY_1')?>",
            days: function (value) {
                return numpf(value, "%d <?=Loc::getMessage('TIME_DAY_1')?>", "%d <?=Loc::getMessage('TIME_DAY_2')?>", "%d <?=Loc::getMessage('TIME_DAY_3')?>");
            },
            month: "<?=Loc::getMessage('TIME_MONTH_1')?>",
            months: function (value) {
                return numpf(value, "%d <?=Loc::getMessage('TIME_MONTH_1')?>", "%d <?=Loc::getMessage('TIME_MONTH_2')?>", "%d <?=Loc::getMessage('TIME_MONTH_3')?>");
            },
            year: "<?=Loc::getMessage('TIME_YEAR_1')?>",
            years: function (value) {
                return numpf(value, "%d <?=Loc::getMessage('TIME_YEAR_1')?>", "%d <?=Loc::getMessage('TIME_YEAR_2')?>", "%d <?=Loc::getMessage('TIME_YEAR_3')?>");
            }
        };
    })();
</script>
<?php
if ($USER->IsAuthorized() && intval(Option::get(DBOARD, 'chatEnabled')) > 0) {
    ?>
    <script>
        __ownerId = '<?=md5($arResult['UF_USER_ID'])?>';
        BX.message({
            'owner_id': '<?=md5($arResult['UF_USER_ID'])?>',
            'status_online': '<?=Loc::getMessage('DETAIL_COMPONENT_ONLINE')?>',
            'status_offline': '<?=Loc::getMessage('DETAIL_COMPONENT_OFFLINE')?>',
        });
    </script>
    <?php
}
?>
