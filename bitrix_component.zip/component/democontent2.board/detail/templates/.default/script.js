$(document).ready(function () {
    jQuery(".timestamp").timeago();

    if (typeof __ownerId !== 'undefined') {
        $(function () {
            socket.emit('status', __ownerId);
            socket.on(__ownerId + ' user status', (data) => {
                switch (data.status) {
                    case 'online':
                        $('.status.indicator').removeClass('offline').addClass('online').html(BX.message('status_online'));
                        break;
                    case 'offline':
                        $('.status.indicator').removeClass('online').addClass('offline').html(BX.message('status_offline'));
                        break;
                }
            });
        });
    }

    $('.detail-favourite').click(function () {
        let $this = $(this);
        let id = $this.attr('data-id');
        let i = $this.attr('data-i');
        $.ajax({
            type: 'POST',
            url: currentPath + '/ajax.php',
            dataType: "json",
            data: 'id=' + id + '&i=' + i + '&type=like',
        });
    });

    $('.showPhone').click(function () {
        let $this = $(this);
        let id = $this.attr('data-id');
        let i = $this.attr('data-i');
        let show = parseInt($this.attr('data-show'));
        if (!show) {
            $.ajax({
                type: 'POST',
                url: currentPath + '/ajax.php',
                dataType: "json",
                data: 'id=' + id + '&i=' + i + '&type=phone',
                success: function (data) {
                    $this.html($this.data('phone-formatted'));
                    $this.attr('data-show', '1')
                },
            });
        } else {
            window.location.href = 'tel:' + $this.data('phone');
        }
    });

    $('.write.send').click(function (e) {
        e.preventDefault();
        let $this = $(this);
        let id = $this.attr('data-id');
        let i = $this.attr('data-i');
        let parent = $(this).parent();
        if (parent.length) {
            if (parent[0].nodeName === 'FORM') {
                let form = $(parent[0]);
                let siblings = $(this).siblings();
                if (siblings.length) {
                    if (siblings[0].nodeName === 'TEXTAREA') {
                        let textarea = $(siblings[0]);
                        if (textarea.val().toString().trim().length) {
                            textarea.removeClass('error');
                            $.ajax({
                                type: "POST",
                                url: currentPath + '/ajax.php',
                                dataType: "json",
                                data: 'type=write&id=' + id + '&i=' + i + '&message=' + textarea.val().toString().trim(),
                                success: function (data) {
                                    if (!data.error) {
                                        form.remove();
                                        $('div#write-message-area').html('<div class="success-message">' + __sendMessageSuccess + '</div>');
                                    } else {
                                        textarea.addClass('error');
                                        textarea.val('');
                                        if (typeof __ownerId !== 'undefined') {
                                            socket.emit(
                                                'new message',
                                                {
                                                    roomId: data.result['id'],
                                                    from: username,
                                                    to: __ownerId,
                                                    message: message,
                                                    userName: data.result['userName'],
                                                    skipAdd: true
                                                }
                                            );
                                        }
                                    }
                                },
                            });
                        } else {
                            textarea.val('');
                            textarea.addClass('error');
                        }
                    }
                }
            }
        }
        return false;
    });
});

