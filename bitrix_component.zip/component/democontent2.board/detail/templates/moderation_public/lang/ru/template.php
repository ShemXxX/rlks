<?php
/**
 * Date: 25.11.2019
 * Time: 09:11
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
$MESS['DETAIL_COMPONENT_MODERATION_MESSAGE'] = 'В настоящее время это объявление проходит проверку модератором.<br>В случае успешной проверки, объявление будет опубликовано в каталоге.';
