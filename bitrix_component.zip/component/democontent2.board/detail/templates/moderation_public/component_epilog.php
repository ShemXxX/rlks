<?php
/**
 * Date: 25.11.2019
 * Time: 09:11
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;

global $APPLICATION;

$APPLICATION->SetTitle(Loc::getMessage('DETAIL_COMPONENT_MODERATION_EPILOG_MESSAGE'));
$APPLICATION->SetPageProperty('title', Loc::getMessage('DETAIL_COMPONENT_MODERATION_EPILOG_MESSAGE'));
