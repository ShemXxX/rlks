<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 08.10.2018
 * Time: 09:25
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['DETAIL_COMPONENT_LOOK_MAP'] = 'Показать на карте';
$MESS['DETAIL_COMPONENT_ADD_FAV'] = 'Добавить в избранное';
$MESS['DETAIL_COMPONENT_SECURE_TRANSACTION'] = 'Безопасная сделка';
$MESS['DETAIL_COMPONENT_DELIVERY_CITY'] = 'Доставка по городу';
$MESS['DETAIL_COMPONENT_RAISE_AD'] = 'Поднять объявление за #SUM# #CURRENCY#';
$MESS['DETAIL_COMPONENT_COLOR_AD'] = 'Выделить цветом за #SUM# #CURRENCY# на #DAYS#';
$MESS['DETAIL_COMPONENT_VIP_AD'] = 'VIP объявление за #SUM# #CURRENCY# на #DAYS#';
$MESS['DETAIL_COMPONENT_PREMIUM_AD'] = 'Премиум объявление за #SUM# #CURRENCY# на #DAYS#';
$MESS['DETAIL_COMPONENT_TURBO_AD'] = 'ТУРБО (Vip + Premium + Цвет) за #SUM# #CURRENCY#';
$MESS['DETAIL_COMPONENT_BUY'] = 'Купить';
$MESS['DETAIL_COMPONENT_LOOK_PHONE'] = 'Показать номер';
$MESS['DETAIL_COMPONENT_WRITE_SELLER'] = 'Написать продавцу';
$MESS['DETAIL_COMPONENT_SUBSCRIBE_SELLER'] = 'Подписаться на продавца';
$MESS['DETAIL_COMPONENT_COMPLAIN_ANNOUNCEMENT'] = 'Пожаловаться на объявление';
$MESS['DETAIL_COMPONENT_HIDE'] = 'Скрыть';
$MESS['DETAIL_COMPONENT_LOOK_ALL'] = 'Показать все';
$MESS['DETAIL_COMPONENT_DESC'] = 'Описание';
$MESS['DETAIL_COMPONENT_CHARACTERISTICS'] = 'Характеристики';
$MESS['DETAIL_COMPONENT_POP_PHONE_TTL'] = 'Свяжитесь с продавцом';
$MESS['DETAIL_COMPONENT_USER_DATE_REGISTER'] = 'На сайте с';
$MESS['DETAIL_COMPONENT_VIEWS'] = 'Просм.';
$MESS['DETAIL_COMPONENT_VIEWS_PHONE'] = 'Просм. телефона';
$MESS['DETAIL_COMPONENT_VIEWS_TOTAL'] = 'всего';
$MESS['DETAIL_COMPONENT_VIEWS_TODAY'] = 'сегодня';
$MESS['DETAIL_COMPONENT_POPUP_COMPLAINT_TITLE'] = 'Пожаловаться на объявление';
$MESS['DETAIL_COMPONENT_POPUP_COMPLAINT_SELECT'] = 'Выберите причину жалобы';
$MESS['DETAIL_COMPONENT_POPUP_COMPLAINT_SUBMIT'] = 'Отправить';
$MESS['DETAIL_COMPONENT_DAYS_1'] = 'день';
$MESS['DETAIL_COMPONENT_DAYS_2'] = 'дня';
$MESS['DETAIL_COMPONENT_DAYS_3'] = 'дней';
$MESS['DETAIL_COMPONENT_SERVICE_ACTIVE_TO'] = 'Услуга активна до';
$MESS['DETAIL_COMPONENT_SERVICE_VIP'] = 'VIP';
$MESS['DETAIL_COMPONENT_SERVICE_PREMIUM'] = 'Premium';
$MESS['DETAIL_COMPONENT_SERVICE_COLORS'] = 'Выделить цветом';
$MESS['DETAIL_COMPONENT_SERVICE_COLORS_STATUS'] = 'Выделение цветом';
$MESS['CONFIRM_DELETE'] = 'Вы действительно хотите удалить этот элемент?';
$MESS['DETAIL_COMPONENT_FROM'] = 'Размещено';
$MESS['DETAIL_COMPONENT_SEND_MESSAGE'] = 'Отправить';
$MESS['DETAIL_COMPONENT_SEND_MESSAGE_AUTH'] = 'Для отправки сообщения продавцу необходимо авторизоваться';
$MESS['DETAIL_COMPONENT_SEND_MESSAGE_SUCCESS'] = 'Сообщение отправлено!';
$MESS['TIME_ACROSS'] = 'через';
$MESS['TIME_BACK'] = 'назад';
$MESS['TIME_LESS_MINUTE'] = 'меньше минуты';
$MESS['TIME_MINUTE_1'] = 'минута';
$MESS['TIME_MINUTE_2'] = 'минуты';
$MESS['TIME_MINUTE_3'] = 'минут';
$MESS['TIME_MINUTE_4'] = 'минуту';
$MESS['TIME_HOUR_1'] = 'час';
$MESS['TIME_HOUR_2'] = 'часа';
$MESS['TIME_HOUR_3'] = 'часов';
$MESS['TIME_DAY_1'] = 'день';
$MESS['TIME_DAY_2'] = 'дня';
$MESS['TIME_DAY_3'] = 'дней';
$MESS['TIME_MONTH_1'] = 'месяц';
$MESS['TIME_MONTH_2'] = 'месяца';
$MESS['TIME_MONTH_3'] = 'месяцев';
$MESS['TIME_YEAR_1'] = 'год';
$MESS['TIME_YEAR_2'] = 'года';
$MESS['TIME_YEAR_3'] = 'лет';
$MESS['DETAIL_COMPONENT_REV_1'] = 'отзыв';
$MESS['DETAIL_COMPONENT_REV_2'] = 'отзыва';
$MESS['DETAIL_COMPONENT_REV_3'] = 'отзывов';
$MESS['DETAIL_COMPONENT_CITY'] = 'Город';
$MESS['DETAIL_COMPONENT_APPROVE'] = 'Опубликовать объявление';
$MESS['DETAIL_COMPONENT_APPROVE_DESCRIPTION'] = 'Пользователь получит почтовое уведомление о том, что его объявление одобрено и доступно на сайте.';
$MESS['DETAIL_COMPONENT_REJECT'] = 'Отклонить объявление';
$MESS['DETAIL_COMPONENT_REMOVE'] = 'Удалить объявление';
$MESS['DETAIL_COMPONENT_REMOVE_DESCRIPTION'] = 'Пользователь не получит никаких уведомлений. Объявление будет удалено безвозвратно.';
$MESS['DETAIL_COMPONENT_REJECT_REASON'] = 'Укажите причину по которой объявление отклонено';
$MESS['DETAIL_COMPONENT_REJECT_REASON_DESCRIPTION'] = 'Пользователь получит уведомление по электронной почте с указанной Вами причиной по которой объявление отклонено.';
$MESS['DETAIL_COMPONENT_MODERATION_WAIT'] = 'Это объявление ожидает проверки. Пожалуйста, подтвердите или отклоните публикацию объявления.';
$MESS['DETAIL_COMPONENT_MODERATION_REJECTED'] = 'Вы отклонили это объявление';
$MESS['DETAIL_COMPONENT_NO_REVIEWS'] = 'нет отзывов';
$MESS['DETAIL_COMPONENT_ADD_FAV'] = 'Добавить в избранное';
$MESS['DETAIL_COMPONENT_REMOVE_FAV'] = 'Удалить из избранного';
$MESS['DETAIL_COMPONENT_SHARE'] = 'Поделиться';
$MESS['DETAIL_COMPONENT_ONLINE'] = 'онлайн';
$MESS['DETAIL_COMPONENT_OFFLINE'] = 'не в сети';