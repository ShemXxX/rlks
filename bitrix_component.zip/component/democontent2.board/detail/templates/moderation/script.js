$(document).ready(function () {
    jQuery(".timestamp").timeago();

    if (typeof __ownerId !== 'undefined') {
        $(function () {
            socket.emit('status', __ownerId);
            socket.on(__ownerId + ' user status', (data) => {
                switch (data.status) {
                    case 'online':
                        $('.status.indicator').removeClass('offline').addClass('online').html(BX.message('status_online'));
                        break;
                    case 'offline':
                        $('.status.indicator').removeClass('online').addClass('offline').html(BX.message('status_offline'));
                        break;
                }
            });
        });
    }

    $('.detail-favourite').click(function () {
        let $this = $(this);
        let id = $this.attr('data-id');
        let i = $this.attr('data-i');
        $.ajax({
            type: 'POST',
            url: currentPath + '/ajax.php',
            dataType: "json",
            data: 'id=' + id + '&i=' + i + '&type=like',
        });
    });

    $('.showPhone').click(function () {
        let $this = $(this);
        let id = $this.attr('data-id');
        let i = $this.attr('data-i');
        let show = parseInt($this.attr('data-show'));
        if (!show) {
            $.ajax({
                type: 'POST',
                url: currentPath + '/ajax.php',
                dataType: "json",
                data: 'id=' + id + '&i=' + i + '&type=phone',
                success: function (data) {
                    $this.html($this.data('phone-formatted'));
                    $this.attr('data-show', '1')
                },
            });
        } else {
            window.location.href = 'tel:' + $this.data('phone');
        }
    });

    $('button#approve').click(function () {
        let id = $(this).attr('data-id'), i = $(this).attr('data-i');
        $.ajax({
            type: 'POST',
            url: currentPath + '/ajax.php',
            dataType: "json",
            data: 'id=' + id + '&i=' + i + '&type=approve',
        });
        window.location.reload();
    });
    $('button#reject').click(function () {
        let id = $(this).attr('data-id'), i = $(this).attr('data-i'), rejectReason = $('#reject-reason').val();
        $.ajax({
            type: 'POST',
            url: currentPath + '/ajax.php',
            dataType: "json",
            data: 'id=' + id + '&i=' + i + '&type=reject&reason=' + rejectReason,
        });
        window.location.reload();
    });
    $('button#remove').click(function () {
        let id = $(this).attr('data-id');
        $.ajax({
            type: 'POST',
            url: currentPath + '/ajax.php',
            dataType: "json",
            data: 'id=' + id + '&type=remove',
        });
        window.location.href = siteDir + 'user/moderation/';
    });
});

