<?php
/*
 * Date and Time: 17.11.2020, 9:20
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

\Bitrix\Main\Loader::includeModule('democontent2.board');

use Bitrix\Main\ArgumentNullException;
use Bitrix\Main\ArgumentOutOfRangeException;
use Bitrix\Main\Context;
use Bitrix\Main\Engine\Response\Json;
use Democontent2\Board\Iblock\Favourites;
use Democontent2\Board\Iblock\Item;
use Democontent2\Board\Iblock\Stat;
use Democontent2\Board\Utils as UtilsAlias;

$request = Context::getCurrent()->getRequest();
$error = 1;
$result = [];

global $USER;

if ($request->isAjaxRequest() && $request->isPost()) {
    if ($request->getPost('type') && $request->getPost('id') && intval($request->getPost('id')) > 0) {
        switch ($request->getPost('type')) {
            case 'phone':
                if ($request->getPost('i') && intval($request->getPost('i')) > 0) {
                    $stat = new Stat(
                        intval($request->getPost('id')),
                        intval($request->getPost('i'))
                    );
                    $stat->setTablePostfix('phone');
                    if ($USER->IsAuthorized()) {
                        $stat->setUserId(intval($USER->GetID()));
                    }
                    $stat->set();
                    $error = 0;
                }
                break;
            case 'like':
                if ($USER->IsAuthorized() && $request->getPost('i') && intval($request->getPost('i')) > 0) {
                    $favourites = new Favourites(
                        intval($USER->GetID()),
                        intval($request->getPost('i'))
                    );
                    $favourites->change(intval($request->getPost('id')));
                    $error = 0;
                }
                break;
            case 'approve':
                if ($USER->IsAdmin() || ($USER->IsAuthorized() && UtilsAlias::isModerator($USER->GetGroups()))) {
                    $item = new Item();
                    $item->setItemId($request->getPostList()->get('id'));
                    $item->setIBlockId($request->getPostList()->get('i'));
                    try {
                        $item->approve();
                        $error = 0;
                    } catch (ArgumentNullException $e) {
                    } catch (ArgumentOutOfRangeException $e) {
                    }
                }
                break;
            case 'reject':
                if ($USER->IsAdmin() || ($USER->IsAuthorized() && UtilsAlias::isModerator($USER->GetGroups()))) {
                    $reason = '';
                    if (strlen($request->getPostList()->get('reason'))) {
                        $reason = HTMLToTxt($request->getPostList()->get('reason'));
                    }
                    $item = new Item();
                    $item->setItemId($request->getPostList()->get('id'));
                    $item->setIBlockId($request->getPostList()->get('i'));
                    $item->reject($reason);
                    $error = 0;
                }
                break;
            case 'remove':
                if ($USER->IsAdmin() || ($USER->IsAuthorized() && UtilsAlias::isModerator($USER->GetGroups()))) {
                    $error = 0;
                    CIBlockElement::Delete($request->getPostList()->get('id'));
                }
                break;
        }
    }
}

$r = new Json([
    'error' => $error,
    'result' => $result
]);
$r->send();
