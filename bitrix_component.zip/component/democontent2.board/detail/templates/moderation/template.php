<?php
/*
 * Date and Time: 08.04.2021, 10:06
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

if (method_exists($this, 'setFrameMode')) {
    $this->setFrameMode(false);
}

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Page\Asset;
use Bitrix\Main\Page\AssetLocation;
use Bitrix\Main\Config\Option;
use Democontent2\Board\Utils;

$mapType = Option::get(DBOARD, 'defaultMap');

switch ($mapType) {
    case 'google':
        Asset::getInstance()->addJs('https://maps.googleapis.com/maps/api/js?language=' . ((USER_LANG == 'ru') ? 'ru' : 'en') . '&key='
            . Option::get(DBOARD, 'google_maps_api_key'));
        break;
    default:
        Asset::getInstance()->addJs(
            'https://api-maps.yandex.ru/2.1/?load=package.full&apikey=' . Option::get(DBOARD, 'yandex_maps_api_key') . '&lang=' . ((USER_LANG == 'ru') ? 'ru_RU' : 'en_US')
        );
}

Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/' . $mapType . '-map.js');
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/lib/timeago/jquery.timeago.js');

Asset::getInstance()->addString(
    '<script defer src="https://yastatic.net/es5-shims/0.0.2/es5-shims.min.js"></script>',
    true,
    AssetLocation::AFTER_JS
);
Asset::getInstance()->addString(
    '<script defer src="https://yastatic.net/share2/share.js"></script>',
    true,
    AssetLocation::AFTER_JS
);

$currencyName = Option::get(DBOARD, 'currency_name');
$images = [];
$characteristics = [];

if (!empty($arResult['UF_IMAGE_ID'])) {
    $images[] = $arResult['UF_IMAGE_ID'];
}

if (strlen($arResult['UF_IMAGES']) > 0) {
    $images = array_merge($images, unserialize($arResult['UF_IMAGES']));
}

if (strlen($arResult['UF_PROPERTIES']) > 0) {
    $characteristics = unserialize($arResult['UF_PROPERTIES']);
}
$vip = false;
$premium = false;
$color = false;
if (!empty($arResult['UF_VIP_END'])) {
    if (strtotime(date('d.m.Y H:i')) < strtotime($arResult['UF_VIP_END'])) {
        $vip = true;
    }
}
if (!empty($arResult['UF_PREMIUM_END'])) {
    if (strtotime(date('d.m.Y H:i')) < strtotime($arResult['UF_PREMIUM_END'])) {
        $premium = true;
    }
}
if (!empty($arResult['UF_COLOR_END'])) {
    if (strtotime(date('d.m.Y H:i')) < strtotime($arResult['UF_COLOR_END'])) {
        $color = true;
    }
}

$arButtons = \CIBlock::GetPanelButtons(
    $arResult['UF_IBLOCK_ID'],
    $arResult['UF_ID'],
    0,
    ["SECTION_BUTTONS" => false, "SESSID" => false]
);
$arItem["EDIT_LINK"] = $arButtons["edit"]["edit_element"]["ACTION_URL"];
$arItem["DELETE_LINK"] = $arButtons["edit"]["delete_element"]["ACTION_URL"];
$this->AddEditAction(
    $arResult['UF_ID'],
    $arItem['EDIT_LINK'],
    CIBlock::GetArrayByID(
        $arResult['UF_IBLOCK_ID'],
        "ELEMENT_EDIT"
    )
);
$this->AddDeleteAction(
    $arResult['UF_ID'],
    $arItem['DELETE_LINK'],
    CIBlock::GetArrayByID(
        $arResult['UF_IBLOCK_ID'],
        "ELEMENT_DELETE"
    ),
    [
        "CONFIRM" => Loc::getMessage('CONFIRM_DELETE')
    ]
);

?>

    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12" id="<?= $this->GetEditAreaId($arResult['UF_ID']) ?>">
        <?php
        if (intval($arResult['UF_MODERATION']) == 2) {
            ?>
            <div class="danger-message">
                <?= Loc::getMessage('DETAIL_COMPONENT_MODERATION_REJECTED') ?>
            </div>
            <?php
        } else {
            ?>
            <div class="info-message">
                <?= Loc::getMessage('DETAIL_COMPONENT_MODERATION_WAIT') ?>
            </div>
            <?php
        }
        ?>
        <h1>
            <?php
            if (isset($arResult['META']['ELEMENT_PAGE_TITLE']) && strlen($arResult['META']['ELEMENT_PAGE_TITLE']) > 0) {
                echo $arResult['META']['ELEMENT_PAGE_TITLE'];
            } else {
                echo $arResult['UF_NAME'];
            }
            ?>
        </h1>
        <?php
        if ($vip || $premium || $color) {
            ?>
            <div class="detail-labels">
                <?php
                if ($vip) {
                    ?>
                    <div class="item vip"><?= Loc::getMessage('DETAIL_COMPONENT_SERVICE_VIP') ?></div>
                    <?php
                }
                if ($premium) {
                    ?>
                    <div class="item premium"><?= Loc::getMessage('DETAIL_COMPONENT_SERVICE_PREMIUM') ?></div>
                    <?php
                }
                if ($color) {
                    ?>
                    <div class="item color"><?= Loc::getMessage('DETAIL_COMPONENT_SERVICE_COLORS_STATUS') ?></div>
                    <?php
                }
                ?>
            </div>
            <?php
        }
        ?>
        <div class="gallery fotorama _mb" data-nav="thumbs" data-width="100%" data-maxheight="350px"
             data-allowfullscreen="true" data-loop="true" data-thumbheight="40" data-transition="slide"
             data-clicktransition="crossfade">
            <?php
            foreach ($images as $value) {
                $img = CFile::ResizeImageGet(
                    $value,
                    [
                        'width' => 730,
                        'height' => 730
                    ],
                    BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
                    true
                );
                ?>
                <div data-img="<?= $img['src'] ?>" data-thumb="<?= $img['src'] ?>"
                     data-thumbwidth="<?= $img['width'] ?>"
                     data-thumbheight="<?= $img['height'] ?>">
                    <div class="fotorama__blur" style="background:url(<?= $img['src'] ?>)"></div>
                </div>
                <?php
            }
            if ($arResult['VIDEO']) {
                ?>
                <a href="<?= $arResult['VIDEO'] ?>"></a>
                <?php
            }
            ?>
        </div>
        <?php
        if ($arResult['UF_LAT'] != 0 && $arResult['UF_LONG'] != 0) {
            ?>
            <div id="map-container">
                <div id="<?= $mapType ?>-map" class="map"></div>
            </div>
            <?php
        }
        ?>
        <div class="delimiter"></div>
        <div class="properties">
            <div class="item">
                <div class="name"><?= Loc::getMessage('DETAIL_COMPONENT_DESC') ?></div>
                <div class="value"><?= TxtToHTML($arResult['UF_DESCRIPTION'], false) ?></div>
            </div>
        </div>
        <?php
        if (count($characteristics)) {
            ?>
            <div class="delimiter"></div>
            <div class="properties">
                <?php
                foreach ($characteristics as $key => $val) {
                    ?>
                    <div class="item">
                        <div class="name"><?= $val['name'] ?></div>
                        <div class="value">
                            <?php
                            if (is_array($val['value'])) {
                                echo implode(', ', $val['value']);
                            } else {
                                echo $val['value'];
                            }
                            ?>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
            <?php
        }
        ?>
        <div class="delimiter"></div>
        <div class="properties">
            <div class="item">
                <div class="name"><?= Loc::getMessage('DETAIL_COMPONENT_SHARE') ?></div>
                <div class="value ya-share2"
                     data-services="vkontakte,facebook,odnoklassniki,twitter,viber,whatsapp,skype,telegram"></div>
            </div>
        </div>
        <div class="delimiter"></div>
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:similar',
            '',
            [
                'IBLOCK_ID' => $arResult['UF_IBLOCK_ID'],
                'CITY_ID' => $arResult['UF_CITY_ID'],
                'SECTION_DEPTH_1' => $arResult['UF_SECTION_DEPTH_1'],
                'SECTION_ID' => $arResult['UF_SECTION_ID'],
                'EXCLUDE_ID' => $arResult['UF_ID'],
                'CITIES' => $arResult['CITIES'],
            ]
        );
        ?>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        if (intval($arResult['UF_OLD_PRICE'])) {
            ?>
            <div class="detail-price__old">
                <?= Utils::price($arResult['UF_OLD_PRICE']) ?>
                <?= $currencyName ?>
            </div>
            <?php
        }
        ?>
        <div class="detail-price">
            <?= Utils::price($arResult['UF_PRICE']) ?>
            <?= $currencyName ?>
        </div>
        <button class="apply _mt _mb showPhone" data-id="<?= $arResult['UF_ID'] ?>"
                data-i="<?= $arResult['UF_IBLOCK_ID'] ?>"
                data-phone="<?= $arResult['USER']['PERSONAL_PHONE'] ?>" data-show="0"
                data-phone-formatted="<?= Utils::formatPhone($arResult['USER']['PERSONAL_PHONE']) ?>">
            <?= Loc::getMessage('DETAIL_COMPONENT_LOOK_PHONE') ?>
        </button>
        <div class="_box _mb">
            <div class="owner">
                <?php
                if (isset($arResult['USER']['AVATAR'])) {
                    ?>
                    <div class="image">
                        <img src="<?= $arResult['USER']['AVATAR']['src'] ?>" alt="<?= $arResult['USER']['NAME'] ?>">
                    </div>
                    <?php
                } else {
                    ?>
                    <div class="colored-name"
                         style="background: <?= strlen($arResult['USER']['NAME']) ? Utils::userBgColor($arResult['USER']['NAME']) : '#ffffff' ?>">
                        <?= strlen($arResult['USER']['NAME']) ? Utils::userNamePrefix($arResult['USER']['NAME'], $arResult['USER']['LAST_NAME']) : '' ?>
                    </div>
                    <?php
                }
                ?>
                <div class="data">
                    <div class="name">
                        <a href="<?= SITE_DIR ?>user/<?= $arResult['USER']['ID'] ?>/">
                            <?= $arResult['USER']['NAME'] ?>
                        </a>
                        <?php
                        if ($USER->IsAuthorized() && intval(Option::get(DBOARD, 'chatEnabled')) > 0) {
                            ?>
                            <span class="status indicator"></span>
                            <?php
                        }
                        ?>
                    </div>
                    <div class="register">
                        <?= Loc::getMessage('DETAIL_COMPONENT_USER_DATE_REGISTER') ?>
                        : <?= date('d.m.Y', strtotime($arResult['USER']['DATE_REGISTER'])) ?>
                    </div>
                    <div class="rating">
                        <?php
                        foreach ([20, 40, 60, 80, 100] as $chunk) {
                            if ($arResult['CURRENT_RATING'] >= $chunk) {
                                ?>
                                <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <g>
                                        <path d="M7 10.713L11.3283 14L9.67167 8.69217L14 5.47826H8.69167L7 0L5.30833 5.47826H0L4.32833 8.69217L2.67167 14L7 10.713Z"
                                              fill="#F2994A"/>
                                    </g>
                                </svg>
                                <?php
                            } else {
                                ?>
                                <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <g>
                                        <path d="M7 10.713L11.3283 14L9.67167 8.69217L14 5.47826H8.69167L7 0L5.30833 5.47826H0L4.32833 8.69217L2.67167 14L7 10.713Z"
                                              fill="#BDBDBD"/>
                                    </g>
                                </svg>
                                <?php
                            }
                        }
                        ?>
                    </div>
                    <div class="reviews">
                        <a href="<?= SITE_DIR ?>user/<?= $arResult['USER']['ID'] ?>/?reviews=1">
                            <?php
                            if ($arResult['REVIEWS_COUNT'] > 0) {
                                echo Utils::declension(
                                    $arResult['REVIEWS_COUNT'],
                                    [
                                        Loc::getMessage('DETAIL_COMPONENT_REV_1'),
                                        Loc::getMessage('DETAIL_COMPONENT_REV_2'),
                                        Loc::getMessage('DETAIL_COMPONENT_REV_3')
                                    ]
                                );
                            } else {
                                echo Loc::getMessage('DETAIL_COMPONENT_NO_REVIEWS');
                            }
                            ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="detail-stat _mb">
            <div class="item">
                <div class="icon">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g id="schedule_24px">
                            <path id="icon/action/schedule_24px" fill-rule="evenodd" clip-rule="evenodd"
                                  d="M8.9925 1.5C4.8525 1.5 1.5 4.86 1.5 9C1.5 13.14 4.8525 16.5 8.9925 16.5C13.14 16.5 16.5 13.14 16.5 9C16.5 4.86 13.14 1.5 8.9925 1.5ZM9 15C5.685 15 3 12.315 3 9C3 5.685 5.685 3 9 3C12.315 3 15 5.685 15 9C15 12.315 12.315 15 9 15ZM8.25 5.25H9.375V9.1875L12.75 11.19L12.1875 12.1125L8.25 9.75V5.25Z"
                                  fill="#4F4F4F"/>
                        </g>
                    </svg>
                </div>
                <div class="value">
                <span title="<?= date('Y-m-d H:i', strtotime($arResult['UF_ACTIVE_FROM'])) ?>"
                      class="timestamp"></span>
                </div>
            </div>
            <div class="item">
                <div class="icon">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g id="remove_red_eye_24px">
                            <path id="icon/image/remove_red_eye_24px" fill-rule="evenodd" clip-rule="evenodd"
                                  d="M0.75 9C2.0475 5.7075 5.25 3.375 9 3.375C12.75 3.375 15.9525 5.7075 17.25 9C15.9525 12.2925 12.75 14.625 9 14.625C5.25 14.625 2.0475 12.2925 0.75 9ZM15.615 9C14.3775 6.4725 11.8425 4.875 9 4.875C6.1575 4.875 3.6225 6.4725 2.385 9C3.6225 11.5275 6.15 13.125 9 13.125C11.85 13.125 14.3775 11.5275 15.615 9ZM9 7.125C10.035 7.125 10.875 7.965 10.875 9C10.875 10.035 10.035 10.875 9 10.875C7.965 10.875 7.125 10.035 7.125 9C7.125 7.965 7.965 7.125 9 7.125ZM5.625 9C5.625 7.14 7.14 5.625 9 5.625C10.86 5.625 12.375 7.14 12.375 9C12.375 10.86 10.86 12.375 9 12.375C7.14 12.375 5.625 10.86 5.625 9Z"
                                  fill="#4F4F4F"/>
                        </g>
                    </svg>
                </div>
                <div class="value">
                    <?= Loc::getMessage('DETAIL_COMPONENT_VIEWS') ?>:
                    <?= Loc::getMessage('DETAIL_COMPONENT_VIEWS_TOTAL') ?>: <?= $arResult['STAT']['TOTAL'] ?>,
                    <?= Loc::getMessage('DETAIL_COMPONENT_VIEWS_TODAY') ?> <?= $arResult['STAT']['TODAY'] ?>
                </div>
            </div>
            <?php
            if (isset($arResult['SHOW_PHONE_STAT'])) {
                ?>
                <div class="item">
                    <div class="icon">
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g id="remove_red_eye_24px">
                                <path id="icon/image/remove_red_eye_24px" fill-rule="evenodd" clip-rule="evenodd"
                                      d="M0.75 9C2.0475 5.7075 5.25 3.375 9 3.375C12.75 3.375 15.9525 5.7075 17.25 9C15.9525 12.2925 12.75 14.625 9 14.625C5.25 14.625 2.0475 12.2925 0.75 9ZM15.615 9C14.3775 6.4725 11.8425 4.875 9 4.875C6.1575 4.875 3.6225 6.4725 2.385 9C3.6225 11.5275 6.15 13.125 9 13.125C11.85 13.125 14.3775 11.5275 15.615 9ZM9 7.125C10.035 7.125 10.875 7.965 10.875 9C10.875 10.035 10.035 10.875 9 10.875C7.965 10.875 7.125 10.035 7.125 9C7.125 7.965 7.965 7.125 9 7.125ZM5.625 9C5.625 7.14 7.14 5.625 9 5.625C10.86 5.625 12.375 7.14 12.375 9C12.375 10.86 10.86 12.375 9 12.375C7.14 12.375 5.625 10.86 5.625 9Z"
                                      fill="#4F4F4F"/>
                            </g>
                        </svg>
                    </div>
                    <div class="value">
                        <?= Loc::getMessage('DETAIL_COMPONENT_VIEWS_PHONE') ?>:
                        <?= Loc::getMessage('DETAIL_COMPONENT_VIEWS_TOTAL') ?>
                        : <?= $arResult['SHOW_PHONE_STAT']['TOTAL'] ?>,
                        <?= Loc::getMessage('DETAIL_COMPONENT_VIEWS_TODAY') ?> <?= $arResult['SHOW_PHONE_STAT']['TODAY'] ?>
                    </div>
                </div>
                <?php
            }
            if (isset($arResult['CITY_PARAMS']['name'])) {
                ?>
                <div class="item">
                    <div class="icon">
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g id="pin_drop_24px">
                                <path id="icon/maps/pin_drop_24px" fill-rule="evenodd" clip-rule="evenodd"
                                      d="M9 1.5C11.4825 1.5 13.5 3.5175 13.5 6C13.5 9.375 9 14.25 9 14.25C9 14.25 4.5 9.375 4.5 6C4.5 3.5175 6.5175 1.5 9 1.5ZM14.25 16.5V15H3.75V16.5H14.25ZM6 6C6 4.3425 7.3425 3 9 3C10.6575 3 12 4.3425 12 6C12 7.5975 10.44 10.095 9 11.9325C7.56 10.1025 6 7.5975 6 6ZM7.5 6C7.5 5.175 8.175 4.5 9 4.5C9.825 4.5 10.5 5.175 10.5 6C10.5 6.825 9.8325 7.5 9 7.5C8.175 7.5 7.5 6.825 7.5 6Z"
                                      fill="#4F4F4F"/>
                            </g>
                        </svg>
                    </div>
                    <div class="value"><?= $arResult['CITY_PARAMS']['name'] ?></div>
                </div>
                <?php
            }
            ?>
        </div>

        <?php
        if (intval($arResult['UF_MODERATION']) != 2) {
            ?>
            <div class="_box _mb">
                <div class="moderation">
                    <button id="approve" class="approve" data-id="<?= $arResult['UF_ID'] ?>"
                            data-i="<?= $arResult['UF_IBLOCK_ID'] ?>">
                        <?= Loc::getMessage('DETAIL_COMPONENT_APPROVE') ?>
                    </button>
                </div>
                <div class="detail-attention">
                    <?= Loc::getMessage('DETAIL_COMPONENT_APPROVE_DESCRIPTION') ?>
                </div>
            </div>
            <div class="_box _mb">
                <div class="moderation">
                <textarea id="reject-reason" cols="30" rows="5"
                          placeholder="<?= Loc::getMessage('DETAIL_COMPONENT_REJECT_REASON') ?>"></textarea>
                    <button id="reject" class="reject _mt" data-id="<?= $arResult['UF_ID'] ?>"
                            data-i="<?= $arResult['UF_IBLOCK_ID'] ?>">
                        <?= Loc::getMessage('DETAIL_COMPONENT_REJECT') ?>
                    </button>
                </div>
                <div class="detail-attention">
                    <?= Loc::getMessage('DETAIL_COMPONENT_REJECT_REASON_DESCRIPTION') ?>
                </div>
            </div>
            <div class="_box _mb">
                <div class="moderation">
                    <button id="remove" class="reject" data-id="<?= $arResult['UF_ID'] ?>"
                            data-i="<?= $arResult['UF_IBLOCK_ID'] ?>">
                        <?= Loc::getMessage('DETAIL_COMPONENT_REMOVE') ?>
                    </button>
                </div>
                <div class="detail-attention">
                    <?= Loc::getMessage('DETAIL_COMPONENT_REMOVE_DESCRIPTION') ?>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
    <script>
        var siteTemplatePath = '<?= SITE_TEMPLATE_PATH ?>',
            siteDir = '<?=SITE_DIR?>',
            locationLat = '<?= $arResult['UF_LAT'] ?>',
            locationLong = '<?= $arResult['UF_LONG'] ?>',
            currentPath = '<?=$this->GetFolder()?>',
            __sendMessageSuccess = '<?=Loc::getMessage('DETAIL_COMPONENT_SEND_MESSAGE_SUCCESS')?>',
            __showAllProperties = '<?=Loc::getMessage('DETAIL_COMPONENT_LOOK_ALL')?>',
            __hideAllProperties = '<?=Loc::getMessage('DETAIL_COMPONENT_HIDE')?>';

        (function () {
            function numpf(n, f, s, t) {
                var n10 = n % 10;
                if ((n10 === 1) && ((n === 1) || (n > 20))) {
                    return f;
                } else if ((n10 > 1) && (n10 < 5) && ((n > 20) || (n < 10))) {
                    return s;
                } else {
                    return t;
                }
            }

            jQuery.timeago.settings.strings = {
                prefixAgo: null,
                prefixFromNow: "<?=Loc::getMessage('TIME_ACROSS')?>",
                suffixAgo: "<?=Loc::getMessage('TIME_BACK')?>",
                suffixFromNow: null,
                seconds: "<?=Loc::getMessage('TIME_LESS_MINUTE')?>",
                minute: "<?=Loc::getMessage('TIME_MINUTE_4')?>",
                minutes: function (value) {
                    return numpf(value, "%d <?=Loc::getMessage('TIME_MINUTE_1')?>", "%d <?=Loc::getMessage('TIME_MINUTE_2')?>", "%d <?=Loc::getMessage('TIME_MINUTE_3')?>");
                },
                hour: "<?=Loc::getMessage('TIME_HOUR_1')?>",
                hours: function (value) {
                    return numpf(value, "%d <?=Loc::getMessage('TIME_HOUR_1')?>", "%d <?=Loc::getMessage('TIME_HOUR_2')?>", "%d <?=Loc::getMessage('TIME_HOUR_3')?>");
                },
                day: "<?=Loc::getMessage('TIME_DAY_1')?>",
                days: function (value) {
                    return numpf(value, "%d <?=Loc::getMessage('TIME_DAY_1')?>", "%d <?=Loc::getMessage('TIME_DAY_2')?>", "%d <?=Loc::getMessage('TIME_DAY_3')?>");
                },
                month: "<?=Loc::getMessage('TIME_MONTH_1')?>",
                months: function (value) {
                    return numpf(value, "%d <?=Loc::getMessage('TIME_MONTH_1')?>", "%d <?=Loc::getMessage('TIME_MONTH_2')?>", "%d <?=Loc::getMessage('TIME_MONTH_3')?>");
                },
                year: "<?=Loc::getMessage('TIME_YEAR_1')?>",
                years: function (value) {
                    return numpf(value, "%d <?=Loc::getMessage('TIME_YEAR_1')?>", "%d <?=Loc::getMessage('TIME_YEAR_2')?>", "%d <?=Loc::getMessage('TIME_YEAR_3')?>");
                }
            };
        })();
    </script>
<?php
if ($USER->IsAuthorized() && intval(Option::get(DBOARD, 'chatEnabled')) > 0) {
    ?>
    <script>
        __ownerId = '<?=md5($arResult['UF_USER_ID'])?>';
        BX.message({
            'owner_id': '<?=md5($arResult['UF_USER_ID'])?>',
            'status_online': '<?=Loc::getMessage('DETAIL_COMPONENT_ONLINE')?>',
            'status_offline': '<?=Loc::getMessage('DETAIL_COMPONENT_OFFLINE')?>',
        });
    </script>
    <?php
}
?>