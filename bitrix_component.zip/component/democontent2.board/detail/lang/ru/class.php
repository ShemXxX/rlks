<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 08.10.2018
 * Time: 09:05
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['CLASS_SERVICE_UP_DESCRIPTION'] = 'Услуга разового поднятия в каталоге для объявления ID:#ID#';
$MESS['CLASS_SERVICE_COLOR_DESCRIPTION'] = 'Услуга выделения цветом в каталоге для объявления ID:#ID#';
$MESS['CLASS_SERVICE_VIP_DESCRIPTION'] = 'Услуга "VIP" для объявления ID:#ID#';
$MESS['CLASS_SERVICE_PREMIUM_DESCRIPTION'] = 'Услуга "Premium" для объявления ID:#ID#';
$MESS['CLASS_SERVICE_TURBO_DESCRIPTION'] = 'Пакет "Турбо" для объявления ID:#ID#';