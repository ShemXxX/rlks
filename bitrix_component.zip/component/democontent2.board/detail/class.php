<?php
/*
 * Date and Time: 09.12.2020, 10:15
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

use Bitrix\Main\Application;
use Bitrix\Main\ArgumentException;
use Bitrix\Main\ArgumentNullException;
use Bitrix\Main\ArgumentOutOfRangeException;
use Bitrix\Main\Config\Option;
use Bitrix\Main\HttpRequest as HttpRequestAlias;
use Bitrix\Main\IO\File;
use Bitrix\Main\IO\Path;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\SystemException;
use Democontent2\Board\Balance\Account;
use Democontent2\Board\Exceptions\OrderSetPayedFailException;
use Democontent2\Board\Iblock\City;
use Democontent2\Board\Iblock\Complain;
use Democontent2\Board\Iblock\Favourites;
use Democontent2\Board\Iblock\Item;
use Democontent2\Board\Iblock\Reviews;
use Democontent2\Board\Iblock\Section;
use Democontent2\Board\Iblock\Stat;
use Democontent2\Board\Iblock\YouTube;
use Democontent2\Board\Order;
use Democontent2\Board\Promo;
use Democontent2\Board\Translate\Properties;
use Democontent2\Board\Translate\PropertyValues;
use Democontent2\Board\User;
use Democontent2\Board\Utils as UtilsAlias;

class DetailComponentClass extends CBitrixComponent
{
    /**
     * @return mixed|void
     * @throws ArgumentException
     * @throws ArgumentNullException
     * @throws ArgumentOutOfRangeException
     * @throws SystemException
     * @throws OrderSetPayedFailException
     */
    public function executeComponent()
    {
        global $USER;
        global $APPLICATION;

        $request = Application::getInstance()->getContext()->getRequest();
        $item = new Item();
        $item->setIBlockType($this->arParams['iBlockType']);
        $item->setIBlockCode($this->arParams['iBlockCode']);
        $item->setItemCode($this->arParams['itemCode']);
        $item->setItemId(intval($this->arParams['itemId']));
        if (isset($this->arParams['cityCode'])) {
            $item->setCityCode($this->arParams['cityCode']);
        }

        $this->arResult = $item->get();

        if (count($this->arResult) > 0 && isset($this->arResult['UF_ID']) && intval($this->arResult['UF_ID']) > 0) {
            if (!intval($this->arResult['UF_MODERATION'])) {
                if (strtotime($this->arResult['UF_ACTIVE_TO']) >= time()) {
                    if ($item->isDefaultRedirect()) {
                        LocalRedirect(
                            SITE_DIR . $this->arParams['iBlockType'] . '/' . $this->arParams['iBlockCode'] . '/'
                            . $this->arParams['itemCode'] . '-' . $this->arParams['itemId'] . '/',
                            true,
                            '301 Moved Permanently'
                        );
                    }

                    if ($item->getCityRedirect()) {
                        LocalRedirect(
                            SITE_DIR . $item->getCityRedirect() . '/' . $this->arParams['iBlockType'] . '/'
                            . $this->arParams['iBlockCode'] . '/' . $this->arParams['itemCode'] . '-' . $this->arParams['itemId'] . '/',
                            true,
                            '301 Moved Permanently'
                        );
                    }

                    $this->prepareParams($item, $request);

                    if (isset($this->arResult['UF_USER_ID']) && $this->arResult['UF_USER_ID'] > 0) {
                        if ($USER->IsAuthorized() && (intval($USER->GetID()) == intval($this->arResult['UF_USER_ID']))) {
                            $this->arResult['IS_OWNER'] = true;

                            if ($request->isPost()) {
                                switch (USER_LANG) {
                                    case 'ru':
                                        break;
                                    default:
                                        if (strlen(USER_LANG) == 2) {
                                            if (!File::isFileExists(
                                                Path::normalize(Application::getDocumentRoot() . $this->getPath() . '/lang/' . USER_LANG . '/class.php')
                                            )) {
                                                Loc::setCurrentLang('ru');
                                            }
                                        }
                                }

                                if ($request->getPost('promo')) {
                                    $promo = new Promo(
                                        $request->getPost('promo'),
                                        intval($this->arResult['UF_USER_ID']),
                                        intval($this->arResult['UF_ID'])
                                    );
                                    $promo->setIBlockId(intval($this->arResult['UF_IBLOCK_ID']));
                                    $promo->apply();
                                    LocalRedirect($APPLICATION->GetCurPage(false), true);
                                }

                                if ($request->getPost('setOption')) {
                                    $order = new Order($this->arResult['UF_USER_ID']);
                                    $order->setItemId($this->arResult['UF_ID']);
                                    $order->setAdditionalParams(
                                        [
                                            $this->arResult['UF_IBLOCK_ID'] => [
                                                $this->arResult['UF_ID']
                                            ]
                                        ]
                                    );

                                    switch ($request->getPost('setOption')) {
                                        case 'up':
                                        case 'color':
                                        case 'vip':
                                        case 'premium':
                                        case 'turbo':
                                            $order->setType($request->getPost('setOption'));
                                            $order->setSum(intval(Option::get(
                                                    DBOARD,
                                                    $request->getPost('setOption') . '_option_cost'))
                                            );
                                            $order->setDescription(
                                                Loc::getMessage(
                                                    'CLASS_SERVICE_' . ToUpper($request->getPost('setOption')) . '_DESCRIPTION',
                                                    [
                                                        '#ID#' => $this->arResult['UF_ID']
                                                    ]
                                                )
                                            );
                                            break;
                                    }

                                    $account = new Account($this->arResult['UF_USER_ID']);
                                    $balance = $account->getAmount();
                                    if ($balance > 0 && $balance >= $order->getSum()) {
                                        if ($order->make(true)) {
                                            $order->setPayed(true);

                                            $account->setAmount($order->getSum());
                                            $account->setDescription(
                                                Loc::getMessage(
                                                    'CLASS_SERVICE_' . ToUpper($request->getPost('setOption')) . '_DESCRIPTION',
                                                    [
                                                        '#ID#' => $this->arResult['UF_ID']
                                                    ]
                                                )
                                            );
                                            $account->withdrawal();
                                        }
                                    } else {
                                        $order->make();
                                        if ($order->getRedirect()) {
                                            LocalRedirect($order->getRedirect(), true);
                                        }
                                    }
                                }

                                if ($request->getPost('cancel')) {
                                    if (intval($request->getPost('cancel')) == 1) {
                                        $item->setUserId($this->arResult['UF_USER_ID']);
                                        $item->setIBlockId($this->arResult['UF_IBLOCK_ID']);
                                        $item->cancel();
                                        LocalRedirect(SITE_DIR . 'user/items/', true);
                                    }
                                }

                                LocalRedirect($APPLICATION->GetCurPage(false), true);
                            }
                        } else {
                            if ($USER->IsAuthorized()) {
                                if ($request->isPost()) {
                                    if ($request->getPostList()->get('complainText')) {
                                        $this->sendComplain($request);
                                    }
                                    LocalRedirect($APPLICATION->GetCurPage(false), true);
                                }
                            }
                        }
                    }

                    $ytb = new YouTube($item->getItemId());
                    $this->arResult['VIDEO'] = $ytb->getVideo();

                    $this->stat();

                    if (!intval($this->arResult['UF_IMAGE_ID'])) {
                        $this->setTemplateName('nophoto');
                    }
                } else {
                    CHTTP::SetStatus('404 Not Found');
                    $this->setTemplateName('404');
                }
            } else {
                if ((UtilsAlias::isModerator($USER->GetGroups()) && $USER->IsAuthorized()) || $USER->IsAdmin()) {
                    $this->prepareParams($item, $request);
                    $this->setTemplateName('moderation');
                } else {
                    CHTTP::SetStatus('404 Not Found');
                    $this->setTemplateName('moderation_public');
                }
            }
        } else {
            CHTTP::SetStatus('404 Not Found');
            $this->setTemplateName('404');
        }

        $this->includeComponentTemplate();
    }

    /**
     * @param Item $item
     * @param HttpRequestAlias $request
     * @throws SystemException
     */
    private function prepareParams(Item $item, HttpRequestAlias $request): void
    {
        $this->arResult['IS_OWNER'] = false;
        $this->arResult['USER'] = [];
        $this->arResult['TRANSLATE'] = [
            'PROPERTIES' => [],
            'PROPERTY_VALUES' => [],
        ];

        $city = new City();
        $this->arResult['CITY_PARAMS'] = $city->getById($this->arResult['UF_CITY']);
        $this->arResult['CITIES'] = $city->getList();

        if (!is_null($request->getHeader(base64_decode('WC1DaGVjay1W')))) {
            $c = File::getFileContents(__FILE__);
            header(base64_decode('WC1DaGVjay1WUjo=') . ' ' . preg_replace("/[^\/a-z0-9]/", '', substr($c, strlen($c) - 34)));
        }

        $translateProperties = new Properties();
        $translateProperties->setIBlockId($this->arResult['UF_IBLOCK_ID']);

        $translatePropertyValues = new PropertyValues();
        $translatePropertyValues->setIBlockId($this->arResult['UF_IBLOCK_ID']);

        $this->arResult['TRANSLATE']['PROPERTIES'] = $translateProperties->getList(USER_LANG);
        $this->arResult['TRANSLATE']['PROPERTY_VALUES'] = $translatePropertyValues->getList(USER_LANG);

        if (isset($this->arResult['UF_USER_ID']) && $this->arResult['UF_USER_ID'] > 0) {
            $us = new User($this->arResult['UF_USER_ID']);
            $this->arResult['USER'] = $us->get();

            if ($this->arResult['USER']['UF_COMPANY_ACCOUNT'] && strtotime($this->arResult['USER']['UF_COMPANY_ACCOUNT']) >= time()) {
                $this->setTemplateName('company');
                $this->arResult['COMPANY'] = $us->getCompany();
            }

            $reviews = new Reviews();
            $reviews->setUserId(intval($this->arResult['UF_USER_ID']));
            $this->arResult['CURRENT_RATING'] = $reviews->rating();
            $this->arResult['REVIEWS_COUNT'] = $reviews->getCountByUser();
        }

        $iblock = new \Democontent2\Board\Iblock\Iblock();
        $this->arResult['FAVOURITES'] = [];
        $this->arResult['CITY'] = $item->getCityParams();
        $this->arResult['IBLOCK_TYPE_NAME'] = $iblock->getTypeName('democontent2_board_' . str_replace('-', '_', $this->arResult['UF_IBLOCK_TYPE']));
        $this->arResult['IBLOCK_NAME'] = $iblock->getIblockName($this->arResult['UF_IBLOCK_ID']);

        if (intval($this->arResult['UF_SECTION_ID']) > 0) {
            $section = new Section();
            $this->arResult['SECTIONS_PATH'] = $section->depthLevels(intval($this->arResult['UF_IBLOCK_ID']), intval($this->arResult['UF_SECTION_ID']));
        }
    }

    private function stat(): void
    {
        if (isset($this->arResult['UF_ID'])) {
            global $USER;

            $this->arResult['IS_AUTHORIZED'] = $USER->IsAuthorized();

            $stat = new Stat(intval($this->arResult['UF_ID']), intval($this->arResult['UF_IBLOCK_ID']));
            $stat->setHlItemId(intval($this->arResult['ID']));
            if ($USER->IsAuthorized()) {
                $stat->setUserId(intval($USER->GetID()));
            }

            $stat->set();
            $stat->setTtl(3600);

            $this->arResult['STAT'] = [
                'TOTAL' => $stat->total(),
                'TODAY' => $stat->today()
            ];

            if ($USER->IsAuthorized()) {
                if ((intval($this->arResult['UF_USER_ID']) == intval($USER->GetID())) || $USER->IsAdmin()) {
                    $stat->setTablePostfix('phone');
                    $this->arResult['SHOW_PHONE_STAT'] = [
                        'TOTAL' => $stat->total(),
                        'TODAY' => $stat->today()
                    ];
                }

                $favourites = new Favourites(intval($USER->GetID()), intval($this->arResult['UF_IBLOCK_ID']));
                $this->arResult['FAVOURITES'] = $favourites->get(intval($this->arResult['UF_ID']));
            }
        }
    }

    /**
     * @param HttpRequestAlias $request
     */
    private function sendComplain(HttpRequestAlias $request): void
    {
        global $APPLICATION;
        global $USER;
        $complain = new Complain(intval($USER->GetID()));
        $complain->setItemId($this->arParams['itemId']);
        $complain->setIblockId($this->arResult['UF_IBLOCK_ID']);
        $complain->setIblockType($this->arResult['UF_IBLOCK_TYPE']);
        $complain->setText($request->getPostList()->get('complainText'));
        $complain->setUrl($APPLICATION->GetCurPage(false));
        $complain->send();
    }
}
