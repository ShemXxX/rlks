<?php
/*
 * Date and Time: 11.11.2020, 13:48
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

use Bitrix\Main\Context;
use Democontent2\Board\Iblock\City;
use Democontent2\Board\Iblock\Items;
use Democontent2\Board\Iblock\Reviews;
use Democontent2\Board\User;

class UserPublicProfileClass extends CBitrixComponent
{
    public function executeComponent()
    {
        global $USER;

        $request = Context::getCurrent()->getRequest();
        $us = new User(intval($this->arParams['id']));
        $userParams = $us->get();
        if (count($userParams) > 0) {
            $city = new City();
            $this->arResult['CITIES'] = $city->getList();

            if ($userParams['UF_COMPANY_ACCOUNT'] && strtotime($userParams['UF_COMPANY_ACCOUNT']) >= time()) {
                $userCompany = $us->getCompany();
                if ($request->get('reviews') && intval($request->get('reviews')) == 1) {
                    LocalRedirect(SITE_DIR . 'store-' . $userCompany['UF_COMPANY_CODE'] . '/?reviews=1', true, '301 Moved Permanently');
                }
                LocalRedirect(SITE_DIR . 'store-' . $userCompany['UF_COMPANY_CODE'] . '/', true, '301 Moved Permanently');
            }

            if ($request->isPost()) {
                if ($USER->IsAuthorized()) {
                    if (intval($USER->GetID()) != intval($this->arParams['id'])) {
                        if ($request->getPost('review')) {
                            $reviews = new Reviews();
                            $reviews->setUserId(intval($USER->GetID()));
                            $reviews->setTo(intval($this->arParams['id']));
                            $reviews->setText($request->getPost('review'));

                            try {
                                $reviews->setRating($request->getPost('rating'));
                            } catch (Exception $e) {
                            }

                            $reviews->add();
                        }
                    }
                }

                LocalRedirect(SITE_DIR . 'user/' . $this->arParams['id'] . '/', true);
            }

            $reviews = new Reviews();
            $reviews->setUserId(intval($this->arParams['id']));
            $this->arResult['CURRENT_RATING'] = $reviews->rating();
            $this->arResult['REVIEWS'] = $reviews->getListByUser();

            $reviews->setUserId(intval($USER->GetID()));
            $reviews->setTo(intval($this->arParams['id']));
            $this->arResult['ALLOW_REVIEW'] = $reviews->checkReview();

            $this->arResult['USER'] = $userParams;

            if ($request->get('id') && intval($request->get('id'))) {
                $items = new Items();
                $items->setUserId(intval($this->arParams['id']));
                $this->arResult['ITEMS'] = $items->getCategoryByUser(intval($request->get('id')));

                if (!count($this->arResult['ITEMS'])) {
                    CHTTP::SetStatus('404 Not Found');
                    $this->setTemplateName('404');
                } else {
                    $this->setTemplateName('category');
                }
            } else {
                if ($request->get('reviews') && intval($request->get('reviews')) == 1) {
                    $this->setTemplateName('reviews');
                } else {
                    $items = new Items();
                    $items->setUserId(intval($this->arParams['id']));
                    $this->arResult['ITEMS'] = $items->getCategoriesByUser();
                }
            }
        } else {
            CHTTP::SetStatus('404 Not Found');
            $this->setTemplateName('404');
        }
        $this->includeComponentTemplate();
    }
}
