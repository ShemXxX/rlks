<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 09.10.2018
 * Time: 11:09
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['USER_PUBLIC_PROFILE_DATE'] = 'Дата регистрации';
$MESS['USER_PUBLIC_PROFILE_BTN_MORE'] = 'Подробнее';
$MESS['USER_PUBLIC_PROFILE_TAB_HEAD1'] = 'Объявления';
$MESS['USER_PUBLIC_PROFILE_TAB_HEAD2'] = 'Отзывы';
$MESS['USER_PUBLIC_PROFILE_ADD_FEEDBACK'] = 'Оставить отзыв';
$MESS['USER_PUBLIC_PROFILE_ADD_FEEDBACK_PLACEHOLDER'] = 'Введите текст отзыва...';
$MESS['USER_PUBLIC_PROFILE_ADD_FEEDBACK_SEND'] = 'Отправить отзыв';
$MESS['USER_PUBLIC_PROFILE_ADD_FEEDBACK_ABANDONED'] = 'Вы уже оставили отзыв для этого пользователя.';
$MESS['USER_PUBLIC_PROFILE_ADD_FEEDBACK_EMPTY'] = 'У данного пользователя еще нет отзывов';
$MESS['USER_PUBLIC_PROFILE_REV_1'] = 'отзыв';
$MESS['USER_PUBLIC_PROFILE_REV_2'] = 'отзыва';
$MESS['USER_PUBLIC_PROFILE_REV_3'] = 'отзывов';
$MESS['USER_PUBLIC_PROFILE_SHOW_ALL'] = 'Посмотреть все';
$MESS['USER_PUBLIC_PROFILE_ONLINE'] = 'онлайн';
$MESS['USER_PUBLIC_PROFILE_OFFLINE'] = 'не в сети';
$MESS['USER_PUBLIC_PROFILE_DATE_REGISTER'] = 'На сайте с';
$MESS['DETAIL_COMPONENT_REV_1'] = 'отзыв';
$MESS['DETAIL_COMPONENT_REV_2'] = 'отзыва';
$MESS['DETAIL_COMPONENT_REV_3'] = 'отзывов';