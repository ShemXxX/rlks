<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 09.10.2018
 * Time: 11:09
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (method_exists($this, 'setFrameMode')) {
    $this->setFrameMode(true);
}

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Democontent2\Board\Utils;

$reviewsCount = count($arResult['REVIEWS']);

?>
<div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
    <?php
    foreach ($arResult['ITEMS'] as $type => $typeValue) {
        foreach ($typeValue as $iblockId => $iblock) {
            $names = [];
            $url = [];
            foreach ($iblock['names'] as $name) {
                $url[] = $name['code'];
                $names[] = '<a href="' . SITE_DIR . implode('/', $url) . '/">' . $name['name'] . '</a>';
            }
            ?>
            <div class="section-links">
                <?php
                foreach ($names as $name) {
                    ?>
                    <div class="item">
                        <?= $name ?>
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g>
                                <path d="M16.125 9L13.125 6V8.25H1.875V9.75H13.125V12L16.125 9Z" fill="#4F4F4F"/>
                            </g>
                        </svg>
                    </div>
                    <?php
                }

                if (count($iblock['items']) >= 4) {
                    ?>
                    <div class="item">
                        <a href="<?= $APPLICATION->GetCurPage(false) ?>?id=<?= $iblockId ?>">
                            <?= Loc::getMessage('USER_PUBLIC_PROFILE_SHOW_ALL') ?>
                        </a>
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g>
                                <path d="M16.125 9L13.125 6V8.25H1.875V9.75H13.125V12L16.125 9Z" fill="#4F4F4F"/>
                            </g>
                        </svg>
                    </div>
                    <?php
                }
                ?>
            </div>
            <div class="items-list">
                <?php
                foreach ($iblock['items'] as $product) {
                    $isFavourite = in_array($product['UF_ID'], $arResult['FAVOURITES']);
                    $pict = null;
                    $imageCounter = 1;
                    if (intval($product['UF_IMAGE_ID'])) {
                        $pict = intval($product['UF_IMAGE_ID']);
                        $pict = CFile::ResizeImageGet(
                            $pict,
                            [
                                'width' => 199,
                                'height' => 151
                            ],
                            BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
                            true
                        );
                    }
                    ?>
                    <div class="item">
                        <div class="image">
                            <div class="favourite<?= ($isFavourite ? ' active' : '') ?>"
                                 data-id="<?= $product['UF_ID'] ?>" data-i="<?= $product['UF_IBLOCK_ID'] ?>">
                        <span class="wenk--right" data-wenk-pos="right"
                              data-wenk="<?= ($isFavourite ? Loc::getMessage('LIST_COMPONENT_REMOVE_FAV') : Loc::getMessage('LIST_COMPONENT_ADD_FAV')) ?>">
                            <?php
                            if ($isFavourite) {
                                ?>
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <g>
                                        <path d="M9 15.8812L7.9125 14.8912C4.05 11.3887 1.5 9.07874 1.5 6.24374C1.5 3.93374 3.315 2.11874 5.625 2.11874C6.93 2.11874 8.1825 2.72624 9 3.68624C9.8175 2.72624 11.07 2.11874 12.375 2.11874C14.685 2.11874 16.5 3.93374 16.5 6.24374C16.5 9.07874 13.95 11.3887 10.0875 14.8987L9 15.8812Z"
                                              fill="#EB5757"/>
                                    </g>
                                </svg>
                                <?php
                            } else {
                                ?>
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <g>
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                              d="M9 3.68624C9.8175 2.72624 11.07 2.11874 12.375 2.11874C14.685 2.11874 16.5 3.93374 16.5 6.24374C16.5 9.07642 13.9542 11.385 10.097 14.8826L10.0875 14.8912L9 15.8812L7.9125 14.8987L7.88289 14.8718C4.03697 11.3769 1.5 9.07149 1.5 6.24374C1.5 3.93374 3.315 2.11874 5.625 2.11874C6.93 2.11874 8.1825 2.72624 9 3.68624ZM9 13.8562L9.075 13.7812C12.645 10.5487 15 8.41124 15 6.24374C15 4.74374 13.875 3.61874 12.375 3.61874C11.22 3.61874 10.095 4.36124 9.705 5.38874H8.3025C7.905 4.36124 6.78 3.61874 5.625 3.61874C4.125 3.61874 3 4.74374 3 6.24374C3 8.41124 5.355 10.5487 8.925 13.7812L9 13.8562Z"
                                              fill="#4F4F4F"/>
                                    </g>
                                </svg>
                                <?php
                            }
                            ?>
                        </span>
                            </div>
                            <a href="<?= $product['URL'] ?>" title="<?= $product['UF_NAME'] ?>">
                                <div class="fotorama _mb" data-width="100%" data-height="151px" data-maxheight="151px"
                                     data-allowfullscreen="false" data-loop="false">
                                    <?php
                                    if (!is_null($pict)) {
                                        ?>
                                        <div data-img="<?= $pict['src'] ?>">
                                            <div class="fotorama__blur"
                                                 style="background:url(<?= $pict['src'] ?>)"></div>
                                        </div>
                                        <?php
                                    } else {
                                        ?>
                                        <svg class="stub" width="40" height="40" viewBox="0 0 40 40" fill="none"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <g>
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                      d="M35 1.66666H11.6667C9.83335 1.66666 8.33335 3.16666 8.33335 4.99999V28.3333C8.33335 30.1667 9.83335 31.6667 11.6667 31.6667H35C36.8334 31.6667 38.3334 30.1667 38.3334 28.3333V4.99999C38.3334 3.16666 36.8334 1.66666 35 1.66666ZM1.66669 8.33332H5.00002V35H31.6667V38.3333H5.00002C3.16669 38.3333 1.66669 36.8333 1.66669 35V8.33332ZM22.0167 23.05L26.6 17.15L32.5 25H14.1667L18.75 19.1167L22.0167 23.05ZM11.6667 28.3333H35V4.99999H11.6667V28.3333Z"
                                                      fill="#BDBDBD"
                                                / >
                                            </g>
                                        </svg>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </a>
                        </div>
                        <div class="content">
                            <div class="link">
                                <a href="<?= $product['URL'] ?>"><?= $product['UF_NAME'] ?></a>
                            </div>
                            <div class="location">
                                <div class="icon">
                                    <svg width="17" height="17" viewBox="0 0 17 17" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                              d="M2.125 7.45875L14.875 2.125L9.53417 14.875H8.84L6.97 10.03L2.125 8.15292V7.45875ZM9.22958 11.9425L12.2329 4.76708L5.0575 7.76333L7.48708 8.70541L8.06791 8.93208L8.29458 9.52L9.22958 11.9425Z"
                                              fill="#999999"/>
                                    </svg>
                                </div>
                                <?php
                                if (intval($product['UF_CITY'])) {
                                    ?>
                                    <div class="text">
                                        <?= $arResult['CITIES'][$product['UF_CITY']]['name'] ?>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
            <?php
        }
    }
    ?>
</div>
<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
    <div class="_box _mb">
        <div class="owner">
            <?php
            if (isset($arResult['USER']['AVATAR'])) {
                ?>
                <div class="image">
                    <img src="<?= $arResult['USER']['AVATAR']['src'] ?>" alt="<?= $arResult['USER']['NAME'] ?>">
                </div>
                <?php
            } else {
                ?>
                <div class="colored-name"
                     style="background: <?= strlen($arResult['USER']['NAME']) ? Utils::userBgColor($arResult['USER']['NAME']) : '#ffffff' ?>">
                    <?= strlen($arResult['USER']['NAME']) ? Utils::userNamePrefix($arResult['USER']['NAME'], $arResult['USER']['LAST_NAME']) : '' ?>
                </div>
                <?php
            }
            ?>
            <div class="data">
                <div class="name">
                    <?= $arResult['USER']['NAME'] ?>
                    <?= $arResult['USER']['LAST_NAME'] ?>
                    <?php
                    if ($USER->IsAuthorized() && intval(Option::get(DBOARD, 'chatEnabled')) > 0) {
                        ?>
                        <span class="status indicator"></span>
                        <?php
                    }
                    ?>
                </div>
                <div class="register">
                    <?= Loc::getMessage('USER_PUBLIC_PROFILE_DATE_REGISTER') ?>
                    : <?= date('d.m.Y', strtotime($arResult['USER']['DATE_REGISTER'])) ?>
                </div>
                <div class="rating">
                    <?php
                    foreach ([20, 40, 60, 80, 100] as $chunk) {
                        if ($arResult['CURRENT_RATING'] >= $chunk) {
                            ?>
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g>
                                    <path d="M7 10.713L11.3283 14L9.67167 8.69217L14 5.47826H8.69167L7 0L5.30833 5.47826H0L4.32833 8.69217L2.67167 14L7 10.713Z"
                                          fill="#F2994A"/>
                                </g>
                            </svg>
                            <?php
                        } else {
                            ?>
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g>
                                    <path d="M7 10.713L11.3283 14L9.67167 8.69217L14 5.47826H8.69167L7 0L5.30833 5.47826H0L4.32833 8.69217L2.67167 14L7 10.713Z"
                                          fill="#BDBDBD"/>
                                </g>
                            </svg>
                            <?php
                        }
                    }
                    ?>
                </div>
                <div class="reviews">
                    <a href="<?= SITE_DIR ?>user/<?= $arResult['USER']['ID'] ?>/?reviews=1">
                        <?php
                        if ($reviewsCount > 0) {
                            echo Utils::declension(
                                $reviewsCount,
                                [
                                    Loc::getMessage('DETAIL_COMPONENT_REV_1'),
                                    Loc::getMessage('DETAIL_COMPONENT_REV_2'),
                                    Loc::getMessage('DETAIL_COMPONENT_REV_3')
                                ]
                            );
                        } else {
                            echo Loc::getMessage('DETAIL_COMPONENT_NO_REVIEWS');
                        }
                        ?>
                    </a>
                </div>
            </div>
        </div>
        <? if ($arResult['ALLOW_REVIEW']): ?>
            <? if ($USER->IsAuthorized() && $USER->GetID() != $arResult['USER']['ID']): ?>
                <button class="write review _mt" data-auth="<?= ($USER->IsAuthorized() ? 1 : 0) ?>">
                    <?= Loc::getMessage('USER_PUBLIC_PROFILE_ADD_FEEDBACK') ?>
                </button>
                <div class="owner-add-review _mt">
                    <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post">
                <textarea rows="6" name="review"
                          placeholder="<?= Loc::getMessage('USER_PUBLIC_PROFILE_ADD_FEEDBACK_PLACEHOLDER') ?>"></textarea>
                        <button type="submit" class="write review _mt">
                            <?= Loc::getMessage('USER_PUBLIC_PROFILE_ADD_FEEDBACK_SEND') ?>
                        </button>
                    </form>
                </div>
            <? endif ?>
        <? else: ?>
            <div class="owner-review-exists">
                <?= Loc::getMessage('USER_PUBLIC_PROFILE_ADD_FEEDBACK_ABANDONED') ?>
            </div>
        <? endif ?>
    </div>
</div>

<script>
    var __ajaxPath = '<?=$this->GetFolder()?>/ajax.php',
        siteTemplatePath = '<?= SITE_TEMPLATE_PATH ?>' //TODO check,
    __ownerId = '<?=md5($arResult['USER']['ID'])?>';
    BX.message({
        'owner_id': '<?=md5($arResult['USER']['ID'])?>',
        'status_online': '<?=Loc::getMessage('USER_PUBLIC_PROFILE_ONLINE')?>',
        'status_offline': '<?=Loc::getMessage('USER_PUBLIC_PROFILE_OFFLINE')?>',
    });
</script>