<?php
/**
 * Date: 17.04.2020
 * Time: 09:23
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Page\Asset;
use Democontent2\Board\Utils;

Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/lib/timeago/jquery.timeago.js');

if (method_exists($this, 'setFrameMode')) {
    $this->setFrameMode(true);
}

$reviewsCount = count($arResult['REVIEWS']);

?>
<div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
    <h1>
        <?= Loc::getMessage('USER_PUBLIC_PROFILE_REVIEWS') ?>
        <?= $arResult['USER']['NAME'] ?>
    </h1>
    <div class="reviews _mb">
        <?php
        foreach ($arResult['REVIEWS'] as $review) {
            $image = null;
            if (intval($review['USER_FROM_PHOTO'])) {
                $image = CFile::ResizeImageGet(
                    $review['USER_FROM_PHOTO'],
                    [
                        'width' => 100,
                        'height' => 100
                    ],
                    BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
                    true
                );
            }
            ?>
            <div class="item">
                <div class="author">
                    <?php
                    if (!is_null($image)) {
                        ?>
                        <div class="image">
                            <a href="<?= SITE_DIR ?>user/<?= $review['UF_FROM'] ?>/">
                                <img src="<?= $image['src'] ?>" alt="<?= $review['USER_FROM_NAME'] ?>">
                            </a>
                        </div>
                        <?php
                    } else {
                        ?>
                        <div class="colored-name"
                             style="background: <?= strlen($arResult['USER']['NAME']) ? Utils::userBgColor($review['USER_FROM_NAME']) : '#ffffff' ?>">
                            <?= strlen($review['USER_FROM_NAME']) ? Utils::userNamePrefix($review['USER_FROM_NAME']) : '' ?>
                        </div>
                        <?php
                    }
                    ?>
                    <div class="data">
                        <a class="name" href="<?= SITE_DIR ?>user/<?= $review['UF_FROM'] ?>/">
                            <?= $review['USER_FROM_NAME'] ?>
                        </a>
                        <div title="<?= date('Y-m-d H:i', strtotime($review['UF_TEXT_TIME'])) ?>"
                             class="date timestamp"></div>
                        <div class="rating"><?= Loc::getMessage('USER_PUBLIC_PROFILE_RATING') ?>
                            <span>
                                <?php
                                foreach ([1, 2, 3, 4, 5] as $chunk) {
                                    if ($review['UF_RATING'] >= $chunk) {
                                        ?>
                                        <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <g>
                                                <path d="M7 10.713L11.3283 14L9.67167 8.69217L14 5.47826H8.69167L7 0L5.30833 5.47826H0L4.32833 8.69217L2.67167 14L7 10.713Z"
                                                      fill="#F2994A"/>
                                            </g>
                                        </svg>
                                        <?php
                                    } else {
                                        ?>
                                        <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <g>
                                                <path d="M7 10.713L11.3283 14L9.67167 8.69217L14 5.47826H8.69167L7 0L5.30833 5.47826H0L4.32833 8.69217L2.67167 14L7 10.713Z"
                                                      fill="#BDBDBD"/>
                                            </g>
                                        </svg>
                                        <?php
                                    }
                                }
                                ?>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="content"><?= $review['UF_TEXT'] ?></div>
                <?php
                if (strlen($review['UF_ANSWER'])) {
                    ?>
                    <div class="response">
                        <div class="date timestamp"
                             title="<?= date('Y-m-d H:i', strtotime($review['UF_ANSWER_TIME'])) ?>"></div>
                        <div class="content"><?= $review['UF_ANSWER'] ?></div>
                    </div>
                    <?php
                }
                ?>
            </div>
            <?php
        }
        ?>
    </div>
</div>
<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
    <div class="_box _mb">
        <div class="owner">
            <?php
            if (isset($arResult['USER']['AVATAR'])) {
                ?>
                <div class="image">
                    <img src="<?= $arResult['USER']['AVATAR']['src'] ?>" alt="<?= $arResult['USER']['NAME'] ?>">
                </div>
                <?php
            } else {
                ?>
                <div class="colored-name"
                     style="background: <?= strlen($arResult['USER']['NAME']) ? Utils::userBgColor($arResult['USER']['NAME']) : '#ffffff' ?>">
                    <?= strlen($arResult['USER']['NAME']) ? Utils::userNamePrefix($arResult['USER']['NAME'], $arResult['USER']['LAST_NAME']) : '' ?>
                </div>
                <?php
            }
            ?>
            <div class="data">
                <div class="name">
                    <?= $arResult['USER']['NAME'] ?>
                    <?php
                    if ($USER->IsAuthorized() && intval(Option::get(DBOARD, 'chatEnabled')) > 0) {
                        ?>
                        <span class="status indicator"></span>
                        <?php
                    }
                    ?>
                </div>
                <div class="register">
                    <?= Loc::getMessage('USER_PUBLIC_PROFILE_DATE_REGISTER') ?>
                    : <?= date('d.m.Y', strtotime($arResult['USER']['DATE_REGISTER'])) ?>
                </div>
                <div class="rating">
                    <?php
                    foreach ([20, 40, 60, 80, 100] as $chunk) {
                        if ($arResult['CURRENT_RATING'] >= $chunk) {
                            ?>
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g>
                                    <path d="M7 10.713L11.3283 14L9.67167 8.69217L14 5.47826H8.69167L7 0L5.30833 5.47826H0L4.32833 8.69217L2.67167 14L7 10.713Z"
                                          fill="#F2994A"/>
                                </g>
                            </svg>
                            <?php
                        } else {
                            ?>
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g>
                                    <path d="M7 10.713L11.3283 14L9.67167 8.69217L14 5.47826H8.69167L7 0L5.30833 5.47826H0L4.32833 8.69217L2.67167 14L7 10.713Z"
                                          fill="#BDBDBD"/>
                                </g>
                            </svg>
                            <?php
                        }
                    }
                    ?>
                </div>
                <div class="reviews">
                    <a href="<?= SITE_DIR ?>user/<?= $arResult['USER']['ID'] ?>/?reviews=1">
                        <?php
                        if ($reviewsCount > 0) {
                            echo Utils::declension(
                                $reviewsCount,
                                [
                                    Loc::getMessage('DETAIL_COMPONENT_REV_1'),
                                    Loc::getMessage('DETAIL_COMPONENT_REV_2'),
                                    Loc::getMessage('DETAIL_COMPONENT_REV_3')
                                ]
                            );
                        } else {
                            echo Loc::getMessage('DETAIL_COMPONENT_NO_REVIEWS');
                        }
                        ?>
                    </a>
                </div>
            </div>
        </div>
        <? if ($arResult['ALLOW_REVIEW']): ?>
            <? if ($USER->GetID() != $arResult['USER']['ID']): ?>
                <button class="write review _mt" data-auth="<?= ($USER->IsAuthorized() ? 1 : 0) ?>">
                    <?= Loc::getMessage('USER_PUBLIC_PROFILE_ADD_FEEDBACK') ?>
                </button>
                <div class="owner-add-review _mt">
                    <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post">
                        <textarea rows="6" name="review"
                                  placeholder="<?= Loc::getMessage('USER_PUBLIC_PROFILE_ADD_FEEDBACK_PLACEHOLDER') ?>"></textarea>
                        <button type="submit" class="write review _mt">
                            <?= Loc::getMessage('USER_PUBLIC_PROFILE_ADD_FEEDBACK_SEND') ?>
                        </button>
                    </form>
                </div>
            <? endif ?>
        <? else: ?>
            <div class="owner-review-exists">
                <?= Loc::getMessage('USER_PUBLIC_PROFILE_ADD_FEEDBACK_ABANDONED') ?>
            </div>
        <? endif ?>
    </div>
</div>

<script>
    var __ownerId = '<?=md5($arResult['USER']['ID'])?>';
    BX.message({
        'owner_id': '<?=md5($arResult['USER']['ID'])?>',
        'status_online': '<?=Loc::getMessage('USER_PUBLIC_PROFILE_ONLINE')?>',
        'status_offline': '<?=Loc::getMessage('USER_PUBLIC_PROFILE_OFFLINE')?>',
    });

    (function () {
        function numpf(n, f, s, t) {
            var n10 = n % 10;
            if ((n10 === 1) && ((n === 1) || (n > 20))) {
                return f;
            } else if ((n10 > 1) && (n10 < 5) && ((n > 20) || (n < 10))) {
                return s;
            } else {
                return t;
            }
        }

        jQuery.timeago.settings.strings = {
            prefixAgo: null,
            prefixFromNow: "<?=Loc::getMessage('TIME_ACROSS')?>",
            suffixAgo: "<?=Loc::getMessage('TIME_BACK')?>",
            suffixFromNow: null,
            seconds: "<?=Loc::getMessage('TIME_LESS_MINUTE')?>",
            minute: "<?=Loc::getMessage('TIME_MINUTE_4')?>",
            minutes: function (value) {
                return numpf(value, "%d <?=Loc::getMessage('TIME_MINUTE_1')?>", "%d <?=Loc::getMessage('TIME_MINUTE_2')?>", "%d <?=Loc::getMessage('TIME_MINUTE_3')?>");
            },
            hour: "<?=Loc::getMessage('TIME_HOUR_1')?>",
            hours: function (value) {
                return numpf(value, "%d <?=Loc::getMessage('TIME_HOUR_1')?>", "%d <?=Loc::getMessage('TIME_HOUR_2')?>", "%d <?=Loc::getMessage('TIME_HOUR_3')?>");
            },
            day: "<?=Loc::getMessage('TIME_DAY_1')?>",
            days: function (value) {
                return numpf(value, "%d <?=Loc::getMessage('TIME_DAY_1')?>", "%d <?=Loc::getMessage('TIME_DAY_2')?>", "%d <?=Loc::getMessage('TIME_DAY_3')?>");
            },
            month: "<?=Loc::getMessage('TIME_MONTH_1')?>",
            months: function (value) {
                return numpf(value, "%d <?=Loc::getMessage('TIME_MONTH_1')?>", "%d <?=Loc::getMessage('TIME_MONTH_2')?>", "%d <?=Loc::getMessage('TIME_MONTH_3')?>");
            },
            year: "<?=Loc::getMessage('TIME_YEAR_1')?>",
            years: function (value) {
                return numpf(value, "%d <?=Loc::getMessage('TIME_YEAR_1')?>", "%d <?=Loc::getMessage('TIME_YEAR_2')?>", "%d <?=Loc::getMessage('TIME_YEAR_3')?>");
            }
        };
    })();
</script>

