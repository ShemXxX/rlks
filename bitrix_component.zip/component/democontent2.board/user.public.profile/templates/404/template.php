<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 09.10.2018
 * Time: 11:09
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (method_exists($this, 'setFrameMode')) {
    $this->setFrameMode(true);
}

use Bitrix\Main\Localization\Loc;

?>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="not-found">
        <div class="title">404</div>
        <div class="content"><?= Loc::getMessage('USER_PUBLIC_PROFILE_COMPONENT_404_MESSAGE') ?></div>
    </div>
</div>
