<?php
/*
 * Date and Time: 19.02.2021, 10:35
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Democontent2\Board\Iblock\Favourites;

global $USER;

$arResult['FAVOURITES'] = [];
if ($USER->IsAuthorized()) {
    $ids = [];
    foreach ($arResult['ITEMS'] as $item) {
        $ids[] = $item['UF_ID'];
    }
    $favourites = new Favourites(intval($USER->GetID()));
    $arResult['FAVOURITES'] = $favourites->checkIdsByUser($ids);
}