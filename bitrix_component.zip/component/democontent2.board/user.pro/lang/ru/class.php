<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 13.10.2018
 * Time: 19:51
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['PRO_ORDER_DESCRIPTION'] = 'Оплата PRO аккаунта для пользователя ID:#USER_ID#';