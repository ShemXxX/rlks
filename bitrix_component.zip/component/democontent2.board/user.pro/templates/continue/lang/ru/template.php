<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 25.09.2018
 * Time: 10:25
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['USER_PRO_CONTINUE_COMPONENT_H1'] = 'PRO аккаунт';
$MESS['USER_PRO_CONTINUE_COMPONENT_DESC'] = 'Срок действаия PRO аккаунта истёк';
$MESS['USER_PRO_CONTINUE_COMPONENT_BTN_BUY'] = 'Купить PRO аккаунт за #PRICE# #CURRENCY#';