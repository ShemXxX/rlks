<?php
/*
 * Date and Time: 11.11.2020, 13:21
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;

$maxSizeAva = intval(Option::get(DBOARD, 'max_image_size'));
$currencyName = Option::get(DBOARD, 'currency_name');
$summ = $arResult['COST'];
$formatImg = 'jpeg, png';
$dateEnd = strtotime($arResult['USER']['UF_COMPANY_ACCOUNT']);
$dateNow = strtotime(date('Y-m-d H:i:s'));
$datediff = ($dateEnd - $dateNow) / (60 * 60 * 24);
$banner = [];
$logo = [];
if (isset($arResult['COMPANY']['UF_LOGO_ID'])) {
    $logo = CFile::ResizeImageGet(
        $arResult['COMPANY']['UF_LOGO_ID'],
        [
            'width' => 250,
            'height' => 250
        ],
        BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
        true
    );
} else {
    $logo['src'] = '';
}
if (isset($arResult['COMPANY']['UF_BANNER_ID'])) {
    $banner = CFile::ResizeImageGet(
        $arResult['COMPANY']['UF_BANNER_ID'],
        [
            'width' => 1130,
            'height' => 350
        ],
        BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
        true
    );
} else {
    $banner['src'] = '';
}
?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('USER_PRO_COMPONENT_H1') ?></h1>
        <?php
        if ($datediff < 5) {
            ?>
            <div class="warning-message">
                <?= Loc::getMessage('USER_PRO_COMPONENT_PRO_ACTIVE_ATTENTION', ['#DATE#' => date('d.m.Y H:i', $dateEnd)]) ?>
            </div>
            <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post" class="_mt">
                <input type="hidden" name="pro" value="1">
                <button class="apply">
                    <?= Loc::getMessage('USER_PRO_COMPONENT_BTN_CONTINUE', ['#PRICE#' => $summ, '#CURRENCY#' => $currencyName]) ?>
                </button>
            </form>
            <?php
        } else {
            ?>
            <div class="success-message">
                <?= Loc::getMessage('USER_PRO_COMPONENT_PRO_ACTIVE_OK', ['#DATE#' => date('d.m.Y H:i', $dateEnd)]) ?>
                <? if (count($arResult['COMPANY']) > 0): ?>
                    <a href="<?= SITE_DIR ?>store-<?= $arResult['COMPANY']['UF_COMPANY_CODE'] ?>/"
                       target="_blank">
                        <?= Loc::getMessage('USER_PRO_COMPONENT_COMPANY_PAGE') ?>
                    </a>
                <? endif ?>
            </div>
            <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="pro" value="1">
                <button type="submit" class="apply _mt">
                    <?= Loc::getMessage('USER_PRO_COMPONENT_BTN_CONTINUE', ['#PRICE#' => $summ, '#CURRENCY#' => $currencyName]) ?>
                </button>
            </form>
            <?php
        }
        ?>
        <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post" enctype="multipart/form-data"
              class="edit-form">
            <input type="hidden" name="pro" value="0">
            <div>
                <label for="banner"><?= Loc::getMessage('USER_PRO_COMPONENT_COMPANY_BANNER') ?></label>
                <input id="banner" type="file" name="images[banner]" accept="image/jpeg,image/png">
            </div>
            <div>
                <label for="logo"><?= Loc::getMessage('USER_PRO_COMPONENT_COMPANY_LOGO') ?></label>
                <input id="logo" type="file" name="images[logo]" accept="image/jpeg,image/png">
            </div>
            <div>
                <label><?= Loc::getMessage('USER_PRO_COMPONENT_FIELD_TITLE') ?></label>
                <input type="text" name="name"
                       value="<?= (isset($arResult['COMPANY']['UF_COMPANY_NAME'])) ? $arResult['COMPANY']['UF_COMPANY_NAME'] : '' ?>"
                       placeholder="<?= Loc::getMessage('USER_PRO_COMPONENT_FIELD_TITLE') ?>">
            </div>
            <div>
                <label><?= Loc::getMessage('USER_PRO_COMPONENT_FIELD_PHONE') ?></label>
                <input type="phone" name="phone"
                       value="<?= (isset($arResult['COMPANY']['UF_COMPANY_NAME'])) ? $arResult['COMPANY']['UF_COMPANY_PHONE'] : '' ?>"
                       placeholder="<?= Loc::getMessage('USER_PRO_COMPONENT_FIELD_PHONE') ?>">
            </div>
            <div>
                <label><?= Loc::getMessage('USER_PRO_COMPONENT_FIELD_EMAIL') ?></label>
                <input type="email" name="email"
                       value="<?= (isset($arResult['COMPANY']['UF_COMPANY_NAME'])) ? $arResult['COMPANY']['UF_COMPANY_EMAIL'] : '' ?>"
                       placeholder="<?= Loc::getMessage('USER_PRO_COMPONENT_FIELD_EMAIL') ?>">
            </div>
            <div>
                <label><?= Loc::getMessage('USER_PRO_COMPONENT_FIELD_ADDRESS') ?></label>
                <input type="text" name="address"
                       value="<?= (isset($arResult['COMPANY']['UF_COMPANY_NAME'])) ? $arResult['COMPANY']['UF_COMPANY_ADDRESS'] : '' ?>"
                       placeholder="<?= Loc::getMessage('USER_PRO_COMPONENT_FIELD_ADDRESS') ?>">
            </div>
            <div>
                <label><?= Loc::getMessage('USER_PRO_COMPONENT_FIELD_TIMEWORK') ?></label>
                <input type="text" name="worktime"
                       value="<?= (isset($arResult['COMPANY']['UF_COMPANY_NAME'])) ? $arResult['COMPANY']['UF_COMPANY_WORKTIME'] : '' ?>"
                       placeholder="<?= Loc::getMessage('USER_PRO_COMPONENT_FIELD_TIMEWORK') ?>">
            </div>
            <div>
                <label><?= Loc::getMessage('USER_PRO_COMPONENT_FIELD_SITE') ?></label>
                <input type="text" name="site"
                       value="<?= (isset($arResult['COMPANY']['UF_COMPANY_NAME'])) ? $arResult['COMPANY']['UF_COMPANY_SITE'] : '' ?>"
                       placeholder="https://example.com">
            </div>
            <div>
                <label><?= Loc::getMessage('USER_PRO_COMPONENT_FIELD_DESC') ?></label>
                <textarea name="description"
                          rows="7"><?= (isset($arResult['COMPANY']['UF_COMPANY_NAME'])) ? $arResult['COMPANY']['UF_COMPANY_DESCR'] : '' ?></textarea>
            </div>
            <button class="apply _mt" type="submit">
                <?= Loc::getMessage('USER_PRO_COMPONENT_BTN_SUBMIT') ?>
            </button>
        </form>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:user.menu',
            ''
        );
        ?>
    </div>
    <script>
        __phoneFormat = parseInt('<?=intval(Option::get(DBOARD, 'phone_code_mask'))?>'),
            __phoneMask = '<?=Option::get(DBOARD, 'phone_mask')?>',
            __maxImageSize = parseInt('<?=intval(Option::get(DBOARD, 'max_image_size'))?>');
    </script>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}