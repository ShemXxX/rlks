<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 13.10.2018
 * Time: 19:43
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['USER_PRO_COMPONENT_H1'] = 'PRO аккаунт';
$MESS['USER_PRO_COMPONENT_BANNER'] = 'Выберите баннер, который будет отображаться на странице компании<br>Рекомендуемый размер 1130x350<br>Изображение в формате #FORMATPICT#. Размером не более #SIZE# Мб..';
$MESS['USER_PRO_COMPONENT_LOGO'] = 'Выберите логотип который будет отображаться на странице компании<br>Изображение в формате #FORMATPICT#. Размером не более #SIZE# Мб..';
$MESS['USER_PRO_COMPONENT_ERROR'] = 'Превышает допустимый размер #SIZE# Мб.';
$MESS['USER_PRO_COMPONENT_FIELD_TITLE'] = 'Название компании*';
$MESS['USER_PRO_COMPONENT_FIELD_PHONE'] = 'Телефон*';
$MESS['USER_PRO_COMPONENT_FIELD_EMAIL'] = 'Email';
$MESS['USER_PRO_COMPONENT_FIELD_ADDRESS'] = 'Адрес';
$MESS['USER_PRO_COMPONENT_FIELD_TIMEWORK'] = 'Время работы';
$MESS['USER_PRO_COMPONENT_FIELD_DESC'] = 'Описание';
$MESS['USER_PRO_COMPONENT_FIELD_SITE'] = 'Веб-сайт';
$MESS['USER_PRO_COMPONENT_EROOR_SIZE_IMG'] = 'Превышает допустимый размер #MAXSIZ Мб';
$MESS['USER_PRO_COMPONENT_BTN_SUBMIT'] = 'Сохранить данные';
$MESS['USER_PRO_COMPONENT_BTN_CONTINUE'] = 'Продлить PRO аккаунт за #PRICE# #CURRENCY#';
$MESS['USER_PRO_COMPONENT_PRO_ACTIVE_OK'] = 'PRO аккаунт активен до #DATE#';
$MESS['USER_PRO_COMPONENT_PRO_ACTIVE_ATTENTION'] = 'Срок активности PRO аккаунта истекает #DATE#';
$MESS['USER_PRO_COMPONENT_COMPANY_PAGE'] = 'Посмотреть страницу компании';
$MESS['USER_PRO_COMPONENT_COMPANY_BANNER'] = 'Баннер';
$MESS['USER_PRO_COMPONENT_COMPANY_LOGO'] = 'Логотип';