<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 25.09.2018
 * Time: 10:25
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['USER_PRO_BUY_COMPONENT_H1'] = 'PRO аккаунт';
$MESS['USER_PRO_BUY_COMPONENT_DESC'] = '<p>Покупка PRO аккаунта позволит Вашей компании получить дополнительные преимущества размещения, такие как: логотип, баннер, дополнительное описание и контакты, часы работы.</p>';
$MESS['USER_PRO_BUY_COMPONENT_BTN_BUY'] = 'Купить PRO аккаунт за #PRICE# #CURRENCY#';