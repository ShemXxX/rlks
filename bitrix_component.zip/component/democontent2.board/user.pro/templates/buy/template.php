<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 13.10.2018
 * Time: 19:43
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;

$currencyName = Option::get(DBOARD, 'currency_name');
$summ = $arResult['COST'];
?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('USER_PRO_BUY_COMPONENT_H1') ?></h1>
        <div class="info-message">
            <?= Loc::getMessage('USER_PRO_BUY_COMPONENT_DESC') ?>
        </div>
        <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post" class="_mt">
            <input type="hidden" name="pro" value="1">
            <button class="apply">
                <?= Loc::getMessage('USER_PRO_BUY_COMPONENT_BTN_BUY', ['#PRICE#' => $summ, '#CURRENCY#' => $currencyName]) ?>
            </button>
        </form>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:user.menu',
            ''
        );
        ?>
    </div>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}