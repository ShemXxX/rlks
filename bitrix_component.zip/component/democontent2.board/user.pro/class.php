<?php
/*
 * Date and Time: 11.11.2020, 13:22
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

use Bitrix\Main\Application;
use Bitrix\Main\Config\Option;
use Bitrix\Main\IO\File;
use Bitrix\Main\IO\Path;
use Bitrix\Main\Localization\Loc;
use Democontent2\Board\Balance\Account;
use Democontent2\Board\Order;
use Democontent2\Board\User;

class UserProComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        global $USER;
        global $APPLICATION;
        if ($USER->IsAuthorized()) {
            $request = Application::getInstance()->getContext()->getRequest();
            $us = new User(intval($USER->GetID()), 0);
            $this->arResult['USER'] = $us->get();
            $this->arResult['COST'] = intval(Option::get(DBOARD, 'company_cost'));

            if (intval($this->arResult['USER']['ID']) > 0) {
                if ($request->isPost()) {
                    switch (USER_LANG) {
                        case 'ru':
                            break;
                        default:
                            if (strlen(USER_LANG) == 2) {
                                if (!File::isFileExists(
                                    Path::normalize(Application::getDocumentRoot() . $this->getPath() . '/lang/' . USER_LANG . '/class.php')
                                )) {
                                    Loc::setCurrentLang('ru');
                                }
                            }
                    }

                    if (intval(Option::get(DBOARD, 'company_cost')) > 0) {
                        if ($request->getPost('pro') && intval($request->getPost('pro')) > 0) {
                            $order = new Order(intval($this->arResult['USER']['ID']));
                            $order->setType('company');
                            $order->setSum(intval(Option::get(DBOARD, 'company_cost')));
                            $order->setDescription(
                                Loc::getMessage(
                                    'PRO_ORDER_DESCRIPTION',
                                    ['#USER_ID#' => $this->arResult['USER']['ID']]
                                )
                            );

                            $account = new Account($this->arResult['USER']['ID']);
                            $balance = $account->getAmount();
                            if ($balance > 0 && $balance >= $order->getSum()) {
                                if ($order->make(true)) {
                                    $order->setPayed(true);

                                    $account->setAmount($order->getSum());
                                    $account->setDescription(
                                        Loc::getMessage(
                                            'PRO_ORDER_DESCRIPTION',
                                            ['#USER_ID#' => $this->arResult['USER']['ID']]
                                        )
                                    );
                                    $account->withdrawal();
                                }
                            } else {
                                $order->make();
                                if ($order->getRedirect()) {
                                    LocalRedirect($order->getRedirect(), true);
                                }
                            }
                        }
                    }

                    if ($this->arResult['USER']['UF_COMPANY_ACCOUNT'] && strtotime($this->arResult['USER']['UF_COMPANY_ACCOUNT']) >= time()) {
                        if ($request->getPost('name') && $request->getPost('phone')) {
                            $us->updateCompany($_POST, $_FILES);
                            LocalRedirect($APPLICATION->GetCurPage(false), true);
                        }
                    }

                    LocalRedirect($APPLICATION->GetCurPage(false), true);
                }

                if (!$this->arResult['USER']['UF_COMPANY_ACCOUNT']) {
                    $this->setTemplateName('buy');
                }

                if ($this->arResult['USER']['UF_COMPANY_ACCOUNT'] && strtotime($this->arResult['USER']['UF_COMPANY_ACCOUNT']) <= time()) {
                    $this->setTemplateName('continue');
                }

                $this->arResult['COMPANY'] = $us->getCompany();

                $this->includeComponentTemplate();
            } else {
                LocalRedirect(SITE_DIR, true);
            }
        } else {
            LocalRedirect(SITE_DIR, true);
        }
    }
}
