<?php
/*
 * Date and Time: 17.12.2020, 8:36
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Page\Asset;

if (Option::get(DBOARD, 'reCaptchaPublic')
    && Option::get(DBOARD, 'reCaptchaSecret')) {
    Asset::getInstance()->addString('<script src="https://www.google.com/recaptcha/api.js?onload=onLoadReCaptcha&render=explicit" async defer></script>');
}
?>
<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12"></div>
<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
    <h1><?= Loc::getMessage('USER_LOGIN_COMPONENT_H1') ?></h1>
    <div class=" _box">
        <?php
        if (strlen($arResult['ERROR'])) {
            ?>
            <div class="danger-message"><?= $arResult['ERROR'] ?></div>
            <?php
        }
        ?>
        <form action="<?= SITE_DIR ?>user/login/" class="edit-form" method="post">
            <label><?= Loc::getMessage('USER_LOGIN_COMPONENT_EMAIL') ?></label>
            <input type="text" placeholder="<?= Loc::getMessage('USER_LOGIN_COMPONENT_EMAIL') ?>" name="email"
                   autocomplete="off" autofocus>
            <label><?= Loc::getMessage('USER_LOGIN_COMPONENT_PASSWORD') ?></label>
            <input type="password" placeholder="<?= Loc::getMessage('USER_LOGIN_COMPONENT_PASSWORD') ?>" name="password"
                   autocomplete="off">
            <div id="reCaptcha" class="_mt _mb"></div>
            <button class="apply" type="submit">
                <?= Loc::getMessage('USER_LOGIN_COMPONENT_SUBMIT') ?>
            </button>
            <div class=" _mt">
                <a href="<?= SITE_DIR ?>user/restore/">
                    <?= Loc::getMessage('USER_LOGIN_COMPONENT_RESTORE_PASSWORD') ?>
                </a>
            </div>
            <div class=" _mt">
                <a href="<?= SITE_DIR ?>user/register/">
                    <?= Loc::getMessage('USER_LOGIN_COMPONENT_REGISTER') ?>
                </a>
            </div>
        </form>
    </div>
</div>
<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12"></div>
<script>
    var __reCaptchaInit = 0;
    <?php
    if (Option::get(DBOARD, 'reCaptchaPublic') && Option::get(DBOARD, 'reCaptchaSecret')) {
    ?>
    __reCaptchaInit = 1;
    var reCaptchaPublicKey = '<?=Option::get(DBOARD, 'reCaptchaPublic')?>';
    var reCaptcha = null;
    var onLoadReCaptcha = function () {
        reCaptcha = grecaptcha.render('reCaptcha', {
            'sitekey': reCaptchaPublicKey,
            'theme': 'light'
        });
    };
    <?php
    }
    ?>
</script>

