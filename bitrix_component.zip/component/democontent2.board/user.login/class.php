<?php
/**
 * Date and Time: 22.07.2020, 9:26
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Application;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Democontent2\Board\Logger;
use ReCaptcha\ReCaptcha;

class UserLoginComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        global $USER;
        global $APPLICATION;

        if ($USER->IsAuthorized()) {
            LocalRedirect(SITE_DIR, true);
        }

        $request = Application::getInstance()->getContext()->getRequest();

        $this->arResult['ERROR'] = '';

        if ($request->isPost()) {
            $requestData = $request->getPostList();
            if ($requestData->get('email') && $requestData->get('password')) {
                $allow = true;
                if (Option::get(DBOARD, 'reCaptchaPublic')
                    && Option::get(DBOARD, 'reCaptchaSecret')) {
                    $secret = Option::get(DBOARD, 'reCaptchaSecret');
                    $reCaptcha = new ReCaptcha($secret);
                    $response = $reCaptcha->verify(
                        $request->getPost('g-recaptcha-response'),
                        Application::getInstance()->getContext()->getServer()->get('REMOTE_ADDR')
                    );

                    if (!$response->isSuccess()) {
                        $allow = false;
                    }
                }

                if ($allow) {
                    $USER = new CUser();
                    $APPLICATION->arAuthResult = $USER->Login(
                        trim($requestData->get('email')),
                        trim($requestData->get('password')),
                        'Y'
                    );

                    Logger::add(
                        (($USER->IsAuthorized()) ? intval($USER->GetID()) : 0),
                        'auth',
                        [
                            (is_array($APPLICATION->arAuthResult)) ? ['message' => $APPLICATION->arAuthResult['MESSAGE'], 'login' => htmlspecialcharsbx(strip_tags($requestData->get('email')))] : ''
                        ]
                    );

                    if (is_array($APPLICATION->arAuthResult) && isset($APPLICATION->arAuthResult['MESSAGE'])) {
                        $this->arResult['ERROR'] = $APPLICATION->arAuthResult['MESSAGE'];
                    } else {
                        LocalRedirect(SITE_DIR, true);
                    }
                } else {
                    $this->arResult['ERROR'] = Loc::getMessage('USER_LOGIN_COMPONENT_CLASS_RECAPTCHA_ERROR');
                }
            } else {
                $this->arResult['ERROR'] = Loc::getMessage('FIELDS_ERROR');
            }
        }

        $this->includeComponentTemplate();
    }
}
