<?php
/**
 * Date and Time: 22.07.2020, 9:23
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Application;
use Democontent2\Board\Iblock\Complain;

class UserComplainsComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        global $USER;
        if (!$USER->IsAuthorized()) {
            LocalRedirect(SITE_DIR, true);
        }

        $request = Application::getInstance()->getContext()->getRequest();
        $complain = new Complain(0);

        if ($request->isPost()) {
            switch ($request->getPostList()->get('type')) {
                case 'remove_complain':
                    if ($request->getPostList()->get('id')) {
                        $complain->delete(intval($request->getPostList()->get('id')));
                    }
                    break;
                case 'remove_item':
                    if ($request->getPostList()->get('id')) {
                        $item = $complain->getComplain(intval($request->getPostList()->get('id')));
                        if (count($item)) {
                            CIBlockElement::Delete($item['UF_ITEM_ID']);
                        }
                    }
                    break;
            }
            LocalRedirect(SITE_DIR . 'user/complains/', true);
        }

        $this->arResult['ITEMS'] = $complain->getList();

        $this->includeComponentTemplate();
    }
}
