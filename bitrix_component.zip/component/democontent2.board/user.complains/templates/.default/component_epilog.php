<?php
/**
 * Date: 19.05.2020
 * Time: 09:32
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
use Bitrix\Main\Localization\Loc;

$APPLICATION->SetTitle(Loc::getMessage('USER_COMPLAINS_TITLE'));
$APPLICATION->SetPageProperty('title', Loc::getMessage('USER_COMPLAINS_TITLE'));

