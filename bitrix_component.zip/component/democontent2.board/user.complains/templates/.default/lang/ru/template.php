<?php
/**
 * Date: 19.05.2020
 * Time: 09:32
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
$MESS['USER_COMPLAINS_COMPONENT_H1'] = 'Жалобы на объявления';
$MESS['USER_COMPLAINS_COMPONENT_TBL_DATE'] = 'Дата/время';
$MESS['USER_COMPLAINS_COMPONENT_TBL_CONTENT'] = 'Содержание';
$MESS['USER_COMPLAINS_COMPONENT_TBL_CONTENT_USER'] = 'Пользователь';
$MESS['USER_COMPLAINS_COMPONENT_TBL_CONTENT_ITEM'] = 'Объявление';
$MESS['USER_COMPLAINS_COMPONENT_TBL_CONTENT_ITEM_OPEN'] = 'Открыть';
$MESS['USER_COMPLAINS_COMPONENT_TEXT'] = 'Текст';
$MESS['USER_COMPLAINS_COMPONENT_REMOVE'] = 'Удалить жалобу';
$MESS['USER_COMPLAINS_COMPONENT_REMOVE_ITEM'] = 'Удалить объявление';
$MESS['USER_COMPLAINS_COMPONENT_EMPTY'] = 'Жалоб от пользователей нет';
