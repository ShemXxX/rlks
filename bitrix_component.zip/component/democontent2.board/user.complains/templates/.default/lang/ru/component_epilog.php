<?php
$MESS['USER_COMPLAINS_TITLE'] = 'Жалобы на объявления';