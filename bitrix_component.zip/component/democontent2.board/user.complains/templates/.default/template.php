<?php
/**
 * Date: 19.05.2020
 * Time: 09:31
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

use Bitrix\Main\Localization\Loc;

?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('USER_COMPLAINS_COMPONENT_H1') ?></h1>
        <?php
        if (!count($arResult['ITEMS'])) {
            ?>
            <div class="info-message _mb">
                <?= Loc::getMessage('USER_COMPLAINS_COMPONENT_EMPTY') ?>
            </div>
            <?php
        } else {
            ?>
            <div class="table">
                <div class="item head">
                    <div class="column">
                        <?= Loc::getMessage('USER_COMPLAINS_COMPONENT_TBL_DATE') ?>
                    </div>
                    <div class="column">
                        <?= Loc::getMessage('USER_COMPLAINS_COMPONENT_TBL_CONTENT') ?>
                    </div>
                </div>
                <?php
                foreach ($arResult['ITEMS'] as $item) {
                    ?>
                    <div class="item">
                        <div class="column">
                            <?= date('d.m.Y H:i:s', strtotime($item['UF_CREATED_AT'])) ?>
                        </div>
                        <div class="column">
                            IP: <?= $item['UF_IP'] ?><br>
                            <?= Loc::getMessage('USER_COMPLAINS_COMPONENT_TBL_CONTENT_USER') ?>:
                            <a href="/bitrix/admin/user_edit.php?ID=<?= $item['UF_USER_ID'] ?>"
                               target="_blank"><?= $item['UF_USER_NAME'] ?> (<?= $item['UF_USER_EMAIL'] ?>)</a><br>
                            <?= Loc::getMessage('USER_COMPLAINS_COMPONENT_TBL_CONTENT_ITEM') ?>:
                            <a href="<?= $item['UF_URL'] ?>"
                               target="_blank"><?= Loc::getMessage('USER_COMPLAINS_COMPONENT_TBL_CONTENT_ITEM_OPEN') ?></a>
                            <br>
                            <?= Loc::getMessage('USER_COMPLAINS_COMPONENT_TEXT') ?>:<br>
                            <?= $item['UF_TEXT'] ?>
                            <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post">
                                <input type="hidden" name="type" value="remove_complain">
                                <input type="hidden" name="id" value="<?= $item['ID'] ?>">
                                <button type="submit" class="write _mt">
                                    <?= Loc::getMessage('USER_COMPLAINS_COMPONENT_REMOVE') ?>
                                </button>
                            </form>
                            <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post">
                                <input type="hidden" name="type" value="remove_item">
                                <input type="hidden" name="id" value="<?= $item['ID'] ?>">
                                <button type="submit" class="write _mt">
                                    <?= Loc::getMessage('USER_COMPLAINS_COMPONENT_REMOVE_ITEM') ?>
                                </button>
                            </form>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
            <?php
        }
        ?>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:user.menu',
            ''
        );
        ?>
    </div>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}
