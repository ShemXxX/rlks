<?php
/**
 * Date: 21.04.2020
 * Time: 16:39
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

use Bitrix\Main\Localization\Loc;

?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('USER_BALANCE_COMPONENT_H1') ?></h1>
        <div class="items-list__sort">
            <div class="item">
                <a href="<?= SITE_DIR ?>user/balance/">
                    <?= Loc::getMessage('USER_BALANCE_COMPONENT_TAB_1') ?>
                </a>
            </div>
            <div class="item">
                <a href="<?= SITE_DIR ?>user/balance/?type=receipts">
                    <?= Loc::getMessage('USER_BALANCE_COMPONENT_TAB_2') ?>
                </a>
            </div>
            <div class="item">
                <a href="<?= SITE_DIR ?>user/balance/?type=write-offs">
                    <?= Loc::getMessage('USER_BALANCE_COMPONENT_TAB_3') ?>
                </a>
            </div>
            <?php
            if ($USER->IsAdmin()) {
                ?>
                <div class="item active">
                    <a href="<?= SITE_DIR ?>user/balance/?type=replenishment">
                        <?= Loc::getMessage('USER_BALANCE_COMPONENT_TAB_4') ?>
                    </a>
                </div>
                <?php
            }
            ?>
        </div>
        <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post" class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <input id="deposit-amount" required name="userId" type="text" data-type="integer"
                       placeholder="<?= Loc::getMessage('USER_BALANCE_COMPONENT_INPUT_PL_USER_ID') ?>">
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 _mt">
                <input id="deposit-amount" required name="sum" type="text" data-type="integer"
                       placeholder="<?= Loc::getMessage('USER_BALANCE_COMPONENT_INPUT_PL_USER_AMOUNT') ?>">
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 _mt">
                <textarea name="description" rows="8"
                          placeholder="<?= Loc::getMessage('USER_BALANCE_COMPONENT_INPUT_PL_USER_TRANS') ?>"></textarea>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 _mt">
                <button class="apply" type="submit">
                    <?= Loc::getMessage('USER_BALANCE_COMPONENT_BTN') ?>
                </button>
            </div>
        </form>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:user.menu',
            ''
        );
        ?>
    </div>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}

