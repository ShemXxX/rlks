<?php
/**
 * Date: 21.04.2020
 * Time: 16:39
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
$MESS['USER_BALANCE_COMPONENT_H1'] = 'Поступления';
$MESS['USER_BALANCE_COMPONENT_TAB_1'] = 'Пополнение счёта';
$MESS['USER_BALANCE_COMPONENT_TAB_2'] = 'Поступления';
$MESS['USER_BALANCE_COMPONENT_TAB_3'] = 'Списания';
$MESS['USER_BALANCE_COMPONENT_TAB_4'] = 'Пополнить баланс пользователя';
$MESS['USER_BALANCE_COMPONENT_REPORT_TTL_1'] = '#';
$MESS['USER_BALANCE_COMPONENT_REPORT_TTL_2'] = 'Дата';
$MESS['USER_BALANCE_COMPONENT_REPORT_TTL_3'] = 'Описание';
$MESS['USER_BALANCE_COMPONENT_REPORT_TTL_4'] = 'Сумма';
