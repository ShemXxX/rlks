<?php
/**
 * Date: 21.04.2020
 * Time: 16:39
 * User: Ruslan Semagin
 * Company: PIXEL365
 * Web: https://pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement,
 * and only as part of the product.
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

use Bitrix\Main\Localization\Loc;
use Democontent2\Board\Utils;

?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('USER_BALANCE_COMPONENT_H1') ?></h1>
        <div class="items-list__sort">
            <div class="item">
                <a href="<?= SITE_DIR ?>user/balance/">
                    <?= Loc::getMessage('USER_BALANCE_COMPONENT_TAB_1') ?>
                </a>
            </div>
            <div class="item">
                <a href="<?= SITE_DIR ?>user/balance/?type=receipts">
                    <?= Loc::getMessage('USER_BALANCE_COMPONENT_TAB_2') ?>
                </a>
            </div>
            <div class="item active">
                <a href="<?= SITE_DIR ?>user/balance/?type=write-offs">
                    <?= Loc::getMessage('USER_BALANCE_COMPONENT_TAB_3') ?>
                </a>
            </div>
            <?php
            if ($USER->IsAdmin()) {
                ?>
                <div class="item">
                    <a href="<?= SITE_DIR ?>user/balance/?type=replenishment">
                        <?= Loc::getMessage('USER_BALANCE_COMPONENT_TAB_4') ?>
                    </a>
                </div>
                <?php
            }
            ?>
        </div>
        <div class="table">
            <div class="item head">
                <div class="column">
                    <?= Loc::getMessage('USER_BALANCE_COMPONENT_REPORT_TTL_1') ?>
                </div>
                <div class="column">
                    <?= Loc::getMessage('USER_BALANCE_COMPONENT_REPORT_TTL_2') ?>
                </div>
                <div class="column">
                    <?= Loc::getMessage('USER_BALANCE_COMPONENT_REPORT_TTL_4') ?>
                </div>
                <div class="column">
                    <?= Loc::getMessage('USER_BALANCE_COMPONENT_REPORT_TTL_3') ?>
                </div>
            </div>
            <?php
            foreach ($arResult['ITEMS'] as $item) {
                if (!intval($item['UF_TYPE'])) {
                    continue;
                }
                ?>
                <div class="item">
                    <div class="column">
                        <?= $item['ID'] ?>
                    </div>
                    <div class="column">
                        <?= date('d.m.Y H:i:s', strtotime($item['UF_CREATED_AT'])) ?>
                    </div>
                    <div class="column">
                        <?= Utils::price($item['UF_AMOUNT']) ?>
                    </div>
                    <div class="column">
                        <?= $item['UF_DESCRIPTION'] ?>
                    </div>
                </div>
                <?php
            }
            ?>
        </div>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:user.menu',
            ''
        );
        ?>
    </div>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}

