<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 22.02.2019
 * Time: 13:25
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['USER_BALANCE_COMPONENT_H1'] = 'Баланс';
$MESS['USER_BALANCE_COMPONENT_TAB_1'] = 'Пополнение счёта';
$MESS['USER_BALANCE_COMPONENT_TAB_2'] = 'Поступления';
$MESS['USER_BALANCE_COMPONENT_TAB_3'] = 'Списания';
$MESS['USER_BALANCE_COMPONENT_TAB_4'] = 'Пополнить баланс пользователя';
$MESS['USER_BALANCE_COMPONENT_BTN'] = 'Пополнить счёт';
$MESS['USER_BALANCE_COMPONENT_REPORT_TTL_1'] = '№ транзакции';
$MESS['USER_BALANCE_COMPONENT_REPORT_TTL_2'] = 'Дата';
$MESS['USER_BALANCE_COMPONENT_REPORT_TTL_3'] = 'Описание';
$MESS['USER_BALANCE_COMPONENT_REPORT_TTL_4'] = 'Сумма';
$MESS['USER_BALANCE_COMPONENT_INPUT_PL'] = 'Введите сумму';
