<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 22.02.2019
 * Time: 13:25
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

use Bitrix\Main\Localization\Loc;

?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('USER_BALANCE_COMPONENT_H1') ?></h1>
        <div class="items-list__sort">
            <div class="item active">
                <a href="<?= SITE_DIR ?>user/balance/">
                    <?= Loc::getMessage('USER_BALANCE_COMPONENT_TAB_1') ?>
                </a>
            </div>
            <div class="item">
                <a href="<?= SITE_DIR ?>user/balance/?type=receipts">
                    <?= Loc::getMessage('USER_BALANCE_COMPONENT_TAB_2') ?>
                </a>
            </div>
            <div class="item">
                <a href="<?= SITE_DIR ?>user/balance/?type=write-offs">
                    <?= Loc::getMessage('USER_BALANCE_COMPONENT_TAB_3') ?>
                </a>
            </div>
            <?php
            if ($USER->IsAdmin()) {
                ?>
                <div class="item">
                    <a href="<?= SITE_DIR ?>user/balance/?type=replenishment">
                        <?= Loc::getMessage('USER_BALANCE_COMPONENT_TAB_4') ?>
                    </a>
                </div>
                <?php
            }
            ?>
        </div>
        <form action="<?= $APPLICATION->GetCurPage(false) ?>" method="post" class="row">
            <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
                <input id="deposit-amount" required name="amount" type="text"
                       class="form-control number-float required" data-type="integer"
                       placeholder="<?= Loc::getMessage('USER_BALANCE_COMPONENT_INPUT_PL') ?>">
            </div>
            <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
                <button class="apply" type="submit">
                    <?= Loc::getMessage('USER_BALANCE_COMPONENT_BTN') ?>
                </button>
            </div>
        </form>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:user.menu',
            ''
        );
        ?>
    </div>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}