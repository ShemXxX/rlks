<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 24.02.2019
 * Time: 16:47
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;

$APPLICATION->SetTitle(Loc::getMessage('USER_BALANCE_COMPONENT_EPILOG_TITLE'));
$APPLICATION->SetPageProperty('title', Loc::getMessage('USER_BALANCE_COMPONENT_EPILOG_TITLE'));