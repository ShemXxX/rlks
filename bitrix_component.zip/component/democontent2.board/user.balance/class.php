<?php
/**
 * Date and Time: 22.07.2020, 9:22
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Application;
use Bitrix\Main\IO\File;
use Bitrix\Main\IO\Path;
use Bitrix\Main\Localization\Loc;
use Democontent2\Board\Balance\Account;
use Democontent2\Board\Balance\Transaction;
use Democontent2\Board\Order;
use Democontent2\Board\User;

class UserBalanceComponentClass extends CBitrixComponent
{
    public function executeComponent()
    {
        global $USER;
        global $APPLICATION;

        if ($USER->IsAuthorized()) {
            $request = Application::getInstance()->getContext()->getRequest();
            $account = new Account($USER->GetID());
            $transaction = new Transaction($USER->GetID());
            if (!$account->checkAccount()) {
                $account->create();
            }

            if ($request->isPost()) {
                switch (USER_LANG) {
                    case 'ru':
                        break;
                    default:
                        if (strlen(USER_LANG) == 2) {
                            if (!File::isFileExists(
                                Path::normalize(Application::getDocumentRoot() . $this->getPath() . '/lang/' . USER_LANG . '/class.php')
                            )) {
                                Loc::setCurrentLang('ru');
                            }
                        }
                }
            }

            if ($USER->IsAdmin()) {
                if ($request->isPost()) {
                    if ($request->getPost('userId') && $request->getPost('sum')
                        && $request->getPost('description')) {
                        $us = new User($request->getPost('userId'));
                        if (count($us->get())) {
                            $account->setUserId($request->getPost('userId'));

                            if (!$account->checkAccount()) {
                                $account->create();
                            }

                            $account->setAmount(intval($request->getPost('sum')));
                            $account->setDescription($request->getPost('description'));
                            $account->accrual();
                        }
                    }

                    if ($request->getPost('amount') && intval($request->getPost('amount')) > 0) {
                        $order = new Order($USER->GetID());
                        $order->setType('balance');
                        $order->setSum(intval($request->getPost('amount')));
                        $order->setDescription(
                            Loc::getMessage('INTERNAL_ACCOUNT')
                        );
                        $order->make();
                        if ($order->getRedirect()) {
                            LocalRedirect($order->getRedirect(), true);
                        }
                    }

                    LocalRedirect(SITE_DIR . 'user/balance/', true);
                }
            } else {
                if ($request->isPost()) {
                    if ($request->getPost('amount') && intval($request->getPost('amount')) > 0) {
                        $order = new Order($USER->GetID());
                        $order->setType('balance');
                        $order->setSum(intval($request->getPost('amount')));
                        $order->setDescription(
                            Loc::getMessage('INTERNAL_ACCOUNT')
                        );
                        $order->make();
                        if ($order->getRedirect()) {
                            LocalRedirect($order->getRedirect(), true);
                        }
                    }

                    LocalRedirect($APPLICATION->GetCurPage(false), true);
                }
            }

            $this->arResult['BALANCE'] = $account->getAmount();
            $this->arResult['ITEMS'] = $transaction->getList();

            if ($request->get('type')) {
                switch ($request->get('type')) {
                    case 'receipts':
                    case 'write-offs':
                        $this->setTemplateName($request->get('type'));
                        break;
                    case 'replenishment':
                        if ($USER->IsAdmin()) {
                            $this->setTemplateName($request->get('type'));
                        } else {
                            LocalRedirect(SITE_DIR, true);
                        }
                        break;
                }
            }

            $this->includeComponentTemplate();
        } else {
            LocalRedirect(SITE_DIR, true);
        }
    }
}
