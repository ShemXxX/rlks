<?php
/*
 * Date and Time: 01.09.2020, 7:18
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

?>
    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <h1><?= Loc::getMessage('USER_MODERATION_COMPONENT_H1') ?></h1>
        <?php
        if (!$arResult['ITEMS']->current()) {
            ?>
            <div class="info-message _mb"><?= Loc::getMessage('USER_MODERATION_COMPONENT_EMPTY') ?></div>
            <?php
        } else {
            ?>
            <div class="items-list">
                <?php
                foreach ($arResult['ITEMS'] as $product) {
                    $arButtons = CIBlock::GetPanelButtons(
                        $product['UF_IBLOCK_ID'],
                        $product['UF_ID'],
                        0,
                        ["SECTION_BUTTONS" => false, "SESSID" => false]
                    );
                    $arItem["EDIT_LINK"] = $arButtons["edit"]["edit_element"]["ACTION_URL"];
                    $arItem["DELETE_LINK"] = $arButtons["edit"]["delete_element"]["ACTION_URL"];
                    $this->AddEditAction(
                        $product['UF_ID'],
                        $arItem['EDIT_LINK'],
                        CIBlock::GetArrayByID(
                            $product['UF_IBLOCK_ID'],
                            "ELEMENT_EDIT"
                        )
                    );
                    $this->AddDeleteAction(
                        $product['UF_ID'],
                        $arItem['DELETE_LINK'],
                        CIBlock::GetArrayByID(
                            $product['UF_IBLOCK_ID'],
                            "ELEMENT_DELETE"
                        ),
                        ["CONFIRM" => Loc::getMessage('CONFIRM_DELETE')]
                    );

                    $pict = null;
                    if (intval($product['UF_IMAGE_ID'])) {
                        $pict = intval($product['UF_IMAGE_ID']);
                        $pict = CFile::ResizeImageGet(
                            $pict,
                            [
                                'width' => 199,
                                'height' => 151
                            ],
                            BX_RESIZE_IMAGE_PROPORTIONAL_ALT,
                            true
                        );
                    }
                    ?>
                    <div class="item" id="<?= $this->GetEditAreaId($product['UF_ID']) ?>">
                        <div class="image">
                            <a href="<?= $product['URL'] ?>" title="<?= $product['UF_NAME'] ?>">
                                <div class="fotorama _mb" data-width="100%" data-height="151px" data-maxheight="151px"
                                     data-allowfullscreen="false" data-loop="false">
                                    <?php
                                    if (!is_null($pict)) {
                                        ?>
                                        <div data-img="<?= $pict['src'] ?>">
                                            <div class="fotorama__blur"
                                                 style="background:url(<?= $pict['src'] ?>)"></div>
                                        </div>
                                        <?php
                                    } else {
                                        ?>
                                        <svg class="stub" width="40" height="40" viewBox="0 0 40 40" fill="none"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <g>
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                      d="M35 1.66666H11.6667C9.83335 1.66666 8.33335 3.16666 8.33335 4.99999V28.3333C8.33335 30.1667 9.83335 31.6667 11.6667 31.6667H35C36.8334 31.6667 38.3334 30.1667 38.3334 28.3333V4.99999C38.3334 3.16666 36.8334 1.66666 35 1.66666ZM1.66669 8.33332H5.00002V35H31.6667V38.3333H5.00002C3.16669 38.3333 1.66669 36.8333 1.66669 35V8.33332ZM22.0167 23.05L26.6 17.15L32.5 25H14.1667L18.75 19.1167L22.0167 23.05ZM11.6667 28.3333H35V4.99999H11.6667V28.3333Z"
                                                      fill="#BDBDBD"
                                                / >
                                            </g>
                                        </svg>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </a>
                        </div>
                        <div class="content">
                            <div class="link">
                                <a href="<?= $product['URL'] ?>"><?= $product['UF_NAME'] ?></a>
                            </div>
                            <div class="location">
                                <?php
                                if (intval($product['UF_CITY'])) {
                                    ?>
                                    <div class="text">
                                        <?= $arResult['CITIES'][$product['UF_CITY']]['name'] ?>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                            <div class="location">
                                <div class="text">
                                    <?php
                                    echo \Democontent2\Board\Utils::dateForHumans($product['UF_DATE_CREATE']);
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
            <?php
        }
        ?>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
        <?php
        $APPLICATION->IncludeComponent(
            'democontent2.board:user.menu',
            ''
        );
        ?>
    </div>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}
