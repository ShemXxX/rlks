<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 03.11.2018
 * Time: 21:18
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['USER_MODERATION_COMPONENT_H1'] = 'Модерация';
$MESS['USER_MODERATION_COMPONENT_EMPTY'] = 'В настоящий момент, нет объявлений ожидающих проверки модератором';
$MESS['USER_MODERATION_COMPONENT_BTN_MORE'] = 'Подробнее';