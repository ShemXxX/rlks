<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 01.10.2018
 * Time: 14:41
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Application;
use Bitrix\Main\Localization\Loc;

if (method_exists($this, 'createFrame')) {
    $frame = $this->createFrame()->begin();
}

$totalPages = ceil(($arParams['TOTAL'] / $arParams['LIMIT']));
if ($arParams['CURRENT_PAGE'] > $totalPages || $totalPages < 2) {
    return;
}

$iCurr = intval($arParams['CURRENT_PAGE']);
$iLastPage = $totalPages;

if ($iCurr == $iLastPage) {
    return;
}

$request = Application::getInstance()->getContext()->getRequest();
$params = [];
if ($request->get('order')) {
    if ($request->get('order')) {
        switch ($request->get('order')) {
            case 'old':
            case 'expensive':
            case 'cheap':
            case 'popular':
                $params['order'] = $request->get('order');
                break;
        }
    }
}
if ($request->get('prop')) {
    $params['prop'] = $request->get('prop');
}

if ($request->get('onlyPhoto')) {
    $params['onlyPhoto'] = $request->get('onlyPhoto');
}
?>
    <a href="<?= $arParams['URL'] ?>?page=<?= $iCurr + 1 ?><?= ((count($params) > 0) ? '&' . http_build_query($params) : '') ?>"
       class="load-more _mt">
        <?= Loc::getMessage('PAGINATION_COMPONENT_SHOW_MORE') ?>
    </a>
<?php
if (method_exists($this, 'createFrame')) {
    $frame->end();
}