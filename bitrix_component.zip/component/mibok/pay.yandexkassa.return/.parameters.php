<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$module_id = "mibok.pay";
if(!CModule::IncludeModule($module_id))
	return;

$shopID = \Bitrix\Main\Config\Option::get($module_id, 'yookassa_shop_id');
$arShop = MibokPay::deviderShop($shopID);
$arShopIDS = false;
if(is_array($arShop))
{
    foreach ($arShop as $item)
        $arShopIDS[$item] = $item;
}

/*$arComponentParameters = array(
	"GROUPS" => array(
	),
	"PARAMETERS" => array(
        "SHOP_ID" => Array(
			"PARENT" => "BASE",
			"NAME" => GetMessage("MIBOK_PAY_YOOKASSA_SHOP_ID"),
			"TYPE"=>"LIST",
			"VALUES" => $arShopIDS,
			"MULTIPLE"=>"N",
			"ADDITIONAL_VALUES"=>"N",
			"REFRESH" => "Y",
		),
	),
);*/
?>
