<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("MIBOK_YOOKASSA_KASSA_NAME_RETURN"),
	"DESCRIPTION" => GetMessage("MIBOK_YOOKASSA_KASSA_DESCRIPTION_RETURN"),
	"ICON" => "/images/icon.png",
	"CACHE_PATH" => "Y",
	"SORT" => 20,
	"PATH" => array(
		"ID" => "mibok",
		"NAME" => GetMessage("MIBOK_CREATER"),
		"CHILD" => array(
			"ID" => "yookassa_kassa",
			"NAME" => GetMessage("MIBOK_YOOKASSA_KASSA"),
			"SORT" => 20,
		)
	),
);

?>