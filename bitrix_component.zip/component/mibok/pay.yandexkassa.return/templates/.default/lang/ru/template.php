<?
$MESS['MIBOK_YOOKASSA_CREATE_ERROR'] = "При создании оплаты №#ID# от #DATE_CREATE# на сумму #AMOUNT# #CURRENCY# произошла ошибка.<br>Обратитесь к администратору сайта";
$MESS['MIBOK_YOOKASSA_PENDING'] = "Платеж №#ID# от #DATE_CREATE# на сумму #AMOUNT# #CURRENCY# создан и ожидает оплаты.<br>Если Вы уже оплатили заказ, обновите страницу через несколько минут.";
$MESS['MIBOK_YOOKASSA_WAITING'] = "Платеж №#ID# от #DATE_CREATE# на сумму #AMOUNT# #CURRENCY# оплачен, деньги авторизованы и ожидают списания.";
$MESS['MIBOK_YOOKASSA_SUCCEEDED'] = "Платеж №#ID# от #DATE_CREATE# на сумму #AMOUNT# #CURRENCY# успешно завершен.";
$MESS['MIBOK_YOOKASSA_CANCELED'] = "Платеж №#ID# от #DATE_CREATE# на сумму #AMOUNT# #CURRENCY# отменен.";
$MESS['MIBOK_YOOKASSA_NO_STATUS'] = "Нет информации по статусу платежа №#ID# от #DATE_CREATE# на сумму #AMOUNT# #CURRENCY#.<br>Обратитесь к администратору сайта";
?>