<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>

<?
use Bitrix\Main\Localization\Loc;
Loc::loadMessages(__FILE__);
?>

<div class="mibok-wrapper-pay">
    <?if($arResult['type'] == 'error'):?>
        <div class="mibok-alert-error mibok-return-info">
            <div class="mibok-icon"></div>
            <div class="mibok-text"><?=$arResult['text'];?></div>
        </div>
    <?elseif($arResult['type'] == 'exist'):?>
        <div class="mibok-alert-<?=$arResult['status']?> mibok-return-info">
            <div class="mibok-icon"></div>
            <div class="mibok-text">
                <?
                switch ($arResult['status'])
                {
                    case 'error': $macros = Loc::getMessage('MIBOK_YOOKASSA_CREATE_ERROR'); break;
                    case 'pending': $macros = Loc::getMessage('MIBOK_YOOKASSA_PENDING'); break;
                    case 'waiting_for_capture': $macros = Loc::getMessage('MIBOK_YOOKASSA_WAITING'); break;
                    case 'succeeded': $macros = Loc::getMessage('MIBOK_YOOKASSA_SUCCEEDED'); break;
                    case 'canceled': $macros = Loc::getMessage('MIBOK_YOOKASSA_CANCELED'); break;
                    default: $macros = Loc::getMessage('MIBOK_YOOKASSA_NO_STATUS'); break;
                }
                ?>
                <?=str_replace(
                    [
                        '#ID#',
                        '#DATE_CREATE#',
                        '#AMOUNT#',
                        '#CURRENCY#',
                    ],
                    [
                        $arResult['id'],
                        $arResult['date'],
                        $arResult['amount'],
                        $arResult['currency'],
                    ],
                    $macros
                );
                ?>
            </div>
        </div>
        
    <?endif;?>
</div>
