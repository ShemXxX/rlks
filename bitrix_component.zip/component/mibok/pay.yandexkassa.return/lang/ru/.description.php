<?
$MESS ['MIBOK_YOOKASSA_KASSA'] = "ЮKassa (ex-Яндекс.Касса)";
$MESS ['MIBOK_YOOKASSA_KASSA_NAME_RETURN'] = "Результат оплаты (ЮKassa)";
$MESS ['MIBOK_YOOKASSA_KASSA_DESCRIPTION_RETURN'] = "Выводит информацию о результате оплаты через ЮKassa";
$MESS ['MIBOK_CREATER'] = "Мибок";
?>