<?
$MESS['MIBOK_PAY_NOT_FOUND'] = 'Модуль оплаты mibok.pay не установлен';
$MESS['MIBOK_PAY_DEMO_EXPIRED'] = 'Демо-режим модуля оплаты mibok.pay закончился';
$MESS['MIBOK_YOOKASSA_RETURN_ERROR'] = 'К сожалению, данная ссылка неверная<br>Обратитесь к администратору сайта';
$MESS['MIBOK_YOOKASSA_RETURN_ERROR_NOT_FOUND'] = 'К сожалению, Ваш платеж не найден<br>Обратитесь к администратору сайта';

?>