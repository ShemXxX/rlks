<?
$MESS['MIBOK_PAY_YOOKASSA_SHOP_ID'] = "Выберите ShopID магазина в ЮKassa";
?>