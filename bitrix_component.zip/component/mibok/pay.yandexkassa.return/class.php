<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>

<?
use Mibok\Pay\Yookassa,
    Bitrix\Main,
    Bitrix\Main\Loader,
	Bitrix\Main\Localization\Loc;
Loc::loadMessages(__FILE__);

class MibokPayYKReturn extends CBitrixComponent
{
    private $module_id = "mibok.pay";
    public $obKassa;

    public function __construct($component = null) 
    {

        parent::__construct($component);

        if(!IsModuleInstalled($this->module_id))
        {
            ShowError(Loc::getMessage('MIBOK_PAY_NOT_FOUND'));
            return;
        }
        $loadRes = Loader::includeSharewareModule($this->module_id);
        if($loadRes == 0)
        {
            ShowError(Loc::getMessage('MIBOK_PAY_NOT_FOUND'));
            return;
        }
        elseif($loadRes == 3)
        {
            ShowError(Loc::getMessage('MIBOK_PAY_DEMO_EXPIRED'));
            return;
        }
    }
    
    public function onPrepareComponentParams($arParams)
    {
        return $arParams;
    }
    
    public function executeComponent()
    {
        $request = \Bitrix\Main\Context::getCurrent()->getRequest();
        $valueKey = htmlspecialcharsbx($request->get("id"));
        if(empty($valueKey))
        {
            $this->arResult['type'] = 'error';
            $this->arResult['text'] = Loc::getMessage('MIBOK_YOOKASSA_RETURN_ERROR');
        }
        else
        {
            if(!$arInfo = Yookassa::getByHash($valueKey))
            {
                $this->arResult['type'] = 'error';
                $this->arResult['text'] = Loc::getMessage('MIBOK_YOOKASSA_RETURN_ERROR_NOT_FOUND');
            }
            else
            {
                $this->arResult = [
                    'type' => 'exist',
                    'id' => $arInfo['ID'],
                    'date' => $arInfo['DATE_CREATE'],
                    'amount' => $arInfo['SUMMA'],
                    'currency' => $arInfo['CURRENCY'],
                    'status' => (!empty($arInfo['STATUS_YOOKASSA']) ? $arInfo['STATUS_YOOKASSA'] : 'error'),
                    'paid' => $arInfo['PAID'],
                ];
            }
        }

        $this->includeComponentTemplate();
        return $this->arResult;
    }
    

}
?>