<?
$MESS['MIBOK_REQUIRED_FIELD'] = 'Обязательное поле для заполнения';
$MESS['MIBOK_ERROR_RESPONSE'] = 'К сожалению, произошла ошибка отправки запроса';
$MESS['MIBOK_EMAIL_ERROR'] = 'Неверный формат email-адреса';
$MESS['MIBOK_PHONE_ERROR'] = 'Неверный формат телефона';
$MESS['MIBOK_INN_ERROR'] = 'Неверный ИНН';
$MESS['MIBOK_REQUIRED_USER_CONSENT'] = 'Необходимо согласие на обработку персональных данных';
?>