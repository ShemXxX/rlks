<?
$MESS['MIBOK_USER_INFO'] = 'Информация о покупателе';
$MESS['MIBOK_USER_DATA_FIO'] = "Ваше имя";
$MESS['MIBOK_USER_DATA_PHONE'] = "Ваш телефон";
$MESS['MIBOK_USER_DATA_EMAIL'] = "Ваш email";
$MESS['MIBOK_USER_DATA_INN'] = "Ваш ИНН";

$MESS['MIBOK_PRODUCT_INFO'] = "Информация о заказе";
$MESS['MIBOK_SELECT_PAYMENT'] = "Выберите способ оплаты";
?>