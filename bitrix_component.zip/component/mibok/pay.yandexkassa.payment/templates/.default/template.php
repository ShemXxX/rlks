<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>

<?
use Bitrix\Main\Localization\Loc;
Loc::loadMessages(__FILE__);
?>
<input  type="hidden" name="signedParameters" value="<?=$this->getComponent()->getSignedParameters()?>">
<form action="" method="post" id="mibok-pay-form" class="mibok-pay-form">
    <div class="mibok-sk-circle">
        <div class="sk-circle">
            <div class="sk-circle1 sk-child"></div>
            <div class="sk-circle2 sk-child"></div>
            <div class="sk-circle3 sk-child"></div>
            <div class="sk-circle4 sk-child"></div>
            <div class="sk-circle5 sk-child"></div>
            <div class="sk-circle6 sk-child"></div>
            <div class="sk-circle7 sk-child"></div>
            <div class="sk-circle8 sk-child"></div>
            <div class="sk-circle9 sk-child"></div>
            <div class="sk-circle10 sk-child"></div>
            <div class="sk-circle11 sk-child"></div>
            <div class="sk-circle12 sk-child"></div>
        </div>
    </div>
    <?=bitrix_sessid_post()?>
    <div class="mibok-wrapper-pay">
        
        <div class="mibok-item">
            <div class="mibok-card">
                <div class="mibok-head">
                    <?=Loc::getMessage('MIBOK_USER_INFO')?>
                </div>
                <div class="mibok-body">
                    <?$userFields = array();
					foreach($arParams['USER_DATA'] as $user):?>
                        <div class="mibok-input">
                            <label for="<?=$user?>"><?=Loc::getMessage('MIBOK_USER_DATA_'.$user)?></label>
                            <input type="text" name="<?=$user?>">
                        </div>
                    <?$userFields[] = Loc::getMessage('MIBOK_USER_DATA_'.$user);
					endforeach;?>
					
                </div>
            </div>
        </div>
        <div class="mibok-item">
            <div class="mibok-card">
                <div class="mibok-head">
                    <?=Loc::getMessage('MIBOK_PRODUCT_INFO')?>
                </div>
                <div class="mibok-body">
                    <?switch ($arParams['SOURCE_PRODUCT'])
                    {
                        case 'def':?>
                            <div class="mibok-input">
                                <label><?=$arParams['TEXT_INPUT_PRODUCT']?></label>
                                <input type="hidden" name="ITEM" value="<?=$arParams['ITEM']?>">
                                <label class="mibok-product"><?=$arParams['ITEM']?></label>
                            </div>
                            <div class="mibok-input">
                                <label><?=$arParams['TEXT_INPUT_AMOUNT']?></label>
                                <input type="hidden" name="SUM" value="<?=$arParams['SUM']?>">
                                <label class="mibok-product"><?=$arParams['SUM']?> <?=$arParams['CURR']?></label>
                            </div>
                            <?if($arResult['type_process'] == 'yookassa')
                            {
                                getHtmlButton('smart', $arParams);
                            }
                            elseif($arResult['type_process'] == 'site')
                            {
                                getHtmlButton('change', $arParams, $arResult);
                            }?>
                            <?break;
                        case 'field':?>
                            <div class="mibok-input">
                                <label><?=$arParams['TEXT_INPUT_PRODUCT']?></label>
                                <input type="text" name="ITEM" value="<?=$arParams['ITEM']?>">
                            </div>
                            <div class="mibok-input">
                                <label><?=$arParams['TEXT_INPUT_AMOUNT']?></label>
                                <input type="text" class="small-size" name="SUM" value="<?=$arParams['SUM']?>"> <label><?=$arParams['CURR']?></label>
                            </div>
                            <?if($arResult['type_process'] == 'yookassa')
                            {
                                getHtmlButton('smart', $arParams);
                            }
                            elseif($arResult['type_process'] == 'site')
                            {
                                getHtmlButton('change', $arParams, $arResult);
                            }?>
                            <?break;
                    }?>
					<?if ($arParams['USER_CONSENT'] == 'Y'):?>
						<?$APPLICATION->IncludeComponent(
							"bitrix:main.userconsent.request",
							"",
							array(
								'ID' => $arParams["USER_CONSENT_ID"],
								"IS_CHECKED" => $arParams["USER_CONSENT_IS_CHECKED"],
								"IS_LOADED" => "Y",
								"AUTO_SAVE" => "N",
								'SUBMIT_EVENT_NAME' => 'my-event-name',
								'REPLACE' => array(
									'button_caption' => $arParams['TEXT_BUTTON'],
									'fields' => $userFields
								),
							)
						);?>
					<?endif;?>
                </div>
            </div>
        </div>
    </div>
</form>
<?
function getHtmlButton($type = 'smart', $arParams, $arResult = array())
{
    switch ($type)
    {
        case 'smart':?>
            <div class="mibok-input">
                <button class="mibok-btn" type="submit"><?=$arParams['TEXT_BUTTON']?></button>
            </div>
            <?break;
        case 'change':?>
            <div class="mibok-input">
                <?if(is_array($arResult['payment_method_data']) && count($arResult['payment_method_data']) == 1):?>
                    <button class="mibok-btn" type="submit"><?=$arParams['TEXT_BUTTON']?></button>
                <?elseif(is_array($arResult['payment_method_data']) && count($arResult['payment_method_data']) > 1):?>
                    <input type="hidden" name="payment_method_data" value="">
                    <label><?=Loc::getMessage('MIBOK_SELECT_PAYMENT')?></label>
                    <?foreach ($arResult['payment_method_data'] as $key):?>
                        <button class="mibok-btn mibok-btn-light" type="submit" name='type-payment' value="<?=$key?>"><?=$arResult['payment_name'][$key]?></button>
                    <?endforeach;
                endif;?>
            </div>
            <?break;
    }
}
?>