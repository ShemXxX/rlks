var dataForm;

document.addEventListener("DOMContentLoaded", function (event) 
{
    var alert;
    var form = document.querySelector('.mibok-pay-form');
    var btnPay = document.querySelectorAll('button[name="type-payment"]');
    var inpPay = document.querySelector('input[name=payment_method_data]');
    var alert = document.querySelector('.mibok-alert-error');
    var signedParameters = document.querySelector('[name=signedParameters]');
   
    for (var i = 0; i < btnPay.length; i++) 
    {
        btnPay[i].addEventListener('click', function(event) {
            inpPay.value = this.value
        });
    }
    
    form.addEventListener('submit', function(e){
        e.preventDefault();
        form.classList.add("prepand")
        dataForm = {};
        if(alert = document.querySelector('.mibok-alert-error'))
            alert.remove();
        if(MValidPayForm(form))
        {
            dataForm = {'params':dataForm};

            var request = BX.ajax.runComponentAction('mibok:pay.yandexkassa.payment', 'pay', {
                mode:'class',
                signedParameters:signedParameters.value,
                data: dataForm
            });

            request.then(function(response){
                if (response.data['status'] === 'success') 
                {
                    window.location.href = response.data['url'];
                }
                else if (response.data['status'] === 'error') 
                {
                    let alert = document.createElement('div');
                    alert.className = 'mibok-alert-error';
                    alert.innerHTML = response.data['text'];
                    document.querySelector('.mibok-wrapper-pay').prepend(alert);
                }
                setTimeout(function(){form.classList.remove("prepand")}, 1000);

            }, function(response){
                let alert = document.createElement('div');
                alert.className = 'mibok-alert-error';
                alert.innerHTML = BX.message("MIBOK_ERROR_RESPONSE");
                document.querySelector('.mibok-wrapper-pay').prepend(alert);
                setTimeout(function(){form.classList.remove("prepand")}, 1000);

            });
        }
        else
        {
            form.classList.remove("prepand")
        }
    });

})

function MValidPayForm(form)
{
    let bValid = true;
	
	
    
    var spanErr = document.querySelectorAll('input + span:not(.main-user-consent-request-announce)');
    spanErr.forEach(function(item) {
        item.remove();
      });
    var spanErr = document.querySelectorAll('label.main-user-consent-request + span');
    spanErr.forEach(function(item) {
        item.remove();
      });
    for (var i = 0; i < form.elements.length; i++)
    {
        if(form.elements[i].type == 'submit' || form.elements[i].type == 'button')
            continue;
        form.elements[i].classList.remove("form-error");
        if(form.elements[i].value != '')
        {
            if(form.elements[i].name === 'EMAIL')
            {
                if(!isEmail(form.elements[i].value))
                {
                    bValid = false;
                    form.elements[i].classList.add("form-error")
                    let error = document.createElement('span');
                    error.innerHTML = BX.message("MIBOK_EMAIL_ERROR");
                    form.elements[i].after(error);
                }
            }
            else if(form.elements[i].name === 'PHONE')
            {
                if(!isPhone(form.elements[i].value))
                {
                    bValid = false;
                    form.elements[i].classList.add("form-error")
                    let error = document.createElement('span');
                    error.innerHTML = BX.message("MIBOK_PHONE_ERROR");
                    form.elements[i].after(error);
                }
            }
            else if(form.elements[i].name === 'INN')
            {
                if(!isINN(form.elements[i].value))
                {
                    bValid = false;
                    form.elements[i].classList.add("form-error")
                    let error = document.createElement('span');
                    error.innerHTML = BX.message("MIBOK_INN_ERROR");
                    form.elements[i].after(error);
                }
            }
            dataForm[form.elements[i].name] = form.elements[i].value;
        }
        else
        {
            bValid = false;
            form.elements[i].classList.add("form-error")
            let error = document.createElement('span');
            error.innerHTML = BX.message("MIBOK_REQUIRED_FIELD");
            //error.className = 'span-error';
            form.elements[i].after(error);
        }
		if(form.elements[i].type == 'checkbox')
		{
			if (form.elements[i].parentNode.classList.contains('main-user-consent-request'))
			{
				if(!form.elements[i].checked)
				{
					bValid = false;
					form.elements[i].parentNode.classList.add("form-error")
					let error = document.createElement('span');
					error.innerHTML = BX.message("MIBOK_REQUIRED_USER_CONSENT");
					form.elements[i].parentNode.after(error);
				}
			}
		}
    }
//	var userConset = document.querySelectorAll('.main-user-consent-request input');
//	if(userConset.length > 0 && !userConset.checked)
//	{
//		
//	}
    return bValid;
    
}



function isEmail(emailAddress) {
   // var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
    var pattern = new RegExp(/^[\w]{1}[\w-\.]*@[\w-]+\.[a-z]{2,4}$/i);
    return pattern.test(emailAddress);
}

function isPhone(phone) {
    var pattern = new RegExp(/^((8|\+7)[\- ]?)?(\(?\d{3}\)?[\- ]?)?[\d\- ]{7,10}$/i);
    return pattern.test(phone);
}

function isINN(inn) {
    var pattern, res;
    pattern = new RegExp(/^(\d{10})$/);
    res = pattern.test(inn);
    if(!res)
    {
        pattern = new RegExp(/^(\d{12})$/);
        return pattern.test(inn);
    }
    else
        return res;
//    var pattern = new RegExp(/^(\d{10,12})$/);
//    return pattern.test(inn);
}

