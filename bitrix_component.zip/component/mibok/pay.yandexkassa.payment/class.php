<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>

<?
use Mibok\Pay\Yookassa,
    Bitrix\Main,
    Bitrix\Main\Loader,
    Bitrix\Main\Config\Option,
	Bitrix\Main\Localization\Loc,
    Bitrix\Main\Engine\Contract\Controllerable,
    Bitrix\Main\Engine\ActionFilter;
Loc::loadMessages(__FILE__);

class MibokPayYKPayment extends CBitrixComponent implements Controllerable
{
    private $module_id = "mibok.pay";
    public $obKassa;

    public function __construct($component = null) 
    {

        parent::__construct($component);

        if(!IsModuleInstalled($this->module_id))
        {
            ShowError(Loc::getMessage('MIBOK_PAY_NOT_FOUND'));
            return;
        }
        $loadRes = Loader::includeSharewareModule($this->module_id);
        if($loadRes == 0)
        {
            ShowError(Loc::getMessage('MIBOK_PAY_NOT_FOUND'));
            return;
        }
        elseif($loadRes == 3)
        {
            ShowError(Loc::getMessage('MIBOK_PAY_DEMO_EXPIRED'));
            return;
        }
    }
    
    public function onPrepareComponentParams($arParams)
    {

//        $resCheck = MibokPay::checkData($arParams);
//        if(!$resCheck['result'])
//        {
//            ShowError($resCheck['error']);
//            return;
//        }
        return $arParams;
    }
    
    public function executeComponent()
    {
        if($this->startResultCache())
        {
            //p($this->arParams);
            //$this->obKassa = new Mibok\Pay\Yookassa((int) $this->arParams['SHOP_ID']);
            //p($this->obKassa);
            //p($_POST);
            $shopId = (int) $this->arParams['SHOP_ID'];
            if($shopId > 0)
            {
                $this->arResult['type_process'] = Option::get($this->module_id, "yookassa_shop_type_process_".$shopId);
                $this->arResult['payment_method_data'] = MibokPay::deviderShop(Option::get($this->module_id, "yookassa_shop_type_".$shopId));
                if(count($this->arResult['payment_method_data']) > 1)
                {
                    $this->arResult['payment_name'] = MibokPay::getPayType('yookassa');
                }
            }
        }
        $this->includeComponentTemplate();
        return $this->arResult;
    }
    
    protected function listKeysSignedParameters()
    {
       return [
              'SHOP_ID',
              'USER_DATA',
              'USER_CONSENT_ID',
         ];
    }
    
    public function configureActions()
	{
		return [
			'pay' => [
				'prefilters' => [
					new ActionFilter\HttpMethod(
						array(/*ActionFilter\HttpMethod::METHOD_GET,*/ ActionFilter\HttpMethod::METHOD_POST)
					),
                    new ActionFilter\Csrf(),
				],
				'postfilters' => []
			]
		];
	}
 

	public function payAction( $params, $signedParameters = '')
	{
        global $USER;
        $signer = new \Bitrix\Main\Component\ParameterSigner;
        $arParamComp = $signer->unsignParameters($this->__name, $signedParameters);
        $domen = ( (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? 'https://' : 'http://' ) . $_SERVER['SERVER_NAME'];
        $obKassa = new Mibok\Pay\Yookassa((int) $arParamComp['SHOP_ID'], $domen, SITE_DIR);
       
        if(!empty($errData = $this->validData($params, $arParamComp['USER_DATA'])))
		{
            return [
                'status' => 'error',
                'text' => implode("<br>", $errData),
            ];
		}
        if(!empty($USER->GetID()))
            $params['USER_ID'] = $USER->GetID();
		if(file_exists($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/lib/userconsent/consent.php') && isset($arParamComp["USER_CONSENT_ID"]))
            \Bitrix\Main\UserConsent\Consent::addByContext($arParamComp["USER_CONSENT_ID"]);
        return $obKassa->createPayment($params);
	}
    
    private function validData(&$dataPayment, $userData)
    {
		
        $arError = array();
        foreach($userData as $item)
        {
            if(!array_key_exists($item, $dataPayment))
            {
                $arError[] = Loc::getMessage('MIBOK_EMPTY_FIELD');
            }
        }
        foreach ($dataPayment as $key => $data)
        {
            if(empty(trim($data)))
            {
               $arError[] = Loc::getMessage('MIBOK_EMPTY_FIELD');
            }
            else
            {
				if($key)
					switch ($key)
					{
						case 'PHONE':
							if(!MibokPay::isPhone($data))
								$arError[] = Loc::getMessage('MIBOK_ERROR_FORMAT_PHONE');
							else
								$dataPayment[$key] = MibokPay::formatPhone($data);
							break;
						case 'EMAIL':
							if(!MibokPay::isEmail($data))
								$arError[] = Loc::getMessage('MIBOK_ERROR_FORMAT_EMAIL');
							break;
						case 'INN':
							if(!MibokPay::isInn($data))
								$arError[] = Loc::getMessage('MIBOK_ERROR_FORMAT_INN');
							break;
						case 'SUM':
							$dataPayment[$key] = htmlspecialcharsbx($dataPayment[$key]);
							$dataPayment[$key] = MibokPay::formatPrice($data);
							if(empty($dataPayment[$key]))
								 $arError[] = Loc::getMessage('MIBOK_ERROR_SUM');
							break;
						case 'ITEM':
							$dataPayment[$key] = htmlspecialcharsbx($dataPayment[$key]);
							if(empty($dataPayment[$key]))
								 $arError[] = Loc::getMessage('MIBOK_ERROR_ITEM');
							break;
						default:
							break;
					}
            }
        }
        return $arError;
    }
}
?>