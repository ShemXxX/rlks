<?
$MESS['MIBOK_PAY_YOOKASSA_SIGN'] = "Подписи к полям и кнопкам";
$MESS['MIBOK_PAY_YOOKASSA_USER'] = "Информация о покупателе";

$MESS['MIBOK_PAY_YOOKASSA_SHOP_ID'] = "Выберите ShopID магазина в ЮKassa";
$MESS['MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT'] = "Источник данных о товаре";
$MESS['MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT_DEFAULT'] = "Данные о товаре и сумме покупатель не сможет отредактировать";
$MESS['MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT_FIELD'] = "Редактируемые покупателем поля формы";
$MESS['MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT_IBLOCK'] = "Элемент инфоблока";
$MESS['MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT_REQUEST'] = "Параметры из адресной строки";
$MESS['MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT_ITEM'] = "Содержание заказа";
$MESS['MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT_ITEM_DEF'] = "Тестовый товар";
$MESS['MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT_SUM'] = "Сумма заказа";
$MESS['MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT_CURR'] = "Подпись валюты";
$MESS['MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT_CURR_DEF'] = "р.";

$MESS['MIBOK_PAY_YOOKASSA_TEXT_BUTTON'] = "Подпись кнопки оплаты";
$MESS['MIBOK_PAY_YOOKASSA_TEXT_INPUT_PRODUCT'] = "Название поля о товаре";
$MESS['MIBOK_PAY_YOOKASSA_TEXT_INPUT_PRODUCT_DEF'] = "Название товара";
$MESS['MIBOK_PAY_YOOKASSA_TEXT_INPUT_AMOUNT'] = "Название поля о сумме заказа";
$MESS['MIBOK_PAY_YOOKASSA_TEXT_INPUT_AMOUNT_DEF'] = "К оплате";
$MESS['MIBOK_PAY_YOOKASSA_TEXT_BUTTON_DEF'] = "Оплатить";
$MESS['MIBOK_PAY_YOOKASSA_USER_DATA'] = "Выводимые поля";

$MESS['MIBOK_PAY_YOOKASSA_USER_FIO'] = "Ваше имя";
$MESS['MIBOK_PAY_YOOKASSA_USER_PHONE'] = "Ваш телефон";
$MESS['MIBOK_PAY_YOOKASSA_USER_EMAIL'] = "Ваш email";
$MESS['MIBOK_PAY_YOOKASSA_USER_INN'] = "Ваш ИНН";


/*$MESS ['CP_BMS_IBLOCK_TYPE'] = "Тип информационного блока";
$MESS ['CP_BMS_IBLOCK_ID'] = "Код информационного блока";
$MESS ['CP_BMS_ID'] = "ID элемента для подсветки пункта меню";
$MESS ['CP_BMS_SECTION_URL'] = "URL, ведущий на страницу с содержимым раздела";
$MESS ['CP_BMS_DEPTH_LEVEL'] = "Сколько уровней вложенности выводить";
$MESS ['CP_BMS_IS_SEF'] = "Включить режим совместимости с поддержкой ЧПУ";
$MESS ['CP_BMS_SEF_BASE_URL'] = "Каталог ЧПУ (относительно корня сайта)";
$MESS ['CP_BMS_SECTION_PAGE_URL'] = "Шаблон URL, ведущий на страницу с содержимым раздела";
$MESS ['CP_BMS_DETAIL_PAGE_URL'] = "Шаблон URL, ведущий на страницу с элементом";*/
?>