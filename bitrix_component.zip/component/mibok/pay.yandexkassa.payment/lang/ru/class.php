<?
$MESS['MIBOK_PAY_NOT_FOUND'] = 'Модуль оплаты mibok.pay не установлен';
$MESS['MIBOK_PAY_DEMO_EXPIRED'] = 'Демо-режим модуля оплаты mibok.pay закончился';
$MESS['MIBOK_EMPTY_FIELD'] = 'Не все поля заполнены';
$MESS['MIBOK_ERROR_FORMAT_PHONE'] = 'Неверный формат номера телефона';
$MESS['MIBOK_ERROR_FORMAT_EMAIL'] = 'Неверный формат Email-адреса';
$MESS['MIBOK_ERROR_FORMAT_INN'] = 'Неверный формат ИНН';
$MESS['MIBOK_ERROR_SUM'] = 'Сумма не может быть равна нулю';
$MESS['MIBOK_ERROR_ITEM'] = 'Нет информации о товаре';
?>