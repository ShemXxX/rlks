<?
$MESS ['MIBOK_YOOKASSA_KASSA'] = "ЮKassa (ex-Яндекс.Касса)";
$MESS ['MIBOK_YOOKASSA_KASSA_NAME'] = "Форма оплаты (ЮKassa)";
$MESS ['MIBOK_YOOKASSA_KASSA_DESCRIPTION'] = "Выводит форму оплаты через ЮKassa";
$MESS ['MIBOK_CREATER'] = "Мибок";
?>