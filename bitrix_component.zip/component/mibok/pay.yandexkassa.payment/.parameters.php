<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

/*if(!CModule::IncludeModule("iblock"))
	return;

$arTypesEx = CIBlockParameters::GetIBlockTypes(Array("all"=>" "));

$arIBlocks=Array();
$db_iblock = CIBlock::GetList(Array("SORT"=>"ASC"), Array("SITE_ID"=>$_REQUEST["site"], "TYPE" => ($arCurrentValues["IBLOCK_TYPE"]!="all"?$arCurrentValues["IBLOCK_TYPE"]:"")));
while($arRes = $db_iblock->Fetch())
	$arIBlocks[$arRes["ID"]] = $arRes["NAME"];*/

$module_id = "mibok.pay";
if(!CModule::IncludeModule($module_id))
	return;

$shopID = \Bitrix\Main\Config\Option::get($module_id, 'yookassa_shop_id');
$arShop = MibokPay::deviderShop($shopID);
$arShopIDS = false;
if(is_array($arShop))
{
    foreach ($arShop as $item)
        $arShopIDS[$item] = $item;
}
$arSource = [
    'def' => GetMessage('MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT_DEFAULT'),
    'field' => GetMessage('MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT_FIELD'),
//    'iblock' => GetMessage('MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT_IBLOCK'),
//    'request' => GetMessage('MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT_REQUEST'),
    ];

$arUserFields = [
    'FIO' => GetMessage('MIBOK_PAY_YOOKASSA_USER_FIO'),
    'PHONE' => GetMessage('MIBOK_PAY_YOOKASSA_USER_PHONE'),
    'EMAIL' => GetMessage('MIBOK_PAY_YOOKASSA_USER_EMAIL'),
    'INN' => GetMessage('MIBOK_PAY_YOOKASSA_USER_INN'),
];

$arComponentParameters = array(
	"GROUPS" => array(
        "USER_FIELDS" => array(
			"SORT" => 400,
			"NAME" => GetMessage("MIBOK_PAY_YOOKASSA_USER"),
		),
        "SIGN_FIELDS" => array(
			"SORT" => 500,
			"NAME" => GetMessage("MIBOK_PAY_YOOKASSA_SIGN"),
		),
	),
	"PARAMETERS" => array(
		"USER_CONSENT" => array(),
        "SHOP_ID" => Array(
			"PARENT" => "BASE",
			"NAME" => GetMessage("MIBOK_PAY_YOOKASSA_SHOP_ID"),
			"TYPE"=>"LIST",
			"VALUES" => $arShopIDS,
			"MULTIPLE"=>"N",
			"ADDITIONAL_VALUES"=>"N",
			"REFRESH" => "Y",
		),
        "SOURCE_PRODUCT" => Array(
			"PARENT" => "DATA_SOURCE",
			"NAME" => GetMessage("MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT"),
			"TYPE"=>"LIST",
			"VALUES" => $arSource,
			"MULTIPLE"=>"N",
			"ADDITIONAL_VALUES"=>"N",
			"REFRESH" => "Y",
		),
        "USER_DATA" => Array(
			"PARENT" => "USER_FIELDS",
			"NAME" => GetMessage("MIBOK_PAY_YOOKASSA_USER_DATA"),
			"TYPE"=>"LIST",
			"VALUES" => $arUserFields,
			"MULTIPLE"=>"Y",
			"ADDITIONAL_VALUES"=>"N",
		),
        "TEXT_BUTTON" => Array(
			"PARENT" => "SIGN_FIELDS",
			"NAME" => GetMessage("MIBOK_PAY_YOOKASSA_TEXT_BUTTON"),
			"TYPE" => "STRING",
			"DEFAULT" => GetMessage("MIBOK_PAY_YOOKASSA_TEXT_BUTTON_DEF"),
		),
	),
);


switch($arCurrentValues["SOURCE_PRODUCT"])
{
    case 'iblock': break;
    case 'request': break;
        
    case 'def':
    case 'field':
    default:
        $arComponentParameters["PARAMETERS"]["ITEM"] = array(
			"PARENT" => "DATA_SOURCE",
			"NAME" => GetMessage("MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT_ITEM"),
			"TYPE" => "STRING",
			"DEFAULT" => GetMessage("MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT_ITEM_DEF"),
		);
        $arComponentParameters["PARAMETERS"]["SUM"] = array(
			"PARENT" => "DATA_SOURCE",
			"NAME" => GetMessage("MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT_SUM"),
			"TYPE" => "STRING",
			"DEFAULT" => 1,
		);
        $arComponentParameters["PARAMETERS"]["CURR"] = array(
			"PARENT" => "DATA_SOURCE",
			"NAME" => GetMessage("MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT_CURR"),
			"TYPE" => "STRING",
			"DEFAULT" => GetMessage("MIBOK_PAY_YOOKASSA_SOURCE_PRODUCT_CURR_DEF"),
		);
        $arComponentParameters["PARAMETERS"]["TEXT_INPUT_PRODUCT"] = array(
			"PARENT" => "SIGN_FIELDS",
			"NAME" => GetMessage("MIBOK_PAY_YOOKASSA_TEXT_INPUT_PRODUCT"),
			"TYPE" => "STRING",
			"DEFAULT" => GetMessage("MIBOK_PAY_YOOKASSA_TEXT_INPUT_PRODUCT_DEF"),
		);
        $arComponentParameters["PARAMETERS"]["TEXT_INPUT_AMOUNT"] = array(
			"PARENT" => "SIGN_FIELDS",
			"NAME" => GetMessage("MIBOK_PAY_YOOKASSA_TEXT_INPUT_AMOUNT"),
			"TYPE" => "STRING",
			"DEFAULT" => GetMessage("MIBOK_PAY_YOOKASSA_TEXT_INPUT_AMOUNT_DEF"),
		);
        break;
}

if($arCurrentValues["IS_SEF"] === "Y")
{
	unset($arComponentParameters["PARAMETERS"]["ID"]);
	unset($arComponentParameters["PARAMETERS"]["SECTION_URL"]);
}
else
{
	unset($arComponentParameters["PARAMETERS"]["SEF_BASE_URL"]);
	unset($arComponentParameters["PARAMETERS"]["DETAIL_PAGE_URL"]);
	unset($arComponentParameters["PARAMETERS"]["SECTION_PAGE_URL"]);
}
?>
