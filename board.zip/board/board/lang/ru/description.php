<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 17.09.2018
 * Time: 14:00
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['CSST_TEMPLATE_NAME'] = 'Универсальная, мультиязычная доска объявлений';
$MESS['CSST_TEMPLATE_DESC'] = '';