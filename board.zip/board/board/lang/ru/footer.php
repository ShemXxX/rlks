<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 11.10.2018
 * Time: 14:26
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
$MESS['TEMPLATE_FOOTER_COPYRIGHT'] = 'Платформа для доски объявлений';
$MESS['TEMPLATE_FOOTER_TURN_OFF_ADBLOCK'] = 'Пожалуйста, отключите AdBlock';