<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Application;
use Bitrix\Main\IO\File;
use Bitrix\Main\IO\Path;
use Bitrix\Main\Localization\Loc;

?>
</div>
<footer class="--base-padding _mb">
    <div class="delimiter"></div>
    <div class="row two-columns">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
            <?php
            if (File::isFileExists(
                Path::normalize(
                    Application::getDocumentRoot() . SITE_TEMPLATE_PATH . "/inc/lang/" . USER_LANG_PATH . "footer/footer_site_name.php"
                )
            )) {
                $APPLICATION->IncludeComponent(
                    "bitrix:main.include", "",
                    [
                        "AREA_FILE_SHOW" => "file",
                        "PATH" => SITE_TEMPLATE_PATH . "/inc/lang/" . USER_LANG_PATH . "footer/footer_site_name.php",
                        "EDIT_TEMPLATE" => "include_areas_template.php",
                        'MODE' => 'php'
                    ],
                    false
                );
            } else {
                $APPLICATION->IncludeComponent(
                    "bitrix:main.include", "",
                    [
                        "AREA_FILE_SHOW" => "file",
                        "PATH" => SITE_TEMPLATE_PATH . "/inc/footer/footer_site_name.php",
                        "EDIT_TEMPLATE" => "include_areas_template.php",
                        'MODE' => 'php'
                    ],
                    false
                );
            }
            ?>
            <? /*DON`T REMOVE OR HIDE THIS BLOCK!*/ ?>
            <span class="vendor-copyright">
                <a href="https://marketplace.1c-bitrix.ru/solutions/democontent2.board/" rel="nofollow" target="_blank"
				style="display: initial;">
                    <?php
                    /*
                     * Removing or hiding the product link is prohibited by the license agreement.
                     * In the event that you delete the link, you will lose the opportunity to receive technical support,
                     * and your license key will be blocked.
                     * You can get additional information by phone +7 (495) 005-23-76
                     */
                    /*DON`T REMOVE OR HIDE THIS!*/
                    echo Loc::getMessage('TEMPLATE_FOOTER_COPYRIGHT');
                    /*DON`T REMOVE OR HIDE THIS!*/
                    ?>
                </a>
            </span>
            <? /*DON`T REMOVE OR HIDE THIS BLOCK!*/ ?>
            <?php
            $APPLICATION->IncludeComponent('democontent2.board:top.languages', '', []);
            ?>
        </div>
        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
            <div class="row">
                <?php
                $APPLICATION->IncludeComponent(
	"bitrix:menu", 
	".default", 
	array(
		"ROOT_MENU_TYPE" => "bottom",
		"MENU_CACHE_TYPE" => "N",
		"MENU_CACHE_TIME" => "0",
		"MENU_CACHE_USE_GROUPS" => "Y",
		"MENU_CACHE_GET_VARS" => array(
		),
		"MAX_LEVEL" => "2",
		"CHILD_MENU_TYPE" => "left",
		"USE_EXT" => "Y",
		"ALLOW_MULTI_SELECT" => "N",
		"COMPONENT_TEMPLATE" => ".default",
		"DELAY" => "N"
	),
	false
);
                ?>
            </div>
        </div>
    </div>
</footer>
</main>
</div>
<script>
    BX.message({
        'site_dir': '<?=SITE_DIR?>',
        'current_page': '<?= $APPLICATION->GetCurPage(false) ?>',
        'turnOffAdBlock': '<?=Loc::getMessage('TEMPLATE_FOOTER_TURN_OFF_ADBLOCK')?>',
    });
</script>
<!--LiveInternet counter--><a href="https://www.liveinternet.ru/click"
target="_blank"><img id="licntC576" width="88" height="15" style="border:0" 
title="LiveInternet: показано число посетителей за сегодня"
src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAEALAAAAAABAAEAAAIBTAA7"
alt=""/></a><script>(function(d,s){d.getElementById("licntC576").src=
"https://counter.yadro.ru/hit?t26.6;r"+escape(d.referrer)+
((typeof(s)=="undefined")?"":";s"+s.width+"*"+s.height+"*"+
(s.colorDepth?s.colorDepth:s.pixelDepth))+";u"+escape(d.URL)+
";h"+escape(d.title.substring(0,150))+";"+Math.random()})
(document,screen)</script><!--/LiveInternet-->

<!-- Top.Mail.Ru counter -->
<script type="text/javascript">
var _tmr = window._tmr || (window._tmr = []);
_tmr.push({id: "3802877", type: "pageView", start: (new Date()).getTime()});
(function (d, w, id) {
  if (d.getElementById(id)) return;
  var ts = d.createElement("script"); ts.type = "text/javascript"; ts.async = true; ts.id = id;
  ts.src = "https://top-fwz1.mail.ru/js/code.js";
  var f = function () {var s = d.getElementsByTagName("script")[0]; s.parentNode.insertBefore(ts, s);};
  if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); }
})(document, window, "tmr-code");
</script>
<noscript><div><img src="https://top-fwz1.mail.ru/counter?id=3802877;js=na" style="position:absolute;left:-9999px;" alt="Top.Mail.Ru" /></div></noscript>
<!-- /Top.Mail.Ru counter -->

<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();
   for (var j = 0; j < document.scripts.length; j++) {if (document.scripts[j].src === r) { return; }}
   k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(95309327, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true,
        ecommerce:"dataLayer"
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/95309327" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<?php
if (File::isFileExists(
    Path::normalize(
        Application::getDocumentRoot() . SITE_TEMPLATE_PATH . "/inc/lang/" . USER_LANG_PATH . "footer/before_body.php"
    )
)) {
    $APPLICATION->IncludeComponent(
        "bitrix:main.include", "",
        [
            "AREA_FILE_SHOW" => "file",
            "PATH" => SITE_TEMPLATE_PATH . "/inc/lang/" . USER_LANG_PATH . "footer/before_body.php",
            "EDIT_TEMPLATE" => "include_areas_template.php",
            'MODE' => 'php'
        ],
        false
    );
} else {
    $APPLICATION->IncludeComponent(
        "bitrix:main.include", "",
        [
            "AREA_FILE_SHOW" => "file",
            "PATH" => SITE_TEMPLATE_PATH . "/inc/footer/before_body.php",
            "EDIT_TEMPLATE" => "include_areas_template.php",
            'MODE' => 'php'
        ],
        false
    );
}
?>
<script>$(document).ready(function() {
	//Показать управление страницами и активировать первую ссылку
$(".paging").show();
$(".paging a:first").addClass("active");
//Взять размер изображения, кол-во изображений, и далее определить размер "холста".
var imageWidth = $(".window").width();
var imageSum = $(".image_reel img").length;
var imageReelWidth = imageWidth * imageSum;
//Подстроить размер "холста" под новый размер
$(".image_reel").css({'width' : imageReelWidth});
//Функции
rotate = function(){
    var triggerID = $active.attr("rel") - 1; //Взять количество раз для прокрутки
    var image_reelPosition = triggerID * imageWidth; //Определить дистанцию для прокрутки

    $(".paging a").removeClass('active'); //Убрать все классы active
    $active.addClass('active'); //Добавить класс active

    //Анимация слайдера
    $(".image_reel").animate({
        left: -image_reelPosition
    }, 500 );

}; 
//Вращение и заддержка
rotateSwitch = function(){
    play = setInterval(function(){ //Задать таймер
        $active = $('.paging a.active').next(); 
        if ( $active.length === 0) {
            $active = $('.paging a:first'); //после последней - обратно на первую
        }
        rotate(); 
    }, 7000); //Время для прокрутки (7 секунд)
};

rotateSwitch(); 
//При наведении
$(".image_reel a").hover(function() {
    clearInterval(play); //прекратить смену слайдов
}, function() {
    rotateSwitch(); //продолжить
});	
//При нажатии
$(".paging a").click(function() {
    $active = $(this); 
//Сброс таймера
    clearInterval(play); //Прекратить смену слайдов
    rotateSwitch(); // Продожить
    rotate(); //Вызвать немедленно смену
    return false;
});
});</script>
</body>
</html>
