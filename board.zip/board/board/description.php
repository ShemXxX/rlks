<?
$arTemplate = array (
  'NAME' => 'Доска объявлений',
  'DESCRIPTION' => '',
  'SORT' => '',
  'TYPE' => '',
);
?>