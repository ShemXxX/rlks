<?php
/**
 * Date and Time: 03.08.2020, 10:05
 * Author: Ruslan Semagin
 * Company: PIXEL365
 * Web-site: https://pixel365.ru
 * Support: https://support.pixel365.ru
 * Email: pixel.365.24@gmail.com
 * Phone: +7 (495) 005-23-76
 * Skype: pixel365
 * Registered Product Copyright: https://www1.fips.ru/ofpstorage/Doc/PrEVM/RUNWPR/000/002/020/617/764/2020617764-00001/document.pdf
 * Product Page: https://marketplace.1c-bitrix.ru/solutions/board/
 * Product License Page: https://marketplace.1c-bitrix.ru/solutions/board/#tab-support-link
 * Use of this code is allowed only under the condition of full compliance with the terms of the license agreement, and only as part of the product.
 */

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$c = count($arResult);
if (!$c) {
    return;
}

if (function_exists('setFrameMode')) {
    $this->setFrameMode(true);
}

$strReturn = '<div class="breadcrumb">';
$strReturn .= '<ul itemscope itemtype="http://schema.org/BreadcrumbList">';

$i = 0;
foreach ($arResult as $k => $v) {
    $i++;

    if ($i == $c) {
        $strReturn .= '<li><span itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><span itemprop="item"><span itemprop="name">' . $v['TITLE'] . '</span></span><meta itemprop="position" content="' . $i . '" /></span></span></li>';
    } else {
        $strReturn .= '<li><span itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a href="' . $v['LINK'] . '" itemprop="item"><span itemprop="name">' . $v['TITLE'] . '</span></a><meta itemprop="position" content="' . $i . '" /></span></span></li>';
    }
}
$strReturn .= '</ul>';
$strReturn .= '</div>';

return $strReturn;
