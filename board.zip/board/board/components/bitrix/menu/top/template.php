<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (!count($arResult)) {
    return;
}

if (method_exists($this, 'setFrameMode')) {
    $this->setFrameMode(true);
}
$i = 0;
?>
<section>
    <?php
    foreach ($arResult as $item) {
        ?>
        <div class="side-menu__item">
            <a href="<?= $item['LINK'] ?>"><?= $item['TEXT'] ?></a>
        </div>
        <?php
    }
    ?>
</section>