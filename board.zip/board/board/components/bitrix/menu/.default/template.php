<?php
/**
 * User: Ruslan Semagin
 * Email: pixel.365.24@gmail.com
 * Date: 10.10.2018
 * Time: 18:30
 * Product Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/
 * License Page: http://marketplace.1c-bitrix.ru/solutions/democontent2.board/#tab-support-link
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (!count($arResult)) {
    return;
}

if (method_exists($this, 'setFrameMode')) {
    $this->setFrameMode(true);
}

$menu = array();
foreach ($arResult as $menuItem) {
    switch (intval($menuItem['DEPTH_LEVEL'])) {
        case 1:
            $menu[$menuItem['CHAIN'][0]] = array(
                'url' => $menuItem['LINK'],
                'items' => array()
            );
            break;
        case 2:
            $menu[$menuItem['CHAIN'][0]]['items'][$menuItem['TEXT']] = $menuItem['LINK'];
            break;
    }
}


$i = 0;
foreach ($menu as $k => $v) {
    $i++;
    ?>
    <div class="col-md-4 col-sm-12">
        <div class="footer-links">
            <div class="title"><?= $k ?></div>
            <div class="items">
                <?php
                foreach ($v['items'] as $k_ => $v_) {
                    ?>
                    <a href="<?= $v_ ?>"><?= $k_ ?></a>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>
    <?php
    if ($i == 3) {
        break;
    }
}