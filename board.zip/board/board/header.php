<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ModuleManager;
use Bitrix\Main\Page\Asset;
use Bitrix\Main\IO\File;
use Bitrix\Main\IO\Path;
use Bitrix\Main\Application;
use Bitrix\Main\Context;
use Bitrix\Main\IO\InvalidPathException;

$logoPath = Option::get(DBOARD, 'logo_path');
$cssMode = Option::get(DBOARD, 'css_mode');

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="<?= SITE_CHARSET ?>">
    <meta name="viewport" content="initial-scale=1.0, width=device-width">
    <title><? $APPLICATION->ShowTitle() ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="Accept-CH" content="DPR, Viewport-Width, Width"/>
    <meta name="robots" content="index, follow"/>
    <meta name="Mediapartners-Google" content="index, follow">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="format-detection" content="telephone=no">
    <meta name="yandex-verification" content="8bee00f9677411f3" />
	
    <?php
    if (!$cssMode) {
        if (File::isFileExists(Path::normalize(Application::getDocumentRoot() . SITE_TEMPLATE_PATH . '/app/css/main.css'))) {
            $mainCss = File::getFileContents(Path::normalize(Application::getDocumentRoot() . SITE_TEMPLATE_PATH . '/app/css/main.css'));
            echo Asset::getInstance()->insertCss($mainCss, true, true);
            unset($mainCss);
        }
    }

    $APPLICATION->ShowHead();

    if ($cssMode) {
        Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . '/app/css/main.css');
    }

    Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . '/app/css/app.css');
    Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . '/app/css/media.css');
    Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/jquery-3.4.1.min.js');
    Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/fotorama.min.js');
    Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/slideout.min.js');
    Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/ads.min.js');
    Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/mask.js');
    Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/app.min.js');
    Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/decode.js');

    try {
        if (File::isFileExists(Path::normalize(
            Application::getDocumentRoot() . SITE_TEMPLATE_PATH . '/app/css/custom.css'
        ))) {
            Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . '/app/css/custom.css');
        }
    } catch (InvalidPathException $e) {
    }

    try {
        if (File::isFileExists(Path::normalize(
            Application::getDocumentRoot() . SITE_TEMPLATE_PATH . '/app/js/custom.js'
        ))) {
            Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/app/js/custom.js');
        }
    } catch (InvalidPathException $e) {
    }

    if (File::isFileExists(
        Path::normalize(
            Application::getDocumentRoot() . SITE_TEMPLATE_PATH . "/inc/lang/" . USER_LANG_PATH . "header/counters.php"
        )
    )) {
        $APPLICATION->IncludeComponent(
            "bitrix:main.include", "",
            [
                "AREA_FILE_SHOW" => "file",
                "PATH" => SITE_TEMPLATE_PATH . "/inc/lang/" . USER_LANG_PATH . "header/counters.php",
                "EDIT_TEMPLATE" => "include_areas_template.php",
                'MODE' => 'php'
            ],
            false
        );
    } else {
        $APPLICATION->IncludeComponent(
            "bitrix:main.include", "",
            [
                "AREA_FILE_SHOW" => "file",
                "PATH" => SITE_TEMPLATE_PATH . "/inc/header/counters.php",
                "EDIT_TEMPLATE" => "include_areas_template.php",
                'MODE' => 'php'
            ],
            false
        );
    }

    CJSCore::Init(["fx"]);
    ?>
</head>
<body>


<?php
if ($USER->IsAuthorized()) {
    $APPLICATION->ShowPanel();
    $APPLICATION->IncludeComponent('democontent2.board:socket.io', '', []);
}

/** sgraf logout component start */
$APPLICATION->IncludeComponent(
  "decode:user.logout", "",
  array(),
  false
);
/** sgraf logout component end */

if (File::isFileExists(
    Path::normalize(
        Application::getDocumentRoot() . SITE_TEMPLATE_PATH . "/inc/lang/" . USER_LANG_PATH . "header/after_body.php"
    )
)) {
    $APPLICATION->IncludeComponent(
        "bitrix:main.include", "",
        [
            "AREA_FILE_SHOW" => "file",
            "PATH" => SITE_TEMPLATE_PATH . "/inc/lang/" . USER_LANG_PATH . "header/after_body.php",
            "EDIT_TEMPLATE" => "include_areas_template.php",
            'MODE' => 'php'
        ],
        false
    );
} else {
    $APPLICATION->IncludeComponent(
        "bitrix:main.include", "",
        [
            "AREA_FILE_SHOW" => "file",
            "PATH" => SITE_TEMPLATE_PATH . "/inc/header/after_body.php",
            "EDIT_TEMPLATE" => "include_areas_template.php",
            'MODE' => 'php'
        ],
        false
    );
}

?>
<div class="wrapper">
    <?php
    $APPLICATION->IncludeComponent('democontent2.board:menu', '', []);
    ?>
    <main id="panel">
        <div class="header">
            <div class="header-top">
                <div class="header-top__left">
                    <div class="menu-icon" data-v="<?= ModuleManager::getVersion(DBOARD) ?>">
                        <span class="menu-icon__item"></span>
                        <span class="menu-icon__item"></span>
                        <span class="menu-icon__item"></span> 
                    </div>
					<div class="menu-text"> Все категории</div>
                    <?php
                    $APPLICATION->IncludeComponent('democontent2.board:location', '', []);
                    ?>
                </div>
                <div class="header-top__right">
                    <?php
                    $APPLICATION->IncludeComponent("democontent2.board:top.menu", "template2", Array(
	
	),
	false
);
                    ?>
                </div>
            </div>
            <div class="delimiter"></div>
            <div class="header-bottom">
                <div class="header-bottom__content">
                    <a href="<?= SITE_DIR ?>" class="logo">
                        <?php
                        if (strlen($logoPath)) {
                            ?>
                            <img src="<?= $logoPath ?>" alt="">
                            <?php
                        } else {
                            ?>
                            <img src="https://via.placeholder.com/203x48" alt="">
                            <?php
                        }
                        ?>
                    </a>
                    <?php
                    $APPLICATION->IncludeComponent("democontent2.board:search", "board_poisk", Array(
	
	),
	false
);
                    ?>
                  
                  <?
                  if ($USER->IsAuthorized()) {
                  if (!CSite::InGroup( array(5) )) {
                    ?>
                    <a href="<?= SITE_DIR ?>user/create/" class="add">
                      <?= Loc::getMessage('HEADER_ADD') ?>
                    </a>
                  <?
                  }
                  }
                  ?>


                </div>
            </div>
        </div>
        <?php
        if (
            ($APPLICATION->GetCurPage() !== SITE_DIR)
            && (Context::getCurrent()->getRequest()->getRequestedPage() !== SITE_DIR . 'index.php')
            && !defined('ERROR_404')
        ) {
            ?>
            <div class="row --base-padding">
                <div class="col-xs-12">
                    <?php
                    $APPLICATION->IncludeComponent(
                        "bitrix:breadcrumb",
                        "",
                        [
                            "START_FROM" => "0",
                            "PATH" => "",
                            "SITE_ID" => Application::getInstance()->getContext()->getSite()
                        ]
                    );
                    ?>
                </div>
            </div>
            <?php
        }

        if (
            ($APPLICATION->GetCurPage() == SITE_DIR || Context::getCurrent()->getRequest()->getRequestedPage() == SITE_DIR . 'index.php')
            && !defined('ERROR_404')
        ) {
            ?>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="delimiter"></div>
                </div>
            </div>
            <?php
        }
        ?>
        <?php
        // Mark the main content row on the homepage so homepage-only layout
        // rules do not affect internal pages.
        $isHomePage = (
            ($APPLICATION->GetCurPage() === SITE_DIR)
            || (Context::getCurrent()->getRequest()->getRequestedPage() === SITE_DIR . 'index.php')
        ) && !defined('ERROR_404');
        ?>
        <div class="row --base-padding two-columns<?= $isHomePage ? ' home-layout' : '' ?>">
