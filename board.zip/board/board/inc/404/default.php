<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="not-found">
        <div class="title">404</div>
        <div class="content">Запрашиваемая страница не найдена или была удалена</div>
    </div>
</div>