<?$APPLICATION->IncludeComponent(
	"innova:slider", 
	".default", 
	array(
		"AUTOPLAY" => "true",
		"AUTOPLAY_SPEED" => "3000",
		"BTN_COLOR" => "#FFFFFF",
		"CACHE_TYPE" => "N",
		"COMPONENT_TEMPLATE" => ".default",
		"HEIGHT" => "460",
		"HEIGHT_MOBILE" => "150",
		"HIDE_TEXT" => "Y",
		"IBLOCK_ID" => "150",
		"SLIDER_COLOR" => "rgba(0, 0, 0, 0.6)",
		"SPEED" => "800",
		"STRETCH_TYPE" => "2",
		"TEXT_ALIGN" => "flex-start"
	),
	false
);?>