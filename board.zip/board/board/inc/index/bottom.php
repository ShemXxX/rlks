<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("");
?><p style="font-size:11pt">
	 «Рлакс» — это электронный каталог товаров,&nbsp;продавцов имеющих торговые помещения. В данном каталоге вы найдёте предложения действующих предпринимателей и компаний, которые официально ведут свою деятельность на территории&nbsp;&nbsp;в Ростове-на-Дону и Ростовской области.
</p>
 Присоединяйтесь к нам в:<br>
 <a href="https://t.me/rlaks">https://t.me/rlaks</a><br>
 <a href="https://vk.com/rlaks">https://vk.com/rlaks</a><br><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>