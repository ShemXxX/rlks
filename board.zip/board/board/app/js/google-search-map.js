$(document).ready(function () {
    if ($('#map').length > 0) {
        GoogleMapInit()
    }
});

function GoogleMapInit() {
    var mapOptions = {
            scrollwheel: false,
            zoomControl: true,
            mapTypeControl: false,
            zoom: 12,
            center: new google.maps.LatLng(locationLat, locationLong),

        },
        mapElement = document.getElementById('map'),
        map = new google.maps.Map(mapElement, mapOptions),
        markers = [],
        infoBubbles = [],
        picts = [];

    function popup(url, title, price, oldPrice, vip, premium) {
        var popup = '<div class="marker-popup">';
        popup += '<div class="pict-wrap">';
        popup += '<img class="marker-popup-img" src="" alt="">';
        popup += '</div>';
        popup += '<div class="desc">';
        popup += '<div class="title medium">' + title;
        popup += '</div>';
        popup += '<p class="labels">';
        if (vip) {
            popup += '<span class="label orange">' + vipTxt + '</span>';
        }
        if (premium) {
            popup += '<span class="label blue">' + premiumTxt + '</span>';
        }
        popup += '</p>';
        popup += '<div class="price ">';
        if (oldPrice) {
            popup += '<div class="old-price">' + oldPrice + '<span class="currency">' + currencyName + '</span></div>';
        }
        popup += price + '<span class="currency">' + currencyName + '</span>';
        popup += '</div>';
        popup += '</div><a href="' + url + '" class="lnk-abs" target="_blank"></a>';
        popup += '</div>';
        return popup;
    }

    function handleMarkerClick(marker, index) {
        for (var i = 0, len = infoBubbles.length; i < len; i++) {
            if (i != index) {
                infoBubbles[i].close(map, marker);
            } else {
                if (!infoBubbles[index].isOpen_) {
                    infoBubbles[index].open(map, marker);
                } else {
                    infoBubbles[index].close(map, marker);
                }
            }

        }
    }

    function addMarker(coordinates, url, icon, ttl, price, oldPrice, vip, premium, index) {
        var marker = new google.maps.Marker({
            position: coordinates,
            map: map,
            title: ttl,
            icon: icon
        });
        var contentString = popup(url, ttl, price, oldPrice, vip, premium);
        infoBubbles[index] = new InfoBubble({
            map: map,
            content: contentString,
            position: coordinates,
            shadowStyle: 0,
            borderRadius: 0,
            closeSrc: stpath + '/images/close.svg',
            padding: '0',
            backgroundColor: '#FFF',
            arrowSize: 15,
            borderWidth: 0,
            borderColor: '#FFF',
            arrowPosition: 50,
            backgroundClassName: 'phoney',
            arrowStyle: 2,
            minHeight: 300,
            maxHeight: 800
        });
        google.maps.event.addListener(marker, "click", function () {
            handleMarkerClick(marker, index);
            if (picts[index]) {
                $.ajax({
                    type: 'POST',
                    url: ajaxPath,
                    dataType: "json",
                    data: 'imageId=' + picts[index],
                    success: function (data) {
                        setTimeout(function () {
                            if (!data.error) {
                                $('.marker-popup-img').attr('src', data.result)
                            } else {
                                $('.marker-popup-img').closest('.pict-wrap').remove();
                            }
                        }, 100)
                    },
                    error: function (data) {
                    }
                });
            }
        });
        markers.push(marker);
    }

    if (mapItems.length > 0) {
        for (var i = 0, len = mapItems.length; i < len; i++) {
            var
                icon = (mapItems[i].color) ? 'https://maps.google.com/mapfiles/ms/icons/yellow-dot.png' : 'https://maps.google.com/mapfiles/ms/icons/red-dot.png',
                url = mapItems[i].url,
                ttl = mapItems[i].name,
                price = mapItems[i].price,
                oldPrice = (mapItems[i].oldPrice * 1 != 0) ? mapItems[i].oldPrice : 0,
                vip = mapItems[i].vip * 1,
                premium = mapItems[i].premium * 1,
                coordinates = new google.maps.LatLng(mapItems[i].lat, mapItems[i].long);
            picts[i] = mapItems[i].imageId;
            addMarker(coordinates, url, icon, ttl, price, oldPrice, vip, premium, i);
        }
        var markerCluster = new MarkerClusterer(map, markers, {imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m'});
    }
}