$(document).ready(function () {
    if (location.protocol === 'https:' && !navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            if (position.coords.latitude && position.coords.longitude) {
                if (typeof locationLat !== 'undefined') {
                    locationLat = position.coords.latitude,
                        locationLong = position.coords.longitude;
                }
            }
        });
    }
});
ymaps.ready(YandexMapInit);

function YandexMapInit() {
    var myMap = new ymaps.Map("yandex-map", {
        center: [__defaultLocation[0], __defaultLocation[1]],
        zoom: 12,
        controls: ['zoomControl', 'fullscreenControl']
    });
    mySearchControl = new ymaps.control.SearchControl({
        options: {
            noPlacemark: true
        }
    }),
        mySearchResults = new ymaps.GeoObjectCollection(null, {
            hintContentLayout: ymaps.templateLayoutFactory.createClass('$[properties.name]')
        });
    myMap.controls.add(mySearchControl);
    myMap.geoObjects.add(mySearchResults);
    myPlacemark = createPlacemark([__defaultLocation[0], __defaultLocation[1]]);
    getAddress([__defaultLocation[0], __defaultLocation[1]]);

    mySearchControl.events.add('resultselect', function (e) {
        console.log(1);
        var index = e.get('index');
        mySearchControl.getResult(index).then(function (res) {
            $('#map-location').val(res.geometry.getCoordinates());
            myPlacemark.geometry.setCoordinates(res.geometry.getCoordinates());
            getAddress(res.geometry.getCoordinates());
        });
    }).add('submit', function () {
        mySearchResults.removeAll();
    });
    myMap.events.add('click', function (e) {
        var coords = e.get('coords');
        $('#map-location').val(coords);
        if (myPlacemark) {
            myPlacemark.geometry.setCoordinates(coords);
        } else {
            myPlacemark = createPlacemark(coords);
            myMap.geoObjects.add(myPlacemark);
            myPlacemark.events.add('dragend', function () {
                getAddress(myPlacemark.geometry.getCoordinates());
            });
        }
        getAddress(coords);
    });
    $('.create-ads-container select[name="city"]').change(function () {
        var coords = __citiesCoordinates[$(this).val()];
        $('#map-location').val(coords);
        if (myPlacemark) {
            myPlacemark.geometry.setCoordinates(coords);
        } else {
            myPlacemark = createPlacemark(coords);
            myMap.geoObjects.add(myPlacemark);
            myPlacemark.events.add('dragend', function () {
                getAddress(myPlacemark.geometry.getCoordinates());
            });
        }
        getAddress(coords);
        myMap.panTo(coords, {flying: 1});
    });

    function createPlacemark(coords) {
        return new ymaps.Placemark(coords, {
            iconCaption: 'search...'
        }, {
            preset: 'islands#violetDotIconWithCaption',
            draggable: true
        });
    }

    function getAddress(coords) {
        myPlacemark.properties.set('iconCaption', 'search...');
        ymaps.geocode(coords).then(function (res) {
            var firstGeoObject = res.geoObjects.get(0);
            myPlacemark.properties
                .set({
                    iconCaption: [
                        firstGeoObject.getLocalities().length ? firstGeoObject.getLocalities() : firstGeoObject.getAdministrativeAreas(),
                        firstGeoObject.getThoroughfare() || firstGeoObject.getPremise()
                    ].filter(Boolean).join(', '),
                    hintContent: firstGeoObject.getAddressLine()
                });
        });
    }

    myMap.geoObjects.add(myPlacemark);
}