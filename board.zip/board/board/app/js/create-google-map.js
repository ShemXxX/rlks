$(document).ready(function () {
    if (location.protocol === 'https:' && !navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            if (position.coords.latitude && position.coords.longitude) {
                locationLat = position.coords.latitude,
                    locationLong = position.coords.longitude;
            }
        });
    }
    GoogleMapInit();
});
function GoogleMapInit() {
    var mapOptions = {
        zoom: 12,
        center: new google.maps.LatLng(__defaultLocation[0], __defaultLocation[1])
    };

    var mapElement = document.getElementById('google-map');
    var map = new google.maps.Map(mapElement, mapOptions);
    var markers = [];
    var marker = new google.maps.Marker({
        position: new google.maps.LatLng(__defaultLocation[0], __defaultLocation[1]),
        map: map
    });
    markers.push(marker);
    var geocoder = new google.maps.Geocoder();
    $('#search-map .btn').click(function (e) {
        e.preventDefault();
        if ($(this).closest('.search-map').find('input').val() != '') {
            geocodeAddress(geocoder, map);
        }
    });

    function geocodeAddress(geocoder, resultsMap) {
        var address = document.getElementById('map-address').value;
        geocoder.geocode({'address': address}, function (results, status) {
            if (status === 'OK') {
                removeMarkers();
                resultsMap.setCenter(results[0].geometry.location);
                $('#map-location').val(results[0].geometry.location.lat() +',' + results[0].geometry.location.lng());
                marker = new google.maps.Marker({
                    map: resultsMap,
                    position: results[0].geometry.location
                });
                markers.push(marker);
            } else {
                alert('Geocode was not successful for the following reason: ' + status);
            }
        });
    }

    google.maps.event.addListener(map, 'click', function (e) {
        var location = e.latLng;
        removeMarkers();
        $('#map-location').val(location.lat() + ',' + location.lng());
        map.panTo(location);
        marker = new google.maps.Marker({
            position: new google.maps.LatLng(location.lat(), location.lng()),
            map: map
        });
        markers.push(marker);
    });
    $('.create-ads-container select[name="city"]').change(function () {
        var coords = __citiesCoordinates[$(this).val()];
        $('#map-location').val(coords);
        removeMarkers();
        var location = new google.maps.LatLng(coords[0], coords[1]);
        map.panTo(location);
        marker = new google.maps.Marker({
            position: new google.maps.LatLng(coords[0], coords[1]),
            map: map
        });
        markers.push(marker);
    });


    function removeMarkers() {
        for (i = 0; i < markers.length; i++) {
            markers[i].setMap(null);
        }
        markers = [];
    }
}