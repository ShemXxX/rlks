$(function() {
    $(window).on('load resize', function() {
        var $width = $(window).width();

        if ($width < 768) {
            $mMenu = $(document).find('.inner-menu');

            $mMenu.removeClass("active");
            $mMenu.find('.title ').removeClass("active");
            $mMenu.find('.title__description').addClass('active');


        }
    });
});
