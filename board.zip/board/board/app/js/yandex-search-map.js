$(document).ready(function () {
    if ($('#map').length > 0) {
        ymaps.ready(YandexMapInit);
    }
});

function YandexMapInit() {
    var myMap = new ymaps.Map("map", {
            center: [locationLat, locationLong],
            zoom: 12,
            controls: ['zoomControl', 'fullscreenControl']
        }),
        clusterer = new ymaps.Clusterer({
            groupByCoordinates: false,
        }),
        picts = [],
        geoObjects = [];

    function popup(url, title, price, oldPrice, imgPath, vip, premium) {
        var popup = '<div class="marker-popup">';
        popup += '<div class="pict-wrap" style="height: 190px;">';
        popup += '<img id="marker-popup-img" src="" data-src="' + imgPath + '" alt="">';
        popup += '</div>';
        popup += '<div class="desc">';
        popup += '<div class="title medium">' + title;
        popup += '</div>';
        popup += '<p class="labels">';
        if (vip) {
            popup += '<span class="label orange">' + vipTxt + '</span>';
        }
        if (premium) {
            popup += '<span class="label blue">' + premiumTxt + '</span>';
        }
        popup += '</p>';
        popup += '<div class="price ">';
        if (oldPrice) {
            popup += '<div class="old-price">' + oldPrice + '<span class="currency">' + currencyName + '</span></div>';
        }
        popup += price + '<span class="currency">' + currencyName + '</span>';
        popup += '</div>';
        popup += '</div><a href="' + url + '" class="lnk-abs" target="_blank"></a>';
        popup += '</div>';
        return popup;
    }

    if (mapItems.length > 0) {
        for (var i = 0, len = mapItems.length; i < len; i++) {
            var color = (mapItems[i].color) ? '#FF9800' : '#1E98FF',
                url = mapItems[i].url,
                ttl = mapItems[i].name,
                price = mapItems[i].price,
                oldPrice = (mapItems[i].oldPrice * 1 != 0) ? mapItems[i].oldPrice : 0,
                vip = mapItems[i].vip * 1,
                premium = mapItems[i].premium * 1,
                imgPath = mapItems[i].imageId * 1;
            geoObjects[i] = new ymaps.Placemark(
                [mapItems[i].lat, mapItems[i].long],
                {
                    hintContent: ttl,
                    balloonContent: popup(url, ttl, price, oldPrice, imgPath, vip, premium),
                },
                {
                    balloonShadow: false,
                    openEmptyBalloon: true,
                    iconColor: color
                });

            geoObjects[i].events.add('balloonopen', function (e) {
                var imgPath = +$('#marker-popup-img').data('src');
                if (imgPath) {
                    if (picts[imgPath] !== undefined) {
                        $('#marker-popup-img').attr('src', picts[imgPath]);
                    } else {
                        $.ajax({
                            type: 'POST',
                            url: ajaxPath,
                            dataType: "json",
                            data: 'imageId=' + imgPath,
                            success: function (data) {
                                if (!data.error) {
                                    $('#marker-popup-img').attr('src', data.result);
                                    picts[imgPath] = data.result;
                                }
                            },
                            error: function (data) {
                            }
                        });
                    }

                } else {
                    $('#marker-popup-img').closest('.pict-wrap').remove();
                }
            });
        }
    }
    clusterer.add(geoObjects);
    myMap.geoObjects.add(clusterer);
}