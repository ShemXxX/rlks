$(document).ready(function () {
    var e = document.createElement("div");
    e.id = "oSJAZnU9Qf1QF7ozxMHACrsNJ";
    e.style.display = "none";
    document.getElementsByTagName('body')[0].appendChild(e);
});
