$(document).ready(function () {
    if ($('#map-container').length > 0) {
        GoogleMapInit()
    }
});
function GoogleMapInit() {
    var mapOptions = {
        zoom: 16,
        center: new google.maps.LatLng(locationLat, locationLong),
    };

    var mapElement = document.getElementById('google-map');
    var map = new google.maps.Map(mapElement, mapOptions);
    var wellCircle = new google.maps.Circle({
        strokeColor: '#0078FF',
        strokeOpacity: 0.8,
        strokeWeight: 2,
        fillColor: '#0078FF',
        fillOpacity: 0.35,
        map: map,
        radius: 50,
        center: new google.maps.LatLng(locationLat, locationLong)
    });
    wellCircle = new google.maps.Circle({
        strokeColor: '#0078FF',
        strokeOpacity: 0.8,
        strokeWeight: 2,
        fillColor: '#0078FF',
        map: map,
        radius: 10,
        center: new google.maps.LatLng(locationLat, locationLong)
    });
}