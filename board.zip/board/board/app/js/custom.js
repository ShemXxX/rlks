(function ($) {
    'use strict';

    function resizeProductFotoramas() {
        $('.rluks-home-products .items-list .fotorama').each(function () {
            var $fotorama = $(this);
            var fotorama = $fotorama.data('fotorama');
            var $image = $fotorama.closest('.image');

            if (!fotorama || !$image.length) {
                return;
            }

            var width = Math.round($image.innerWidth());

            if (width > 0) {
                $fotorama.attr({
                    'data-width': '100%',
                    'data-height': '240px',
                    'data-maxheight': '240px'
                });

                fotorama.setOptions({
                    width: width,
                    height: 240,
                    maxheight: 240
                });

                fotorama.resize({
                    width: width,
                    height: 240
                }, 0);
            }
        });
    }

    var resizeTimer = null;

    function scheduleResize(delay) {
        clearTimeout(resizeTimer);

        resizeTimer = setTimeout(
            resizeProductFotoramas,
            typeof delay === 'number' ? delay : 0
        );
    }

    $(window).on('load resize orientationchange', function () {
        scheduleResize(50);
    });

    // Штатный обработчик сначала создаёт новую галерею.
    // Затем этот обработчик задаёт ей нужные размеры.
    $(document).on(
        'mouseover',
        '.rluks-home-products .images .nav a.item',
        function () {
            scheduleResize(0);
        }
    );

    $(function () {
        scheduleResize(50);
        setTimeout(resizeProductFotoramas, 250);
        setTimeout(resizeProductFotoramas, 600);
    });

})(jQuery);