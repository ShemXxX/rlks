//LAZY
!function (a, b) {
    var c = b(a, a.document, Date);
    a.lazySizes = c, "object" == typeof module && module.exports && (module.exports = c)
}("undefined" != typeof window ? window : {}, function (a, b, c) {
    "use strict";
    var d, e;
    if (function () {
        var b, c = {
            lazyClass: "lazyload",
            loadedClass: "lazyloaded",
            loadingClass: "lazyloading",
            preloadClass: "lazypreload",
            errorClass: "lazyerror",
            autosizesClass: "lazyautosizes",
            srcAttr: "data-src",
            srcsetAttr: "data-srcset",
            sizesAttr: "data-sizes",
            minSize: 40,
            customMedia: {},
            init: !0,
            expFactor: 1.5,
            hFac: .8,
            loadMode: 2,
            loadHidden: !0,
            ricTimeout: 0,
            throttleDelay: 125
        };
        e = a.lazySizesConfig || a.lazysizesConfig || {};
        for (b in c) b in e || (e[b] = c[b])
    }(), !b || !b.getElementsByClassName) return {
        init: function () {
        }, cfg: e, noSupport: !0
    };
    var f = b.documentElement, g = a.HTMLPictureElement, h = "addEventListener", i = "getAttribute", j = a[h].bind(a),
        k = a.setTimeout, l = a.requestAnimationFrame || k, m = a.requestIdleCallback, n = /^picture$/i,
        o = ["load", "error", "lazyincluded", "_lazyloaded"], p = {}, q = Array.prototype.forEach, r = function (a, b) {
            return p[b] || (p[b] = new RegExp("(\\s|^)" + b + "(\\s|$)")), p[b].test(a[i]("class") || "") && p[b]
        }, s = function (a, b) {
            r(a, b) || a.setAttribute("class", (a[i]("class") || "").trim() + " " + b)
        }, t = function (a, b) {
            var c;
            (c = r(a, b)) && a.setAttribute("class", (a[i]("class") || "").replace(c, " "))
        }, u = function (a, b, c) {
            var d = c ? h : "removeEventListener";
            c && u(a, b), o.forEach(function (c) {
                a[d](c, b)
            })
        }, v = function (a, c, e, f, g) {
            var h = b.createEvent("Event");
            return e || (e = {}), e.instance = d, h.initEvent(c, !f, !g), h.detail = e, a.dispatchEvent(h), h
        }, w = function (b, c) {
            var d;
            !g && (d = a.picturefill || e.pf) ? (c && c.src && !b[i]("srcset") && b.setAttribute("srcset", c.src), d({
                reevaluate: !0,
                elements: [b]
            })) : c && c.src && (b.src = c.src)
        }, x = function (a, b) {
            return (getComputedStyle(a, null) || {})[b]
        }, y = function (a, b, c) {
            for (c = c || a.offsetWidth; c < e.minSize && b && !a._lazysizesWidth;) c = b.offsetWidth, b = b.parentNode;
            return c
        }, z = function () {
            var a, c, d = [], e = [], f = d, g = function () {
                var b = f;
                for (f = d.length ? e : d, a = !0, c = !1; b.length;) b.shift()();
                a = !1
            }, h = function (d, e) {
                a && !e ? d.apply(this, arguments) : (f.push(d), c || (c = !0, (b.hidden ? k : l)(g)))
            };
            return h._lsFlush = g, h
        }(), A = function (a, b) {
            return b ? function () {
                z(a)
            } : function () {
                var b = this, c = arguments;
                z(function () {
                    a.apply(b, c)
                })
            }
        }, B = function (a) {
            var b, d = 0, f = e.throttleDelay, g = e.ricTimeout, h = function () {
                b = !1, d = c.now(), a()
            }, i = m && g > 49 ? function () {
                m(h, {timeout: g}), g !== e.ricTimeout && (g = e.ricTimeout)
            } : A(function () {
                k(h)
            }, !0);
            return function (a) {
                var e;
                (a = !0 === a) && (g = 33), b || (b = !0, e = f - (c.now() - d), e < 0 && (e = 0), a || e < 9 ? i() : k(i, e))
            }
        }, C = function (a) {
            var b, d, e = 99, f = function () {
                b = null, a()
            }, g = function () {
                var a = c.now() - d;
                a < e ? k(g, e - a) : (m || f)(f)
            };
            return function () {
                d = c.now(), b || (b = k(g, e))
            }
        }, D = function () {
            var g, m, o, p, y, D, F, G, H, I, J, K, L = /^img$/i, M = /^iframe$/i,
                N = "onscroll" in a && !/(gle|ing)bot/.test(navigator.userAgent), O = 0, P = 0, Q = 0, R = -1,
                S = function (a) {
                    Q--, (!a || Q < 0 || !a.target) && (Q = 0)
                }, T = function (a) {
                    return null == K && (K = "hidden" == x(b.body, "visibility")), K || !("hidden" == x(a.parentNode, "visibility") && "hidden" == x(a, "visibility"))
                }, U = function (a, c) {
                    var d, e = a, g = T(a);
                    for (G -= c, J += c, H -= c, I += c; g && (e = e.offsetParent) && e != b.body && e != f;) (g = (x(e, "opacity") || 1) > 0) && "visible" != x(e, "overflow") && (d = e.getBoundingClientRect(), g = I > d.left && H < d.right && J > d.top - 1 && G < d.bottom + 1);
                    return g
                }, V = function () {
                    var a, c, h, j, k, l, n, o, q, r, s, t, u = d.elements;
                    if ((p = e.loadMode) && Q < 8 && (a = u.length)) {
                        for (c = 0, R++; c < a; c++) if (u[c] && !u[c]._lazyRace) if (!N || d.prematureUnveil && d.prematureUnveil(u[c])) ba(u[c]); else if ((o = u[c][i]("data-expand")) && (l = 1 * o) || (l = P), r || (r = !e.expand || e.expand < 1 ? f.clientHeight > 500 && f.clientWidth > 500 ? 500 : 370 : e.expand, d._defEx = r, s = r * e.expFactor, t = e.hFac, K = null, P < s && Q < 1 && R > 2 && p > 2 && !b.hidden ? (P = s, R = 0) : P = p > 1 && R > 1 && Q < 6 ? r : O), q !== l && (D = innerWidth + l * t, F = innerHeight + l, n = -1 * l, q = l), h = u[c].getBoundingClientRect(), (J = h.bottom) >= n && (G = h.top) <= F && (I = h.right) >= n * t && (H = h.left) <= D && (J || I || H || G) && (e.loadHidden || T(u[c])) && (m && Q < 3 && !o && (p < 3 || R < 4) || U(u[c], l))) {
                            if (ba(u[c]), k = !0, Q > 9) break
                        } else !k && m && !j && Q < 4 && R < 4 && p > 2 && (g[0] || e.preloadAfterLoad) && (g[0] || !o && (J || I || H || G || "auto" != u[c][i](e.sizesAttr))) && (j = g[0] || u[c]);
                        j && !k && ba(j)
                    }
                }, W = B(V), X = function (a) {
                    var b = a.target;
                    if (b._lazyCache) return void delete b._lazyCache;
                    S(a), s(b, e.loadedClass), t(b, e.loadingClass), u(b, Z), v(b, "lazyloaded")
                }, Y = A(X), Z = function (a) {
                    Y({target: a.target})
                }, $ = function (a, b) {
                    try {
                        a.contentWindow.location.replace(b)
                    } catch (c) {
                        a.src = b
                    }
                }, _ = function (a) {
                    var b, c = a[i](e.srcsetAttr);
                    (b = e.customMedia[a[i]("data-media") || a[i]("media")]) && a.setAttribute("media", b), c && a.setAttribute("srcset", c)
                }, aa = A(function (a, b, c, d, f) {
                    var g, h, j, l, m, p;
                    (m = v(a, "lazybeforeunveil", b)).defaultPrevented || (d && (c ? s(a, e.autosizesClass) : a.setAttribute("sizes", d)), h = a[i](e.srcsetAttr), g = a[i](e.srcAttr), f && (j = a.parentNode, l = j && n.test(j.nodeName || "")), p = b.firesLoad || "src" in a && (h || g || l), m = {target: a}, s(a, e.loadingClass), p && (clearTimeout(o), o = k(S, 2500), u(a, Z, !0)), l && q.call(j.getElementsByTagName("source"), _), h ? a.setAttribute("srcset", h) : g && !l && (M.test(a.nodeName) ? $(a, g) : a.src = g), f && (h || l) && w(a, {src: g})), a._lazyRace && delete a._lazyRace, t(a, e.lazyClass), z(function () {
                        var b = a.complete && a.naturalWidth > 1;
                        p && !b || (b && s(a, "ls-is-cached"), X(m), a._lazyCache = !0, k(function () {
                            "_lazyCache" in a && delete a._lazyCache
                        }, 9)), "lazy" == a.loading && Q--
                    }, !0)
                }), ba = function (a) {
                    if (!a._lazyRace) {
                        var b, c = L.test(a.nodeName), d = c && (a[i](e.sizesAttr) || a[i]("sizes")), f = "auto" == d;
                        (!f && m || !c || !a[i]("src") && !a.srcset || a.complete || r(a, e.errorClass) || !r(a, e.lazyClass)) && (b = v(a, "lazyunveilread").detail, f && E.updateElem(a, !0, a.offsetWidth), a._lazyRace = !0, Q++, aa(a, b, f, d, c))
                    }
                }, ca = C(function () {
                    e.loadMode = 3, W()
                }), da = function () {
                    3 == e.loadMode && (e.loadMode = 2), ca()
                }, ea = function () {
                    if (!m) {
                        if (c.now() - y < 999) return void k(ea, 999);
                        m = !0, e.loadMode = 3, W(), j("scroll", da, !0)
                    }
                };
            return {
                _: function () {
                    y = c.now(), d.elements = b.getElementsByClassName(e.lazyClass), g = b.getElementsByClassName(e.lazyClass + " " + e.preloadClass), j("scroll", W, !0), j("resize", W, !0), j("pageshow", function (a) {
                        if (a.persisted) {
                            var c = b.querySelectorAll("." + e.loadingClass);
                            c.length && c.forEach && l(function () {
                                c.forEach(function (a) {
                                    a.complete && ba(a)
                                })
                            })
                        }
                    }), a.MutationObserver ? new MutationObserver(W).observe(f, {
                        childList: !0,
                        subtree: !0,
                        attributes: !0
                    }) : (f[h]("DOMNodeInserted", W, !0), f[h]("DOMAttrModified", W, !0), setInterval(W, 999)), j("hashchange", W, !0), ["focus", "mouseover", "click", "load", "transitionend", "animationend"].forEach(function (a) {
                        b[h](a, W, !0)
                    }), /d$|^c/.test(b.readyState) ? ea() : (j("load", ea), b[h]("DOMContentLoaded", W), k(ea, 2e4)), d.elements.length ? (V(), z._lsFlush()) : W()
                }, checkElems: W, unveil: ba, _aLSL: da
            }
        }(), E = function () {
            var a, c = A(function (a, b, c, d) {
                var e, f, g;
                if (a._lazysizesWidth = d, d += "px", a.setAttribute("sizes", d), n.test(b.nodeName || "")) for (e = b.getElementsByTagName("source"), f = 0, g = e.length; f < g; f++) e[f].setAttribute("sizes", d);
                c.detail.dataAttr || w(a, c.detail)
            }), d = function (a, b, d) {
                var e, f = a.parentNode;
                f && (d = y(a, f, d), e = v(a, "lazybeforesizes", {
                    width: d,
                    dataAttr: !!b
                }), e.defaultPrevented || (d = e.detail.width) && d !== a._lazysizesWidth && c(a, f, e, d))
            }, f = function () {
                var b, c = a.length;
                if (c) for (b = 0; b < c; b++) d(a[b])
            }, g = C(f);
            return {
                _: function () {
                    a = b.getElementsByClassName(e.autosizesClass), j("resize", g)
                }, checkElems: g, updateElem: d
            }
        }(), F = function () {
            !F.i && b.getElementsByClassName && (F.i = !0, E._(), D._())
        };
    return k(function () {
        e.init && F()
    }), d = {cfg: e, autoSizer: E, loader: D, init: F, uP: w, aC: s, rC: t, hC: r, fire: v, gW: y, rAF: z}
});

var lead_allow = false, lead_warn = '', ads_block = null, this_document = this, is_scrolled = false, __cities = [],
    __categories = [];
var _App = {
    parse_url: function () {
        let url = document.location.href;
        return url.split("?");
    },
    search_city: function () {
        $('input#search-city').on('keyup', function () {
            let word = $(this).val();
            if (word.trim().length > 0) {
                let filter = __cities.filter(function (item) {
                    return item.name.toLowerCase().includes(word.toLowerCase().trim());
                });
                _App.put_city(filter);
            } else {
                _App.put_city();
            }
        });
    },
    put_city: function (filter) {
        if (typeof filter === 'undefined') {
            filter = __cities;
        }
        let container = $('div#search-cities');
        if (filter.length < 1) {
            container.html('<div class="empty">' + BX.message('cities_not_found') + '</div>');
        } else {
            container.html('');
            container.append('<a href="' + BX.message('current_page') + '?skipCity=1">' + BX.message('any_city') + '</a>');
            for (let k in filter) {
                if (filter[k]['big']) {
                    container.append('<a href="' + BX.message('current_page') + '?changeCity=' + filter[k]['id'] + '" class="bold">' + filter[k]['name'] + '</a>');
                } else {
                    container.append('<a href="' + BX.message('current_page') + '?changeCity=' + filter[k]['id'] + '">' + filter[k]['name'] + '</a>');
                }
            }
        }
    },
    str_to_float: function (str) {
        var reg = /\d+([\.,]\d+)?/g,
            regP = /[\.,]/g,
            regN = /\d+/;
        if (str.match(reg)) {
            if (str.match(regP) && str.split(regP)[1].length < 2) {
                str = (str.split(regP)[1].length === 0) ? str.split(regP)[0] + '.' : (regN.test(str.split(regP)[1])) ? str : str.slice(0, -1);
            } else {
                str = str.match(reg);
                str = (str) ? str[0] : '';
            }
        } else {
            str = ''
        }
        return _App.strip_zeros(str);
    },
    strip_zeros: function (str) {
        if (str.charAt(0) === 0 || str.charAt(0) === '0') {
            return _App.str_to_float(str.substr(1))
        }
        return str
    },
    event_listeners: function () {
        window.addEventListener("orientationchange", function () {
            //TODO
        });

        window.addEventListener('scroll', function () {
            if (!is_scrolled) {
                if (pageYOffset > 0) {
                    is_scrolled = true;
                    //TODO
                }
            } else {
                //TODO
            }

            if (window.screen.availWidth >= 1024) {
                if (ads_block !== null) {
                    if (pageYOffset > 1200) {
                        //TODO
                    } else {
                        //TODO
                    }
                }
            }
        });
    },
    filter_indicator: function (obj) {
        if ($(obj).data('type') === 'dropdown') {
            let items = $(obj).find('input:checked');
            if (items.length) {
                $('#' + $(obj).data('type') + '-ind-' + $(obj).data('id')).addClass('active');
            } else {
                $('#' + $(obj).data('type') + '-ind-' + $(obj).data('id')).removeClass('active');
            }
        } else {
            let items = $(obj).find('input');
            if (items.length) {
                if (parseFloat($(items[0]).val()) || parseFloat($(items[1]).val())) {
                    $('#' + $(obj).data('type') + '-ind-' + $(obj).data('id')).addClass('active');
                } else {
                    $('#' + $(obj).data('type') + '-ind-' + $(obj).data('id')).removeClass('active');
                }
            } else {
                $('#' + $(obj).data('type') + '-ind-' + $(obj).data('id')).removeClass('active');
            }
        }
    },
    isDesktop: function () {
        return ($(window).width() > 991);
    },
    isTabletWide: function () {
        return ($(window).width() > 767 && $(window).width() < 992);
    },
    isTablet: function () {
        return ($(window).width() < 768 && $(window).width() < 479);
    },
    isPhoneWide: function () {
        return ($(window).width() < 480);
    }
};

$(document).ready(function () {
    if (!document.getElementById('oSJAZnU9Qf1QF7ozxMHACrsNJ')) {
        lead_allow = false;
        lead_warn = '<div class="notification">' + BX.message('turnOffAdBlock') + '</div>';
    }

    if ($(window).width() > 992) {
        $('.chat-container').height($(window).height() - 100)
    } else {
        $('.chat-container').height($(window).height() - 80)
    }

    $('.dialogs-window .item').click(function () {
        $('.messages-window').toggleClass('open');
    });

    $('.js-select').each(function () {
        var pl = $(this).attr('placeholder');
        var search = ($(this).hasClass('has-search')) ? '' : Infinity;
        $(this).select2({
            language: 'ru',
            placeholder: pl,
            minimumResultsForSearch: search
        });
    });

    //$('#menu').removeClass('--dn');
    var slideout = new Slideout({
        'panel': document.getElementById('panel'),
        'menu': document.getElementById('menu'),
        'padding': 256,
        'tolerance': 70,
        'duration': 50,
        'touch': false
    });

    $('.menu-icon').click(function () {
        $(this).toggleClass('--active');
        slideout.toggle();
    });

    _App.event_listeners();

    $('.filter .item .title').click(function () {
        let parent = $(this).parent();
        $(parent).toggleClass('active');
        _App.filter_indicator(parent);
    });

    // $('span.checkbox').click(function () {
    //     _App.filter_indicator($(this).parents()[4]);
    // });

    $('input[data-type="integer"]').on('keyup', function () {
        let $this = $(this);
        let $val = _App.str_to_float($this.val());
        $this.val($val);

        if (parseFloat($val)) {
            $($this.siblings()[0]).addClass('active');
        } else {
            $($this.siblings()[0]).removeClass('active');
        }
    });

    $('.inputs div div.close').click(function () {
        let $this = $(this);
        $($this.siblings()[0]).val('');
        $this.removeClass('active');
    });

    $('.detail-favourite, .favourite').click(function () {
        let icon = $(this).children()[0];
        if ($(this).hasClass('active')) {
            $(this).removeClass('active');
            $(icon).attr('data-wenk', 'Добавить в избранное');
            $(icon).html('<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><g><path fill-rule="evenodd" clip-rule="evenodd" d="M9 3.68624C9.8175 2.72624 11.07 2.11874 12.375 2.11874C14.685 2.11874 16.5 3.93374 16.5 6.24374C16.5 9.07642 13.9542 11.385 10.097 14.8826L10.0875 14.8912L9 15.8812L7.9125 14.8987L7.88289 14.8718C4.03697 11.3769 1.5 9.07149 1.5 6.24374C1.5 3.93374 3.315 2.11874 5.625 2.11874C6.93 2.11874 8.1825 2.72624 9 3.68624ZM9 13.8562L9.075 13.7812C12.645 10.5487 15 8.41124 15 6.24374C15 4.74374 13.875 3.61874 12.375 3.61874C11.22 3.61874 10.095 4.36124 9.705 5.38874H8.3025C7.905 4.36124 6.78 3.61874 5.625 3.61874C4.125 3.61874 3 4.74374 3 6.24374C3 8.41124 5.355 10.5487 8.925 13.7812L9 13.8562Z" fill="#4F4F4F"/></g></svg>');
        } else {
            $(this).addClass('active');
            $(icon).attr('data-wenk', 'Удалить из избранного');
            $(icon).html('<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><g><path d="M9 15.8812L7.9125 14.8912C4.05 11.3887 1.5 9.07874 1.5 6.24374C1.5 3.93374 3.315 2.11874 5.625 2.11874C6.93 2.11874 8.1825 2.72624 9 3.68624C9.8175 2.72624 11.07 2.11874 12.375 2.11874C14.685 2.11874 16.5 3.93374 16.5 6.24374C16.5 9.07874 13.95 11.3887 10.0875 14.8987L9 15.8812Z" fill="#EB5757"/></g></svg>');
        }
    });

    $('.menu-second').click(function () {
        let $this = $(this);
        let child = $this.children();
        if (child.length) {
            $this.toggleClass('active');
            $('#hidden-' + $this.attr('id')).toggleClass('active');
            return false;
        }
    });

    $('#change-city').click(function () {
        $('div#full').addClass('active');
        return false;
    });

    $('div#close').click(function () {
        $('div#full').remove();
    });

    $('a#change-city').click(function () {
        if (__cities.length > 0) {
            let svg = '<svg width="12" height="13" viewBox="0 0 12 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.5016 0.735004C11.9386 1.14094 11.9637 1.82428 11.5578 2.26128L2.31753 12.2087C1.91159 12.6457 1.22826 12.6709 0.791254 12.265C0.354251 11.859 0.329067 11.1757 0.735003 10.7387L9.97529 0.791253C10.3812 0.354251 11.0646 0.329067 11.5016 0.735004Z" fill="#333333"/><path d="M11.6153 12.1591C11.1826 12.5697 10.4991 12.5517 10.0885 12.1191L0.743297 2.27014C0.33275 1.83747 0.350689 1.1539 0.783363 0.743357C1.21604 0.33281 1.8996 0.350747 2.31015 0.783422L11.6554 10.6323C12.0659 11.065 12.048 11.7486 11.6153 12.1591Z" fill="#333333"/></svg>';
            let html = '<div id="full" class="full active"><div class="modal"><div class="window"><div id="close" class="close">' + svg + '</div><div class="title">' + BX.message('select_city') + '</div><div class="search"><input id="search-city" placeholder="' + BX.message('select_city_placeholder') + '"></div><div class="items" id="search-cities"></div></div><div class="bg"></div></div></div>';
            $('body').prepend(html);
            $('div#close').click(function () {
                $('div#full').remove();
            });
            _App.search_city();
            _App.put_city();
        } else {
            $.ajax({
                type: "POST",
                url: BX.message('locationAjaxPath'),
                dataType: "json",
                success: function (data) {
                    __cities = data['result'];
                    let svg = '<svg width="12" height="13" viewBox="0 0 12 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.5016 0.735004C11.9386 1.14094 11.9637 1.82428 11.5578 2.26128L2.31753 12.2087C1.91159 12.6457 1.22826 12.6709 0.791254 12.265C0.354251 11.859 0.329067 11.1757 0.735003 10.7387L9.97529 0.791253C10.3812 0.354251 11.0646 0.329067 11.5016 0.735004Z" fill="#333333"/><path d="M11.6153 12.1591C11.1826 12.5697 10.4991 12.5517 10.0885 12.1191L0.743297 2.27014C0.33275 1.83747 0.350689 1.1539 0.783363 0.743357C1.21604 0.33281 1.8996 0.350747 2.31015 0.783422L11.6554 10.6323C12.0659 11.065 12.048 11.7486 11.6153 12.1591Z" fill="#333333"/></svg>';
                    let html = '<div id="full" class="full active"><div class="modal"><div class="window"><div id="close" class="close">' + svg + '</div><div class="title">' + BX.message('select_city') + '</div><div class="search"><input id="search-city" placeholder="' + BX.message('select_city_placeholder') + '"></div><div class="items" id="search-cities"></div></div><div class="bg"></div></div></div>';
                    $('body').prepend(html);
                    $('div#close').click(function () {
                        $('div#full').remove();
                    });

                    _App.search_city();
                    _App.put_city();
                },
            });
        }

        return false;
    });

    $('svg#reset-city').click(function () {
        window.location.href = BX.message('current_page') + '?skipCity=1';
    });

    $('.write.review').click(function () {
        //TODO add review
        let $this = $(this);
        if ($this.data('auth')) {
            $this.remove();
            $('div.owner-add-review').toggleClass('active');
        } else {
            //TODO need auth
        }
    });

    $('.write.message').click(function () {
        $(this).remove();
        $('div#write-message-area').addClass('active');
    });

    $('.title.collapse').click(function () {
        let $this = $(this);
        $this.toggleClass('active');
        $this.parent().toggleClass('active');
        $this.parent().find('div.title__description').toggleClass('active');
    });

    $('.images .nav a.item').on('mouseover', function () {
        let $this = $(this);
        let imageArea = $($this.parents()[1]).siblings('a');
        let img = $this.data('img');
        if ($this.hasClass('more')) {
            $(imageArea).html('<div class="more">' + $this.data('text') + '</div><div class="fotorama _mb" data-width="100%" data-height="200px" data-maxheight="200px" data-allowfullscreen="false" data-loop="false"><div data-img="' + img + '"><div class="fotorama__blur" style="background:url(' + img + ')"></div></div></div>');
            imageArea.find('.fotorama').fotorama();
        } else {
            $(imageArea).html('<div class="fotorama _mb" data-width="100%" data-height="200px" data-maxheight="200px" data-allowfullscreen="false" data-loop="false"><div data-img="' + img + '"><div class="fotorama__blur" style="background:url(' + img + ')"></div></div></div>');
            imageArea.find('.fotorama').fotorama();
        }
    });

    $('.images .nav a.item.more').on('mouseout', function () {
        let $this = $(this);
        let imageArea = $($this.parents()[1]).siblings('a');
        imageArea.find('div.more').remove();
    });

    $('input#cat-filter').on('keyup', function () {
        __categories = BX.message('categoriesFilter');
        let $cat = $('div#categories-nav');
        let word = $(this).val();
        if (word.trim().length > 0) {
            let filter = __categories.filter(function (item) {
                return item.name.toLowerCase().includes(word.toLowerCase().trim());
            });
            if (filter.length) {
                $cat.html('');
                for (let k in filter) {
                    $cat.append('<div class="item"><a href="' + filter[k]['url'] + '">' + filter[k]['name'] + '</a></div>');
                }
            } else {
                $cat.html('');
            }
        } else {
            $cat.html('');
            for (let k in __categories) {
                $cat.append('<div class="item"><a href="' + __categories[k]['url'] + '">' + __categories[k]['name'] + '</a></div>');
            }
        }
    });
});


