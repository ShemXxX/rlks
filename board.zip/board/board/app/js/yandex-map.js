$(document).ready(function () {
    if ($('#map-container').length > 0) {
        ymaps.ready(YandexMapInit);
    }
});

function YandexMapInit() {
    var myMap = new ymaps.Map("yandex-map", {
        center: [locationLat, locationLong],
        zoom: 16,
        controls: ['zoomControl', 'fullscreenControl']
    });
    var myCircle = new ymaps.Circle([
        [locationLat, locationLong],
        50
    ], {}, {
        draggable: false,
        strokeColor: '#0078FF',
        strokeOpacity: 0.8,
        fillColor: '#0078FF',
        fillOpacity: 0.35,
        strokeWidth: 2
    });
    myMap.geoObjects.add(myCircle);

    myCircle = new ymaps.Circle([
        [locationLat, locationLong],
        10
    ], {}, {
        draggable: false,
        strokeColor: '#0078FF',
        strokeOpacity: 0.8,
        fillColor: '#0078FF',
        strokeWidth: 2
    });
    myMap.geoObjects.add(myCircle);
}